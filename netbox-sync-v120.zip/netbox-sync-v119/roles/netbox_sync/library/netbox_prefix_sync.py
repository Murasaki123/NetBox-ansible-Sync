#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Create the missing IP prefixes (networks) that follow from the collected interface addresses.

An interface address 10.1.2.5/24 implies the network 10.1.2.0/24. Each distinct network is created once, scoped to the
site, status active, in the global table. Nothing that already exists is changed or deleted: a prefix that NetBox
already has (in any VRF or site) is only counted. Host routes (/32, /128), loopback and link-local networks and the
default route are not prefixes and are skipped. Standard library only.
"""
from __future__ import annotations

import ipaddress
import json
import re
import ssl
import urllib.error
import urllib.parse
import urllib.request

try:  # Ansible is absent in the unit tests
    from ansible.module_utils.basic import AnsibleModule
except ImportError:  # pragma: no cover
    AnsibleModule = None

DOCUMENTATION = r"""
module: netbox_prefix_sync
short_description: Create the missing prefixes implied by interface addresses
options:
  netbox_url: {type: str, required: true}
  netbox_token: {type: str, required: true}
  validate_certs: {type: bool, default: true}
  site: {type: str, required: true, description: "Site name or slug."}
  addresses: {type: list, elements: dict, default: [], description: "Items with ip, prefix (mask length) and interface."}
  interface_zones: {type: dict, default: {}, description: "Security zone per interface name (optional)."}
  source_device: {type: str, default: "", description: "Device the addresses were collected from (goes into the comment)."}
"""

PAGE_LIMIT = 500
MAX_PAGES = 1000


class NetBoxApiError(RuntimeError):
    """Safe-to-print API error (never contains the token)."""


class Api:
    def __init__(self, base_url, token, verify=True, timeout=30, urlopen=None):
        self.base = base_url.rstrip("/")
        self._token = token
        self._timeout = timeout
        self._urlopen = urlopen or urllib.request.urlopen
        self._ctx = ssl.create_default_context() if verify else ssl._create_unverified_context()
        self._scheme = None  # "Token" (v1) or "Bearer" (v2), detected on first use

    @staticmethod
    def _detail(exc):
        try:
            return exc.read().decode("utf-8", "replace")[:300]
        except Exception:  # noqa: BLE001
            return ""

    def request(self, method, url, body=None):
        data = json.dumps(body).encode("utf-8") if body is not None else None
        shown = url[len(self.base):] if url.startswith(self.base) else url
        schemes = [self._scheme] if self._scheme else ["Token", "Bearer"]
        for idx, scheme in enumerate(schemes):
            req = urllib.request.Request(url, data=data, method=method, headers={
                "Authorization": "%s %s" % (scheme, self._token), "Accept": "application/json",
                "Content-Type": "application/json"})
            try:
                with self._urlopen(req, timeout=self._timeout, context=self._ctx) as resp:
                    raw = resp.read()
                self._scheme = scheme
                try:
                    return json.loads(raw.decode("utf-8")) if raw else None
                except ValueError as exc:
                    raise NetBoxApiError("%s %s: response is not valid JSON" % (method, shown)) from exc
            except urllib.error.HTTPError as exc:
                if exc.code in (401, 403) and idx < len(schemes) - 1:
                    continue
                raise NetBoxApiError(("%s %s: HTTP %s %s" % (method, shown, exc.code, self._detail(exc))).strip()) from exc
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                raise NetBoxApiError("%s %s: %s" % (method, shown, getattr(exc, "reason", exc))) from exc
        raise NetBoxApiError("%s %s: no response" % (method, shown))

    def get_all(self, path, params):
        url = "%s%s?%s" % (self.base, path, urllib.parse.urlencode(dict(params, limit=PAGE_LIMIT)))
        rows, seen = [], set()
        for _ in range(MAX_PAGES):
            if url in seen:
                raise NetBoxApiError("GET %s: pagination loop detected" % path)
            seen.add(url)
            page = self.request("GET", url)
            if not isinstance(page, dict) or not isinstance(page.get("results"), list):
                raise NetBoxApiError("GET %s: unexpected response (no 'results' list)" % path)
            rows.extend(page["results"])
            nxt = page.get("next")
            if not nxt:
                return rows
            parsed, base = urllib.parse.urlsplit(nxt), urllib.parse.urlsplit(self.base)
            url = urllib.parse.urlunsplit((base.scheme, base.netloc, parsed.path, parsed.query, ""))
        raise NetBoxApiError("GET %s: too many pages" % path)



def resolve_site(api, site):
    """Exactly one site whose name or slug equals `site` (case-insensitive, like the UI dropdown value)."""
    wanted = str(site).strip().casefold()
    sites = [r for r in api.get_all("/api/dcim/sites/", {}) if isinstance(r, dict)]  # a NetBox has few sites
    rows = [r for r in sites if wanted in (str(r.get("name", "")).casefold(), str(r.get("slug", "")).casefold())]
    if len(rows) != 1:
        raise NetBoxApiError("site %r: %d matches by name or slug among %d sites in NetBox (need exactly one; known: %s)" % (
            site, len(rows), len(sites), ", ".join("%s/%s" % (r.get("name"), r.get("slug")) for r in sites[:20])))
    return rows[0]["id"]



_VLAN_IF = re.compile(r"(?i)^(?:vlanif|vlan|vl|bvi)\s*-?(\d{1,4})$")
_SUBIF = re.compile(r"\.(\d{1,4})$")


def vlan_from_interface(name):
    """VLAN id that the interface name carries: Vlanif100 / vlan 100 -> 100, gi1/0/2.1010 / Eth-Trunk1.640 -> 1010 / 640."""
    text = str(name or "").strip()
    match = _VLAN_IF.match(text) or _SUBIF.search(text)
    if match and 1 <= int(match.group(1)) <= 4094:
        return int(match.group(1))
    return None


def build_comment(source_device, entries, zones=None):
    """Comment for a new prefix: where the address came from and which VLAN the interface name points to."""
    lines = []
    for entry in entries:
        where = ", ".join(x for x in (str(entry.get("interface") or ""), "%s/%s" % (entry["ip"], entry["prefix"])) if x)
        lines.append("Источник: %s (%s)" % (source_device, where) if source_device else "Источник: %s" % where)
    vlans = []
    for entry in entries:
        vlan = vlan_from_interface(entry.get("interface"))
        if vlan is not None and vlan not in vlans:
            vlans.append(vlan)
    if vlans:
        lines.append("Vlan: %s" % ", ".join(str(v) for v in vlans))
    by_name = {str(k).casefold(): str(v) for k, v in (zones or {}).items() if v}
    found = []
    for entry in entries:
        zone = by_name.get(str(entry.get("interface") or "").casefold())
        if zone and zone not in found:
            found.append(zone)
    if found:
        lines.append("Zone: %s" % ", ".join(found))
    return "\n".join(lines)


def group_by_network(addresses):
    """({network: [items]}, skipped notes) for items {"ip": "10.1.2.5", "prefix": "24", "interface": ...}."""
    nets, skipped = {}, []
    for item in addresses or []:
        try:
            net = ipaddress.ip_interface("%s/%s" % (item["ip"], item["prefix"])).network
        except (KeyError, TypeError, ValueError):
            skipped.append("%r: not a valid address/mask" % (item,))
            continue
        if net.prefixlen == 0 or net.prefixlen == net.max_prefixlen:
            continue  # default route or a host address: not a prefix
        if net.network_address.is_loopback or net.network_address.is_link_local:
            continue
        nets.setdefault(net, []).append(item)
    return nets, skipped


def networks_from(addresses):
    """(sorted distinct networks, skipped notes)."""
    grouped, skipped = group_by_network(addresses)
    return sorted(grouped, key=lambda n: (n.version, int(n.network_address), n.prefixlen)), skipped


def find_vlan(api, site_id, vid, cache):
    """NetBox id of the single VLAN `vid` of the site; None when there is none or the choice is ambiguous."""
    if vid not in cache:
        rows = [r for r in api.get_all("/api/ipam/vlans/", {"site_id": site_id, "vid": vid})
                if isinstance(r, dict) and r.get("vid") == vid and (r.get("site") or {}).get("id") == site_id]
        cache[vid] = rows[0]["id"] if len(rows) == 1 else None
    return cache[vid]


def prefix_vlan(api, site_id, entries, cache):
    """VLAN object for a prefix: only when all addresses of the network point to one VLAN id that exists once."""
    vids = {vlan_from_interface(e.get("interface")) for e in entries} - {None}
    if len(vids) != 1:
        return None
    return find_vlan(api, site_id, vids.pop(), cache)


def sync_prefixes(api, site, addresses, check_mode=False, source_device="", zones=None):
    out = {"changed": False, "created": [], "unchanged": 0, "skipped": [], "errors": [], "vlan_linked": 0}
    vlan_cache = {}
    grouped, _ = group_by_network(addresses)
    nets, out["skipped"] = networks_from(addresses)
    if not nets:
        return out
    site_id = resolve_site(api, site)
    for net in nets:
        text = str(net)
        try:
            found = [r for r in api.get_all("/api/ipam/prefixes/", {"prefix": text}) if isinstance(r, dict)]
            if any(r.get("prefix") == text for r in found):
                out["unchanged"] += 1
                continue
            if check_mode:
                out["created"].append(text)
                continue
            comment = build_comment(source_device, grouped.get(net, []), zones)
            vlan_id = prefix_vlan(api, site_id, grouped.get(net, []), vlan_cache)
            body = {"prefix": text, "status": "active", "comments": comment}
            if vlan_id is not None:
                body["vlan"] = vlan_id
            try:  # NetBox 4.2+ scopes a prefix to a site; older versions have a plain site field
                api.request("POST", api.base + "/api/ipam/prefixes/", dict(body, scope_type="dcim.site", scope_id=site_id))
            except NetBoxApiError as exc:
                if "scope" not in str(exc):
                    raise
                api.request("POST", api.base + "/api/ipam/prefixes/", dict(body, site=site_id))
            out["created"].append(text)
            out["vlan_linked"] += 1 if vlan_id is not None else 0
        except NetBoxApiError as exc:
            out["errors"].append("Prefix %s: %s" % (text, exc))
    out["changed"] = bool(out["created"])
    return out


def main():
    if AnsibleModule is None:  # pragma: no cover
        raise SystemExit("ansible is required")
    module = AnsibleModule(argument_spec=dict(
        netbox_url=dict(type="str", required=True),
        netbox_token=dict(type="str", required=True, no_log=True),
        validate_certs=dict(type="bool", default=True),
        site=dict(type="str", required=True),
        addresses=dict(type="list", elements="dict", default=[]),
        source_device=dict(type="str", default=""),
        interface_zones=dict(type="dict", default={}),
    ), supports_check_mode=True)
    p = module.params
    api = Api(p["netbox_url"], p["netbox_token"], verify=p["validate_certs"])
    try:
        out = sync_prefixes(api, p["site"], p["addresses"], module.check_mode, p["source_device"], p["interface_zones"])
    except NetBoxApiError as exc:
        module.fail_json(msg="Cannot synchronize prefixes of site %s: %s" % (p["site"], exc))
    for text in out["skipped"] + out["errors"]:
        module.warn(text)
    module.exit_json(created_count=len(out["created"]), **out)


if __name__ == "__main__":
    main()
