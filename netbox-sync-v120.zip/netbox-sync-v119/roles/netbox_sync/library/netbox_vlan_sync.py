#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Synchronize the VLANs of one site with a few API calls instead of one module call per VLAN.

A switch can report thousands of VLANs; one netbox.netbox.netbox_vlan call each took longer than the job
timeout. This module resolves the site once (exactly one match by name or slug), reads the site's VLANs once
(with pagination) and creates only the missing ones (vid + name), in bulk. Existing VLANs are never modified or
deleted; a VLAN with the same vid and another name is created next to it, as before. Errors of one chunk are
collected, the other chunks continue. Standard library only.
"""
from __future__ import annotations

import json
import ssl
import urllib.error
import urllib.parse
import urllib.request

try:  # Ansible is absent in the unit tests
    from ansible.module_utils.basic import AnsibleModule
except ImportError:  # pragma: no cover
    AnsibleModule = None

DOCUMENTATION = r"""
module: netbox_vlan_sync
short_description: Create the missing VLANs of a site in bulk
options:
  netbox_url: {type: str, required: true}
  netbox_token: {type: str, required: true}
  validate_certs: {type: bool, default: true}
  site: {type: str, required: true, description: "Site name or slug."}
  vlans: {type: list, elements: dict, default: [], description: "Items with vid and name."}
"""

CHUNK = 200
# What switches print for a VLAN that has no name (Eltex shows "-"). Such VLANs are not written to NetBox.
PLACEHOLDER_NAMES = {"-", "--", "n/a", "none", "null"}
PAGE_LIMIT = 500
MAX_PAGES = 1000


class NetBoxApiError(RuntimeError):
    """Safe-to-print API error (never contains the token)."""


class Api:
    def __init__(self, base_url, token, verify=True, timeout=30, urlopen=None):
        self.base = base_url.rstrip("/")
        self._token = token
        self._timeout = timeout
        self._urlopen = urlopen or urllib.request.urlopen
        self._ctx = ssl.create_default_context() if verify else ssl._create_unverified_context()
        self._scheme = None  # "Token" (v1) or "Bearer" (v2), detected on first use

    @staticmethod
    def _detail(exc):
        try:
            return exc.read().decode("utf-8", "replace")[:300]
        except Exception:  # noqa: BLE001
            return ""

    def request(self, method, url, body=None):
        data = json.dumps(body).encode("utf-8") if body is not None else None
        shown = url[len(self.base):] if url.startswith(self.base) else url
        schemes = [self._scheme] if self._scheme else ["Token", "Bearer"]
        for idx, scheme in enumerate(schemes):
            req = urllib.request.Request(url, data=data, method=method, headers={
                "Authorization": "%s %s" % (scheme, self._token), "Accept": "application/json",
                "Content-Type": "application/json"})
            try:
                with self._urlopen(req, timeout=self._timeout, context=self._ctx) as resp:
                    raw = resp.read()
                self._scheme = scheme
                try:
                    return json.loads(raw.decode("utf-8")) if raw else None
                except ValueError as exc:
                    raise NetBoxApiError("%s %s: response is not valid JSON" % (method, shown)) from exc
            except urllib.error.HTTPError as exc:
                if exc.code in (401, 403) and idx < len(schemes) - 1:
                    continue
                raise NetBoxApiError(("%s %s: HTTP %s %s" % (method, shown, exc.code, self._detail(exc))).strip()) from exc
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                raise NetBoxApiError("%s %s: %s" % (method, shown, getattr(exc, "reason", exc))) from exc
        raise NetBoxApiError("%s %s: no response" % (method, shown))

    def get_all(self, path, params):
        url = "%s%s?%s" % (self.base, path, urllib.parse.urlencode(dict(params, limit=PAGE_LIMIT)))
        rows, seen = [], set()
        for _ in range(MAX_PAGES):
            if url in seen:
                raise NetBoxApiError("GET %s: pagination loop detected" % path)
            seen.add(url)
            page = self.request("GET", url)
            if not isinstance(page, dict) or not isinstance(page.get("results"), list):
                raise NetBoxApiError("GET %s: unexpected response (no 'results' list)" % path)
            rows.extend(page["results"])
            nxt = page.get("next")
            if not nxt:
                return rows
            parsed, base = urllib.parse.urlsplit(nxt), urllib.parse.urlsplit(self.base)
            url = urllib.parse.urlunsplit((base.scheme, base.netloc, parsed.path, parsed.query, ""))
        raise NetBoxApiError("GET %s: too many pages" % path)



def resolve_site(api, site):
    """Exactly one site whose name or slug equals `site` (case-insensitive, like the UI dropdown value)."""
    wanted = str(site).strip().casefold()
    sites = [r for r in api.get_all("/api/dcim/sites/", {}) if isinstance(r, dict)]  # a NetBox has few sites
    rows = [r for r in sites if wanted in (str(r.get("name", "")).casefold(), str(r.get("slug", "")).casefold())]
    if len(rows) != 1:
        raise NetBoxApiError("site %r: %d matches by name or slug among %d sites in NetBox (need exactly one; known: %s)" % (
            site, len(rows), len(sites), ", ".join("%s/%s" % (r.get("name"), r.get("slug")) for r in sites[:20])))
    return rows[0]["id"]


def sync_vlans(api, site, vlans, check_mode=False):
    out = {"changed": False, "created": [], "unchanged": 0, "unnamed": 0, "skipped": [], "errors": []}
    site_id = resolve_site(api, site)
    existing = {(int(r["vid"]), str(r.get("name"))) for r in api.get_all("/api/ipam/vlans/", {"site_id": site_id})
                if isinstance(r, dict) and r.get("vid") is not None and (r.get("site") or {}).get("id") == site_id}
    wanted, seen = [], set()
    for item in vlans or []:
        try:
            vid, name = int(item["vid"]), str(item["name"]).strip()
        except (KeyError, TypeError, ValueError):
            out["skipped"].append("%r: no vid/name" % (item,))
            continue
        if not 1 <= vid <= 4094:
            out["skipped"].append("%s %r: invalid" % (vid, name))
            continue
        if not name or name in PLACEHOLDER_NAMES:  # the switch reports no name: nothing useful to record
            out["unnamed"] += 1
            continue
        key = (vid, name)
        if key in seen:
            continue
        seen.add(key)
        if key in existing:
            out["unchanged"] += 1
        else:
            wanted.append({"vid": vid, "name": name[:64], "site": site_id, "status": "active"})
    for start in range(0, len(wanted), CHUNK):
        chunk = wanted[start:start + CHUNK]
        if check_mode:
            out["created"].extend("%s - %s" % (v["vid"], v["name"]) for v in chunk)
            continue
        try:
            api.request("POST", "%s/api/ipam/vlans/" % api.base, chunk)
            out["created"].extend("%s - %s" % (v["vid"], v["name"]) for v in chunk)
        except NetBoxApiError:
            for vlan in chunk:  # find the offending VLAN; the rest is still written
                try:
                    api.request("POST", "%s/api/ipam/vlans/" % api.base, vlan)
                    out["created"].append("%s - %s" % (vlan["vid"], vlan["name"]))
                except NetBoxApiError as exc:
                    out["errors"].append("VLAN %s %s: %s" % (vlan["vid"], vlan["name"], exc))
    out["changed"] = bool(out["created"])
    return out


def main():
    if AnsibleModule is None:  # pragma: no cover
        raise SystemExit("ansible is required")
    module = AnsibleModule(argument_spec=dict(
        netbox_url=dict(type="str", required=True),
        netbox_token=dict(type="str", required=True, no_log=True),
        validate_certs=dict(type="bool", default=True),
        site=dict(type="str", required=True),
        vlans=dict(type="list", elements="dict", default=[]),
    ), supports_check_mode=True)
    p = module.params
    api = Api(p["netbox_url"], p["netbox_token"], verify=p["validate_certs"])
    try:
        out = sync_vlans(api, p["site"], p["vlans"], module.check_mode)
    except NetBoxApiError as exc:
        module.fail_json(msg="Cannot synchronize VLANs of site %s: %s" % (p["site"], exc))
    for text in out["skipped"] + out["errors"]:
        module.warn(text)
    module.exit_json(created_count=len(out["created"]), **out)


if __name__ == "__main__":
    main()
