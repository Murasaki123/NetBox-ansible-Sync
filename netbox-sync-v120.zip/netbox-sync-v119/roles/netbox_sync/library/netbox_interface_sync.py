#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Synchronise the interfaces of ONE NetBox device through the REST API by numeric IDs.

Why this exists: netbox.netbox.netbox_device_interface looks an interface up by name and
raises "More than one result returned" when NetBox returns several records. That happens
for the two members of an HA / virtual-chassis pair, whose interface names are identical.
This module never searches by name across devices:

  1. the device is resolved by exact name and must be unique -> numeric device_id;
  2. all interfaces of that device are read with full pagination
     (GET /api/dcim/interfaces/?device_id=<id>) and every row is additionally checked
     client-side (row["device"]["id"] == device_id), so rows of a virtual-chassis sibling
     can never leak in;
  3. per collected interface: 0 matches -> POST with device_id, 1 match -> PATCH by interface
     id, >1 matches -> skipped with a warning (device, name, all ids); nothing is deleted,
     renamed or picked at random;
  4. LAG membership is applied afterwards by numeric id of the parent interface.

Only the standard library is used, so the core can be unit-tested without Ansible.
"""
from __future__ import annotations

import json
import re
import ssl
import urllib.error
import urllib.parse
import urllib.request

try:  # Ansible is absent in the unit tests
    from ansible.module_utils.basic import AnsibleModule
except ImportError:  # pragma: no cover
    AnsibleModule = None

DOCUMENTATION = r"""
module: netbox_interface_sync
short_description: Create/update the interfaces of one NetBox device by numeric IDs
description:
  - Resolves the device by exact name, reads its interfaces with pagination and creates or updates them via POST/PATCH using numeric IDs.
  - Interfaces whose name occurs more than once on that device are skipped and reported; nothing is deleted or renamed.
options:
  netbox_url: {type: str, required: true}
  netbox_token: {type: str, required: true}
  validate_certs: {type: bool, default: true}
  device_name: {type: str, required: true}
  interfaces: {type: dict, default: {}, description: "Collected facts, interface name -> attributes."}
  interface_type_map: {type: dict, default: {}}
  lag_parent_by_member: {type: dict, default: {}}
  write: {type: bool, default: true, description: "false = only read and report the interface IDs."}
"""

ENABLED_VALUES = {"up", "enabled", "true"}
PAGE_LIMIT = 500
MAX_PAGES = 1000


class NetBoxApiError(RuntimeError):
    """Safe-to-print API error (never contains the token)."""


class Api:
    def __init__(self, base_url, token, verify=True, timeout=30, urlopen=None):
        self.base = base_url.rstrip("/")
        self._token = token
        self._timeout = timeout
        self._urlopen = urlopen or urllib.request.urlopen
        self._ctx = ssl.create_default_context() if verify else ssl._create_unverified_context()
        self._scheme = None  # "Token" (v1) or "Bearer" (v2), detected on first use

    @staticmethod
    def _detail(exc):
        try:
            return exc.read().decode("utf-8", "replace")[:300]
        except Exception:  # noqa: BLE001
            return ""

    def request(self, method, url, body=None):
        data = json.dumps(body).encode("utf-8") if body is not None else None
        shown = url[len(self.base):] if url.startswith(self.base) else url
        schemes = [self._scheme] if self._scheme else ["Token", "Bearer"]
        for idx, scheme in enumerate(schemes):
            req = urllib.request.Request(url, data=data, method=method, headers={
                "Authorization": "%s %s" % (scheme, self._token), "Accept": "application/json",
                "Content-Type": "application/json"})
            try:
                with self._urlopen(req, timeout=self._timeout, context=self._ctx) as resp:
                    raw = resp.read()
                self._scheme = scheme
                try:
                    return json.loads(raw.decode("utf-8")) if raw else None
                except ValueError as exc:
                    raise NetBoxApiError("%s %s: response is not valid JSON" % (method, shown)) from exc
            except urllib.error.HTTPError as exc:
                if exc.code in (401, 403) and idx < len(schemes) - 1:
                    continue  # nothing was changed: retry with the other token scheme
                raise NetBoxApiError(("%s %s: HTTP %s %s" % (method, shown, exc.code, self._detail(exc))).strip()) from exc
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                raise NetBoxApiError("%s %s: %s" % (method, shown, getattr(exc, "reason", exc))) from exc
        raise NetBoxApiError("%s %s: no response" % (method, shown))

    def get_all(self, path, params):
        """Follow `next` links until exhausted; never trusts a single page to be complete."""
        url = "%s%s?%s" % (self.base, path, urllib.parse.urlencode(dict(params, limit=PAGE_LIMIT)))
        rows, seen = [], set()
        for _ in range(MAX_PAGES):
            if url in seen:
                raise NetBoxApiError("GET %s: pagination loop detected" % path)
            seen.add(url)
            page = self.request("GET", url)
            if not isinstance(page, dict) or not isinstance(page.get("results"), list):
                raise NetBoxApiError("GET %s: unexpected response (no 'results' list)" % path)
            rows.extend(page["results"])
            nxt = page.get("next")
            if not nxt:
                total = page.get("count")
                if isinstance(total, int) and total != len(rows):
                    raise NetBoxApiError("GET %s: incomplete result (%d of %d rows)" % (path, len(rows), total))
                return rows
            url = self._same_origin(nxt)
        raise NetBoxApiError("GET %s: too many pages" % path)

    def _same_origin(self, nxt):
        """NetBox may build `next` with an internal host name; keep our configured origin."""
        parsed = urllib.parse.urlsplit(nxt)
        base = urllib.parse.urlsplit(self.base)
        return urllib.parse.urlunsplit((base.scheme, base.netloc, parsed.path, parsed.query, ""))


def resolve_device(api, name):
    rows = api.get_all("/api/dcim/devices/", {"name": name})
    exact = [r for r in rows if isinstance(r, dict) and r.get("name") == name]
    if len(exact) != 1:
        raise NetBoxApiError(
            "NetBox device lookup for exact name %r returned %d object(s); exactly one is required "
            "(ids: %s)" % (name, len(exact), ", ".join(str(r.get("id")) for r in exact) or "none"))
    return int(exact[0]["id"])


def read_device_interfaces(api, device_id):
    """All interfaces that really belong to device_id (client-side verified)."""
    rows = api.get_all("/api/dcim/interfaces/", {"device_id": device_id})
    own, foreign = [], 0
    for row in rows:
        owner = (row.get("device") or {}).get("id") if isinstance(row, dict) else None
        if owner == device_id:
            own.append(row)
        else:
            foreign += 1
    return own, foreign


def group_by_name(interfaces):
    grouped = {}
    for row in interfaces:
        if isinstance(row.get("name"), str) and row["name"]:
            grouped.setdefault(row["name"], []).append(row)
    return grouped


def _text(value):
    return "" if value is None else str(value)


def desired_attributes(name, facts, type_map):
    """Mirror of the v92 field mapping (type/enabled/mtu/mac/description); None type = skip."""
    facts = facts if isinstance(facts, dict) else {}
    itype = facts.get("type")
    if not itype:
        match = re.match(r"^[A-Za-z-]+", name)
        itype = (type_map or {}).get(match.group(0) if match else "", "")
    if not itype:
        return None
    status = facts["admin_status"] if "admin_status" in facts else facts.get("operstatus", "down")
    attrs = {"type": itype, "enabled": _text(status).lower() in ENABLED_VALUES,
             "description": _text(facts.get("description"))[:200]}
    mtu = facts.get("mtu")
    if mtu not in (None, ""):
        try:
            attrs["mtu"] = int(mtu)
        except (TypeError, ValueError):
            pass
    mac = facts.get("mac_address") or facts.get("macaddress")
    if mac:
        attrs["mac_address"] = _text(mac)
    return attrs


def _current(existing, key):
    value = existing.get(key)
    if isinstance(value, dict):
        value = value.get("value", value.get("id"))
    return value


def changed_fields(existing, desired):
    diff = {}
    for key, value in desired.items():
        cur = _current(existing, key)
        if key == "mac_address":
            if _text(cur).lower() != value.lower():
                diff[key] = value
        elif key == "description":
            if _text(cur) != value:
                diff[key] = value
        elif cur != value:
            diff[key] = value
    return diff


def _write(api, method, path, body, errors, label):
    """POST/PATCH; some NetBox versions dropped the writable mac_address field, so retry once without it."""
    try:
        return api.request(method, api.base + path, body)
    except NetBoxApiError as exc:
        if "mac_address" in body and "mac_address" in str(exc) and len(body) > 1:
            trimmed = {k: v for k, v in body.items() if k != "mac_address"}
            try:
                return api.request(method, api.base + path, trimmed)
            except NetBoxApiError as exc2:
                exc = exc2
        errors.append("%s: %s" % (label, exc))
        return None


def sync_interfaces(api, device_name, facts_by_name, type_map, lag_parent_by_member, write=True, check_mode=False):
    device_id = resolve_device(api, device_name)
    own, foreign = read_device_interfaces(api, device_id)
    grouped = group_by_name(own)
    duplicates = {n: [r["id"] for r in rows] for n, rows in grouped.items() if len(rows) > 1}
    ids = {n: rows[0]["id"] for n, rows in grouped.items() if len(rows) == 1}
    out = {"device_id": device_id, "created": [], "updated": [], "unchanged": [], "skipped": [],
           "duplicates": duplicates, "errors": [], "warnings": [], "ignored_foreign_rows": foreign}
    for name, found in duplicates.items():
        out["warnings"].append(
            "Skipping interface %s on %s (device id %s): NetBox contains %d records with this exact name "
            "(IDs: %s). Nothing was changed or deleted." % (name, device_name, device_id, len(found),
                                                          ", ".join(str(i) for i in found)))
    if foreign:
        out["warnings"].append("Ignored %d interface row(s) returned for device_id=%s that belong to another device."
                               % (foreign, device_id))
    if write:
        for name, facts in (facts_by_name or {}).items():
            if name in duplicates:
                out["skipped"].append(name)
                continue
            attrs = desired_attributes(name, facts, type_map)
            if attrs is None:
                out["skipped"].append(name)
                out["warnings"].append("Skipping interface %s: no validated NetBox type mapping was collected." % name)
                continue
            label = "%s/%s" % (device_name, name)
            if name in ids:
                diff = changed_fields(grouped[name][0], attrs)
                if not diff:
                    out["unchanged"].append(name)
                elif check_mode:
                    out["updated"].append(name)
                elif _write(api, "PATCH", "/api/dcim/interfaces/%s/" % ids[name], diff, out["errors"], label) is not None:
                    out["updated"].append(name)
            elif check_mode:
                out["created"].append(name)
            else:
                body = dict(attrs, device=device_id, name=name)
                created = _write(api, "POST", "/api/dcim/interfaces/", body, out["errors"], label)
                if isinstance(created, dict) and created.get("id") is not None:
                    ids[name] = created["id"]
                    grouped[name] = [created]
                    out["created"].append(name)
        # LAG membership by numeric id of the parent interface (parents may be new in this run)
        for member, parent in (lag_parent_by_member or {}).items():
            if member in duplicates or member not in ids or member not in (facts_by_name or {}):
                continue
            if parent in duplicates or parent not in ids:
                out["warnings"].append("LAG %s for %s not applied: parent interface is missing or ambiguous." % (parent, member))
                continue
            cur = (grouped[member][0].get("lag") or {}).get("id") if isinstance(grouped[member][0], dict) else None
            if cur != ids[parent] and not check_mode:
                _write(api, "PATCH", "/api/dcim/interfaces/%s/" % ids[member], {"lag": ids[parent]},
                       out["errors"], "%s/%s lag" % (device_name, member))
    out["interface_ids"] = ids
    return out


def main():
    if AnsibleModule is None:  # pragma: no cover
        raise SystemExit("ansible is required")
    module = AnsibleModule(argument_spec=dict(
        netbox_url=dict(type="str", required=True),
        netbox_token=dict(type="str", required=True, no_log=True),
        validate_certs=dict(type="bool", default=True),
        device_name=dict(type="str", required=True),
        interfaces=dict(type="dict", default={}),
        interface_type_map=dict(type="dict", default={}),
        lag_parent_by_member=dict(type="dict", default={}),
        write=dict(type="bool", default=True),
    ), supports_check_mode=True)
    p = module.params
    api = Api(p["netbox_url"], p["netbox_token"], verify=p["validate_certs"])
    try:
        out = sync_interfaces(api, p["device_name"], p["interfaces"], p["interface_type_map"],
                              p["lag_parent_by_member"], write=p["write"], check_mode=module.check_mode)
    except NetBoxApiError as exc:
        module.fail_json(msg="Cannot synchronize interfaces for %s: %s" % (p["device_name"], exc))
    for text in out["warnings"]:
        module.warn(text)
    for text in out["errors"]:
        module.warn("Interface error (other interfaces continue): " + text)
    out["changed"] = bool(out["created"] or out["updated"])
    module.exit_json(**out)


if __name__ == "__main__":
    main()
