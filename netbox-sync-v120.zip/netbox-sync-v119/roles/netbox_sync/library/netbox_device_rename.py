#!/usr/bin/python
# -*- coding: utf-8 -*-
"""Rename an existing NetBox device that is identified by its serial number.

When a device is renamed in netbox-sync, the NetBox module would create a second device under the
new name. This module runs before that step: if NetBox has no device with the new name but has
exactly one device with the same serial number, that device is renamed (PATCH by numeric id).

Safety rules (nothing is ever deleted):
  * empty or placeholder serials ("unknown", "N/A", ...) are never used for matching;
  * more than one device with that serial -> warning, nothing renamed;
  * the device that currently owns the serial must not be another device of the netbox-sync registry
    (protected_names), otherwise two inventory devices would be mixed up;
  * an API error stops the task (a silent fallback would create the duplicate this module prevents).

Standard library only, so the core can be unit-tested without Ansible.
"""
from __future__ import annotations

import json
import ssl
import urllib.error
import urllib.parse
import urllib.request

try:  # Ansible is absent in the unit tests
    from ansible.module_utils.basic import AnsibleModule
except ImportError:  # pragma: no cover
    AnsibleModule = None

DOCUMENTATION = r"""
module: netbox_device_rename
short_description: Rename an existing NetBox device located by serial number
options:
  netbox_url: {type: str, required: true}
  netbox_token: {type: str, required: true}
  validate_certs: {type: bool, default: true}
  device_name: {type: str, required: true, description: "The name that must exist in NetBox."}
  serial: {type: str, default: "", description: "Serial number collected from the device."}
  protected_names: {type: list, elements: str, default: [], description: "Names of other netbox-sync devices that must never be renamed."}
"""

PLACEHOLDER_SERIALS = {"unknown", "n/a", "na", "none", "null", "nil", "-", "--", "0", "default", "default string",
                       "not available", "not specified", "not set", "to be filled by o.e.m.", "undefined", "serial"}
MIN_SERIAL_LENGTH = 4
PAGE_LIMIT = 500
MAX_PAGES = 1000


class NetBoxApiError(RuntimeError):
    """Safe-to-print API error (never contains the token)."""


class Api:
    def __init__(self, base_url, token, verify=True, timeout=30, urlopen=None):
        self.base = base_url.rstrip("/")
        self._token = token
        self._timeout = timeout
        self._urlopen = urlopen or urllib.request.urlopen
        self._ctx = ssl.create_default_context() if verify else ssl._create_unverified_context()
        self._scheme = None  # "Token" (v1) or "Bearer" (v2), detected on first use

    @staticmethod
    def _detail(exc):
        try:
            return exc.read().decode("utf-8", "replace")[:300]
        except Exception:  # noqa: BLE001
            return ""

    def request(self, method, url, body=None):
        data = json.dumps(body).encode("utf-8") if body is not None else None
        shown = url[len(self.base):] if url.startswith(self.base) else url
        schemes = [self._scheme] if self._scheme else ["Token", "Bearer"]
        for idx, scheme in enumerate(schemes):
            req = urllib.request.Request(url, data=data, method=method, headers={
                "Authorization": "%s %s" % (scheme, self._token), "Accept": "application/json",
                "Content-Type": "application/json"})
            try:
                with self._urlopen(req, timeout=self._timeout, context=self._ctx) as resp:
                    raw = resp.read()
                self._scheme = scheme
                try:
                    return json.loads(raw.decode("utf-8")) if raw else None
                except ValueError as exc:
                    raise NetBoxApiError("%s %s: response is not valid JSON" % (method, shown)) from exc
            except urllib.error.HTTPError as exc:
                if exc.code in (401, 403) and idx < len(schemes) - 1:
                    continue
                raise NetBoxApiError(("%s %s: HTTP %s %s" % (method, shown, exc.code, self._detail(exc))).strip()) from exc
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                raise NetBoxApiError("%s %s: %s" % (method, shown, getattr(exc, "reason", exc))) from exc
        raise NetBoxApiError("%s %s: no response" % (method, shown))

    def get_all(self, path, params):
        url = "%s%s?%s" % (self.base, path, urllib.parse.urlencode(dict(params, limit=PAGE_LIMIT)))
        rows, seen = [], set()
        for _ in range(MAX_PAGES):
            if url in seen:
                raise NetBoxApiError("GET %s: pagination loop detected" % path)
            seen.add(url)
            page = self.request("GET", url)
            if not isinstance(page, dict) or not isinstance(page.get("results"), list):
                raise NetBoxApiError("GET %s: unexpected response (no 'results' list)" % path)
            rows.extend(page["results"])
            nxt = page.get("next")
            if not nxt:
                return rows
            parsed, base = urllib.parse.urlsplit(nxt), urllib.parse.urlsplit(self.base)
            url = urllib.parse.urlunsplit((base.scheme, base.netloc, parsed.path, parsed.query, ""))
        raise NetBoxApiError("GET %s: too many pages" % path)


def usable_serial(serial):
    text = " ".join(str(serial or "").split())
    if len(text) < MIN_SERIAL_LENGTH or text.casefold() in PLACEHOLDER_SERIALS:
        return ""
    return text


def rename_by_serial(api, device_name, serial, protected_names=(), check_mode=False):
    out = {"status": "", "changed": False, "warnings": [], "device_id": None, "old_name": None, "new_name": device_name}
    serial = usable_serial(serial)
    if not serial:
        out["status"] = "no_usable_serial"
        return out
    same_name = [r for r in api.get_all("/api/dcim/devices/", {"name": device_name})
                 if isinstance(r, dict) and r.get("name") == device_name]
    if same_name:
        out["status"], out["device_id"] = "name_exists", same_name[0].get("id")
        return out
    owners = [r for r in api.get_all("/api/dcim/devices/", {"serial": serial})
              if isinstance(r, dict) and str(r.get("serial", "")).strip().casefold() == serial.casefold()]
    if not owners:
        out["status"] = "not_found"  # genuinely new device: the regular create step handles it
        return out
    if len(owners) > 1:
        out["status"] = "ambiguous_serial"
        out["warnings"].append("Not renaming: serial %s belongs to %d NetBox devices (%s); resolve it manually. "
                               "A new device %s will be created." % (serial, len(owners), ", ".join(
                                   "%s (id %s)" % (r.get("name"), r.get("id")) for r in owners), device_name))
        return out
    owner = owners[0]
    out["device_id"], out["old_name"] = owner.get("id"), owner.get("name")
    if str(owner.get("name", "")).casefold() in {str(n).casefold() for n in (protected_names or [])}:
        out["status"] = "owner_is_other_inventory_device"
        out["warnings"].append("Not renaming NetBox device %r (id %s): its name is still used by another device in netbox-sync "
                               "although the serial %s matches. Check the serial numbers." % (owner.get("name"), owner.get("id"), serial))
        return out
    if not check_mode:
        api.request("PATCH", "%s/api/dcim/devices/%s/" % (api.base, owner["id"]), {"name": device_name})
    out["status"], out["changed"] = "renamed", True
    return out


def main():
    if AnsibleModule is None:  # pragma: no cover
        raise SystemExit("ansible is required")
    module = AnsibleModule(argument_spec=dict(
        netbox_url=dict(type="str", required=True),
        netbox_token=dict(type="str", required=True, no_log=True),
        validate_certs=dict(type="bool", default=True),
        device_name=dict(type="str", required=True),
        serial=dict(type="str", default=""),
        protected_names=dict(type="list", elements="str", default=[]),
    ), supports_check_mode=True)
    p = module.params
    api = Api(p["netbox_url"], p["netbox_token"], verify=p["validate_certs"])
    try:
        out = rename_by_serial(api, p["device_name"], p["serial"], p["protected_names"], module.check_mode)
    except NetBoxApiError as exc:
        module.fail_json(msg="Cannot check or rename the NetBox device %s by serial number: %s" % (p["device_name"], exc))
    for text in out["warnings"]:
        module.warn(text)
    module.exit_json(**out)


if __name__ == "__main__":
    main()
