"""NetBox steps that run after the Ansible synchronization: virtual chassis and LLDP cables.

Standard library only, so it can be tested without the web framework. Every write is
idempotent (existing objects are left alone) and a failure on one object never stops
the remaining ones; errors are collected and reported to the operator.
"""
from __future__ import annotations

import json
import re
import ssl
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable

NON_CABLE_INTERFACE_TYPES = {"lag", "virtual", "bridge"}


class NetBoxError(RuntimeError):
    """A NetBox API call failed; the message is safe to show (it never contains the token)."""


@dataclass
class StepResult:
    created: int = 0
    updated: int = 0
    unchanged: int = 0
    skipped: int = 0
    errors: list[str] = field(default_factory=list)


class NetBoxClient:
    def __init__(self, base_url: str, token: str, verify: bool = False, timeout: int = 20,
                 urlopen: Callable[..., Any] | None = None) -> None:
        self.base_url = base_url.rstrip("/")
        self._token = token
        self._timeout = timeout
        self._urlopen = urlopen or urllib.request.urlopen
        self._context = ssl.create_default_context() if verify else ssl._create_unverified_context()
        self._scheme: str | None = None  # "Token" (v1 tokens) or "Bearer" (v2 tokens), detected on first use

    @staticmethod
    def _detail(exc: urllib.error.HTTPError) -> str:
        try:
            raw = exc.read().decode("utf-8", "replace")
        except Exception:
            return ""
        try:
            data = json.loads(raw)
            return json.dumps(data, ensure_ascii=False)[:300]
        except ValueError:
            return raw[:300]

    def _send(self, method: str, url: str, body: dict[str, Any] | None = None) -> Any:
        data = json.dumps(body).encode("utf-8") if body is not None else None
        schemes = [self._scheme] if self._scheme else ["Token", "Bearer"]
        shown = url[len(self.base_url):] if url.startswith(self.base_url) else url
        for index, scheme in enumerate(schemes):
            request = urllib.request.Request(url, data=data, method=method, headers={
                "Authorization": f"{scheme} {self._token}", "Accept": "application/json",
                "Content-Type": "application/json"})
            try:
                with self._urlopen(request, timeout=self._timeout, context=self._context) as response:
                    raw = response.read()
                self._scheme = scheme
                return json.loads(raw.decode("utf-8")) if raw else None
            except urllib.error.HTTPError as exc:
                if exc.code in (401, 403) and index < len(schemes) - 1:
                    continue  # nothing was changed on 401/403: retry with the other token scheme
                raise NetBoxError(f"{method} {shown}: HTTP {exc.code} {self._detail(exc)}".strip()) from exc
            except (urllib.error.URLError, TimeoutError, OSError, ValueError) as exc:
                raise NetBoxError(f"{method} {shown}: {getattr(exc, 'reason', exc)}") from exc
        raise NetBoxError(f"{method} {shown}: no response")

    def get_all(self, path: str, params: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        query = urllib.parse.urlencode({**(params or {}), "limit": 1000})
        url: str | None = f"{self.base_url}{path}?{query}"
        results: list[dict[str, Any]] = []
        while url:
            page = self._send("GET", url)
            results.extend((page or {}).get("results", []))
            next_url = (page or {}).get("next")
            url = next_url if next_url and str(next_url).startswith(self.base_url) else None
        return results

    def post(self, path: str, body: dict[str, Any]) -> Any:
        return self._send("POST", f"{self.base_url}{path}", body)

    def patch(self, path: str, body: dict[str, Any]) -> Any:
        return self._send("PATCH", f"{self.base_url}{path}", body)


def _one_device(client: NetBoxClient, name: str) -> dict[str, Any] | None:
    found = client.get_all("/api/dcim/devices/", {"name": name})
    if len(found) > 1:
        raise NetBoxError(f"в NetBox найдено несколько устройств с именем «{name}»")
    return found[0] if found else None


def sync_virtual_chassis(client: NetBoxClient, chassis_list: Iterable[dict[str, Any]],
                         log: Callable[[str], None]) -> StepResult:
    """One NetBox Virtual Chassis per local group; its members are the already synchronized physical devices."""
    result = StepResult()
    for chassis in chassis_list:
        name, members = str(chassis["name"]), list(chassis["members"])
        try:
            devices: list[dict[str, Any]] = []
            missing: list[str] = []
            for member in members:
                device = _one_device(client, member)
                (devices if device else missing).append(device or member)  # type: ignore[arg-type]
            if missing:
                result.skipped += 1
                log(f"Виртуальное шасси «{name}» пропущено: в NetBox ещё нет устройств {', '.join(missing)}.")
                continue
            existing = [v for v in client.get_all("/api/dcim/virtual-chassis/", {"name": name}) if v.get("name") == name]
            if existing:
                vc = existing[0]
            else:
                vc = client.post("/api/dcim/virtual-chassis/", {"name": name})
                result.created += 1
                log(f"Виртуальное шасси «{name}» создано.")
            changed = False
            taken = {d.get("vc_position") for d in devices
                     if (d.get("virtual_chassis") or {}).get("id") == vc["id"] and d.get("vc_position") is not None}
            for device in devices:
                if (device.get("virtual_chassis") or {}).get("id") == vc["id"] and device.get("vc_position") is not None:
                    continue
                position = 1
                while position in taken:
                    position += 1
                taken.add(position)
                client.patch(f"/api/dcim/devices/{device['id']}/", {"virtual_chassis": vc["id"], "vc_position": position})
                device["virtual_chassis"], device["vc_position"] = {"id": vc["id"]}, position
                changed = True
                result.updated += 1
                log(f"Устройство «{device['name']}» добавлено в виртуальное шасси «{name}» (позиция {position}).")
            if not (vc.get("master") or {}).get("id"):
                client.patch(f"/api/dcim/virtual-chassis/{vc['id']}/", {"master": devices[0]["id"]})
                changed = True
                log(f"Мастер шасси «{name}»: {devices[0]['name']}.")
            if not changed and existing:
                result.unchanged += 1
                log(f"Виртуальное шасси «{name}» уже актуально.")
        except (NetBoxError, KeyError, IndexError) as exc:
            message = f"Виртуальное шасси «{name}»: {exc}"
            result.errors.append(message)
            log(f"ОШИБКА. {message}")
    return result


# --- Stacks: one managed address, several physical units (Eltex MES) ----------------------------------------
_STACK_PORT = re.compile(r"(?i)^(?:te|gi|fa|ge|xg|tengigabitethernet|gigabitethernet|fastethernet)(\d+)/\d+/\d+$")


def stack_port_unit(interface: Any) -> int | None:
    """Unit number of a stacked physical port (te2/0/20 -> 2); None for logical interfaces."""
    match = _STACK_PORT.match(str(interface or "").strip())
    return int(match.group(1)) if match else None


def stack_unit_device_name(host: str, unit: int, numbers: Iterable[int]) -> str:
    """The master (lowest unit) keeps the stack name; unit N is "<name>-N"."""
    ordered = sorted(set(numbers))
    return host if len(ordered) < 2 or unit == ordered[0] else f"{host}-{unit}"


def stack_port_device(device: str, interface: Any, stacks: dict[str, Iterable[int]]) -> str:
    """NetBox device that owns `interface` of `device`; `stacks` = {stack name: unit numbers}."""
    numbers: list[int] = []
    for name, value in (stacks or {}).items():
        if str(name).casefold() == str(device or "").casefold():
            numbers = sorted(set(int(v) for v in value))
            break
    unit = stack_port_unit(interface)
    if len(numbers) < 2 or unit is None or unit not in numbers:
        return device
    return stack_unit_device_name(device, unit, numbers)


def sync_stack_chassis(client: NetBoxClient, stacks: dict[str, dict[str, Any]], log: Callable[[str], None]) -> StepResult:
    """Virtual chassis for each multi-unit stack, then LAG membership that spans units.

    `stacks` = {name: {"units": [unit numbers], "lag_members": {aggregate: [member ports]}}}. The unit devices and their
    interfaces were already written by the Ansible role; a LAG spanning several units can only be set once the units
    belong to one virtual chassis, which is why it happens here.
    """
    result = StepResult()
    for host, info in stacks.items():
        numbers = sorted(set(int(u) for u in info.get("units", [])))
        if len(numbers) < 2:
            continue
        names = [stack_unit_device_name(host, n, numbers) for n in numbers]
        partial = sync_virtual_chassis(client, [{"name": host, "members": names}], log)
        result.created += partial.created
        result.updated += partial.updated
        result.unchanged += partial.unchanged
        result.skipped += partial.skipped
        result.errors.extend(partial.errors)
        if partial.errors or partial.skipped:
            continue
        try:
            master = _one_device(client, names[0])
            if master is None:
                continue
            owned: dict[int, list[dict[str, Any]]] = {}

            def interfaces_of(device: dict[str, Any]) -> list[dict[str, Any]]:
                if device["id"] not in owned:  # rows are verified to belong to this very device
                    owned[device["id"]] = [i for i in client.get_all("/api/dcim/interfaces/", {"device_id": device["id"]})
                                           if (i.get("device") or {}).get("id") == device["id"]]
                return owned[device["id"]]

            parents = {i["name"]: i for i in interfaces_of(master)}
            for number, device_name in zip(numbers[1:], names[1:]):
                device = _one_device(client, device_name)
                if device is None:
                    continue
                own = {i["name"]: i for i in interfaces_of(device)}
                for aggregate, members in (info.get("lag_members") or {}).items():
                    parent = parents.get(aggregate)
                    for member in members or []:
                        if stack_port_unit(member) != number or member not in own:
                            continue
                        if parent is None:
                            log(f"LAG {aggregate} для {device_name} {member} не назначен: агрегат не найден на мастере {names[0]}.")
                            continue
                        if ((own[member].get("lag") or {}).get("id")) == parent["id"]:
                            continue
                        client.patch(f"/api/dcim/interfaces/{own[member]['id']}/", {"lag": parent["id"]})
                        own[member]["lag"] = {"id": parent["id"]}
                        result.updated += 1
                        log(f"Порт {device_name} {member} добавлен в LAG {aggregate} (мастер {names[0]}).")
        except (NetBoxError, KeyError) as exc:
            message = f"LAG стека «{host}»: {exc}"
            result.errors.append(message)
            log(f"ОШИБКА. {message}")
    return result


def sync_cables(client: NetBoxClient, links: Iterable[dict[str, Any]], normalise: Callable[[Any], str],
                log: Callable[[str], None]) -> StepResult:
    """Create a cable for each LLDP link whose two interfaces already exist in NetBox and are free."""
    result = StepResult()
    devices: dict[str, dict[str, Any] | None] = {}
    interfaces: dict[int, list[dict[str, Any]]] = {}

    def device(name: str) -> dict[str, Any] | None:
        if name not in devices:
            devices[name] = _one_device(client, name)
        return devices[name]

    def interface(device_name: str, port: str) -> dict[str, Any] | None:
        dev = device(device_name)
        if dev is None:
            raise NetBoxError(f"устройства «{device_name}» нет в NetBox")
        if dev["id"] not in interfaces:
            interfaces[dev["id"]] = client.get_all("/api/dcim/interfaces/", {"device_id": dev["id"]})
        items = interfaces[dev["id"]]
        exact = [i for i in items if i.get("name") == port]
        if exact:
            return exact[0]
        candidates = [i for i in items if normalise(i.get("name")) == normalise(port)]
        return candidates[0] if len(candidates) == 1 else None

    for link in links:
        label = f"{link['local_name']} {link['local_interface']} ↔ {link['remote_name']} {link['remote_interface']}"
        try:
            a = interface(link["local_name"], link["local_interface"])
            b = interface(link["remote_name"], link["remote_interface"])
            if a is None or b is None:
                result.skipped += 1
                log(f"Кабель пропущен ({label}): интерфейс не найден в NetBox.")
                continue
            if a["id"] == b["id"]:
                result.skipped += 1
                continue
            types = {(a.get("type") or {}).get("value"), (b.get("type") or {}).get("value")}
            if types & NON_CABLE_INTERFACE_TYPES:
                result.skipped += 1
                log(f"Кабель пропущен ({label}): к логическому интерфейсу кабель не подключается.")
                continue
            cable_a, cable_b = (a.get("cable") or {}).get("id"), (b.get("cable") or {}).get("id")
            if cable_a and cable_a == cable_b:
                result.unchanged += 1
                continue
            if cable_a or cable_b:
                result.skipped += 1
                log(f"Кабель пропущен ({label}): порт уже подключён другим кабелем в NetBox.")
                continue
            created = client.post("/api/dcim/cables/", {
                "a_terminations": [{"object_type": "dcim.interface", "object_id": a["id"]}],
                "b_terminations": [{"object_type": "dcim.interface", "object_id": b["id"]}],
                "status": "connected"})
            marker = {"id": (created or {}).get("id", -1)}
            a["cable"], b["cable"] = marker, marker
            result.created += 1
            log(f"Кабель создан: {label}.")
        except (NetBoxError, KeyError) as exc:
            message = f"Кабель {label}: {exc}"
            result.errors.append(message)
            log(f"ОШИБКА. {message}")
    return result


def shared_ip_exclusions(members_by_chassis: dict[str, list[str]], ips_by_device: dict[str, set[str]]) -> dict[str, list[str]]:
    """IPs that several members of one virtual chassis report (HA pairs, VIPs) are synchronized once,
    by the first member; later members must not claim the same address."""
    exclusions: dict[str, list[str]] = {}
    for members in members_by_chassis.values():
        seen: set[str] = set()
        for index, member in enumerate(members):
            ips = set(ips_by_device.get(member, set()))
            if index:
                shared = sorted(ips & seen)
                if shared:
                    exclusions[member] = shared
            seen |= ips
    return exclusions


# --- Site / device-role choices for the device form -------------------------------------------------
PRESET_SITES = ("P24",)
PRESET_ROLES = ("sw", "l3-sw", "core-sw", "router", "fw")
_KINDS = {
    "site": ("/api/dcim/sites/", lambda name, slug: {"name": name, "slug": slug, "status": "active"}),
    "role": ("/api/dcim/device-roles/", lambda name, slug: {"name": name, "slug": slug, "color": "9e9e9e"}),
}


def derive_slug(text: str) -> str:
    """Lower case, whitespace becomes '-', must stay ASCII [a-z0-9_-]; '' when that is impossible."""
    slug = "-".join(str(text or "").strip().lower().split())
    return slug if slug and all(c.isascii() and (c.isalnum() or c in "-_") for c in slug) else ""


def list_choices(client: NetBoxClient) -> dict[str, list[dict[str, Any]]]:
    """Real NetBox sites/roles plus the presets that do not exist there yet (exists=False)."""
    out: dict[str, list[dict[str, Any]]] = {}
    for kind, presets in (("site", PRESET_SITES), ("role", PRESET_ROLES)):
        rows = client.get_all(_KINDS[kind][0], {})
        items = {str(r["slug"]).casefold(): {"slug": r["slug"], "name": r.get("name") or r["slug"], "exists": True}
                 for r in rows if isinstance(r, dict) and r.get("slug")}
        for preset in presets:
            slug = derive_slug(preset)
            items.setdefault(slug, {"slug": slug, "name": preset, "exists": False})
        out[kind] = sorted(items.values(), key=lambda i: str(i["name"]).casefold())
    return out


def ensure_object(client: NetBoxClient, kind: str, name: str, slug: str = "") -> dict[str, Any]:
    """Create the site/role unless it already exists (matched by slug, then by name). Never overwrites."""
    path, build = _KINDS[kind]
    name = " ".join(str(name or "").split())
    slug = slug or derive_slug(name)
    if not name or not slug or len(name) > 100:
        raise NetBoxError("Укажите название латиницей: буквы, цифры, «-» и «_» (до 100 символов).")
    for params in ({"slug": slug}, {"name": name}):
        found = [r for r in client.get_all(path, params) if isinstance(r, dict) and r.get("slug")]
        exact = [r for r in found if str(r["slug"]).casefold() == slug.casefold() or str(r.get("name", "")).casefold() == name.casefold()]
        if exact:
            return {"slug": exact[0]["slug"], "name": exact[0].get("name") or exact[0]["slug"], "exists": True, "created": False}
    created = client.post(path, build(name, slug))
    if not isinstance(created, dict) or not created.get("slug"):
        raise NetBoxError("NetBox вернул неожиданный ответ при создании объекта.")
    return {"slug": created["slug"], "name": created.get("name") or name, "exists": True, "created": True}
