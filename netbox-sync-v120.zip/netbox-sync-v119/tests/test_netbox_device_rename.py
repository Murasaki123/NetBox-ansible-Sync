"""Rename-by-serial: a device renamed in netbox-sync must not become a second NetBox device."""
import importlib.util
import io
import json
import sys
import unittest
import urllib.error
import urllib.parse
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("netbox_device_rename", ROOT / "roles/netbox_sync/library/netbox_device_rename.py")
mod = importlib.util.module_from_spec(spec)
sys.modules["netbox_device_rename"] = mod
spec.loader.exec_module(mod)
BASE = "https://nb.example"


class Resp:
    def __init__(self, payload):
        self._raw = json.dumps(payload).encode()
    def read(self):
        return self._raw
    def __enter__(self):
        return self
    def __exit__(self, *a):
        return False


class FakeNetBox:
    def __init__(self, devices, page=2, scheme="Token"):
        self.devices, self.page, self.scheme, self.calls, self.fail = devices, page, scheme, [], None

    def __call__(self, req, timeout=None, context=None):
        if not req.get_header("Authorization").startswith(self.scheme + " "):
            raise urllib.error.HTTPError(req.full_url, 403, "no", {}, io.BytesIO(b"{}"))
        p = urllib.parse.urlsplit(req.full_url)
        q = {k: v[0] for k, v in urllib.parse.parse_qs(p.query).items()}
        self.calls.append((req.get_method(), p.path, q, json.loads(req.data) if req.data else None))
        if self.fail == req.get_method():
            raise urllib.error.HTTPError(req.full_url, 500, "x", {}, io.BytesIO(b"{}"))
        if req.get_method() == "PATCH":
            dev = next(d for d in self.devices if d["id"] == int(p.path.strip("/").split("/")[-1]))
            dev.update(json.loads(req.data))
            return Resp(dev)
        rows = [d for d in self.devices if all(str(d.get(k, "")).casefold() == v.casefold() for k, v in q.items() if k in ("name", "serial"))]
        off = int(q.get("offset", 0))
        chunk = rows[off:off + self.page]
        nxt = "http://internal:8080%s?%s" % (p.path, urllib.parse.urlencode({**q, "offset": off + self.page})) if off + self.page < len(rows) else None
        return Resp({"count": len(rows), "next": nxt, "results": chunk})


def run(nb, name="NEW-NAME", serial="SN123456", protected=(), **kw):
    return mod.rename_by_serial(mod.Api(BASE, "tok-123456789", urlopen=nb), name, serial, protected, **kw)


def patches(nb):
    return [c for c in nb.calls if c[0] == "PATCH"]


class RenameTests(unittest.TestCase):
    def test_existing_device_is_renamed_by_id_and_no_second_device_is_needed(self):
        nb = FakeNetBox([{"id": 7, "name": "OLD-NAME", "serial": "SN123456"}, {"id": 8, "name": "OTHER", "serial": "ZZ999999"}])
        r = run(nb)
        self.assertEqual((r["status"], r["changed"], r["old_name"], r["device_id"]), ("renamed", True, "OLD-NAME", 7))
        self.assertEqual(nb.devices[0]["name"], "NEW-NAME")
        self.assertEqual(nb.devices[1]["name"], "OTHER")
        self.assertEqual(patches(nb)[0][1:], ("/api/dcim/devices/7/", {}, {"name": "NEW-NAME"}))
        self.assertEqual(run(nb)["status"], "name_exists")  # second run: nothing to do
        self.assertEqual(len(patches(nb)), 1)

    def test_serial_match_is_case_insensitive_and_whitespace_tolerant(self):
        nb = FakeNetBox([{"id": 7, "name": "OLD", "serial": "sn123456"}])
        self.assertEqual(run(nb, serial="  SN123456 ")["status"], "renamed")

    def test_unknown_device_is_left_for_the_normal_create_step(self):
        nb = FakeNetBox([{"id": 7, "name": "OLD", "serial": "SN999999"}])
        r = run(nb)
        self.assertEqual((r["status"], r["changed"]), ("not_found", False))
        self.assertFalse(patches(nb))

    def test_name_already_present_never_renames_anything(self):
        nb = FakeNetBox([{"id": 1, "name": "NEW-NAME", "serial": ""}, {"id": 7, "name": "OLD", "serial": "SN123456"}])
        r = run(nb)
        self.assertEqual(r["status"], "name_exists")
        self.assertFalse(patches(nb))
        self.assertEqual([c[2] for c in nb.calls if "serial" in c[2]], [])

    def test_placeholder_and_empty_serials_are_never_used(self):
        for bad in ("", None, "unknown", "N/A", "None", "-", "0", "abc", "Default string", "To be filled by O.E.M."):
            nb = FakeNetBox([{"id": 7, "name": "OLD", "serial": str(bad)}])
            r = run(nb, serial=bad)
            self.assertEqual(r["status"], "no_usable_serial", bad)
            self.assertFalse(nb.calls, bad)

    def test_ambiguous_serial_is_reported_and_not_renamed(self):
        nb = FakeNetBox([{"id": 7, "name": "A", "serial": "SN123456"}, {"id": 8, "name": "B", "serial": "SN123456"}], page=1)
        r = run(nb)
        self.assertEqual((r["status"], r["changed"]), ("ambiguous_serial", False))
        self.assertIn("id 7", r["warnings"][0])
        self.assertIn("id 8", r["warnings"][0])
        self.assertFalse(patches(nb))

    def test_device_owned_by_another_registry_entry_is_protected(self):
        nb = FakeNetBox([{"id": 7, "name": "SW-2", "serial": "SN123456"}])
        r = run(nb, protected=["sw-2", "SW-3"])
        self.assertEqual(r["status"], "owner_is_other_inventory_device")
        self.assertFalse(patches(nb))
        self.assertTrue(r["warnings"])

    def test_api_errors_stop_the_run_instead_of_creating_a_duplicate(self):
        nb = FakeNetBox([{"id": 7, "name": "OLD", "serial": "SN123456"}])
        nb.fail = "GET"
        with self.assertRaises(mod.NetBoxApiError):
            run(nb)
        nb = FakeNetBox([{"id": 7, "name": "OLD", "serial": "SN123456"}])
        nb.fail = "PATCH"
        with self.assertRaisesRegex(mod.NetBoxApiError, "HTTP 500"):
            run(nb)

    def test_check_mode_and_bearer_tokens(self):
        nb = FakeNetBox([{"id": 7, "name": "OLD", "serial": "SN123456"}], scheme="Bearer")
        r = run(nb, check_mode=True)
        self.assertEqual((r["status"], r["changed"]), ("renamed", True))
        self.assertFalse(patches(nb))
        self.assertEqual(nb.devices[0]["name"], "OLD")

    def test_pagination_of_serial_lookup_is_followed(self):
        nb = FakeNetBox([{"id": i, "name": "D%d" % i, "serial": "SN123456"} for i in range(1, 6)], page=2)
        self.assertEqual(run(nb)["status"], "ambiguous_serial")
        self.assertGreaterEqual(len([c for c in nb.calls if c[1] == "/api/dcim/devices/" and "serial" in c[2]]), 3)

    def test_wiring_in_playbook_and_inventory(self):
        import yaml
        tasks = yaml.safe_load((ROOT / "roles/netbox_sync/tasks/sync_to_netbox.yml").read_text())
        names = [t["name"] for t in tasks]
        self.assertLess(names.index("Rename the existing NetBox device found by serial number"),
                        names.index("Create or update device record"))
        task = tasks[names.index("Rename the existing NetBox device found by serial number")]["netbox_device_rename"]
        self.assertIn("device_serial", task["serial"])
        self.assertIn("netbox_sync_registry_names", task["protected_names"])
        self.assertIn('"netbox_sync_registry_names": [row["name"] for row in rows]', (ROOT / "webui/app.py").read_text())


if __name__ == "__main__":
    unittest.main()
