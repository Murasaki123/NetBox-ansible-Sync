import importlib.util
import io
import json
import sys
import unittest
import urllib.error
import urllib.parse
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("netbox_prefix_sync", ROOT / "roles/netbox_sync/library/netbox_prefix_sync.py")
mod = importlib.util.module_from_spec(spec)
sys.modules["netbox_prefix_sync"] = mod
spec.loader.exec_module(mod)
BASE = "https://nb.example"


class Resp:
    def __init__(self, payload):
        self._raw = json.dumps(payload).encode()

    def read(self):
        return self._raw

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


class Fake:
    def __init__(self, prefixes=None, legacy=False, vlans=None):
        self.vlans = list(vlans or [])
        self.prefixes = list(prefixes or [])
        self.legacy = legacy
        self.posts = []

    def __call__(self, req, timeout=None, context=None):
        url, method = req.full_url, req.get_method()
        parsed = urllib.parse.urlparse(url)
        query = urllib.parse.parse_qs(parsed.query)
        if method == "GET" and parsed.path == "/api/dcim/sites/":
            return Resp({"results": [{"id": 3, "name": "P24", "slug": "p24"}], "next": None})
        if method == "GET" and parsed.path == "/api/ipam/vlans/":
            rows = [v for v in self.vlans if str(v["vid"]) == query["vid"][0] and str(v["site"]["id"]) == query["site_id"][0]]
            return Resp({"results": rows, "next": None})
        if method == "GET" and parsed.path == "/api/ipam/prefixes/":
            return Resp({"results": [p for p in self.prefixes if p["prefix"] == query["prefix"][0]], "next": None})
        if method == "POST" and parsed.path == "/api/ipam/prefixes/":
            body = json.loads(req.data)
            if self.legacy and "scope_type" in body:
                raise urllib.error.HTTPError(url, 400, "bad", {}, io.BytesIO(b'{"scope_type":["unknown field"]}'))
            self.posts.append(body)
            self.prefixes.append({"prefix": body["prefix"]})
            return Resp(body)
        raise AssertionError((method, url))


def run(fake, addresses):
    return mod.sync_prefixes(mod.Api(BASE, "t", urlopen=fake), "P24", addresses)


A = lambda ip, p: {"ip": ip, "prefix": p, "interface": "x"}  # noqa: E731


class PrefixTests(unittest.TestCase):
    def test_networks_derived_and_deduplicated(self):
        nets, skipped = mod.networks_from([A("10.1.2.5", "24"), A("10.1.2.9", 24), A("10.255.255.2", "24"), A("192.168.0.1", "30")])
        self.assertEqual([str(n) for n in nets], ["10.1.2.0/24", "10.255.255.0/24", "192.168.0.0/30"])
        self.assertEqual(skipped, [])

    def test_hosts_loopback_default_and_garbage_are_not_prefixes(self):
        nets, skipped = mod.networks_from([A("10.0.0.1", "32"), A("127.0.0.1", "8"), A("169.254.1.1", "16"),
                                           A("0.0.0.0", "0"), A("fe80::1", "64"), A("bad", "24"), {"ip": "1.1.1.1"}])
        self.assertEqual(nets, [])
        self.assertEqual(len(skipped), 2)

    def test_create_with_site_scope_then_idempotent(self):
        fake = Fake()
        first = mod.sync_prefixes(mod.Api(BASE, "t", urlopen=fake), "P24", [A("10.1.2.5", "24"), A("10.1.2.6", "24")], source_device="SW1")
        self.assertEqual((first["created"], first["errors"]), (["10.1.2.0/24"], []))
        self.assertEqual(fake.posts, [{"prefix": "10.1.2.0/24", "status": "active", "scope_type": "dcim.site", "scope_id": 3,
                                      "comments": "Источник: SW1 (x, 10.1.2.5/24)\nИсточник: SW1 (x, 10.1.2.6/24)"}])
        second = run(fake, [A("10.1.2.5", "24")])
        self.assertEqual((second["created"], second["unchanged"]), ([], 1))
        self.assertEqual(len(fake.posts), 1)

    def test_existing_prefix_anywhere_is_left_alone(self):
        fake = Fake(prefixes=[{"prefix": "10.9.0.0/16", "vrf": {"id": 5}}])
        res = run(fake, [A("10.9.0.1", "16")])
        self.assertEqual((res["created"], res["unchanged"], fake.posts), ([], 1, []))

    def test_old_netbox_falls_back_to_site_field(self):
        fake = Fake(legacy=True)
        res = run(fake, [A("10.1.2.5", "24")])
        self.assertEqual(res["errors"], [])
        self.assertEqual(fake.posts, [{"prefix": "10.1.2.0/24", "status": "active", "site": 3,
                                      "comments": "Источник: x, 10.1.2.5/24"}])

    def test_vlan_from_interface_name(self):
        for name, vlan in (("Vlanif100", 100), ("vlan 25", 25), ("gi1/0/2.1010", 1010), ("Eth-Trunk1.640", 640),
                           ("GigabitEthernet0/0/1", None), ("Eth-Trunk1", None), ("Vlanif5000", None), ("", None), (None, None)):
            self.assertEqual(mod.vlan_from_interface(name), vlan, name)

    def test_comment_has_source_and_vlan(self):
        text = mod.build_comment("FW1", [{"ip": "10.1.2.5", "prefix": "24", "interface": "Vlanif100"},
                                         {"ip": "10.1.2.6", "prefix": "24", "interface": "Eth-Trunk1.100"}])
        self.assertEqual(text, "Источник: FW1 (Vlanif100, 10.1.2.5/24)\nИсточник: FW1 (Eth-Trunk1.100, 10.1.2.6/24)\nVlan: 100")

    def test_prefix_gets_the_vlan_of_its_interfaces(self):
        fake = Fake(vlans=[{"id": 77, "vid": 785, "site": {"id": 3}}, {"id": 78, "vid": 1010, "site": {"id": 3}},
                           {"id": 79, "vid": 1010, "site": {"id": 3}}, {"id": 80, "vid": 20, "site": {"id": 99}}])
        res = mod.sync_prefixes(mod.Api(BASE, "t", urlopen=fake), "P24", [
            {"ip": "10.10.78.1", "prefix": 30, "interface": "gi1/0/1.785"},   # one VLAN -> linked
            {"ip": "10.10.10.1", "prefix": 24, "interface": "gi1/0/2.1010"},  # two VLANs with this id -> ambiguous, not linked
            {"ip": "10.20.0.1", "prefix": 24, "interface": "gi1/0/2.20"},     # only on another site -> not linked
            {"ip": "10.30.0.1", "prefix": 24, "interface": "gi1/0/3"}])      # no VLAN in the name
        self.assertEqual((res["errors"], res["vlan_linked"], len(fake.posts)), ([], 1, 4))
        linked = {p["prefix"]: p.get("vlan") for p in fake.posts}
        self.assertEqual(linked, {"10.10.78.0/30": 77, "10.10.10.0/24": None, "10.20.0.0/24": None, "10.30.0.0/24": None})

    def test_different_vlans_in_one_network_are_not_guessed(self):
        fake = Fake(vlans=[{"id": 1, "vid": 5, "site": {"id": 3}}, {"id": 2, "vid": 6, "site": {"id": 3}}])
        mod.sync_prefixes(mod.Api(BASE, "t", urlopen=fake), "P24", [
            {"ip": "10.1.1.1", "prefix": 24, "interface": "gi1/0/1.5"}, {"ip": "10.1.1.2", "prefix": 24, "interface": "gi1/0/1.6"}])
        self.assertNotIn("vlan", fake.posts[0])

    def test_no_addresses_means_no_api_calls(self):
        fake = Fake()
        res = mod.sync_prefixes(mod.Api(BASE, "t", urlopen=lambda *a, **k: (_ for _ in ()).throw(AssertionError("called"))), "P24", [A("1.1.1.1", "32")])
        self.assertEqual(res["created"], [])

    def test_role_wiring(self):
        text = (ROOT / "roles/netbox_sync/tasks/sync_to_netbox.yml").read_text()
        self.assertIn("netbox_prefix_sync:", text)
        self.assertIn("failed_when: false", text.split("netbox_prefix_sync:")[1].split("- name:")[0])


if __name__ == "__main__":
    unittest.main()
