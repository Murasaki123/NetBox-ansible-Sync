from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]


class ESRAdministrationUiTests(unittest.TestCase):
    def test_interface_and_route_panes_have_independent_vrf_selectors(self):
        html = (ROOT / 'webui' / 'index.html').read_text(encoding='utf-8')
        self.assertIn('id="esr-vrf-interfaces"', html)
        self.assertIn('id="esr-vrf-routes"', html)
        self.assertIn('function esrRenderInterfaces(parsed)', html)
        self.assertIn('function esrRenderRoutes(parsed)', html)
        self.assertIn("(x.vrf||'VRF0')===vrf", html)

    def test_raw_config_is_compact_and_interface_heading_uses_requested_wording(self):
        html = (ROOT / 'webui' / 'index.html').read_text(encoding='utf-8')
        self.assertIn('#esr-raw{max-height:180px}', html)
        self.assertIn('Интерфейсы и саб-интерфейсы', html)
        self.assertNotIn('Интерфейсы и подынтерфейсы', html)

    def test_nat_pool_details_are_inline_and_not_a_separate_pane(self):
        html = (ROOT / 'webui' / 'index.html').read_text(encoding='utf-8')
        self.assertIn('function esrPoolRef(name,parsed)', html)
        self.assertNotIn('esrRulesetRef', html)
        self.assertIn("x.ruleset||'—'", html)
        self.assertNotIn('data-esr-tab="nat-pools"', html)
        self.assertNotIn('id="esr-pane-nat-pools"', html)

    def test_rule_references_can_open_network_service_acl_and_route_map_objects(self):
        html = (ROOT / 'webui' / 'index.html').read_text(encoding='utf-8')
        self.assertIn('function esrRuleRefs(value,parsed)', html)
        self.assertIn('function esrAclRef(name,parsed)', html)
        self.assertIn('function esrRouteMapRef(name,parsed)', html)

    def test_vrrp_is_collapsed_to_id_and_expands_individual_fields(self):
        html = (ROOT / 'webui' / 'index.html').read_text(encoding='utf-8')
        self.assertIn('function esrVrrpRef(groups,legacy)', html)
        for field in ("['id',v.id]", "['ip',v.ip]", "['priority',v.priority]", "['group',v.group]"):
            self.assertIn(field, html)
        self.assertIn('esrRich(esrVrrpRef(x.vrrp_groups,x.vrrp))', html)

    def test_pbr_is_expanded_from_interface_and_not_duplicated_in_routing(self):
        html = (ROOT / 'webui' / 'index.html').read_text(encoding='utf-8')
        self.assertIn('esrRich(esrRouteMapRef(x.policy_route_map,parsed))', html)
        self.assertIn('<strong>rule:</strong>', html)
        self.assertIn('<strong>match:</strong>', html)
        self.assertIn('<strong>action:</strong>', html)
        self.assertNotIn('id="esr-route-maps"', html)
        self.assertNotIn('Route-map / PBR</h3>', html)

    def test_esr_registry_refresh_is_automatic_and_manual_button_is_removed(self):
        html = (ROOT / 'webui' / 'index.html').read_text(encoding='utf-8')
        self.assertNotIn('id="esr-refresh"', html)
        self.assertIn('startEsrRegistryAutoRefresh()', html)
        self.assertIn('loadEsrAdminDevices(false)', html)
        self.assertIn('15000', html)

    def test_zone_and_pbr_references_show_related_objects(self):
        html = (ROOT / 'webui' / 'index.html').read_text(encoding='utf-8')
        self.assertIn('function esrZoneRef(name,parsed)', html)
        self.assertIn('Где используется:', html)
        self.assertIn('esrRich(esrZoneRef(x.zone,parsed))', html)

    def test_dependency_lists_are_compact_and_expand_on_demand(self):
        html = (ROOT / 'webui' / 'index.html').read_text(encoding='utf-8')
        self.assertIn('function esrUsageDisclosure(label,items)', html)
        self.assertIn('<details class="esr-usage">', html)
        self.assertIn('${esc(label)}: ${values.length}', html)
        self.assertIn('Интерфейсы\',ifaces', html)
        self.assertIn('Интерфейсы\',used', html)
        self.assertIn('Правила NAT\',pool.used_in', html)
        self.assertIn('Использования\',item.used_in', html)
        self.assertIn('Использования\',x.used_in', html)
        self.assertIn('Не используется', html)
        self.assertIn('esr-usage-list', html)

    def test_zone_and_route_map_details_do_not_print_full_interface_lists_by_default(self):
        html = (ROOT / 'webui' / 'index.html').read_text(encoding='utf-8')
        zone = html[html.index('function esrZoneRef('):html.index('function esrPoolRef(')]
        route_map = html[html.index('function esrRouteMapRef('):html.index('function esrAclRef(')]
        self.assertIn("esrUsageDisclosure('Интерфейсы',ifaces)", zone)
        self.assertNotIn("ifaces.map(esc).join('<br>')", zone)
        self.assertIn("esrUsageDisclosure('Интерфейсы',used)", route_map)
        self.assertNotIn("used.map(esc).join('<br>')", route_map)

    def test_vlans_have_a_dedicated_navigation_pane_and_are_not_listed_above_interfaces(self):
        html = (ROOT / 'webui' / 'index.html').read_text(encoding='utf-8')
        self.assertIn('data-esr-tab="vlans"', html)
        self.assertIn('id="esr-pane-vlans"', html)
        self.assertIn('id="esr-vlan-table"', html)
        self.assertIn('function esrRenderVlans(parsed)', html)
        self.assertIn('function esrVlanContains(spec,id)', html)
        self.assertIn('tagged|untagged', html)
        interface_pane = html[html.index('id="esr-pane-interfaces"'):html.index('id="esr-pane-vlans"')]
        self.assertNotIn('esr-vlans', interface_pane)
        self.assertIn("esrRenderVlans(d.parsed)", html)

    def test_vlan_inventory_shows_bridge_pvid_and_allowed_port_membership(self):
        html = (ROOT / 'webui' / 'index.html').read_text(encoding='utf-8')
        vlan_renderer = html[html.index('function esrRenderVlans('):html.index('function esrRenderRoutes(')]
        for heading in ("'VLAN ID'", "'Имя'", "'Bridge-интерфейсы'", "'PVID на портах'", "'Разрешён на портах'"):
            self.assertIn(heading, vlan_renderer)
        self.assertIn('esrUsageDisclosure', vlan_renderer)

    def test_security_zone_names_are_clickable_in_security_zones_table(self):
        html = (ROOT / 'webui' / 'index.html').read_text(encoding='utf-8')
        self.assertIn("d.parsed.zones.map(x=>[esrRich(esrZoneRef(x.name,d.parsed))", html)
