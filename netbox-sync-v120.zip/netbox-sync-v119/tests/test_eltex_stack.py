import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests"))

import yaml  # noqa: E402

from filter_plugins import netbox_sync_parsers as f  # noqa: E402
from webui import netbox_post_sync as nps  # noqa: E402
from test_netbox_post_sync import FakeNetBox, client_for  # noqa: E402

INVENTORY = '''NAME: "1" DESCR: "MES5324A 24-port 10G"
PID: MES5324A rev.B  VID: 0  SN: ESE7000244

NAME: "2" DESCR: "MES5324A 24-port 10G"
PID: MES5324A rev.B  VID: 0  SN: ESE7000247
'''
SINGLE = '''NAME: "1" DESCR: "MES5324A 24-port 10G"
PID: MES5324A rev.B  VID: 0  SN: ESE7000244
'''


def units_of(text):
    return f.build_eltex_stack_units(f.parse_eltex_inventory(text))


class FilterTests(unittest.TestCase):
    def test_units_of_stack_and_standalone(self):
        units = units_of(INVENTORY)
        self.assertEqual([(u["unit"], u["serial"]) for u in units], [(1, "ESE7000244"), (2, "ESE7000247")])
        self.assertEqual(units[0]["model"], "MES5324A")
        self.assertEqual(len(units_of(SINGLE)), 1)

    def test_standalone_keeps_every_interface_on_the_one_device(self):
        ifaces = {"te1/0/1": {}, "te1/0/2": {}, "Po1": {}}
        self.assertEqual(f.stack_unit_interfaces(ifaces, units_of(SINGLE)), ifaces)
        self.assertEqual(f.stack_unit_interfaces(ifaces, []), ifaces)
        self.assertEqual(f.stack_unit_device_name("SW", 1, units_of(SINGLE)), "SW")

    def test_stack_splits_interfaces_by_unit(self):
        units = units_of(INVENTORY)
        ifaces = {"te1/0/1": {}, "te2/0/3": {}, "Po1": {}}
        self.assertEqual(sorted(f.stack_unit_interfaces(ifaces, units)), ["Po1", "te1/0/1"])
        self.assertEqual(sorted(f.stack_unit_interfaces(ifaces, units, 2)), ["te2/0/3"])

    def test_names_and_port_owner(self):
        units = units_of(INVENTORY)
        self.assertEqual(f.stack_unit_device_name("SW", 1, units), "SW")
        self.assertEqual(f.stack_unit_device_name("SW", 2, units), "SW-2")
        stacks = {"SW": [1, 2]}
        self.assertEqual(f.stack_port_device("SW", "te2/0/1", stacks), "SW-2")
        self.assertEqual(f.stack_port_device("sw", "te1/0/1", stacks), "sw")
        self.assertEqual(f.stack_port_device("SW", "Po1", stacks), "SW")
        self.assertEqual(f.stack_port_device("X", "te2/0/1", stacks), "X")
        self.assertEqual(f.stack_port_device("SW", "te2/0/1", {"SW": [1]}), "SW")

    def test_python_mirror_matches_filter(self):
        stacks = {"SW": [1, 2, 3]}
        for dev in ("SW", "sw", "Other"):
            for port in ("te1/0/1", "te2/0/9", "gi3/0/1", "Po1", "te4/0/1", "TenGigabitEthernet2/0/5", ""):
                self.assertEqual(f.stack_port_device(dev, port, stacks), nps.stack_port_device(dev, port, stacks), (dev, port))
        for unit in (1, 2, 3):
            self.assertEqual(f.stack_unit_device_name("SW", unit, [1, 2, 3]), nps.stack_unit_device_name("SW", unit, [1, 2, 3]))


class StackNetBox(FakeNetBox):
    def add_interface(self, device, name, type_value="1000base-t", cable=None):
        item = super().add_interface(device, name, type_value, cable)
        item["device"] = {"id": device["id"]}
        item["lag"] = None
        return item

    def __call__(self, request, timeout=None, context=None):
        if request.get_method() == "PATCH" and "/api/dcim/interfaces/" in request.full_url:
            body = json.loads(request.data)
            iid = int(request.full_url.rstrip("/").split("/")[-1])
            self.calls.append(("PATCH", request.full_url, request.get_header("Authorization")))
            for items in self.interfaces.values():
                for item in items:
                    if item["id"] == iid:
                        item["lag"] = {"id": body["lag"]}
                        return __import__("test_netbox_post_sync").FakeResponse(item)
            raise AssertionError("no interface")
        return super().__call__(request, timeout, context)


class StackChassisTests(unittest.TestCase):
    def setUp(self):
        self.fake = StackNetBox()
        self.sw, self.sw2 = self.fake.add_device("SW"), self.fake.add_device("SW-2")
        self.po = self.fake.add_interface(self.sw, "Po1", "lag")
        self.fake.add_interface(self.sw, "te1/0/1")
        self.m2 = self.fake.add_interface(self.sw2, "te2/0/1")
        self.stacks = {"SW": {"units": [1, 2], "lag_members": {"Po1": ["te1/0/1", "te2/0/1"]}}}

    def test_chassis_and_cross_unit_lag_then_idempotent(self):
        first = nps.sync_stack_chassis(client_for(self.fake), self.stacks, lambda _: None)
        self.assertEqual(first.errors, [])
        self.assertEqual(self.fake.vcs[0]["name"], "SW")
        self.assertEqual((self.sw["vc_position"], self.sw2["vc_position"]), (1, 2))
        self.assertEqual(self.fake.vcs[0]["master"], {"id": self.sw["id"]})
        self.assertEqual(self.m2["lag"], {"id": self.po["id"]})
        writes = sum(1 for c in self.fake.calls if c[0] in ("PATCH", "POST"))
        second = nps.sync_stack_chassis(client_for(self.fake), self.stacks, lambda _: None)
        self.assertEqual(second.errors, [])
        self.assertEqual(sum(1 for c in self.fake.calls if c[0] in ("PATCH", "POST")), writes)

    def test_single_unit_creates_no_chassis(self):
        result = nps.sync_stack_chassis(client_for(self.fake), {"SW": {"units": [1], "lag_members": {}}}, lambda _: None)
        self.assertEqual((result.created, result.errors, self.fake.vcs), (0, [], []))

    def test_missing_unit_device_is_skipped_not_failed(self):
        fake = StackNetBox()
        fake.add_device("SW")
        result = nps.sync_stack_chassis(client_for(fake), self.stacks, lambda _: None)
        self.assertEqual((result.skipped, result.errors, fake.vcs), (1, [], []))


class StaticWiringTests(unittest.TestCase):
    def test_role_files(self):
        tasks = yaml.safe_load((ROOT / "roles/netbox_sync/tasks/sync_stack_unit.yml").read_text())
        names = " ".join(t.get("name", "") for t in tasks)
        self.assertGreaterEqual(len(tasks), 4)
        text = (ROOT / "roles/netbox_sync/tasks/sync_to_netbox.yml").read_text()
        self.assertIn("sync_stack_unit.yml", text)
        self.assertIn("stack_units | default([]) | length) > 1", text)
        self.assertIn("stack_unit_interfaces", text)
        self.assertIn("stack_port_device", text)
        self.assertTrue(names)

    def test_app_wiring(self):
        app = (ROOT / "webui/app.py").read_text()
        for needle in ("netbox_sync_stacks", "_stack_registry", "sync_stack_chassis", "stack_port_device"):
            self.assertIn(needle, app)

    def test_standalone_does_not_trigger_unit_loop(self):
        text = (ROOT / "roles/netbox_sync/tasks/sync_to_netbox.yml").read_text()
        self.assertIn("(stack_units | default([]))[1:]", text)


if __name__ == "__main__":
    unittest.main()
