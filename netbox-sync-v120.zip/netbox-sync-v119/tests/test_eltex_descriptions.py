"""Eltex MES `show interfaces description`: descriptions and admin state reach the interface facts."""
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from filter_plugins import netbox_sync_parsers as f  # noqa: E402

SAMPLE = """Port       Port Mode (VLAN)         State State       Description
---------- ------------------------ ----- ----------- -----------
te1/0/1    Trunk                    Up    Up          RMIAC-S139-ELX-SW-23-3
te1/0/2    Access (2770)            Up    Down        ITS_Upravtodor
te1/0/23   Access (1)               Up    Not Present
te2/0/5    Access (1)               Down  Down        spare port

Ch         Port Mode (VLAN)         State State       Description
---------- ------------------------ ----- ----------- -----------
Po1        Trunk                    Up    Up          USG6670_FW1
Po6        Access (1)               Up    Not Present
Po8        Trunk                    Up    Down        Continent
"""


class EltexDescriptionTests(unittest.TestCase):
    def test_physical_and_port_channel_descriptions(self):
        r = f.parse_eltex_interface_descriptions(SAMPLE)
        self.assertEqual(r["te1/0/1"]["description"], "RMIAC-S139-ELX-SW-23-3")
        self.assertEqual(r["te1/0/2"]["description"], "ITS_Upravtodor")
        self.assertEqual(r["te2/0/5"]["description"], "spare port")
        self.assertEqual(r["te2/0/5"]["admin_status"], "disabled")
        self.assertEqual(r["te1/0/2"]["admin_status"], "enabled")
        self.assertEqual(r["Po1"]["description"], "USG6670_FW1")
        self.assertEqual(r["Po8"]["description"], "Continent")
        self.assertEqual(r["Po6"]["description"], "")
        self.assertEqual(r["te1/0/23"]["operstatus"], "not_present")

    def test_role_collects_description_table_not_the_failing_command(self):
        text = (ROOT / "roles/netbox_sync/tasks/eltex.yml").read_text()
        self.assertIn("command: show interfaces description", text)
        self.assertNotIn("command: show interfaces Port-Channel", text)


if __name__ == "__main__":
    unittest.main()
