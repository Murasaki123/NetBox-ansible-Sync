"""ESR VRRP: the virtual address (VIP) becomes an IP object with role vrrp and is never taken from the other node."""
import sys
import unittest
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from filter_plugins import netbox_sync_parsers as f  # noqa: E402

OWN = [{"ip": "10.10.10.251", "prefix": "24", "interface": "gi1/0/2.1010"}]
DETAIL = [{"id": 10, "interface": "gi1/0/2.1010", "virtual_ip": "10.10.10.1/24", "state": "Master"}]


def lookup(item, results):
    return {"item": item, "json": {"results": results}}


class VipEntries(unittest.TestCase):
    def test_vip_entry(self):
        self.assertEqual(f.build_vrrp_ip_entries(DETAIL, OWN),
                         [{"ip": "10.10.10.1", "prefix": "24", "interface": "gi1/0/2.1010", "role": "vrrp"}])

    def test_mask_taken_from_own_address_when_missing(self):
        out = f.build_vrrp_ip_entries([{"interface": "gi1/0/2.1010", "virtual_ip": "10.10.10.1"}], OWN)
        self.assertEqual(out[0]["prefix"], "24")

    def test_garbage_duplicates_and_known_are_left_out(self):
        details = DETAIL + DETAIL + [{"interface": "", "virtual_ip": "10.1.1.1/24"}, {"interface": "x", "virtual_ip": "bad"},
                                     {"interface": "gi1/0/9", "virtual_ip": "10.9.9.9"}, "junk", {}]
        self.assertEqual(len(f.build_vrrp_ip_entries(details, OWN)), 1)
        self.assertEqual(f.build_vrrp_ip_entries(DETAIL, OWN + [{"ip": "10.10.10.1", "prefix": "24", "interface": "gi1/0/2.1010"}]), [])
        self.assertEqual(f.build_vrrp_ip_entries(None, None), [])


class PlannerVip(unittest.TestCase):
    VIP = {"ip": "10.10.10.1", "prefix": "24", "interface": "gi1/0/2.1010", "role": "vrrp"}

    def test_new_vip_is_created_with_role(self):
        plan = f.plan_ip_assignments([lookup(self.VIP, [])], {"gi1/0/2.1010": 7})
        self.assertEqual(plan[0]["action"], "create")
        self.assertEqual(plan[0]["body"]["role"], "vrrp")
        self.assertEqual(plan[0]["body"]["assigned_object_id"], 7)

    def test_vip_on_the_other_node_is_not_moved(self):
        other = {"id": 50, "address": "10.10.10.1/24", "assigned_object_id": 99, "assigned_object_type": "dcim.interface"}
        plan = f.plan_ip_assignments([lookup(self.VIP, [other])], {"gi1/0/2.1010": 7})
        self.assertEqual((plan[0]["action"], plan[0]["id"]), ("create", None))

    def test_plain_address_still_moves_as_before(self):
        plain = dict(self.VIP)
        plain.pop("role")
        other = {"id": 50, "address": "10.10.10.1/24", "assigned_object_id": 99, "assigned_object_type": "dcim.interface"}
        plan = f.plan_ip_assignments([lookup(plain, [other])], {"gi1/0/2.1010": 7})
        self.assertEqual((plan[0]["action"], plan[0]["id"]), ("update", 50))
        self.assertNotIn("role", plan[0]["body"])

    def test_own_vip_is_reused_and_gets_the_role(self):
        mine = {"id": 51, "address": "10.10.10.1/24", "assigned_object_id": 7, "assigned_object_type": "dcim.interface"}
        plan = f.plan_ip_assignments([lookup(self.VIP, [mine])], {"gi1/0/2.1010": 7})
        self.assertEqual((plan[0]["action"], plan[0]["id"], plan[0]["body"]["role"]), ("update", 51, "vrrp"))


class Wiring(unittest.TestCase):
    def test_task_added_after_vrrp_details(self):
        tasks = yaml.safe_load((ROOT / "roles/netbox_sync/tasks/eltex_esr.yml").read_text())
        names = [t.get("name", "") for t in tasks]
        self.assertLess(names.index("Parse ESR VRRP detail facts (optional)"), names.index("Add VRRP virtual addresses to the address list"))
        self.assertIn("build_vrrp_ip_entries", str(tasks[names.index("Add VRRP virtual addresses to the address list")]))


if __name__ == "__main__":
    unittest.main()
