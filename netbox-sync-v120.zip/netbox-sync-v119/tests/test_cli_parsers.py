import re
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "filter_plugins"))
from netbox_sync_parsers import (  # noqa: E402
    parse_eltex_interfaces,
    parse_eltex_esr_version,
    parse_eltex_esr_system,
    parse_eltex_esr_interfaces,
    parse_eltex_esr_descriptions,
    parse_eltex_esr_ip_interfaces,
    parse_eltex_esr_vlans,
    parse_eltex_esr_vrrp,
    parse_eltex_esr_routes,
    parse_eltex_esr_failover,
    parse_eltex_version,
    parse_eltex_system,
    parse_eltex_inventory,
    parse_eltex_interface_descriptions,
    parse_eltex_lag_members,
    parse_eltex_lag_states,
    apply_eltex_lag_states,
    parse_eltex_lldp,
    parse_eltex_vlans,
    validate_eltex_vlan_memberships,
    filter_eltex_configured_port_channels,
    filter_eltex_vlan_port_channels,
    parse_cisco_interfaces,
    parse_cisco_interface_descriptions,
    parse_cisco_inventory,
    parse_cisco_lag_members,
    parse_cisco_lldp,
    parse_cisco_version,
    parse_snr_interfaces,
    parse_snr_running_config,
    parse_snr_vlans,
    parse_snr_lag_members,
    parse_snr_lldp,
    parse_snr_version,
    parse_huawei_device_model,
    parse_huawei_hostname,
    build_huawei_usg6670_report,
    parse_huawei_interfaces,
    parse_huawei_ip_interface_brief,
    build_ip_list_from_interfaces,
    FilterModule,
    find_duplicate_interface_names,
    is_valid_ip_with_prefix,
    plan_ip_assignments,
    parse_huawei_lag_members,
    parse_huawei_running_config,
    parse_huawei_vlans,
    parse_huawei_lldp,
    parse_huawei_version,
    parse_vlans,
)


class CliParserTests(unittest.TestCase):

    def test_duplicate_netbox_interface_names_are_reported_with_ids(self):
        result = find_duplicate_interface_names([
            {"id": 10, "name": "Eth-Trunk2.2840"},
            {"id": 11, "name": "Eth-Trunk2.2840"},
            {"id": 12, "name": "GigabitEthernet1/0/1"},
            {"id": 13, "name": ""},
        ])
        self.assertEqual(result, {"Eth-Trunk2.2840": [10, 11]})
        self.assertEqual(FilterModule().filters()["find_duplicate_interface_names"], find_duplicate_interface_names)

    def test_usg6635e_lldp_brief_real_output_is_parsed(self):
        text = (Path(__file__).parent / "fixtures" / "usg6635e_lldp_brief.txt").read_text()
        got = {(i["local_interface"], i["chassis_id"], i["neighbor_interface"]) for i in parse_huawei_lldp(text)}
        self.assertEqual(got, {
            ("XGigabitEthernet0/0/1", "cc9d-a27a-ac40", "te1/0/20"),
            ("XGigabitEthernet0/0/0", "cc9d-a27a-ac40", "te2/0/20"),
            ("MEth0/0/0", "7079-b3f2-4140", "Gi3/0/47"),
            ("GigabitEthernet0/0/15", "7079-b3f2-4140", "Gi8/0/39"),
            ("GigabitEthernet0/0/14", "44a1-913f-fb80", "GigabitEthernet0/0/0"),
            ("GigabitEthernet0/0/1", "44a1-9169-af15", "GigabitEthernet0/0/1"),
            ("GigabitEthernet0/0/0", "44a1-9169-af15", "GigabitEthernet0/0/0"),
        })  # interfaces with 0 neighbors produce nothing

    def test_usg6635e_collects_lldp_like_usg6670(self):
        import yaml
        root = Path(__file__).resolve().parents[1] / "roles/netbox_sync/tasks"
        tasks = yaml.safe_load((root / "huawei.yml").read_text())
        collect = next(t for t in tasks if t.get("name") == "Collect Huawei USG LLDP neighbors when supported (read-only)")
        self.assertEqual(collect["ansible.netcommon.cli_command"]["command"], "display lldp neighbor brief")
        self.assertEqual(collect["when"], "device_profile == 'huawei_usg6635e'")
        self.assertFalse(collect["failed_when"])
        parse = next(t for t in tasks if t.get("name") == "Parse Huawei USG LLDP neighbors")
        self.assertIn("parse_huawei_lldp", parse["ansible.builtin.set_fact"]["lldp_neighbors"])
        self.assertIn("usg6670_lldp_raw_text", parse["ansible.builtin.set_fact"])
        report = (root / "collect_facts.yml").read_text()
        self.assertIn("'lldp_raw':", report)
        self.assertIn("usg6670_lldp_raw_text", report)
        self.assertIn("'lldp_neighbors': lldp_neighbors | default([])", report)

    def test_usg_hrp_standby_refusal_is_not_a_failure_and_is_visible_in_the_report(self):
        import yaml
        import jinja2
        root = Path(__file__).resolve().parents[1] / "roles/netbox_sync/tasks"
        env = jinja2.Environment(undefined=jinja2.Undefined)
        env.tests["search"] = lambda value, pattern: re.search(pattern, value) is not None
        refusal = "The device is in HRP stanby state, so this command can not be executed."
        for name in ("huawei.yml", "huawei_usg6670.yml"):
            tasks = yaml.safe_load((root / name).read_text())
            collect = next(t for t in tasks if "display lldp neighbor brief" in str(t.get("ansible.netcommon.cli_command", "")))
            self.assertFalse(collect["failed_when"], name)  # refusal must not fail the collection
            keep = next(t for t in tasks if "usg6670_lldp_raw_text" in t.get("ansible.builtin.set_fact", {}))
            # the error text (module `msg`, no stdout) must reach the report
            raw = env.from_string(keep["ansible.builtin.set_fact"]["usg6670_lldp_raw_text"]).render(usg6670_lldp_raw={"failed": False, "msg": refusal})
            self.assertEqual(raw, refusal, name)
            ok = env.from_string(keep["ansible.builtin.set_fact"]["usg6670_lldp_raw_text"]).render(usg6670_lldp_raw={"stdout": "Interface X has 0 Neighbors:"})
            self.assertEqual(ok, "Interface X has 0 Neighbors:")
            note = next(t for t in tasks if t.get("name") == "Note that LLDP is unavailable on an HRP standby node")
            cond = [c for c in (note["when"] if isinstance(note["when"], list) else [note["when"]]) if "search" in c][0]
            expr = cond.replace("usg6670_lldp_raw_text | default('') | lower", "(text | lower)")
            for text, expected in ((refusal, True), ("HRP STANDBY state", True), ("Interface X has 0 Neighbors:", False), ("", False)):
                self.assertEqual(env.compile_expression(expr)(text=text), expected, (name, text))
            self.assertEqual(parse_huawei_lldp(refusal), [])

    def _lookup(self, ip, prefix, interface, results=None, **extra):
        return {"item": {"ip": ip, "prefix": prefix, "interface": interface}, "json": {"count": len(results or []), "results": results or []}, **extra}

    def test_ip_plan_creates_updates_and_never_duplicates_a_host(self):
        ids = {"Eth-Trunk0": 11, "Vlanif1": 12}
        plan = plan_ip_assignments([
            self._lookup("10.0.0.1", 24, "Eth-Trunk0"),
            self._lookup("10.0.1.1", 24, "Eth-Trunk0", [{"id": 5, "address": "10.0.1.1/24", "assigned_object_id": 99}]),
            self._lookup("10.0.2.1", 30, "Vlanif1", [{"id": 6, "address": "10.0.2.1/24", "assigned_object_id": None}]),
            self._lookup("10.0.3.1", 30, "Vlanif1", [{"id": 7, "address": "10.0.3.1/24", "assigned_object_id": 12}]),
            self._lookup("2001:db8::1", 64, "Vlanif1"),
            self._lookup("2001:db8::2", 64, "Vlanif1", [{"id": 8, "address": "2001:0db8:0:0:0:0:0:2/64", "assigned_object_id": 12}]),
        ], ids)
        by = {p["label"]: p for p in plan}
        self.assertEqual((by["10.0.0.1/24"]["action"], by["10.0.0.1/24"]["body"]["address"], by["10.0.0.1/24"]["body"]["assigned_object_id"]), ("create", "10.0.0.1/24", 11))
        self.assertEqual((by["10.0.1.1/24"]["action"], by["10.0.1.1/24"]["id"], "address" in by["10.0.1.1/24"]["body"]), ("update", 5, False))
        self.assertEqual((by["10.0.2.1/30"]["action"], by["10.0.2.1/30"]["id"], by["10.0.2.1/30"]["body"]["address"]), ("update", 6, "10.0.2.1/30"))
        self.assertEqual((by["10.0.3.1/30"]["action"], by["10.0.3.1/30"]["body"]["address"]), ("update", "10.0.3.1/30"))
        self.assertEqual(by["2001:db8::1/64"]["action"], "create")
        self.assertEqual((by["2001:db8::2/64"]["action"], by["2001:db8::2/64"]["id"]), ("update", 8))

    def test_ip_plan_same_host_with_other_mask_on_another_interface_is_left_to_netbox(self):
        # 10.255.255.2/24 belongs to another interface; collected 10.255.255.2/30. NetBox decides: with
        # ENFORCE_GLOBAL_UNIQUE off the POST succeeds, otherwise NetBox refuses and the run reports it.
        # The other object is never modified or taken over.
        plan = plan_ip_assignments([self._lookup("10.255.255.2", 30, "Eth-Trunk0", [{"id": 3, "address": "10.255.255.2/24", "assigned_object_id": 77}])], {"Eth-Trunk0": 1})
        self.assertEqual((plan[0]["action"], plan[0]["id"], plan[0]["body"]["address"], plan[0]["body"]["assigned_object_id"]), ("create", None, "10.255.255.2/30", 1))

    def test_ip_plan_is_stable_when_both_masks_legitimately_exist(self):
        # second run after duplicates were allowed: /24 on the other pair, /30 on this interface
        both = [{"id": 3, "address": "10.255.255.2/24", "assigned_object_id": 77}, {"id": 4, "address": "10.255.255.2/30", "assigned_object_id": 1}]
        plan = plan_ip_assignments([self._lookup("10.255.255.2", 30, "Eth-Trunk0", both)], {"Eth-Trunk0": 1})
        self.assertEqual((plan[0]["action"], plan[0]["id"], "address" in plan[0]["body"]), ("update", 4, False))

    def test_ip_plan_with_duplicates_allowed_gives_every_ha_member_its_own_object(self):
        ids = {"Eth-Trunk0": 1}
        node1_owns = {"id": 10, "address": "10.0.0.1/24", "assigned_object_id": 500, "assigned_object_type": "dcim.interface"}
        # node 2 (interface id 1) sees the object of node 1: it must NOT be moved, a second one is created
        plan = plan_ip_assignments([self._lookup("10.0.0.1", 24, "Eth-Trunk0", [node1_owns])], ids, None, True)
        self.assertEqual((plan[0]["action"], plan[0]["id"], plan[0]["body"]["assigned_object_id"]), ("create", None, 1))
        # without the switch the old behavior stays: the object is re-assigned
        plan = plan_ip_assignments([self._lookup("10.0.0.1", 24, "Eth-Trunk0", [node1_owns])], ids)
        self.assertEqual((plan[0]["action"], plan[0]["id"]), ("update", 10))
        # second run: both objects exist, each node reuses its own
        mine = {"id": 11, "address": "10.0.0.1/24", "assigned_object_id": 1, "assigned_object_type": "dcim.interface"}
        plan = plan_ip_assignments([self._lookup("10.0.0.1", 24, "Eth-Trunk0", [node1_owns, mine])], ids, None, True)
        self.assertEqual((plan[0]["action"], plan[0]["id"]), ("update", 11))
        # a free object with this address is adopted, an object of a non-interface owner is left alone
        free = {"id": 12, "address": "10.0.0.1/24", "assigned_object_id": None}
        plan = plan_ip_assignments([self._lookup("10.0.0.1", 24, "Eth-Trunk0", [node1_owns, free])], ids, None, True)
        self.assertEqual((plan[0]["action"], plan[0]["id"]), ("update", 12))
        vm = {"id": 13, "address": "10.0.0.1/24", "assigned_object_id": 1, "assigned_object_type": "virtualization.vminterface"}
        plan = plan_ip_assignments([self._lookup("10.0.0.1", 24, "Eth-Trunk0", [vm])], ids, None, True)
        self.assertEqual(plan[0]["action"], "create")
        # two objects on the same interface are ambiguous, never guessed
        plan = plan_ip_assignments([self._lookup("10.0.0.1", 24, "Eth-Trunk0", [mine, dict(mine, id=14)])], ids, None, True)
        self.assertEqual(plan[0]["action"], "skip")

    def test_shared_ip_switch_is_wired_from_settings_to_inventory_and_playbook(self):
        root = Path(__file__).resolve().parents[1]
        app = (root / "webui/app.py").read_text()
        html = (root / "webui/index.html").read_text()
        play = (root / "roles/netbox_sync/tasks/sync_to_netbox.yml").read_text()
        self.assertIn("netbox_shared_ip_on_all_members", app)
        self.assertIn("ip_exclusions = {} if shared_ip_on_all_members else _vc_shared_ip_exclusions()", app)
        self.assertIn('"netbox_allow_duplicate_ips": shared_ip_on_all_members', app)
        self.assertIn("shared_ip_on_all_members: bool = False", app)
        self.assertIn('id="netbox-shared-ip"', html)
        self.assertIn("shared_ip_on_all_members:$('netbox-shared-ip').checked", html)
        self.assertIn("netbox_allow_duplicate_ips | default(false) | bool", play)

    def test_ip_plan_skips_ambiguous_objects_and_unusable_interfaces_and_ignores_skipped_lookups(self):
        two = [{"id": 1, "address": "10.1.1.1/24"}, {"id": 2, "address": "10.1.1.1/24"}]
        plan = plan_ip_assignments([
            self._lookup("10.1.1.1", 24, "A", two),
            self._lookup("10.1.1.2", 24, "Missing"),
            self._lookup("10.1.1.3", 24, "Dup"),
            {"item": {"ip": "10.9.9.9", "prefix": 24, "interface": "A"}, "skipped": True},
            {"item": {"ip": "10.9.9.8", "prefix": 24, "interface": "A"}},
        ], {"A": 1, "Dup": 2}, {"Dup": [2, 3]})
        self.assertEqual([p["action"] for p in plan], ["skip", "skip", "skip"])
        self.assertIn("id 1", plan[0]["reason"])
        self.assertIn("does not exist", plan[1]["reason"])
        self.assertIn("ambiguous", plan[2]["reason"])

    def test_ip_tasks_use_the_plan_and_do_not_fail_the_device_on_a_rejected_ip(self):
        import yaml
        tasks = yaml.safe_load((Path(__file__).resolve().parents[1] / "roles/netbox_sync/tasks/sync_to_netbox.yml").read_text())
        by = {t["name"]: t for t in tasks}
        create, update = by["Create IP objects using the exact NetBox interface ID"], by["Update an existing IP object using the exact NetBox interface ID"]
        self.assertEqual(create["ansible.builtin.uri"]["body"], "{{ item.body }}")
        self.assertIn(400, create["ansible.builtin.uri"]["status_code"])  # reported, not fatal
        self.assertIn(400, update["ansible.builtin.uri"]["status_code"])
        self.assertIn("{{ item.id }}", update["ansible.builtin.uri"]["url"])
        self.assertIn("Report IP addresses rejected by NetBox", by)
        self.assertIn("Report IP addresses that were not changed", by)

    def test_ip_validation_needs_no_netaddr_and_accepts_ipv4_and_ipv6(self):
        ok = [{"ip": "10.0.0.1", "prefix": 24}, {"ip": "10.0.0.1", "prefix": "32"}, {"ip": "2001:db8::1", "prefix": 64},
              {"ip": "fe80::1", "prefix": 128}]
        bad = [{"ip": "10.0.0.1", "prefix": 33}, {"ip": "10.0.0.256", "prefix": 24}, {"ip": "x", "prefix": 24},
               {"ip": "10.0.0.1", "prefix": -1}, {"ip": "10.0.0.1"}, {"ip": "2001:db8::1", "prefix": 129}, {"ip": "10.0.0.1", "prefix": "a"}]
        self.assertTrue(all(is_valid_ip_with_prefix(i) for i in ok))
        self.assertFalse(any(is_valid_ip_with_prefix(i) for i in bad))
        self.assertIn("is_valid_ip_with_prefix", FilterModule().filters())

    def test_build_ip_list_from_interface_facts_keeps_explicit_prefix_and_interface(self):
        result = build_ip_list_from_interfaces({
            "Vlanif10": {"ip_addresses": ["192.0.2.1/24", "198.51.100.2/30"]},
            "GigabitEthernet1/0/1": {"ip_addresses": ["not-an-ip", "203.0.113.9/32"]},
        })
        self.assertEqual(result, [
            {"ip": "192.0.2.1", "prefix": 24, "interface": "Vlanif10"},
            {"ip": "198.51.100.2", "prefix": 30, "interface": "Vlanif10"},
            {"ip": "203.0.113.9", "prefix": 32, "interface": "GigabitEthernet1/0/1"},
        ])

    def test_build_ip_list_deduplicates_existing_and_interface_records(self):
        result = build_ip_list_from_interfaces(
            {"Vlanif10": {"ip_addresses": ["192.0.2.1/24"]}},
            [{"ip": "192.0.2.1", "prefix": 24, "interface": "Vlanif10"}])
        self.assertEqual(len(result), 1)

    def test_huawei_ip_interface_filter_is_registered_for_ansible(self):
        filters = FilterModule().filters()
        self.assertIn("parse_huawei_ip_interface_brief", filters)
        self.assertIs(filters["parse_huawei_ip_interface_brief"], parse_huawei_ip_interface_brief)

    def test_huawei_usg_version(self):
        parsed = parse_huawei_version("""Huawei Versatile Routing Platform Software
VRP (R) Software, Version 5.170 (USG6600E V600R007C20SPC600)
USG6635E uptime is 24 weeks, 3 days, 16 hours
""")
        self.assertEqual(parsed["model"], "USG6635E")
        self.assertIn("V600R007C20SPC600", parsed["version"])

    def test_huawei_s5735_esn_output(self):
        parsed = parse_huawei_version("ESN of slot 0: 21980109384EL6000854")
        self.assertEqual(parsed["serial"], "21980109384EL6000854")

    def test_huawei_usg6670_master_esn_output(self):
        parsed = parse_huawei_version("2026-10-28 16:00:19.056 +04:00\nESN of master:210235G7G610KC000008")
        self.assertEqual(parsed["serial"], "210235G7G610KC000008")

    def test_huawei_hostname_and_usg6670_report_sections(self):
        hostname = parse_huawei_hostname("sysname DTC-HUW2_23-1\n")
        self.assertEqual(hostname, "DTC-HUW2_23-1")
        interfaces = {
            "GigabitEthernet1/0/0": {"operstatus": "up", "type": "1000base-t"},
            "GigabitEthernet1/0/1": {"operstatus": "down", "type": "1000base-t"},
            "Eth-Trunk2": {"operstatus": "up", "type": "lag"},
            "Eth-Trunk2.2": {"operstatus": "up", "type": "virtual"},
            "Eth-Trunk2.3164": {"operstatus": "down", "type": "virtual"},
            "LoopBack0": {"operstatus": "up", "type": "virtual"},
        }
        interfaces["Eth-Trunk2.2"]["ip_addresses"] = ["10.20.2.1/24"]
        report = build_huawei_usg6670_report(hostname, "SERIAL123", interfaces, {"Eth-Trunk2": ["GigabitEthernet1/0/0"]}, [{"local_interface": "GigabitEthernet1/0/0", "chassis_id": "7079-b3f2-4140", "neighbor_interface": "Te5/0/3"}])
        self.assertEqual(report["hostname"], "DTC-HUW2_23-1")
        self.assertEqual(report["serial"], "SERIAL123")
        self.assertEqual(set(report["physical_interfaces"]), {"GigabitEthernet1/0/0", "GigabitEthernet1/0/1"})
        self.assertEqual(report["eth_trunks"]["Eth-Trunk2"]["members"], ["GigabitEthernet1/0/0"])
        self.assertEqual(set(report["subinterfaces"]["Eth-Trunk2"]), {"Eth-Trunk2.2", "Eth-Trunk2.3164"})
        self.assertEqual(report["subinterfaces"]["Eth-Trunk2"]["Eth-Trunk2.2"]["ip_addresses"], ["10.20.2.1/24"])
        self.assertNotIn("LoopBack0", report["physical_interfaces"])
        self.assertEqual(report["lldp_neighbors"][0]["chassis_id"], "7079-b3f2-4140")

    def test_huawei_usg6670_subinterfaces_sorted_numerically(self):
        interfaces = {f"Eth-Trunk2.{suffix}": {"operstatus": "up", "type": "virtual"} for suffix in [3164, 12, 2, 9, 3222, 3]}
        report = build_huawei_usg6670_report("fw", "SN", interfaces, {})
        self.assertEqual(list(report["subinterfaces"]["Eth-Trunk2"]), ["Eth-Trunk2.2", "Eth-Trunk2.3", "Eth-Trunk2.9", "Eth-Trunk2.12", "Eth-Trunk2.3164", "Eth-Trunk2.3222"])

    def test_huawei_lldp_neighbor_brief_table(self):
        parsed = parse_huawei_lldp("""Local Intf       Neighbor Dev             Neighbor Intf             Exptime(s)
GE0/0/5          -                        cc9d-a25e-8e82            96
GE0/0/21         DTC-P24-HUW-SW-23-10     GE0/0/9                   105
XGE0/0/4         RIC-9410R-SW             Te7/0/11                  95
""")
        self.assertEqual(len(parsed), 3)
        self.assertEqual(parsed[0]["local_interface"], "GE0/0/5")
        self.assertEqual(parsed[0]["chassis_id"], "cc9d-a25e-8e82")
        self.assertNotIn("neighbor_device", parsed[0])
        self.assertEqual(parsed[1]["neighbor_device"], "DTC-P24-HUW-SW-23-10")
        self.assertEqual(parsed[1]["neighbor_interface"], "GE0/0/9")
        self.assertEqual(parsed[2]["neighbor_device"], "RIC-9410R-SW")
        self.assertEqual(parsed[2]["neighbor_interface"], "Te7/0/11")

    def test_huawei_s5735_expanded_lldp_neighbor_output(self):
        raw = """GigabitEthernet0/0/9 has 1 neighbor(s):
Neighbor index :1
Chassis type   :MAC address
Chassis ID     :6012-3ce8-8130
Port ID type   :Interface name
Port ID        :GigabitEthernet0/0/21
System name    :DTC-P24-HUW-SW-23.102
Management address type  :ipv4
Management address value :192.168.1.253
Expired time   :99s

GigabitEthernet0/0/21 has 1 neighbor(s):
Neighbor index :1
Chassis type   :MAC address
Chassis ID     :a8f9-4bad-a24b
Port ID type   :Locally assigned
Port ID        :gi1/0/1
System name    :AR1-COMERCIAL
Management address type  :ipv4
Management address value :10.10.23.251
Expired time   :106s

XGigabitEthernet0/0/4 has 1 neighbor(s):
Neighbor index :1
Chassis type   :MAC address
Chassis ID     :cc9d-a27a-ac40
Port ID type   :Interface name
Port ID        :te2/0/10
System name    :DTC-P24-ELX-SW
Management address type  :ipv4
Management address value :10.10.23.253
Expired time   :109s
"""
        parsed = parse_huawei_lldp(raw)
        self.assertEqual(len(parsed), 3)
        self.assertEqual(parsed[0]["local_interface"], "GigabitEthernet0/0/9")
        self.assertEqual(parsed[0]["chassis_id"], "6012-3ce8-8130")
        self.assertEqual(parsed[0]["neighbor_interface"], "GigabitEthernet0/0/21")
        self.assertEqual(parsed[0]["neighbor_device"], "DTC-P24-HUW-SW-23.102")
        self.assertEqual(parsed[1]["chassis_id"], "a8f9-4bad-a24b")
        self.assertEqual(parsed[1]["neighbor_interface"], "gi1/0/1")
        self.assertEqual(parsed[2]["local_interface"], "XGigabitEthernet0/0/4")
        self.assertEqual(parsed[2]["chassis_id"], "cc9d-a27a-ac40")
        self.assertEqual(parsed[2]["neighbor_device"], "DTC-P24-ELX-SW")

    def test_huawei_usg6670_expanded_lldp_output(self):
        raw = """Interface GigabitEthernet3/0/9 has 1 Neighbors:
Neighbor 1:
    ChassisIdSubtype: MacAddress
    ChasssisId: 7079-b3f2-4140
    PortIdSubtype: InterfaceName
    PortId: Te5/0/3
    SysCapSupported:
    SysCapEnabled: Bridge/Switch
    SysCapEnabled: Router
Interface GigabitEthernet3/0/8 has 1 Neighbors:
Neighbor 1:
    ChassisIdSubtype: MacAddress
    ChasssisId: cc9d-a27a-ac40
    PortIdSubtype: InterfaceName
    PortId: te2/0/21
    SysCapEnabled: Bridge/Switch
    SysCapEnabled: Router
Interface GigabitEthernet3/0/7 has 0 Neighbors:
Interface GigabitEthernet1/0/0 has 1 Neighbors:
Neighbor 1:
    ChassisIdSubtype: MacAddress
    ChasssisId: 24a5-2cfd-70f3
    PortIdSubtype: InterfaceName
    PortId: GigabitEthernet1/0/0
    SysCapEnabled: Router
"""
        parsed = parse_huawei_lldp(raw)
        self.assertEqual(len(parsed), 3)
        self.assertEqual(parsed[0]["local_interface"], "GigabitEthernet3/0/9")
        self.assertEqual(parsed[0]["chassis_id"], "7079-b3f2-4140")
        self.assertEqual(parsed[0]["neighbor_interface"], "Te5/0/3")
        self.assertEqual(parsed[0]["chassis_id_subtype"], "MacAddress")
        self.assertEqual(parsed[0]["port_id_subtype"], "InterfaceName")
        self.assertEqual(parsed[0]["system_capabilities"], ["Bridge/Switch", "Router"])
        self.assertEqual(parsed[1]["local_interface"], "GigabitEthernet3/0/8")
        self.assertEqual(parsed[2]["chassis_id"], "24a5-2cfd-70f3")

    def test_huawei_display_device_prefers_exact_switch_model(self):
        self.assertEqual(parse_huawei_device_model("S5735-L48P4X-A's Device status:"), "S5735-L48P4X-A")
        self.assertEqual(parse_huawei_device_model("USG6635E's Device status:"), "USG6635E")

    def test_huawei_usg_ip_interface_brief_enriches_subinterface_ip(self):
        interfaces = parse_huawei_interfaces("""Interface PHY Protocol InUti OutUti inErrors outErrors
Eth-Trunk2.2 up up 0% 0% 0 0
Eth-Trunk2.3 down down 0% 0% 0 0
""")
        enriched = parse_huawei_ip_interface_brief("""Interface                         IP Address/Mask      Physical   Protocol
Eth-Trunk2.2                      10.20.2.1/24         up         up
Eth-Trunk2.3                      unassigned           down       down
""", interfaces)
        self.assertEqual(enriched["Eth-Trunk2.2"]["ip_addresses"], ["10.20.2.1/24"])
        self.assertEqual(enriched["Eth-Trunk2.2"]["operstatus"], "up")
        self.assertEqual(enriched["Eth-Trunk2.3"]["ip_addresses"], [])
        self.assertEqual(enriched["Eth-Trunk2.3"]["operstatus"], "down")

    def test_huawei_interfaces_keep_aggregates_subinterfaces_and_physical_members(self):
        parsed = parse_huawei_interfaces("""Interface PHY Protocol InUti OutUti inErrors outErrors
Eth-Trunk0 up up 0.01% 0.12% 0 0
  GigabitEthernet0/0/0 up up 0% 0% 0 0
Eth-Trunk1.640 up up 0% 0% 0 0
Vlanif168 down down -- -- 0 0
MEth0/0/0 up up 0% 0% 0 0
""")
        self.assertEqual(parsed["Eth-Trunk0"]["type"], "lag")
        self.assertEqual(parsed["GigabitEthernet0/0/0"]["type"], "1000base-t")
        self.assertEqual(parsed["Eth-Trunk1.640"]["type"], "virtual")
        self.assertEqual(parsed["Vlanif168"]["operstatus"], "down")
        self.assertIn("MEth0/0/0", parsed)

    def test_huawei_s5735_running_config_enriches_interfaces_and_vlans(self):
        raw = """vlan 23
 description Manage_Network
 name Manage_Network
#
vlan 2716
 description service_OUS
#
interface Vlanif23
 description mgm_RIC-S5735-rack03
 ip address 192.168.23.102 255.255.255.0
#
interface GigabitEthernet0/0/8
 description ADMIN_IN_DC
 shutdown
 port link-type access
 port default vlan 2256
#
interface GigabitEthernet0/0/4
 description NetFlow
 port link-type trunk
 port trunk pvid vlan 2716
 port trunk allow-pass vlan 2716
#
interface GigabitEthernet0/0/14
 description KNGFW1_ETH1
 eth-trunk 3
#
interface XGigabitEthernet0/0/4
 description DTC-P24-CSC-CSW-23-254
 port link-type trunk
 undo port trunk allow-pass vlan 1
 port trunk allow-pass vlan 4 23 100 316 2256 2716 2748
#
"""
        base = {
            "Vlanif23": {"operstatus": "up", "type": "virtual", "description": ""},
            "GigabitEthernet0/0/8": {"operstatus": "down", "type": "1000base-t", "description": ""},
        }
        parsed = parse_huawei_running_config(raw, base)
        self.assertEqual(parsed["interfaces"]["Vlanif23"]["description"], "mgm_RIC-S5735-rack03")
        self.assertEqual(parsed["interfaces"]["Vlanif23"]["ip_addresses"], ["192.168.23.102/24"])
        access = parsed["interfaces"]["GigabitEthernet0/0/8"]
        self.assertEqual(access["description"], "ADMIN_IN_DC")
        self.assertEqual(access["untagged_vlans"], [2256])
        self.assertEqual(access["admin_status"], "disabled")
        trunk = parsed["interfaces"]["GigabitEthernet0/0/4"]
        self.assertEqual(trunk["native_vlan"], 2716)
        self.assertEqual(trunk["tagged_vlans"], [])
        uplink = parsed["interfaces"]["XGigabitEthernet0/0/4"]
        self.assertEqual(uplink["tagged_vlans"], [4, 23, 100, 316, 2256, 2716, 2748])
        self.assertEqual(parsed["interfaces"]["GigabitEthernet0/0/14"]["lag"], "Eth-Trunk3")
        vlans = {item["vid"]: item for item in parsed["vlans"]}
        self.assertEqual(vlans[23]["name"], "Manage_Network")
        self.assertEqual(vlans[23]["description"], "Manage_Network")
        self.assertEqual(vlans[2716]["name"], "VLAN2716")
        self.assertEqual(parse_huawei_vlans(raw), parsed["vlans"])

    def test_huawei_aggregate_members_allow_speed_annotation(self):
        raw = """Eth-Trunk1 up up 18% 17% 0 0
  GigabitEthernet1/0/8(10G) up up 9% 8% 0 0
  GigabitEthernet3/0/8(10G) up up 9% 9% 0 0
Eth-Trunk1.95 up up 1% 2% 0 0
"""
        self.assertEqual(parse_huawei_lag_members(raw), {"Eth-Trunk1": ["GigabitEthernet1/0/8", "GigabitEthernet3/0/8"]})
        self.assertIn("GigabitEthernet1/0/8", parse_huawei_interfaces(raw))

    def test_eltex_mes5324a_active_version_and_stack_system_output(self):
        version = parse_eltex_version("""Active-image: flash://system/images/rs
  Version: 6.6.11.2
  Commit: 5674e940
Inactive-image: flash://system/images/_rs
  Version: 6.6.3
""")
        system = parse_eltex_system("""System Description:                       MES5324A rev.B 24-Port 10G SFP+ Managed Switch
System Up Time (days,hour:min:sec):       166,14:05:49
Unit                            Type
---- ----------------------------------------------------------
 1         MES5324A rev.B 24-Port 10G SFP+ Managed Switch
 2         MES5324A rev.B 24-Port 10G SFP+ Managed Switch
""")
        self.assertEqual(version["version"], "6.6.11.2")
        self.assertEqual(version["model"], "")
        self.assertEqual(system["model"], "MES5324A")
        self.assertEqual(system["unit_count"], 2)
        self.assertEqual(len(system["units"]), 2)

    def test_eltex_inventory_extracts_both_stack_serials_and_transceivers(self):
        parsed = parse_eltex_inventory("""NAME: "1"   DESCR: "24-Port 10G SFP+ Managed Switch"
PID: MES5324A rev.B   VID: 0   SN: ESE7000244

NAME: "TenGigabitEthernet1/0/1"    DESCR: "SFP-10G-LR"
PID: SFP-10G-LR    VID: V01     SN: PJBN771503

NAME: "2"   DESCR: "24-Port 10G SFP+ Managed Switch"
PID: MES5324A rev.B   VID: 0   SN: ESE7000247
""")
        self.assertEqual([u["serial"] for u in parsed["units"]], ["ESE7000244", "ESE7000247"])
        self.assertEqual(parsed["units"][0]["pid"], "MES5324A rev.B")
        self.assertEqual(parsed["transceivers"][0]["serial"], "PJBN771503")

    def test_eltex_interface_details_keep_descriptions_and_not_present_state(self):
        parsed = parse_eltex_interface_descriptions("""Port       Port Mode (VLAN)         Admin Link
te1/0/1    Trunk                    Up    Up          RMIAC-S139-ELX-SW-23-3
te2/0/4    Access (1)               Down  Down
Po1        Trunk                    Up    Up          USG6670_FW1
Po6        Access (1)               Up    Not Present
""")
        self.assertEqual(parsed["te1/0/1"]["description"], "RMIAC-S139-ELX-SW-23-3")
        self.assertEqual(parsed["te2/0/4"]["admin_status"], "disabled")
        self.assertEqual(parsed["Po1"]["type"] if "type" in parsed["Po1"] else "lag", "lag")
        self.assertEqual(parsed["Po6"]["operstatus"], "not_present")

    def test_eltex_vlan_parser_handles_wrapped_membership_ranges(self):
        parsed = parse_eltex_vlans("""Vlan       Name           Tagged Ports      UnTagged Ports      Created by
---- ----------------- ------------------ ------------------ ----------------
1           -                             te1/0/5,te1/0/8,         D
                                             te1/0/11,te1/0/15,
                                            te1/0/23-32,
                                             te2/0/4-5,
9   MFC_Zastava_to_RT    Po1,Po5,Po10                              S
120  Inet_Vid_analit_B    Po11             te1/0/7              S
""")
        vlans = {row["vid"]: row for row in parsed}
        self.assertEqual(vlans[9]["tagged_ports"], ["Po1", "Po5", "Po10"])
        self.assertEqual(vlans[120]["tagged_ports"], ["Po11"])
        self.assertEqual(vlans[120]["untagged_ports"], ["te1/0/7"])
        self.assertIn("te1/0/32", vlans[1]["untagged_ports"])

    def test_eltex_vlan_parser_preserves_wrapped_names_from_real_cli_layout(self):
        raw = """Vlan       Name           Tagged Ports      UnTagged Ports      Created by
---- ----------------- ------------------ ------------------ ----------------
1042 Internal_myudm.ru   te2/0/10,Po3-4                             S
1253 ISP_Megafon_Inter te2/0/10,te2/0/13                            S
            net
2301 MGMT_APK_Safe_cit te1/0/1,te1/0/4,                            S
             y          te2/0/1,Po1,Po5
"""
        parsed = {row["vid"]: row for row in parse_eltex_vlans(raw)}
        self.assertEqual(parsed[1042]["name"], "Internal_myudm.ru")
        self.assertEqual(parsed[1042]["tagged_ports"], ["te2/0/10", "Po3", "Po4"])
        self.assertEqual(parsed[1253]["name"], "ISP_Megafon_Internet")
        self.assertEqual(parsed[1253]["tagged_ports"], ["te2/0/10", "te2/0/13"])
        self.assertEqual(parsed[2301]["name"], "MGMT_APK_Safe_city")
        self.assertEqual(parsed[2301]["tagged_ports"], ["te1/0/1", "te1/0/4", "te2/0/1", "Po1", "Po5"])

    def test_eltex_interfaces_status_keeps_not_present_distinct(self):
        parsed = parse_eltex_interfaces("""Port       Type         Duplex  Speed  Neg      ctrl State
te1/0/22   10G-Fiber    Full    10000  Disabled Off  Up
te1/0/23      --        --      --      --     --  Not Present
te2/0/4    10G-Fiber      --      --      --     --  Down (adm)
""")
        self.assertEqual(parsed["te1/0/22"]["operstatus"], "up")
        self.assertEqual(parsed["te1/0/23"]["operstatus"], "not_present")
        self.assertEqual(parsed["te2/0/4"]["operstatus"], "down")

    def test_eltex_vlan_membership_rejects_ports_not_observed_on_two_unit_stack(self):
        # Regression for the DTC-P24-ELX-SW report: the VLAN table contained
        # te1/0/25-32 and complete te3/0/1-32 ... te8/0/1-32 ranges even though
        # the actual MES-5324A stack has only te1/0/1-24 and te2/0/1-24.
        raw = """Vlan       Name           Tagged Ports      UnTagged Ports      Created by
1           -                             te1/0/23-32,te2/0/23-32,te3/0/1-32,te8/0/1-32,Po1-2 D
120  USERS                 Po11             te2/0/7              S
"""
        parsed = parse_eltex_vlans(raw)
        observed = {f"te{unit}/0/{port}": {} for unit in (1, 2) for port in range(1, 25)}
        observed.update({"Po1": {}, "Po2": {}, "Po11": {}})
        validated = validate_eltex_vlan_memberships(parsed, observed)
        vlans = {row["vid"]: row for row in validated}
        self.assertEqual(vlans[1]["untagged_ports"], ["te1/0/23", "te1/0/24", "te2/0/23", "te2/0/24", "Po1", "Po2"])
        self.assertEqual(vlans[120]["tagged_ports"], ["Po11"])
        self.assertEqual(vlans[120]["untagged_ports"], ["te2/0/7"])
        all_members = [p for row in validated for field in ("tagged_ports", "untagged_ports") for p in row[field]]
        self.assertFalse(any(re.match(r"(?i)^te[3-8]/", p) for p in all_members))
        self.assertFalse(any(re.match(r"(?i)^te[12]/0/(?:2[5-9]|3[0-2])$", p) for p in all_members))

    def test_eltex_filters_unconfigured_placeholder_port_channels(self):
        interfaces = {
            'Po1': {'type': 'lag', 'description': '', 'port_mode': 'Trunk', 'admin_status': 'enabled'},
            'Po2': {'type': 'lag', 'description': '', 'port_mode': 'Trunk', 'admin_status': 'enabled'},
            'Po6': {'type': 'lag', 'description': '', 'port_mode': 'Access (1)', 'admin_status': 'enabled'},
            'Po8': {'type': 'lag', 'description': '', 'port_mode': 'Access (1)', 'admin_status': 'enabled'},
            'Po10': {'type': 'lag', 'description': 'uplink', 'port_mode': 'Access (1)', 'admin_status': 'enabled'},
            'te1/0/1': {'type': '10gbase-x-sfpp', 'description': ''},
        }
        vlans = [
            {'vid': 1, 'name': '-', 'tagged_ports': [], 'untagged_ports': ['Po1', 'Po2', 'Po6', 'Po8', 'Po10']},
            {'vid': 9, 'name': 'uplink', 'tagged_ports': ['Po1'], 'untagged_ports': []},
            {'vid': 644, 'name': 'configured', 'tagged_ports': ['Po8'], 'untagged_ports': []},
        ]
        lag_members = {'Po2': ['te1/0/1']}
        filtered = filter_eltex_configured_port_channels(interfaces, vlans, lag_members)
        self.assertEqual({name for name in filtered if name.startswith('Po')}, {'Po1', 'Po2', 'Po8', 'Po10'})
        filtered_vlans = filter_eltex_vlan_port_channels(vlans, interfaces, lag_members)
        vlan1 = next(row for row in filtered_vlans if row['vid'] == 1)
        self.assertEqual(vlan1['untagged_ports'], ['Po1', 'Po2', 'Po8', 'Po10'])

    def test_eltex_channel_group_only_returns_active_members(self):
        parsed = parse_eltex_lag_members("""Channel  Ports
Po1      Active: te1/0/22,te2/0/22
Po8      Non-candidate: te1/0/18,te2/0/18
Po10     Active: te1/0/17,te2/0/17
Po12
""")
        self.assertEqual(parsed, {"Po1": ["te1/0/22", "te2/0/22"], "Po10": ["te1/0/17", "te2/0/17"]})

    def test_eltex_lag_non_candidate_state_is_preserved_separately_from_link_state(self):
        raw = """Channel  Ports
Po1      Active: te1/0/22,te2/0/22
Po8      Non-candidate: te1/0/18,te2/0/18
Po10     Active: te1/0/17,te2/0/17
"""
        states = parse_eltex_lag_states(raw)
        self.assertEqual(states, {"Po1": "active", "Po8": "non_candidate", "Po10": "active"})
        interfaces = {"Po8": {"operstatus": "down", "type": "lag"}, "Po1": {"operstatus": "up", "type": "lag"}}
        enriched = apply_eltex_lag_states(interfaces, states)
        self.assertEqual(enriched["Po8"]["operstatus"], "down")
        self.assertEqual(enriched["Po8"]["lag_status"], "non_candidate")
        self.assertEqual(enriched["Po1"]["lag_status"], "active")
        # Non-candidate ports are not falsely represented as active LAG members.
        self.assertNotIn("Po8", parse_eltex_lag_members(raw))

    def test_eltex_lldp_parses_device_port_and_wrapped_port_id(self):
        parsed = parse_eltex_lldp("""Port       Device ID          Port ID               System Name           Capabilities  TTL
te1/0/1    e0:d9:e3:1a:d8:40      te1/0/2                                          O        117
te1/0/19   44:a1:91:69:af:15 XGigabitEthernet0        RIC-USG6635-FW3              R        103
                                  /0/1
te1/0/17   54:4b:8c:f4:67:c0     xe-1/2/2          18-IZHK58-AR1.udmvt.ru         B, R      115
te1/0/21   44:a1:91:3f:fb:80 GigabitEthernet1/        DTC-USG6670-FW2              R        90
                                    0/8
""")
        self.assertEqual(len(parsed), 4)
        self.assertEqual(parsed[3]["neighbor_interface"], "GigabitEthernet1/0/8")
        self.assertEqual(parsed[0]["neighbor_interface"], "te1/0/2")
        self.assertEqual(parsed[1]["neighbor_interface"], "XGigabitEthernet0/0/1")
        self.assertEqual(parsed[1]["neighbor_device"], "RIC-USG6635-FW3")
        self.assertEqual(parsed[2]["neighbor_device"], "18-IZHK58-AR1.udmvt.ru")

    def test_eltex_lldp_does_not_treat_capability_letters_as_device_name(self):
        parsed = parse_eltex_lldp("""Port       Device ID          Port ID               System Name           Capabilities  TTL
te1/0/1    e0:d9:e3:1a:d8:40      te1/0/2                                          O
""")
        self.assertEqual(len(parsed), 1)
        self.assertNotIn("neighbor_device", parsed[0])

    def test_eltex_system_parser_handles_missing_model(self):
        self.assertEqual(parse_eltex_system("System Up Time: 1 day")["model"], "")

    def test_eltex_stack_ports_and_port_channels(self):
        parsed = parse_eltex_interfaces("""Port Name Status Speed Duplex Auto Negotiation Flow Control
te1/0/21 Connected 10G Full Enabled Disabled
te2/0/21 NotPresent -- -- -- --
Po1 Up 20G Full Enabled Disabled
""")
        self.assertEqual(parsed["te1/0/21"]["operstatus"], "up")
        self.assertEqual(parsed["te2/0/21"]["operstatus"], "down")
        self.assertEqual(parsed["Po1"]["type"], "lag")

    def test_eltex_mes5324a_show_interfaces_status_real_format(self):
        parsed = parse_eltex_interfaces("""Port       Type         Duplex  Speed  Neg      ctrl State         (d,h:m:s)   Pressure Mode    Port Mode (VLAN)
---------- ------------ ------  ------ -------- ---- ----------- ------------- -------- ------- ------------------------
te1/0/1    10G-Fiber    Full    10000  Disabled Off  Up          73,19:42:28   Disabled Off     Trunk
te1/0/2    10G-Fiber      --      --      --     --  Down (nc)         --         --     --     Access (2770)
te1/0/4    10G-Fiber      --      --      --     --  Down (adm)        --         --     --     Access (1)
te1/0/23       --        --      --      --     --  Not Present       --         --     --     Access (1)
Po1        10G          Full    20000  Enabled  Off  Up            Trunk
Po8        10G            --      --      --     --  Down (nc)     Trunk
Po9           --          --      --      --     --  Not Present   Access (1)
""")
        self.assertEqual(set(parsed), {"te1/0/1", "te1/0/2", "te1/0/4", "te1/0/23", "Po1", "Po8", "Po9"})
        self.assertEqual(parsed["te1/0/1"]["operstatus"], "up")
        self.assertEqual(parsed["te1/0/2"]["operstatus"], "down")
        self.assertEqual(parsed["te1/0/4"]["operstatus"], "down")
        self.assertEqual(parsed["te1/0/23"]["operstatus"], "not_present")
        self.assertEqual(parsed["Po1"]["type"], "lag")
        self.assertEqual(parsed["Po8"]["operstatus"], "down")

    def test_cisco_catalyst_9410_ios_xe_version_inventory_interfaces_and_lag(self):
        version = parse_cisco_version("""Cisco IOS XE Software, Version 16.06.04
cisco C9410R (X86) processor with 123456K bytes of memory
System serial number : FOC1234ABCD
""")
        inventory = parse_cisco_inventory("""NAME: \"Chassis\", DESCR: \"Cisco Catalyst 9410\"
PID: C9410R, VID: V01, SN: FOC1234ABCD""")
        self.assertEqual(version["version"], "16.06.04")
        self.assertEqual(inventory, {"model": "C9410R", "serial": "FOC1234ABCD"})
        interfaces = parse_cisco_interfaces("""Port      Name               Status       Vlan       Duplex Speed Type
Gi1/0/1                      connected    10         a-full a-1000 10/100/1000BaseTX
Fo1/0/1                      notconnect   1          auto   auto   40GBase-SR4
Po1                          connected    trunk      a-full a-40G
""")
        self.assertEqual(interfaces["Gi1/0/1"]["operstatus"], "up")
        self.assertEqual(interfaces["Fo1/0/1"]["type"], "40gbase-x-qsfpp")
        self.assertEqual(interfaces["Po1"]["type"], "lag")
        self.assertEqual(parse_cisco_lag_members("1 Po1(SU) LACP Gi1/0/1(P) Fo1/0/1(P)"), {"Po1": ["Gi1/0/1", "Fo1/0/1"]})

    def test_cisco_interfaces_status_keeps_name_column_and_descriptions(self):
        parsed = parse_cisco_interfaces("""Port      Name                         Status       Vlan       Duplex Speed Type
Gi3/0/47  USG6635_FW4_MGMT             connected    23         a-full a-1000 10/100/1000BaseTX
Te4/0/1   HuwS5735_21                  connected    trunk      a-full a-10000 10GBase-SR
Te4/0/8   Coordinator_ATS_v252         notconnect   1          auto   auto 10GBase-SR
Po14                                   notconnect   trunk      auto   auto -
""")
        self.assertEqual(parsed["Gi3/0/47"]["description"], "USG6635_FW4_MGMT")
        self.assertEqual(parsed["Te4/0/1"]["operstatus"], "up")
        self.assertEqual(parsed["Te4/0/8"]["description"], "Coordinator_ATS_v252")
        self.assertEqual(parsed["Po14"]["type"], "lag")
        self.assertEqual(parsed["Po14"]["operstatus"], "down")

    def test_cisco_interface_descriptions_preserve_full_text(self):
        parsed = parse_cisco_interface_descriptions("""Interface                      Status         Protocol Description
Gi8/0/46                       up             up       DTC-P24-ELX-SW-23-254
Gi8/0/5                        down           down     UserGate_up_to_LogServer
Te4/0/9                        up             up       Coordinator_ATSr_v252
Po14                           down           down     Test Yadro aggregate
""")
        self.assertEqual(parsed["Gi8/0/46"], "DTC-P24-ELX-SW-23-254")
        self.assertEqual(parsed["Gi8/0/5"], "UserGate_up_to_LogServer")
        self.assertEqual(parsed["Te4/0/9"], "Coordinator_ATSr_v252")
        self.assertEqual(parsed["Po14"], "Test Yadro aggregate")

    def test_cisco_lldp_detail_parser(self):
        parsed = parse_cisco_lldp("""Local Intf: Te7/0/9
Chassis id: 6012.3ce8.81c0
Port id: XGigabitEthernet0/0/4
Port Description: DTC-P24-CSC-CSW-23-254
System Name: DTC-P24-HUW-SW-23-129
System Description:
Huawei Switch S5735-S24T4X
Management Addresses:
    IP: 192.168.1.253

Local Intf: Te6/0/4
Chassis id: 24a5.2cfd.70f3
Port id: GigabitEthernet3/0/9
System Name: DTC-USG6670-FW1
Management Addresses:
    IP: 91.230.91.9
""")
        self.assertEqual(len(parsed), 2)
        self.assertEqual(parsed[0]["neighbor_device"], "DTC-P24-HUW-SW-23-129")
        self.assertEqual(parsed[0]["neighbor_interface"], "XGigabitEthernet0/0/4")
        self.assertEqual(parsed[0]["management_ip"], "192.168.1.253")
        self.assertEqual(parsed[1]["local_interface"], "Te6/0/4")

    def test_snr_s5311_enos_version_interfaces_and_lag(self):
        parsed = parse_snr_version("""SNR-S5311G-48TX-POE Ethernet Managed Switch
eNOS software, Compiled on 09/04/26 10:31:23 (d67f5439d)
Software Version 1.23.0
BootRom Version 1.14
HardWare Version 1.0.0
Serial No.: SWBM052189001917
""")
        self.assertEqual(parsed, {"model": "SNR-S5311G-48TX-POE", "version": "1.23.0", "serial": "SWBM052189001917"})
        interfaces = parse_snr_interfaces("""Interface Status VLAN Duplex Speed Type
ge1 up 1 full 1000 copper
ge2 down 1 auto auto copper
xe1 up trunk full 10000 fiber
Port-Channel1 up trunk full 20000 logical
""")
        self.assertEqual(interfaces["ge1"]["operstatus"], "up")
        self.assertEqual(interfaces["ge2"]["operstatus"], "down")
        self.assertEqual(interfaces["xe1"]["type"], "10gbase-x-sfpp")
        self.assertEqual(interfaces["Port-Channel1"]["type"], "lag")
        self.assertEqual(parse_snr_lag_members("1 Port-Channel1(SU) LACP ge1(P) xe1(P)"), {"Port-Channel1": ["ge1", "xe1"]})

    def test_snr_lldp_neighbors_brief_parses_wrapped_real_v95_output(self):
        # Captured from SNR-171: the second remote Port ID is wrapped in the
        # middle of GigabitEthernet0/0/22 at the terminal width.
        raw = """Local Interface             Chassis ID             CID subtype    Port ID       
       PID subtype      Time Mark        System-name
ge47                        f8-f0-82-d6-60-d3      4              ge47          
       Interface        114              DTC-P24-SNR-SW-23-170
ge48                        f4-de-af-95-6d-70      4              GigabitEtherne
t0/0/22Interface        91               DTC-P24-HUW-SW-23-111
"""
        parsed = parse_snr_lldp(raw)
        self.assertEqual(len(parsed), 2)
        self.assertEqual(parsed[0], {
            "local_interface": "ge47",
            "chassis_id": "f8-f0-82-d6-60-d3",
            "neighbor_interface": "ge47",
            "neighbor_device": "DTC-P24-SNR-SW-23-170",
        })
        self.assertEqual(parsed[1], {
            "local_interface": "ge48",
            "chassis_id": "f4-de-af-95-6d-70",
            "neighbor_interface": "GigabitEthernet0/0/22",
            "neighbor_device": "DTC-P24-HUW-SW-23-111",
        })

    def test_snr_lldp_neighbors_brief_parses_peer_snr_report(self):
        # Captured from SNR-170; the peer name and ge47 remote port are present.
        raw = """Local Interface             Chassis ID             CID subtype    Port ID       
       PID subtype      Time Mark        System-name
ge47                        f8-f0-82-d6-89-01      4              ge47          
       Interface        108              DTC-P24-SNR-SW-23-171
"""
        self.assertEqual(parse_snr_lldp(raw), [{
            "local_interface": "ge47",
            "chassis_id": "f8-f0-82-d6-89-01",
            "neighbor_interface": "ge47",
            "neighbor_device": "DTC-P24-SNR-SW-23-171",
        }])

    def test_snr_running_config_enriches_descriptions_ip_and_hybrid_vlan_details(self):
        brief = {
            "ge1": {"operstatus": "down", "type": "1000base-t", "description": ""},
            "ge48": {"operstatus": "up", "type": "1000base-t", "description": ""},
            "xe6": {"operstatus": "down", "type": "10gbase-x-sfpp", "description": ""},
            "vlan1": {"operstatus": "up", "type": "virtual", "description": ""},
        }
        config = """hostname test
interface ge1
 description 37_5.1
 switchport mode hybrid
 switchport hybrid native vlan 701
 switchport hybrid allowed vlan 2 tag
 switchport hybrid allowed vlan 701 untag
!
interface ge48
 switchport mode hybrid
 switchport hybrid native vlan 1
 switchport hybrid allowed vlan 2 tag
 switchport hybrid allowed vlan 1 untag
!
interface xe6
 description to_Cisco_9410R
 switchport mode trunk
 switchport trunk allowed vlan 23
 switchport trunk native vlan 1
!
interface vlan1
 ip address 192.168.1.1/24
!
ip route 0.0.0.0/0 192.168.23.1
end
"""
        parsed = parse_snr_running_config(config, brief)
        self.assertEqual(parsed["ge1"]["description"], "37_5.1")
        self.assertEqual(parsed["ge1"]["tagged_vlans"], [2])
        self.assertEqual(parsed["ge1"]["untagged_vlans"], [701])
        self.assertEqual(parsed["ge1"]["native_vlan"], 701)
        self.assertEqual(parsed["xe6"]["description"], "to_Cisco_9410R")
        self.assertEqual(parsed["xe6"]["allowed_vlans"], [23])
        self.assertEqual(parsed["xe6"]["tagged_vlans"], [23])
        self.assertEqual(parsed["xe6"]["untagged_vlans"], [1])
        self.assertEqual(parsed["vlan1"]["ip_addresses"], ["192.168.1.1/24"])
        self.assertEqual(parsed["ge48"]["description"], "")

    def test_huawei_lldp_detail_keeps_remote_port_and_chassis_id(self):
        parsed = parse_huawei_lldp("""Interface GigabitEthernet3/0/9 has 1 Neighbors:
  ChassisId: 7079-b3f2-4140
  PortId: Te6/0/4
  System name: DTC-P24-ELX-SW
""")
        self.assertEqual(len(parsed), 1)
        self.assertEqual(parsed[0]["local_interface"], "GigabitEthernet3/0/9")
        self.assertEqual(parsed[0]["neighbor_interface"], "Te6/0/4")
        self.assertEqual(parsed[0]["chassis_id"], "7079-b3f2-4140")

    def test_snr_vlan_parser_reads_named_vlan_blocks(self):
        parsed = parse_snr_vlans("""vlan 2
 name Phones
!
vlan 23
 name Management
!
vlan 316
 name Tests
!
vlan 701
 name Workers_OUS
!
""")
        self.assertEqual(parsed, [
            {"vid": 2, "name": "Phones", "status": "active"},
            {"vid": 23, "name": "Management", "status": "active"},
            {"vid": 316, "name": "Tests", "status": "active"},
            {"vid": 701, "name": "Workers_OUS", "status": "active"},
        ])

    def test_snr_vlan_parser_removes_trailing_operational_state_from_names(self):
        parsed = parse_snr_vlans("""vlan 2 name Phones state enable
vlan 23
 name Management state enable
!
vlan 316 name Tests state disable
""")
        self.assertEqual(parsed, [
            {"vid": 2, "name": "Phones", "status": "active"},
            {"vid": 23, "name": "Management", "status": "active"},
            {"vid": 316, "name": "Tests", "status": "active"},
        ])

    def test_vlan_parser_skips_headers_and_invalid_ids(self):
        parsed = parse_vlans("VLAN Name Status\n1 default active\n23 users active\n4095 invalid active\n")
        self.assertEqual([x["vid"] for x in parsed], [1, 23])


if __name__ == "__main__":
    unittest.main()


class EltexEsrParserTests(unittest.TestCase):
    def test_esr_version_and_system_identity(self):
        v = parse_eltex_esr_version("Boot version: 1.14.5.2\nSW version: 1.14.5 build 5[596cabe53]")
        self.assertEqual(v["version"], "1.14.5 build 5[596cabe53]")
        self.assertEqual(v["boot_version"], "1.14.5.2")
        system = parse_eltex_esr_system("System type: Eltex ESR-200 Service Router\nSystem name: AR1-COMERCIAL\nSoftware version: 1.14.5 build 5[596cabe53]\nHardware version: 1v8\nMAC: A8:F9:4B:AD:A2:4A\nSerial: NP02003282")
        self.assertEqual(system["hostname"], "AR1-COMERCIAL")
        self.assertEqual(system["serial"], "NP02003282")

    def test_esr_system_parses_actual_show_system_labels(self):
        output = """System type:           Eltex ESR-200 Service Router
System name:           AR1-COMERCIAL
Software version:      1.14.5 build 5[596cabe53] (date 20/04/2022 time 11:45:35)
Hardware version:      1v8
System uptime:         878 days, 23 hours, 48 minutes and 53 seconds
System MAC address:    A8:F9:4B:AD:A2:4A
System serial number:  NP02003282
"""
        parsed = parse_eltex_esr_system(output)
        self.assertEqual(parsed["hostname"], "AR1-COMERCIAL")
        self.assertEqual(parsed["version"], "1.14.5 build 5[596cabe53] (date 20/04/2022 time 11:45:35)")
        self.assertEqual(parsed["uptime"], "878 days, 23 hours, 48 minutes and 53 seconds")
        self.assertEqual(parsed["mac"], "A8:F9:4B:AD:A2:4A")
        self.assertEqual(parsed["serial"], "NP02003282")

    def test_esr_system_serial_label_variants(self):
        for label in ("Serial", "Serial number", "Serial No.", "Serial No"):
            for separator in (": ", " ", " : "):
                with self.subTest(label=label, separator=separator):
                    parsed = parse_eltex_esr_system(f"System name: AR1-COMERCIAL\n{label}{separator}NP02003282")
                    self.assertEqual(parsed["serial"], "NP02003282")

    def test_esr_system_does_not_guess_missing_serial(self):
        parsed = parse_eltex_esr_system("System name: AR1-COMERCIAL\nMAC: A8:F9:4B:AD:A2:4A")
        self.assertEqual(parsed["serial"], "")

    def test_esr_interfaces_and_descriptions(self):
        status = parse_eltex_esr_interfaces("Interface Admin state Link state MTU MAC address Last change Mode\ngi1/0/1 Up Up 1500 a8:f9:4b:ad:a2:4b 878 days routerport\ngi1/0/1.18 Down Down 1500 a8:f9:4b:ad:a2:4b 3 seconds routerport")
        self.assertEqual(status["gi1/0/1"]["operstatus"], "up")
        self.assertEqual(status["gi1/0/1.18"]["type"], "virtual")
        self.assertEqual(status["gi1/0/1.18"]["admin_status"], "disabled")
        desc = parse_eltex_esr_descriptions("Interface Admin State Link State Description\ngi1/0/1 Up Up ISP-Megafon\ngi1/0/1.785 Up Up RT_for_Wi-Fi")
        self.assertEqual(desc["gi1/0/1.785"]["description"], "RT_for_Wi-Fi")

    def test_esr_ip_vlans_vrrp_routes_and_failover(self):
        ips = parse_eltex_esr_ip_interfaces("10.10.23.251/24 gi1/0/1.1023 Up Up static")
        self.assertEqual(ips["gi1/0/1.1023"]["address"], "10.10.23.251/24")
        vlans = parse_eltex_esr_vlans('vlan 1023\n  name "mgm_kommers"\nexit\nvlan 1070\n  name "Guest_VM_Test"\nexit')
        self.assertEqual(vlans, [{"vid":1023,"name":"mgm_kommers","status":"active"},{"vid":1070,"name":"Guest_VM_Test","status":"active"}])
        vrrp = parse_eltex_esr_vrrp("Virtual router   Virtual IP                          Priority   Preemption   State\n10               10.10.10.1/24                       200        Enabled      Master")
        self.assertEqual(vrrp[0]["id"], 10)
        detail = parse_eltex_esr_vrrp("VRRP ID: 10\nInterface: gi1/0/2.1010\nPriority: 200\nState: Master\nSource IP address: 10.10.10.251\nVirtual IP address: 10.10.10.1/24")
        self.assertEqual(detail[0]["interface"], "gi1/0/2.1010")
        routes = parse_eltex_esr_routes("S     * 0.0.0.0/0 [1/251] via 178.176.102.137 on vrrp.30 [static]")
        self.assertEqual(routes[0]["next_hop"], "178.176.102.137")
        failover = parse_eltex_esr_failover("Communication interface: gi1/0/1.1023\nStatus: Running\nSend errors: 387\nReceive errors: 0")
        self.assertEqual(failover["status"], "Running")
        self.assertEqual(failover["send_errors"], 387)
