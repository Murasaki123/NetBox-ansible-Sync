"""Interface sync by numeric IDs: HA members with identical names, pagination, duplicates, errors."""
import importlib.util
import io
import json
import sys
import unittest
import urllib.error
import urllib.parse
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("netbox_interface_sync", ROOT / "roles/netbox_sync/library/netbox_interface_sync.py")
mod = importlib.util.module_from_spec(spec)
sys.modules["netbox_interface_sync"] = mod
spec.loader.exec_module(mod)

BASE = "https://nb.example"


class Resp:
    def __init__(self, payload):
        self._raw = json.dumps(payload).encode()
    def read(self):
        return self._raw
    def __enter__(self):
        return self
    def __exit__(self, *a):
        return False


class FakeNetBox:
    """Devices + interfaces. `leak_vc` mimics a device_id filter that also returns VC siblings."""
    def __init__(self, page=2, leak_vc=False, token_scheme="Token"):
        self.devices = [{"id": 1, "name": "DTC-HUW2_23-1"}, {"id": 2, "name": "DTC-P24-HUW-23-1"}]
        self.ifaces = []
        self.next_id = 100
        self.page, self.leak_vc, self.scheme = page, leak_vc, token_scheme
        self.calls = []
        self.fail = {}  # (method, path-substring) -> HTTP code

    def add(self, dev, name, **kw):
        row = {"id": self.next_id, "name": name, "device": {"id": dev}, "type": {"value": "other"},
               "enabled": True, "description": "", "lag": None, "mtu": None, "mac_address": None}
        row.update(kw)
        self.next_id += 1
        self.ifaces.append(row)
        return row

    def __call__(self, req, timeout=None, context=None):
        url, method = req.full_url, req.get_method()
        self.calls.append((method, url))
        if not req.get_header("Authorization").startswith(self.scheme + " "):
            raise urllib.error.HTTPError(url, 403, "forbidden", {}, io.BytesIO(b"{}"))
        parsed = urllib.parse.urlsplit(url)
        q = urllib.parse.parse_qs(parsed.query)
        for (m, frag), code in self.fail.items():
            if m == method and frag in parsed.path:
                raise urllib.error.HTTPError(url, code, "err", {}, io.BytesIO(b'{"detail":"boom"}'))
        body = json.loads(req.data) if req.data else None
        if parsed.path == "/api/dcim/devices/":
            rows = [d for d in self.devices if d["name"] == q["name"][0]]
            return Resp({"count": len(rows), "next": None, "results": rows})
        if parsed.path == "/api/dcim/interfaces/" and method == "GET":
            dev = int(q["device_id"][0])
            rows = [r for r in self.ifaces if r["device"]["id"] == dev or (self.leak_vc and r["device"]["id"] in (1, 2))]
            off = int(q.get("offset", ["0"])[0])
            chunk = rows[off:off + self.page]
            nxt = None
            if off + self.page < len(rows):
                nxt = "http://internal-netbox:8080/api/dcim/interfaces/?" + urllib.parse.urlencode(
                    {"device_id": dev, "limit": q["limit"][0], "offset": off + self.page})
            return Resp({"count": len(rows), "next": nxt, "results": chunk})
        if parsed.path == "/api/dcim/interfaces/" and method == "POST":
            row = self.add(body["device"], body["name"], **{k: v for k, v in body.items() if k not in ("device", "name", "type")})
            row["type"] = {"value": body["type"]}
            return Resp(row)
        if parsed.path.startswith("/api/dcim/interfaces/") and method == "PATCH":
            iid = int(parsed.path.strip("/").split("/")[-1])
            row = next(r for r in self.ifaces if r["id"] == iid)
            for k, v in body.items():
                row[k] = {"value": v} if k == "type" else ({"id": v} if k == "lag" else v)
            return Resp(row)
        raise AssertionError((method, url))


FACTS = {"Eth-Trunk2.2840": {"type": "virtual", "admin_status": "up", "description": "vlan 2840"},
         "GigabitEthernet3/0/2": {"admin_status": "down"},
         "Eth-Trunk2": {"type": "lag", "admin_status": "up"}}
TYPES = {"GigabitEthernet": "1000base-t", "Eth-Trunk": "lag"}


def run(nb, device="DTC-HUW2_23-1", facts=FACTS, lag=None, **kw):
    api = mod.Api(BASE, "tok-123456789", urlopen=nb)
    return mod.sync_interfaces(api, device, facts, TYPES, lag or {}, **kw)


class InterfaceSyncTests(unittest.TestCase):
    def test_ha_members_with_identical_names_are_updated_independently_by_their_own_ids(self):
        for leak in (False, True):
            nb = FakeNetBox(leak_vc=leak)
            a = nb.add(1, "Eth-Trunk2.2840")
            b = nb.add(2, "Eth-Trunk2.2840")
            r1 = run(nb, "DTC-HUW2_23-1")
            r2 = run(nb, "DTC-P24-HUW-23-1")
            self.assertEqual(r1["interface_ids"]["Eth-Trunk2.2840"], a["id"])
            self.assertEqual(r2["interface_ids"]["Eth-Trunk2.2840"], b["id"])
            self.assertEqual(r1["duplicates"], {}, leak)
            self.assertEqual(a["description"], "vlan 2840")
            self.assertEqual(b["description"], "vlan 2840")
            self.assertTrue(all(row["device"]["id"] in (1, 2) for row in nb.ifaces))
            self.assertEqual(sum(1 for x in nb.ifaces if x["device"]["id"] == 1), 3)  # created the missing ones on 1 only
            if leak:
                self.assertEqual(r1["ignored_foreign_rows"] > 0, True)

    def test_missing_interface_is_created_with_exact_device_id_and_type_mapping(self):
        nb = FakeNetBox()
        r = run(nb)
        self.assertCountEqual(r["created"], list(FACTS))
        posts = [u for m, u in nb.calls if m == "POST"]
        self.assertEqual(len(posts), 3)
        gi = next(x for x in nb.ifaces if x["name"] == "GigabitEthernet3/0/2")
        self.assertEqual((gi["device"]["id"], gi["type"]["value"], gi["enabled"]), (1, "1000base-t", False))
        self.assertEqual(set(r["interface_ids"]), set(FACTS))

    def test_second_run_is_idempotent(self):
        nb = FakeNetBox()
        run(nb)
        before = len([c for c in nb.calls if c[0] != "GET"])
        r = run(nb)
        self.assertEqual(len([c for c in nb.calls if c[0] != "GET"]), before)
        self.assertEqual((r["created"], r["updated"]), ([], []))
        self.assertEqual(len(r["unchanged"]), 3)

    def test_real_duplicates_on_one_device_are_skipped_not_touched(self):
        nb = FakeNetBox()
        d1 = nb.add(1, "LoopBack0")
        d2 = nb.add(1, "LoopBack0")
        other = nb.add(2, "LoopBack0")
        r = run(nb, facts={"LoopBack0": {"type": "virtual"}, "Vlanif18": {"type": "virtual"}})
        self.assertEqual(r["duplicates"], {"LoopBack0": [d1["id"], d2["id"]]})
        self.assertNotIn("LoopBack0", r["interface_ids"])
        self.assertIn("Vlanif18", r["created"])  # other interfaces continue
        self.assertEqual(d1["description"], "")
        self.assertEqual(other["description"], "")
        self.assertFalse([c for c in nb.calls if c[0] == "PATCH"])
        self.assertTrue(any("LoopBack0" in w and str(d1["id"]) in w and str(d2["id"]) in w for w in r["warnings"]))
        self.assertFalse(any(c[0] == "DELETE" for c in nb.calls))

    def test_pagination_reads_every_page_and_keeps_configured_origin(self):
        nb = FakeNetBox(page=2)
        for i in range(7):
            nb.add(1, "Gi1/0/%d" % i)
        r = run(nb, facts={})
        self.assertEqual(len(r["interface_ids"]), 7)
        gets = [u for m, u in nb.calls if "/interfaces/" in u]
        self.assertEqual(len(gets), 4)
        self.assertTrue(all(u.startswith(BASE) for u in gets))
        self.assertTrue(all("device_id=1" in u for u in gets))

    def test_incomplete_or_invalid_responses_fail_loudly(self):
        class Bad:
            def __call__(self, req, timeout=None, context=None):
                return Resp({"unexpected": True})
        with self.assertRaises(mod.NetBoxApiError):
            mod.sync_interfaces(mod.Api(BASE, "t", urlopen=Bad()), "x", {}, {}, {})

        class Garbage:
            def __call__(self, req, timeout=None, context=None):
                class R(Resp):
                    def __init__(s):
                        s._raw = b"<html>"
                return R()
        with self.assertRaises(mod.NetBoxApiError):
            mod.sync_interfaces(mod.Api(BASE, "t", urlopen=Garbage()), "x", {}, {}, {})

    def test_device_must_be_unique_and_exact(self):
        nb = FakeNetBox()
        nb.devices.append({"id": 3, "name": "DTC-HUW2_23-1"})
        with self.assertRaisesRegex(mod.NetBoxApiError, "exactly one"):
            run(nb)
        with self.assertRaisesRegex(mod.NetBoxApiError, "returned 0"):
            run(FakeNetBox(), "missing-device")
        self.assertFalse([c for c in nb.calls if "/interfaces/" in c[1]])

    def test_http_error_on_one_interface_does_not_block_the_others(self):
        nb = FakeNetBox()
        nb.fail[("POST", "/api/dcim/interfaces/")] = 400
        r = run(nb)
        self.assertEqual(len(r["errors"]), 3)
        self.assertIn("HTTP 400", r["errors"][0])
        nb2 = FakeNetBox()
        orig = nb2.__call__
        state = {"n": 0}
        def flaky(req, timeout=None, context=None):
            if req.get_method() == "POST":
                state["n"] += 1
                if state["n"] == 1:
                    raise urllib.error.HTTPError(req.full_url, 500, "x", {}, io.BytesIO(b"{}"))
            return orig(req, timeout, context)
        r = mod.sync_interfaces(mod.Api(BASE, "tok", urlopen=flaky), "DTC-HUW2_23-1", FACTS, TYPES, {})
        self.assertEqual((len(r["errors"]), len(r["created"])), (1, 2))

    def test_bearer_tokens_are_detected(self):
        nb = FakeNetBox(token_scheme="Bearer")
        r = run(nb)
        self.assertEqual(len(r["created"]), 3)

    def test_mac_address_is_dropped_when_netbox_rejects_the_legacy_field(self):
        nb = FakeNetBox()
        orig = nb.__call__
        def strict(req, timeout=None, context=None):
            if req.get_method() == "POST" and b"mac_address" in (req.data or b""):
                raise urllib.error.HTTPError(req.full_url, 400, "x", {}, io.BytesIO(b'{"mac_address":["unknown field"]}'))
            return orig(req, timeout, context)
        r = mod.sync_interfaces(mod.Api(BASE, "tok", urlopen=strict), "DTC-HUW2_23-1",
                                {"Gi1/0/1": {"type": "1000base-t", "mac_address": "aa:bb:cc:dd:ee:ff"}}, {}, {})
        self.assertEqual((r["created"], r["errors"]), (["Gi1/0/1"], []))

    def test_lag_membership_uses_numeric_parent_id(self):
        nb = FakeNetBox()
        facts = {"GigabitEthernet3/0/2": {"admin_status": "up"}, "Eth-Trunk2": {"type": "lag"}}
        r = run(nb, facts=facts, lag={"GigabitEthernet3/0/2": "Eth-Trunk2"})
        member = next(x for x in nb.ifaces if x["name"] == "GigabitEthernet3/0/2")
        self.assertEqual(member["lag"], {"id": r["interface_ids"]["Eth-Trunk2"]})
        before = len([c for c in nb.calls if c[0] == "PATCH"])
        run(nb, facts=facts, lag={"GigabitEthernet3/0/2": "Eth-Trunk2"})
        self.assertEqual(len([c for c in nb.calls if c[0] == "PATCH"]), before)

    def test_untyped_interface_is_skipped_with_warning_and_read_only_mode_writes_nothing(self):
        nb = FakeNetBox()
        r = run(nb, facts={"Mystery9": {}})
        self.assertEqual(r["skipped"], ["Mystery9"])
        self.assertTrue(r["warnings"])
        nb.add(1, "Vlanif18")
        r = run(nb, write=False)
        self.assertEqual(set(r["interface_ids"]), {"Vlanif18"})
        self.assertFalse([c for c in nb.calls if c[0] in ("POST", "PATCH")])

    def test_check_mode_makes_no_changes(self):
        nb = FakeNetBox()
        r = run(nb, check_mode=True)
        self.assertEqual(len(r["created"]), 3)
        self.assertFalse([c for c in nb.calls if c[0] in ("POST", "PATCH")])

    def test_every_interface_query_is_scoped_to_device_id(self):
        nb = FakeNetBox()
        nb.add(1, "A"); nb.add(2, "A")
        run(nb, facts={"A": {"type": "virtual"}})
        for m, u in nb.calls:
            if "/dcim/interfaces/" in u and m == "GET":
                self.assertIn("device_id=", u)


if __name__ == "__main__":
    unittest.main()
