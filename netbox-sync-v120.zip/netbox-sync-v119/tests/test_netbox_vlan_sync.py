"""Bulk VLAN synchronization: thousands of VLANs must cost a handful of API calls."""
import importlib.util
import io
import json
import sys
import unittest
import urllib.error
import urllib.parse
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("netbox_vlan_sync", ROOT / "roles/netbox_sync/library/netbox_vlan_sync.py")
mod = importlib.util.module_from_spec(spec)
sys.modules["netbox_vlan_sync"] = mod
spec.loader.exec_module(mod)
BASE = "https://nb.example"


class Resp:
    def __init__(self, payload):
        self._raw = json.dumps(payload).encode()

    def read(self):
        return self._raw

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


class Fake:
    def __init__(self, sites=None, vlans=None, bad_vid=None):
        self.sites = sites if sites is not None else [{"id": 3, "name": "P24", "slug": "p24"}]
        self.vlans = vlans or []
        self.bad_vid = bad_vid
        self.calls = []

    def __call__(self, req, timeout=None, context=None):
        url, method = req.full_url, req.get_method()
        self.calls.append(method)
        path = urllib.parse.urlparse(url).path
        if method == "GET" and path == "/api/dcim/sites/":
            return Resp({"results": self.sites, "next": None})
        if method == "GET" and path == "/api/ipam/vlans/":
            return Resp({"results": self.vlans, "next": None})
        if method == "POST" and path == "/api/ipam/vlans/":
            body = json.loads(req.data)
            items = body if isinstance(body, list) else [body]
            if any(i["vid"] == self.bad_vid for i in items):
                raise urllib.error.HTTPError(url, 400, "bad", {}, io.BytesIO(b'{"name":["bad"]}'))
            for i in items:
                self.vlans.append({"vid": i["vid"], "name": i["name"], "site": {"id": i["site"]}})
            return Resp(items)
        raise AssertionError((method, url))


def run(fake, vlans):
    return mod.sync_vlans(mod.Api(BASE, "tok", urlopen=fake), "P24", vlans)


class VlanSyncTests(unittest.TestCase):
    def test_thousands_of_vlans_few_calls_and_idempotent(self):
        fake = Fake(vlans=[{"vid": 10, "name": "old", "site": {"id": 3}}])
        wanted = [{"vid": 10, "name": "old"}] + [{"vid": v, "name": "v%d" % v} for v in range(100, 1600)]
        first = run(fake, wanted)
        self.assertEqual((len(first["created"]), first["unchanged"], first["errors"]), (1500, 1, []))
        self.assertLess(len(fake.calls), 20)
        second = run(fake, wanted)
        self.assertEqual((second["created"], second["unchanged"], second["changed"]), ([], 1501, False))

    def test_bad_vlan_reported_and_others_still_created(self):
        fake = Fake(bad_vid=150)
        res = run(fake, [{"vid": v, "name": "n%d" % v} for v in (100, 150, 200)])
        self.assertEqual(len(res["created"]), 2)
        self.assertEqual(len(res["errors"]), 1)
        self.assertIn("150", res["errors"][0])

    def test_invalid_items_skipped_and_site_must_be_unique(self):
        res = run(Fake(), [{"vid": 0, "name": "x"}, {"vid": 5000, "name": "x"}, {"name": "x"}, {"vid": 7, "name": " "}])
        self.assertEqual((res["created"], len(res["skipped"]), res["unnamed"]), ([], 3, 1))
        with self.assertRaises(mod.NetBoxApiError):
            run(Fake(sites=[]), [{"vid": 7, "name": "a"}])

    def test_other_site_vlans_do_not_count_as_existing(self):
        fake = Fake(vlans=[{"vid": 7, "name": "a", "site": {"id": 99}}])
        self.assertEqual(len(run(fake, [{"vid": 7, "name": "a"}])["created"]), 1)

    def test_site_matches_slug_or_name_case_insensitively(self):
        fake = Fake(sites=[{"id": 3, "name": "P24", "slug": "p24-dc"}, {"id": 4, "name": "Other", "slug": "other"}])
        for given in ("p24", "P24", "P24-DC"):
            self.assertEqual(mod.resolve_site(mod.Api(BASE, "t", urlopen=fake), given), 3)

    def test_unnamed_vlans_are_not_written(self):
        fake = Fake()
        res = run(fake, [{"vid": 1, "name": "-"}, {"vid": 2, "name": " - "}, {"vid": 3, "name": ""}, {"vid": 10, "name": "MGMT"}])
        self.assertEqual(res["created"], ["10 - MGMT"])
        self.assertEqual(res["unnamed"], 3)
        self.assertEqual([v["vid"] for v in fake.vlans], [10])

    def test_role_uses_bulk_module(self):
        text = (ROOT / "roles/netbox_sync/tasks/sync_to_netbox.yml").read_text()
        self.assertIn("netbox_vlan_sync:", text)
        self.assertNotIn("netbox.netbox.netbox_vlan:", text)


if __name__ == "__main__":
    unittest.main()
