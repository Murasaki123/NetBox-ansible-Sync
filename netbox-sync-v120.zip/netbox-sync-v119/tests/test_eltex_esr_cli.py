import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from eltex_esr_cli import clean, run_command, run_commands, strip_pager, strip_running_config_preamble  # noqa: E402


class FakeChannel:
    def __init__(self, chunks):
        self.chunks = list(chunks)
        self.sent = []

    def send(self, data):
        self.sent.append(data)

    def recv_ready(self):
        return bool(self.chunks)

    def recv(self, _size):
        return self.chunks.pop(0)


class CommandDrivenFakeChannel(FakeChannel):
    def __init__(self, responses):
        super().__init__([])
        self.responses = list(responses)

    def send(self, data):
        self.sent.append(data)
        if data.strip():
            self.chunks.append(self.responses.pop(0))


class EltexEsrCliRunnerTests(unittest.TestCase):
    def test_command_output_excludes_echo_and_prompt(self):
        channel = FakeChannel([b"show system\r\nSystem type: Eltex ESR-200 Service Router\r\nSystem name: AR1-COMERCIAL\r\nAR1-COMERCIAL#\r\n"])
        output = run_command(channel, "AR1-COMERCIAL#", "show system", timeout=1)
        self.assertEqual(output, "System type: Eltex ESR-200 Service Router\nSystem name: AR1-COMERCIAL\n")
        self.assertEqual(channel.sent, ["show system\n"])

    def test_batch_runs_multiple_commands_on_the_same_channel(self):
        channel = CommandDrivenFakeChannel([
            b"show system\r\nSystem name: AR1\r\nAR1#\r\n",
            b"show ip interface\r\nInterface: vlan 10\r\nAR1#\r\n",
        ])
        results = run_commands(channel, "AR1#", ["show system", "show ip interface"], timeout=1)
        self.assertEqual([item["command"] for item in results], ["show system", "show ip interface"])
        self.assertIn("System name: AR1", results[0]["stdout"])
        self.assertIn("Interface: vlan 10", results[1]["stdout"])
        self.assertEqual(channel.sent, ["show system\n", "show ip interface\n"])

    def test_paged_output_is_continued_and_markers_removed(self):
        channel = FakeChannel([b"show running-config\r\ninterface gigabitethernet 1/0/1.18\r\n  security-zone UNTRUST\r\n --More-- ",
                               b"\x08\x08\x08\x08\x08\x08\x08\x08\x08\x08 exit\r\nAR1#\r\n"])
        output = run_command(channel, "AR1#", "show running-config", timeout=1)
        self.assertEqual(channel.sent, ["show running-config\n", " "])
        self.assertIn("security-zone UNTRUST", output)
        self.assertNotIn("More", output)
        self.assertTrue(output.rstrip().endswith("exit"))

    def test_running_config_accepts_prompt_with_cli_context_suffix(self):
        channel = FakeChannel([
            b"show running-config\r\nhostname AR1\r\n",
            b"AR1(config)#\r\n",
        ])
        output = run_command(channel, "AR1#", "show running-config", timeout=2)
        self.assertEqual(output, "hostname AR1\n")

    def test_running_config_accepts_spaced_context_prompt_without_trailing_newline(self):
        channel = FakeChannel([
            b"show running-config\r\nhostname AR1\r\n",
            b"AR1 (config)#",
        ])
        output = run_command(channel, "AR1#", "show running-config", timeout=1)
        self.assertEqual(output, "hostname AR1\n")

    def test_clean_removes_nonprinting_terminal_control_bytes(self):
        self.assertEqual(clean("line\x00\x07\x08\x1b[31mtext\x1b[0m\r\n"), "linetext\n")

    def test_timeout_diagnostic_does_not_echo_received_configuration(self):
        channel = FakeChannel([b"show running-config\r\nusername admin password SECRET\r\n"])
        with self.assertRaises(TimeoutError) as ctx:
            run_command(channel, "AR1#", "show running-config", timeout=0.1)
        self.assertIn("Received", str(ctx.exception))
        self.assertNotIn("SECRET", str(ctx.exception))

    def test_running_config_removes_progressive_command_echo_before_first_config_line(self):
        noisy = "sshshoshowshow show rshow rushow running-config\nhostname ESR1000\nvlan 3\n"
        self.assertEqual(strip_running_config_preamble(noisy), "hostname ESR1000\nvlan 3\n")

    def test_strip_pager_leaves_normal_text(self):
        self.assertEqual(strip_pager("no more output here\n"), "no more output here\n")

    def test_clean_removes_terminal_escape_sequences(self):
        self.assertEqual(clean("\x1b[32mAR1-COMERCIAL#\x1b[0m\r\n"), "AR1-COMERCIAL#\n")


if __name__ == "__main__":
    unittest.main()
