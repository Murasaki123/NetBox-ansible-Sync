"""Site / device-role choices for the device form (presets, real NetBox data, idempotent creation)."""
import io
import json
import sys
import unittest
import urllib.error
import urllib.parse
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from webui import netbox_post_sync as nps  # noqa: E402


class Resp:
    def __init__(self, payload):
        self._raw = json.dumps(payload).encode()
    def read(self):
        return self._raw
    def __enter__(self):
        return self
    def __exit__(self, *a):
        return False


class FakeNetBox:
    def __init__(self):
        self.data = {"/api/dcim/sites/": [], "/api/dcim/device-roles/": []}
        self.calls, self.fail_post = [], False

    def __call__(self, req, timeout=None, context=None):
        parsed = urllib.parse.urlsplit(req.full_url)
        q = {k: v[0] for k, v in urllib.parse.parse_qs(parsed.query).items()}
        self.calls.append((req.get_method(), parsed.path, q))
        rows = self.data[parsed.path]
        if req.get_method() == "GET":
            sel = [r for r in rows if all(str(r.get(k)) == v for k, v in q.items() if k in ("slug", "name"))]
            return Resp({"count": len(sel), "next": None, "results": sel})
        if self.fail_post:
            raise urllib.error.HTTPError(req.full_url, 400, "bad", {}, io.BytesIO(b'{"slug":["invalid"]}'))
        body = json.loads(req.data)
        body["id"] = len(rows) + 1
        rows.append(body)
        return Resp(body)


def client(fake):
    return nps.NetBoxClient("https://nb.example", "tok-123456789", urlopen=fake)


class ChoicesTests(unittest.TestCase):
    def test_presets_are_offered_when_netbox_has_none(self):
        res = nps.list_choices(client(FakeNetBox()))
        self.assertEqual([s["slug"] for s in res["site"]], ["p24"])
        self.assertEqual(sorted(r["slug"] for r in res["role"]), sorted(["sw", "l3-sw", "core-sw", "router", "fw"]))
        self.assertTrue(all(not i["exists"] for i in res["site"] + res["role"]))

    def test_real_netbox_objects_are_listed_and_not_duplicated_by_presets(self):
        fake = FakeNetBox()
        fake.data["/api/dcim/sites/"] += [{"name": "P24", "slug": "p24"}, {"name": "Офис", "slug": "office"}]
        fake.data["/api/dcim/device-roles/"] += [{"name": "Switch", "slug": "sw"}]
        res = nps.list_choices(client(fake))
        self.assertEqual({s["slug"]: s["exists"] for s in res["site"]}, {"p24": True, "office": True})
        roles = {r["slug"]: r for r in res["role"]}
        self.assertTrue(roles["sw"]["exists"] and roles["sw"]["name"] == "Switch")
        self.assertFalse(roles["fw"]["exists"])
        self.assertEqual(len(res["role"]), 5)

    def test_ensure_creates_once_and_is_idempotent(self):
        fake = FakeNetBox()
        first = nps.ensure_object(client(fake), "site", "P24")
        self.assertEqual((first["slug"], first["created"]), ("p24", True))
        again = nps.ensure_object(client(fake), "site", "P24")
        self.assertEqual((again["slug"], again["created"]), ("p24", False))
        self.assertEqual(len([c for c in fake.calls if c[0] == "POST"]), 1)
        self.assertEqual(fake.data["/api/dcim/sites/"][0]["status"], "active")

    def test_role_payload_has_color_and_ascii_slug_from_name(self):
        fake = FakeNetBox()
        res = nps.ensure_object(client(fake), "role", "Core SW")
        self.assertEqual(res["slug"], "core-sw")
        self.assertEqual(fake.data["/api/dcim/device-roles/"][0]["color"], "9e9e9e")

    def test_existing_name_with_other_slug_is_reused_not_recreated(self):
        fake = FakeNetBox()
        fake.data["/api/dcim/device-roles/"].append({"name": "router", "slug": "rtr"})
        res = nps.ensure_object(client(fake), "role", "router")
        self.assertEqual((res["slug"], res["created"]), ("rtr", False))
        self.assertFalse([c for c in fake.calls if c[0] == "POST"])

    def test_invalid_names_and_api_errors_are_reported(self):
        for bad in ("", "   ", "Площадка", "a/b", "x" * 101):
            with self.assertRaises(nps.NetBoxError, msg=bad):
                nps.ensure_object(client(FakeNetBox()), "site", bad)
        fake = FakeNetBox()
        fake.fail_post = True
        with self.assertRaisesRegex(nps.NetBoxError, "HTTP 400"):
            nps.ensure_object(client(fake), "site", "newsite")

    def test_derive_slug(self):
        self.assertEqual(nps.derive_slug("L3 SW"), "l3-sw")
        self.assertEqual(nps.derive_slug("core-sw"), "core-sw")
        self.assertEqual(nps.derive_slug("Москва"), "")

    def test_api_and_form_are_wired(self):
        app = (ROOT / "webui/app.py").read_text()
        html = (ROOT / "webui/index.html").read_text()
        for route in ('"/api/netbox/choices"', '"/api/netbox/sites"', '"/api/netbox/roles"'):
            self.assertIn(route, app)
        self.assertIn('<select id="dnb-site"', html)
        self.assertIn('<select id="dnb-role"', html)
        self.assertIn("＋ Новая…", html)
        self.assertIn("resolveNbChoice", html)


if __name__ == "__main__":
    unittest.main()
