"""Security zones for the prefix comments: Huawei `display zone`, ESR `security-zone`."""
import importlib.util
import sys
import unittest
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from filter_plugins import netbox_sync_parsers as f  # noqa: E402

spec = importlib.util.spec_from_file_location("netbox_prefix_sync", ROOT / "roles/netbox_sync/library/netbox_prefix_sync.py")
mod = importlib.util.module_from_spec(spec)
sys.modules["netbox_prefix_sync"] = mod
spec.loader.exec_module(mod)

HUAWEI = """2026-11-13 09:34:14.330 +04:00
local
 priority is 100
 interface of the zone is (0):
#
trust
 priority is 85
 interface of the zone is (0):
#
untrust
 priority is 5
 interface of the zone is (5):
    Eth-Trunk1.1096
    Eth-Trunk1.16
    Eth-Trunk1.983
    Eth-Trunk2.36
    Vlanif4093
#
dmz
 priority is 50
 interface of the zone is (3):
    Eth-Trunk2.222
    Eth-Trunk2.4
    Virtual-if0
#
mgmt                                      
 description Management
 priority is 99
 interface of the zone is (10):
    Eth-Trunk2.200
    GigabitEthernet0/0/0
    GigabitEthernet1/0/6
    Vlanif27
"""

ESR = """interface gigabitethernet 1/0/1.18
  shutdown
  description "ISP_RT"
  security-zone UNTRUST
exit
interface gigabitethernet 1/0/1.785
  description "RT_for_Wi-Fi"
  security-zone UNTRUST
  ip address 10.10.78.1/30
  vrrp id 78
  vrrp ip 78.85.7.78/30
  vrrp priority 200
  vrrp group 10
  vrrp
exit
interface tengigabitethernet 1/0/2
  security-zone TRUST
exit
interface gigabitethernet 1/0/3
  description "no zone"
exit
security zone TRUST
exit
"""


class ZoneParsers(unittest.TestCase):
    def test_huawei(self):
        z = f.parse_huawei_zones(HUAWEI)
        self.assertEqual(z["Eth-Trunk1.1096"], "untrust")
        self.assertEqual(z["Vlanif4093"], "untrust")
        self.assertEqual(z["Virtual-if0"], "dmz")
        self.assertEqual(z["GigabitEthernet0/0/0"], "mgmt")
        self.assertEqual(z["Vlanif27"], "mgmt")
        self.assertEqual(len(z), 5 + 3 + 4)
        self.assertNotIn("local", z.values())
        self.assertEqual(f.parse_huawei_zones("Error: unsupported"), {})
        self.assertEqual(f.parse_huawei_zones(""), {})

    def test_esr(self):
        z = f.parse_eltex_esr_zones(ESR)
        self.assertEqual(z, {"gi1/0/1.18": "UNTRUST", "gi1/0/1.785": "UNTRUST", "te1/0/2": "TRUST"})
        self.assertEqual(f.parse_eltex_esr_zones(""), {})


class CommentZone(unittest.TestCase):
    def test_zone_line_case_insensitive_and_unique(self):
        entries = [{"ip": "10.1.2.5", "prefix": "24", "interface": "Eth-Trunk1.16"},
                   {"ip": "10.1.2.6", "prefix": "24", "interface": "eth-trunk1.16"}]
        text = mod.build_comment("FW1", entries, {"Eth-Trunk1.16": "untrust"})
        self.assertTrue(text.endswith("Vlan: 16\nZone: untrust"))
        self.assertNotIn("Zone", mod.build_comment("FW1", entries, {}))
        self.assertNotIn("Zone", mod.build_comment("FW1", entries))


class Wiring(unittest.TestCase):
    def test_tasks_and_report(self):
        for rel in ("collect_facts", "eltex_esr", "load_reviewed_facts", "sync_to_netbox"):
            yaml.safe_load((ROOT / "roles/netbox_sync/tasks" / (rel + ".yml")).read_text())
        collect = (ROOT / "roles/netbox_sync/tasks/collect_facts.yml").read_text()
        self.assertIn("command: display zone", collect)
        self.assertIn("'interface_zones': interface_zones | default({})", collect)
        self.assertIn("interface_zones", (ROOT / "roles/netbox_sync/tasks/load_reviewed_facts.yml").read_text())
        self.assertIn("interface_zones:", (ROOT / "roles/netbox_sync/tasks/sync_to_netbox.yml").read_text())


if __name__ == "__main__":
    unittest.main()
