# Production acceptance checklist

- [x] Target NetBox version recorded: 4.5.10 (API integration still requires a test instance).
- [x] Local device registry is the source of device addresses and credentials for collection; credentials are encrypted at rest.
- [x] Collect and sync are separate workflows; sync loads saved facts instead of polling devices again.
- [x] Manual sync requires explicit UI confirmation, the Administration write-enable setting, a configured NetBox URL/token, fresh reports, one matching collection batch, and explicit NetBox site/role/device-type mappings.
- [x] NetBox API token is encrypted at rest; Administration never returns the token value.
- [x] Automatic sync is independently configurable and disabled by default; it runs only after a successful collection and for the same target set.
- [x] NetBox object deletion remains disabled; reverse configuration workflow is removed from UI and playbook.
- [x] Parser unit tests cover supplied Huawei USG/VRP and Eltex MES CLI samples.
- [x] Added Cisco IOS/IOS XE and SNR eNOS collection paths with parser unit tests; actual hardware output validation remains pending.
- [x] Web UI selects an exact model profile; unknown models are registry/TCP-only and blocked from CLI collection.
- [x] Separate Huawei USG and S5735 task entry points are selected by model profile.
- [ ] Run `ansible-playbook --syntax-check` in the deployment image with installed collections.
- [ ] Verify exact Ansible Core and collection versions installed from local artifacts.
- [ ] Verify Cisco IOS XE terminal handling and SNR eNOS SSH prompt/terminal handling in the deployment image.
- [ ] Run read-only collection against reachable and unreachable Huawei USG6670/USG6635E, Huawei S5735 models, Eltex MES-5324A, Cisco Catalyst 9410 (IOS XE 16.06.04), and SNR S5311G48TXPOE (eNOS 1.23.0) devices.
- [ ] Validate all NetBox device type, site, role and interface type mappings against NetBox 4.5.10.
- [ ] Test sync against a disposable NetBox instance and review each created/updated object.
- [ ] Test stack member and serial-number modeling; physical stack topology is not fully implemented yet.
- [x] Add local logical-device grouping with explicit physical-member association and optional ESR-200 VRRP fact collection; actual CLI output validation and NetBox modeling remain pending.
- [ ] Validate LLDP/CDP neighbor parsing and cable mapping before enabling topology sync.
- [ ] Verify external network access is not required during normal operation.


## ESR administration v120
- Opening the ESR administration section loads the current ESR device registry automatically.
- The ESR registry refreshes automatically while the section is active; no manual refresh button is shown.
- The selected device remains selected if it remains eligible.
- The selected device's saved configuration is reloaded only when the registry/selection changes; SSH collection remains an explicit user action.
- Parsed data includes typed dependency edges for interfaces, zones, VRRP, PBR, bridge/VLAN, NAT pools and VRFs.
- Object drill-down shows related interfaces, rules or zone-pairs where applicable.
- All ESR operations remain read-only; no configuration writes are performed.


### v119 — dependency disclosure

- Zone and route-map/PBR interface dependencies are displayed as counts and expand to exact names only on demand.
- Zone-pair, NAT pool, ACL and network/service-object references use the same compact disclosure pattern.
- Empty dependency lists explicitly report «Не используется».

### v120 — VLAN inventory and Security Zone navigation

- VLAN inventory is available as a separate sidebar pane; the Interfaces pane no longer prints the complete VLAN list inline.
- VLAN rows show ID/name and expandable bridge, PVID and allowed-port membership. VLAN ranges in switchport allowed-VLAN declarations are evaluated when matching membership.
- Security Zone names in the Security zones table open their detail disclosure, consistent with zone references from Interfaces.
