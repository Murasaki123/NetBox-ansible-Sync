## v87 — Unambiguous IP-to-interface assignment
- Resolve the NetBox device once and fetch its interfaces by numeric device ID.
- Assign IP addresses through the NetBox REST API using the exact numeric interface ID, avoiding ambiguous lookup by repeated interface names across devices.
- Create a missing IP object or update a single exact match. If NetBox returns multiple IP objects for the same address, skip it and report the ambiguity rather than selecting one arbitrarily.
- Detect duplicate interface names within one physical device; skip only those ambiguous interface updates and report the conflicting object IDs. Do not create duplicate records, delete records, or merge objects.
- Identical interface names on the two members of a Huawei HA virtual chassis remain valid. Shared HA IP exclusions and virtual chassis post-sync behavior are preserved.

