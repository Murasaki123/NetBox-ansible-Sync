"""NetBox steps that run after the Ansible synchronization: virtual chassis and LLDP cables.

Standard library only, so it can be tested without the web framework. Every write is
idempotent (existing objects are left alone) and a failure on one object never stops
the remaining ones; errors are collected and reported to the operator.
"""
from __future__ import annotations

import json
import ssl
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable

NON_CABLE_INTERFACE_TYPES = {"lag", "virtual", "bridge"}


class NetBoxError(RuntimeError):
    """A NetBox API call failed; the message is safe to show (it never contains the token)."""


@dataclass
class StepResult:
    created: int = 0
    updated: int = 0
    unchanged: int = 0
    skipped: int = 0
    errors: list[str] = field(default_factory=list)


class NetBoxClient:
    def __init__(self, base_url: str, token: str, verify: bool = False, timeout: int = 20,
                 urlopen: Callable[..., Any] | None = None) -> None:
        self.base_url = base_url.rstrip("/")
        self._token = token
        self._timeout = timeout
        self._urlopen = urlopen or urllib.request.urlopen
        self._context = ssl.create_default_context() if verify else ssl._create_unverified_context()
        self._scheme: str | None = None  # "Token" (v1 tokens) or "Bearer" (v2 tokens), detected on first use

    @staticmethod
    def _detail(exc: urllib.error.HTTPError) -> str:
        try:
            raw = exc.read().decode("utf-8", "replace")
        except Exception:
            return ""
        try:
            data = json.loads(raw)
            return json.dumps(data, ensure_ascii=False)[:300]
        except ValueError:
            return raw[:300]

    def _send(self, method: str, url: str, body: dict[str, Any] | None = None) -> Any:
        data = json.dumps(body).encode("utf-8") if body is not None else None
        schemes = [self._scheme] if self._scheme else ["Token", "Bearer"]
        shown = url[len(self.base_url):] if url.startswith(self.base_url) else url
        for index, scheme in enumerate(schemes):
            request = urllib.request.Request(url, data=data, method=method, headers={
                "Authorization": f"{scheme} {self._token}", "Accept": "application/json",
                "Content-Type": "application/json"})
            try:
                with self._urlopen(request, timeout=self._timeout, context=self._context) as response:
                    raw = response.read()
                self._scheme = scheme
                return json.loads(raw.decode("utf-8")) if raw else None
            except urllib.error.HTTPError as exc:
                if exc.code in (401, 403) and index < len(schemes) - 1:
                    continue  # nothing was changed on 401/403: retry with the other token scheme
                raise NetBoxError(f"{method} {shown}: HTTP {exc.code} {self._detail(exc)}".strip()) from exc
            except (urllib.error.URLError, TimeoutError, OSError, ValueError) as exc:
                raise NetBoxError(f"{method} {shown}: {getattr(exc, 'reason', exc)}") from exc
        raise NetBoxError(f"{method} {shown}: no response")

    def get_all(self, path: str, params: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        query = urllib.parse.urlencode({**(params or {}), "limit": 1000})
        url: str | None = f"{self.base_url}{path}?{query}"
        results: list[dict[str, Any]] = []
        while url:
            page = self._send("GET", url)
            results.extend((page or {}).get("results", []))
            next_url = (page or {}).get("next")
            url = next_url if next_url and str(next_url).startswith(self.base_url) else None
        return results

    def post(self, path: str, body: dict[str, Any]) -> Any:
        return self._send("POST", f"{self.base_url}{path}", body)

    def patch(self, path: str, body: dict[str, Any]) -> Any:
        return self._send("PATCH", f"{self.base_url}{path}", body)


def _one_device(client: NetBoxClient, name: str) -> dict[str, Any] | None:
    found = client.get_all("/api/dcim/devices/", {"name": name})
    if len(found) > 1:
        raise NetBoxError(f"в NetBox найдено несколько устройств с именем «{name}»")
    return found[0] if found else None


def sync_virtual_chassis(client: NetBoxClient, chassis_list: Iterable[dict[str, Any]],
                         log: Callable[[str], None]) -> StepResult:
    """One NetBox Virtual Chassis per local group; its members are the already synchronized physical devices."""
    result = StepResult()
    for chassis in chassis_list:
        name, members = str(chassis["name"]), list(chassis["members"])
        try:
            devices: list[dict[str, Any]] = []
            missing: list[str] = []
            for member in members:
                device = _one_device(client, member)
                (devices if device else missing).append(device or member)  # type: ignore[arg-type]
            if missing:
                result.skipped += 1
                log(f"Виртуальное шасси «{name}» пропущено: в NetBox ещё нет устройств {', '.join(missing)}.")
                continue
            existing = [v for v in client.get_all("/api/dcim/virtual-chassis/", {"name": name}) if v.get("name") == name]
            if existing:
                vc = existing[0]
            else:
                vc = client.post("/api/dcim/virtual-chassis/", {"name": name})
                result.created += 1
                log(f"Виртуальное шасси «{name}» создано.")
            changed = False
            taken = {d.get("vc_position") for d in devices
                     if (d.get("virtual_chassis") or {}).get("id") == vc["id"] and d.get("vc_position") is not None}
            for device in devices:
                if (device.get("virtual_chassis") or {}).get("id") == vc["id"] and device.get("vc_position") is not None:
                    continue
                position = 1
                while position in taken:
                    position += 1
                taken.add(position)
                client.patch(f"/api/dcim/devices/{device['id']}/", {"virtual_chassis": vc["id"], "vc_position": position})
                device["virtual_chassis"], device["vc_position"] = {"id": vc["id"]}, position
                changed = True
                result.updated += 1
                log(f"Устройство «{device['name']}» добавлено в виртуальное шасси «{name}» (позиция {position}).")
            if not (vc.get("master") or {}).get("id"):
                client.patch(f"/api/dcim/virtual-chassis/{vc['id']}/", {"master": devices[0]["id"]})
                changed = True
                log(f"Мастер шасси «{name}»: {devices[0]['name']}.")
            if not changed and existing:
                result.unchanged += 1
                log(f"Виртуальное шасси «{name}» уже актуально.")
        except (NetBoxError, KeyError, IndexError) as exc:
            message = f"Виртуальное шасси «{name}»: {exc}"
            result.errors.append(message)
            log(f"ОШИБКА. {message}")
    return result


def sync_cables(client: NetBoxClient, links: Iterable[dict[str, Any]], normalise: Callable[[Any], str],
                log: Callable[[str], None]) -> StepResult:
    """Create a cable for each LLDP link whose two interfaces already exist in NetBox and are free."""
    result = StepResult()
    devices: dict[str, dict[str, Any] | None] = {}
    interfaces: dict[int, list[dict[str, Any]]] = {}

    def device(name: str) -> dict[str, Any] | None:
        if name not in devices:
            devices[name] = _one_device(client, name)
        return devices[name]

    def interface(device_name: str, port: str) -> dict[str, Any] | None:
        dev = device(device_name)
        if dev is None:
            raise NetBoxError(f"устройства «{device_name}» нет в NetBox")
        if dev["id"] not in interfaces:
            interfaces[dev["id"]] = client.get_all("/api/dcim/interfaces/", {"device_id": dev["id"]})
        items = interfaces[dev["id"]]
        exact = [i for i in items if i.get("name") == port]
        if exact:
            return exact[0]
        candidates = [i for i in items if normalise(i.get("name")) == normalise(port)]
        return candidates[0] if len(candidates) == 1 else None

    for link in links:
        label = f"{link['local_name']} {link['local_interface']} ↔ {link['remote_name']} {link['remote_interface']}"
        try:
            a = interface(link["local_name"], link["local_interface"])
            b = interface(link["remote_name"], link["remote_interface"])
            if a is None or b is None:
                result.skipped += 1
                log(f"Кабель пропущен ({label}): интерфейс не найден в NetBox.")
                continue
            if a["id"] == b["id"]:
                result.skipped += 1
                continue
            types = {(a.get("type") or {}).get("value"), (b.get("type") or {}).get("value")}
            if types & NON_CABLE_INTERFACE_TYPES:
                result.skipped += 1
                log(f"Кабель пропущен ({label}): к логическому интерфейсу кабель не подключается.")
                continue
            cable_a, cable_b = (a.get("cable") or {}).get("id"), (b.get("cable") or {}).get("id")
            if cable_a and cable_a == cable_b:
                result.unchanged += 1
                continue
            if cable_a or cable_b:
                result.skipped += 1
                log(f"Кабель пропущен ({label}): порт уже подключён другим кабелем в NetBox.")
                continue
            created = client.post("/api/dcim/cables/", {
                "a_terminations": [{"object_type": "dcim.interface", "object_id": a["id"]}],
                "b_terminations": [{"object_type": "dcim.interface", "object_id": b["id"]}],
                "status": "connected"})
            marker = {"id": (created or {}).get("id", -1)}
            a["cable"], b["cable"] = marker, marker
            result.created += 1
            log(f"Кабель создан: {label}.")
        except (NetBoxError, KeyError) as exc:
            message = f"Кабель {label}: {exc}"
            result.errors.append(message)
            log(f"ОШИБКА. {message}")
    return result


def shared_ip_exclusions(members_by_chassis: dict[str, list[str]], ips_by_device: dict[str, set[str]]) -> dict[str, list[str]]:
    """IPs that several members of one virtual chassis report (HA pairs, VIPs) are synchronized once,
    by the first member; later members must not claim the same address."""
    exclusions: dict[str, list[str]] = {}
    for members in members_by_chassis.values():
        seen: set[str] = set()
        for index, member in enumerate(members):
            ips = set(ips_by_device.get(member, set()))
            if index:
                shared = sorted(ips & seen)
                if shared:
                    exclusions[member] = shared
            seen |= ips
    return exclusions
