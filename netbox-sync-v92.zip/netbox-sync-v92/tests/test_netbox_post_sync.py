import io
import json
import sys
import unittest
import urllib.error
import urllib.parse
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from webui import netbox_post_sync as nps  # noqa: E402


def normalise(value):
    text = "".join(str(value or "").split()).lower()
    for long_name, short in (("gigabitethernet", "gi"), ("tengigabitethernet", "te")):
        if text.startswith(long_name):
            return short + text[len(long_name):]
    return text


class FakeResponse:
    def __init__(self, payload):
        self._raw = json.dumps(payload).encode()

    def read(self):
        return self._raw

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


class FakeNetBox:
    """Tiny in-memory NetBox: devices, interfaces, virtual chassis and cables."""

    def __init__(self, scheme="Token"):
        self.scheme = scheme
        self.devices = []
        self.interfaces = {}
        self.vcs = []
        self.cables = []
        self.calls = []
        self.fail_cable_posts = False
        self._next = 100

    def add_device(self, name):
        device = {"id": len(self.devices) + 1, "name": name, "virtual_chassis": None, "vc_position": None}
        self.devices.append(device)
        return device

    def add_interface(self, device, name, type_value="1000base-t", cable=None):
        item = {"id": self._next, "name": name, "type": {"value": type_value}, "cable": cable}
        self._next += 1
        self.interfaces.setdefault(device["id"], []).append(item)
        return item

    def _http_error(self, url, code, body):
        return urllib.error.HTTPError(url, code, "err", {}, io.BytesIO(json.dumps(body).encode()))

    def __call__(self, request, timeout=None, context=None):
        url, method = request.full_url, request.get_method()
        auth = request.get_header("Authorization")
        self.calls.append((method, url, auth))
        if not auth.startswith(self.scheme + " "):
            raise self._http_error(url, 403, {"detail": "Invalid token"})
        parsed = urllib.parse.urlparse(url)
        query = urllib.parse.parse_qs(parsed.query)
        path = parsed.path
        body = json.loads(request.data) if request.data else None
        if method == "GET" and path == "/api/dcim/devices/":
            return FakeResponse({"results": [d for d in self.devices if d["name"] == query["name"][0]], "next": None})
        if method == "GET" and path == "/api/dcim/interfaces/":
            return FakeResponse({"results": self.interfaces.get(int(query["device_id"][0]), []), "next": None})
        if method == "GET" and path == "/api/dcim/virtual-chassis/":
            return FakeResponse({"results": [v for v in self.vcs if v["name"] == query["name"][0]], "next": None})
        if method == "POST" and path == "/api/dcim/virtual-chassis/":
            vc = {"id": 500 + len(self.vcs), "name": body["name"], "master": None}
            self.vcs.append(vc)
            return FakeResponse(vc)
        if method == "PATCH" and path.startswith("/api/dcim/devices/"):
            device = next(d for d in self.devices if d["id"] == int(path.rstrip("/").split("/")[-1]))
            device["virtual_chassis"] = {"id": body["virtual_chassis"]}
            device["vc_position"] = body["vc_position"]
            return FakeResponse(device)
        if method == "PATCH" and path.startswith("/api/dcim/virtual-chassis/"):
            vc = next(v for v in self.vcs if v["id"] == int(path.rstrip("/").split("/")[-1]))
            vc["master"] = {"id": body["master"]}
            return FakeResponse(vc)
        if method == "POST" and path == "/api/dcim/cables/":
            if self.fail_cable_posts:
                raise self._http_error(url, 400, {"detail": "boom"})
            cable = {"id": 900 + len(self.cables)}
            self.cables.append(cable)
            ids = {body["a_terminations"][0]["object_id"], body["b_terminations"][0]["object_id"]}
            for items in self.interfaces.values():
                for item in items:
                    if item["id"] in ids:
                        item["cable"] = {"id": cable["id"]}
            return FakeResponse(cable)
        raise AssertionError(f"unexpected request {method} {url}")


def client_for(fake):
    return nps.NetBoxClient("http://netbox.local:8000", "secret-token", urlopen=fake)


class PostSyncTests(unittest.TestCase):
    def test_token_scheme_is_detected_and_error_never_contains_token(self):
        fake = FakeNetBox(scheme="Bearer")
        fake.add_device("sw1")
        client = client_for(fake)
        self.assertEqual(len(client.get_all("/api/dcim/devices/", {"name": "sw1"})), 1)
        self.assertEqual([c[2].split()[0] for c in fake.calls], ["Token", "Bearer"])
        client.get_all("/api/dcim/devices/", {"name": "sw1"})
        self.assertEqual(fake.calls[-1][2].split()[0], "Bearer")  # remembered, no second probe
        bad = client_for(FakeNetBox(scheme="Other"))
        with self.assertRaises(nps.NetBoxError) as ctx:
            bad.get_all("/api/dcim/devices/", {"name": "x"})
        self.assertNotIn("secret-token", str(ctx.exception))
        self.assertIn("Invalid token", str(ctx.exception))

    def test_virtual_chassis_created_members_assigned_and_idempotent(self):
        fake = FakeNetBox()
        a, b = fake.add_device("DTC-P24-HUW-23-1"), fake.add_device("DTC-HUW2_23-1")
        logs = []
        chassis = [{"name": "Huawei USG 6670", "members": ["DTC-P24-HUW-23-1", "DTC-HUW2_23-1"]}]
        first = nps.sync_virtual_chassis(client_for(fake), chassis, logs.append)
        self.assertEqual((first.created, first.updated, first.errors), (1, 2, []))
        self.assertEqual(fake.vcs[0]["name"], "Huawei USG 6670")
        self.assertEqual((a["vc_position"], b["vc_position"]), (1, 2))
        self.assertEqual(fake.vcs[0]["master"], {"id": a["id"]})
        patches_before = sum(1 for c in fake.calls if c[0] in ("PATCH", "POST"))
        second = nps.sync_virtual_chassis(client_for(fake), chassis, logs.append)
        self.assertEqual((second.created, second.updated, second.unchanged, second.errors), (0, 0, 1, []))
        self.assertEqual(sum(1 for c in fake.calls if c[0] in ("PATCH", "POST")), patches_before)

    def test_virtual_chassis_skipped_when_a_member_is_not_in_netbox_yet(self):
        fake = FakeNetBox()
        fake.add_device("only-one")
        result = nps.sync_virtual_chassis(client_for(fake), [{"name": "G", "members": ["only-one", "ghost"]}], lambda _: None)
        self.assertEqual((result.skipped, result.created, result.errors), (1, 0, []))
        self.assertEqual(fake.vcs, [])

    def test_cables_created_with_abbreviated_remote_port_then_idempotent(self):
        fake = FakeNetBox()
        s1, s2 = fake.add_device("s1"), fake.add_device("s2")
        fake.add_interface(s1, "GigabitEthernet3/0/9")
        fake.add_interface(s2, "TenGigabitEthernet5/0/3")
        links = [{"local_name": "s1", "local_interface": "GigabitEthernet3/0/9",
                  "remote_name": "s2", "remote_interface": "Te5/0/3"}]
        first = nps.sync_cables(client_for(fake), links, normalise, lambda _: None)
        self.assertEqual((first.created, first.errors), (1, []))
        second = nps.sync_cables(client_for(fake), links, normalise, lambda _: None)
        self.assertEqual((second.created, second.unchanged, second.errors), (0, 1, []))
        self.assertEqual(len(fake.cables), 1)

    def test_cables_skip_occupied_logical_and_unknown_ports_without_failing(self):
        fake = FakeNetBox()
        s1, s2 = fake.add_device("s1"), fake.add_device("s2")
        fake.add_interface(s1, "Gi1/0/1", cable={"id": 7})
        fake.add_interface(s2, "Gi1/0/1")
        fake.add_interface(s1, "Eth-Trunk1", type_value="lag")
        fake.add_interface(s2, "Eth-Trunk1", type_value="lag")
        logs = []
        links = [
            {"local_name": "s1", "local_interface": "Gi1/0/1", "remote_name": "s2", "remote_interface": "Gi1/0/1"},
            {"local_name": "s1", "local_interface": "Eth-Trunk1", "remote_name": "s2", "remote_interface": "Eth-Trunk1"},
            {"local_name": "s1", "local_interface": "Gi9/9/9", "remote_name": "s2", "remote_interface": "Gi1/0/1"},
        ]
        result = nps.sync_cables(client_for(fake), links, normalise, logs.append)
        self.assertEqual((result.created, result.skipped, result.errors), (0, 3, []))
        self.assertEqual(fake.cables, [])

    def test_cable_error_is_collected_and_other_links_still_processed(self):
        fake = FakeNetBox()
        s1, s2, s3 = fake.add_device("s1"), fake.add_device("s2"), fake.add_device("s3")
        for dev in (s1, s2, s3):
            fake.add_interface(dev, "Gi1/0/1")
            fake.add_interface(dev, "Gi1/0/2")
        links = [{"local_name": "s1", "local_interface": "Gi1/0/1", "remote_name": "s2", "remote_interface": "Gi1/0/1"},
                 {"local_name": "s3", "local_interface": "Gi1/0/1", "remote_name": "ghost", "remote_interface": "Gi1/0/1"}]
        fake.fail_cable_posts = True
        result = nps.sync_cables(client_for(fake), links, normalise, lambda _: None)
        self.assertEqual(len(result.errors), 2)
        self.assertIn("boom", result.errors[0])
        self.assertIn("ghost", result.errors[1])

    def test_shared_ip_exclusions_keep_first_member_only(self):
        ips = {"a": {"10.0.0.1", "10.0.0.2"}, "b": {"10.0.0.1", "10.0.0.3"}, "c": {"10.0.0.1"}}
        result = nps.shared_ip_exclusions({"g": ["a", "b", "c"]}, ips)
        self.assertEqual(result, {"b": ["10.0.0.1"], "c": ["10.0.0.1"]})
        self.assertEqual(nps.shared_ip_exclusions({"g": ["a"]}, ips), {})


class WiringTests(unittest.TestCase):
    def test_sync_job_runs_post_sync_and_ip_sync_is_default_on(self):
        app = (ROOT / "webui/app.py").read_text()
        self.assertIn('if mode == "sync":\n            # Also after a partial Ansible failure', app)
        self.assertIn("post_text, post_ok = _netbox_post_sync(limit)", app)
        self.assertIn('"sync_ip_addresses": True,', app)
        self.assertIn('"ip_sync_exclude": ip_exclusions.get(row["name"], []),', app)
        task = (ROOT / "roles/netbox_sync/tasks/sync_to_netbox.yml").read_text()
        self.assertIn("item.ip not in (ip_sync_exclude | default([]))", task)


if __name__ == "__main__":
    unittest.main()
