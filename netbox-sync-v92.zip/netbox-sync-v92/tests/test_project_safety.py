from pathlib import Path
import unittest
import yaml

ROOT = Path(__file__).resolve().parents[1]

class ProjectSafetyTests(unittest.TestCase):
    def test_yaml_files_parse(self):
        candidates = list(ROOT.rglob('*.yml')) + list(ROOT.rglob('*.yaml'))
        for path in candidates:
            if path.name == 'vault.yml':
                # This file is plaintext placeholder in the starter archive; parse still required.
                pass
            with self.subTest(path=str(path.relative_to(ROOT))):
                with path.open(encoding='utf-8') as handle:
                    yaml.safe_load(handle)

    def test_reverse_configuration_workflow_is_removed(self):
        site = (ROOT / 'site.yml').read_text()
        main_tasks = (ROOT / 'roles/netbox_sync/tasks/main.yml').read_text()
        self.assertIn("workflow_mode in ['collect', 'sync']", site)
        self.assertNotIn("workflow_mode == 'deploy'", site)
        self.assertNotIn('include_tasks: render.yml', main_tasks)
        self.assertFalse((ROOT / 'roles/netbox_sync/tasks/deploy.yml').exists())
        self.assertFalse((ROOT / 'roles/netbox_sync/tasks/render.yml').exists())

    def test_vault_password_uses_persistent_data_volume_not_single_file_mount(self):
        compose = (ROOT / 'docker-compose.yml').read_text()
        self.assertIn('ANSIBLE_VAULT_PASSWORD_FILE: /var/lib/netbox-sync/vault_pass', compose)
        self.assertIn('NETBOX_VAULT_FILE: /var/lib/netbox-sync/vault.yml', compose)
        self.assertNotIn('/run/secrets/vault_pass', compose)
        self.assertNotIn('VAULT_PASS_PATH', compose)

    def test_no_fake_company_endpoint(self):
        path = ROOT / 'group_vars/all.yml'
        self.assertNotIn('netbox.company.com', path.read_text())

    def test_default_inventory_does_not_query_netbox(self):
        config = (ROOT / 'ansible.cfg').read_text()
        self.assertIn('inventory = inventory/local.yml', config)
        self.assertNotIn('netbox.netbox.nb_inventory', config)
        self.assertFalse((ROOT / 'inventory/netbox.yml').exists())
        self.assertTrue((ROOT / 'inventory/local.yml').exists())

    def test_ansible_collections_use_stable_path(self):
        app = (ROOT / "webui/app.py").read_text()
        dockerfile = (ROOT / "Dockerfile").read_text()
        native_installer = (ROOT / "deploy/install-native.sh").read_text()
        self.assertIn('env["ANSIBLE_COLLECTIONS_PATH"] = ansible_collections_path(env)', app)
        self.assertIn("ansible-galaxy collection install -p /usr/share/ansible/collections", dockerfile)
        self.assertIn('collection install -p /usr/share/ansible/collections', native_installer)

    def test_vendor_task_vars_do_not_override_per_device_ssh_credentials(self):
        # collect_facts.yml dynamically include_vars the vendor file at task runtime.
        # Credentials must remain sourced from the local device registry, not env vars.
        for vendor in ("huawei", "eltex", "cisco", "snr"):
            text = (ROOT / "group_vars" / f"{vendor}.yml").read_text()
            self.assertNotRegex(text, r"(?m)^\s*ansible_(?:user|password)\s*:")

    def test_ssh_host_key_scan_uses_paramiko_with_legacy_fallbacks(self):
        app = (ROOT / 'webui/app.py').read_text()
        self.assertIn('def _scan_paramiko_ssh_key(', app)
        self.assertIn('diffie-hellman-group14-sha1', app)
        self.assertIn('diffie-hellman-group-exchange-sha1', app)
        self.assertIn('diffie-hellman-group1-sha1', app)
        self.assertIn('security.key_types = tuple(dict.fromkeys', app)
        self.assertIn('security.ciphers = tuple(dict.fromkeys', app)
        self.assertIn('security.digests = tuple(dict.fromkeys', app)
        self.assertNotIn('["ssh-keyscan",', app)
        self.assertIn('paramiko==3.5.1', (ROOT / "requirements.txt").read_text())

    def test_paramiko_ssh_transport_is_used_for_all_network_cli_devices(self):
        app = (ROOT / "webui/app.py").read_text()
        self.assertIn('if host_vars["ansible_connection"] == "ansible.netcommon.network_cli":', app)
        self.assertIn('host_vars["ansible_network_cli_ssh_type"] = "paramiko"', app)
        self.assertNotIn('def _is_legacy_cisco_device(', app)
        self.assertNotIn('legacy_cisco: bool', app)


    def test_esr_collection_is_inventory_only(self):
        esr = (ROOT / 'roles/netbox_sync/tasks/eltex_esr.yml').read_text()
        self.assertIn('show ip interface', esr)
        self.assertIn('show running-config vlans', esr)
        self.assertNotIn('show ip route', esr)
        self.assertIn('show vrrp', esr)
        self.assertIn('failed_when: false', esr)
        self.assertNotIn('show ip firewall failover', esr)
        self.assertNotIn('show interfaces switch-port status', esr)

    def test_esr_ip_list_is_saved_and_restored_for_netbox_sync(self):
        collect = (ROOT / 'roles/netbox_sync/tasks/eltex_esr.yml').read_text()
        report = (ROOT / 'roles/netbox_sync/tasks/collect_facts.yml').read_text()
        restore = (ROOT / 'roles/netbox_sync/tasks/load_reviewed_facts.yml').read_text()
        sync = (ROOT / 'roles/netbox_sync/tasks/sync_to_netbox.yml').read_text()
        self.assertIn("'ip_list': ip_list | default([])", report)
        self.assertNotIn("'routes':", report)
        self.assertIn("'vrrp_summary': elt_esr_vrrp_summary | default([])", report)
        self.assertIn("'vrrp_details': elt_esr_vrrp_details | default([])", report)
        self.assertNotIn("'firewall_failover':", report)
        self.assertIn("item.prefix | int <= 32", sync)
        self.assertIn('ip_list: "{{ reviewed_facts.ip_list | default([]) }}"', restore)
        self.assertIn('loop: "{{ ip_list | default([]) }}"', sync)
        self.assertIn("item.value.admin_status | default(item.value.operstatus", sync)
        self.assertIn("item.value.mac_address | default(item.value.macaddress", sync)

    def test_esr_management_tab_is_explicitly_inert(self):
        html = (ROOT / 'webui/index.html').read_text()
        self.assertIn('data-tab="esr-management"', html)
        self.assertIn('id="tab-esr-management"', html)
        self.assertIn('Здесь пока нет команд, форм изменения конфигурации или действий на оборудовании.', html)

    def test_pytz_dependency_is_explicit(self):
        requirements = (ROOT / 'requirements.txt').read_text().lower()
        self.assertIn('pytz==2026.5', requirements)


    def test_upgrade_script_preserves_persistent_data_and_rolls_back(self):
        script = (ROOT / "upgrade.sh").read_text()
        self.assertIn("/opt/netbox-sync-updates", script)
        self.assertIn("/opt/netbox-sync-backups", script)
        self.assertIn("--exclude='/local_data/***'", script)
        self.assertIn("--exclude='/.env'", script)
        self.assertIn("restore_backup", script)
        self.assertIn("processed/", script)

    def test_virtual_chassis_is_local_preliminary_model(self):
        app = (ROOT / 'webui/app.py').read_text()
        ui = (ROOT / 'webui/index.html').read_text()
        self.assertIn('CREATE TABLE IF NOT EXISTS virtual_chassis', app)
        self.assertIn('CREATE TABLE IF NOT EXISTS virtual_chassis_members', app)
        self.assertIn('def list_virtual_chassis', app)
        self.assertIn('virtual-chassis-list', ui)
        self.assertIn('vc-logical-data', ui)
        self.assertIn('Автоматически обновляется по отчётам при успешном сборе фактов', ui)
        self.assertIn('dvc-enabled', ui)
        self.assertIn('def _refresh_virtual_chassis_from_reports', app)
        self.assertNotIn('vc-import-vrrp', ui)
        self.assertNotIn('open-config', ui)
        self.assertIn('virtual_chassis_vrrp_candidates', app)

    def test_usg6670_omits_synthetic_vlan_range_and_report_export_actions_exist(self):
        task_file = ROOT / "roles" / "netbox_sync" / "tasks" / "huawei_usg6670.yml"
        task_text = task_file.read_text(encoding="utf-8").lower()
        self.assertNotIn("command: display vlan", task_text)
        self.assertIn("vlan_list: []", task_text)
        ui = (ROOT / "webui" / "index.html").read_text(encoding="utf-8")
        self.assertIn('id="select-fact-report"', ui)
        self.assertIn('id="download-fact-report"', ui)
        self.assertIn("JSON.stringify(selectedFactReport.facts,null,2)", ui)
        self.assertIn("r.facts.report&&Object.keys(r.facts.report).length?r.facts.report:r.facts", ui)
        self.assertIn("build_huawei_usg6670_report", (ROOT / "roles" / "netbox_sync" / "tasks" / "collect_facts.yml").read_text(encoding="utf-8"))
        self.assertIn("command: display esn", task_text)
        self.assertIn("command: display current-configuration | include sysname", task_text)

    def test_topology_renders_parallel_cables_for_multiple_links_between_same_devices(self):
        ui = (ROOT / 'webui/index.html').read_text(encoding='utf-8')
        self.assertIn('const edgeGroups=new Map()', ui)
        self.assertIn('const offset=(i-(edges.length-1)/2)*spacing', ui)
        self.assertIn(' Q ${cx} ${cy} ${b.x} ${b.y}', ui)
        self.assertIn('const tLocal=0.22,tRemote=0.78,labelSide=', ui)
        self.assertIn('const leftName=displayPort(l.local_device_id,l.local_aggregate),rightName=displayPort(l.remote_device_id,l.remote_aggregate)', ui)

    def test_dashboard_restores_v69_layout_and_removes_redundant_badges(self):
        html = (ROOT / "webui/index.html").read_text()
        self.assertIn("grid-template-columns:minmax(0,1.25fr) minmax(340px,.9fr)", html)
        self.assertIn('grid-template-areas:"ops recent" "params inventory" "params attention"', html)
        self.assertIn(".dashboard-primary,.dashboard-secondary{display:contents}", html)
        self.assertNotIn("Рабочий процесс", html)
        self.assertNotIn("Отдельный список ESR", html)
        self.assertNotIn("Автоматически обнаруженные связи · открыть карту", html)

    def test_netbox_interface_sync_preflights_duplicate_names_per_device(self):
        task = (ROOT / "roles/netbox_sync/tasks/sync_to_netbox.yml").read_text()
        filters = (ROOT / "filter_plugins/netbox_sync_parsers.py").read_text()
        self.assertIn("/api/dcim/devices/?name=", task)
        self.assertIn("/api/dcim/interfaces/?device_id=", task)
        self.assertIn("find_duplicate_interface_names", task)
        self.assertIn("item.key not in (netbox_duplicate_interface_names | default({}))", task)
        self.assertIn("No records were changed or deleted.", task)
        self.assertIn("/api/ipam/ip-addresses/?address=", task)
        self.assertIn("assigned_object_id:", task)
        self.assertIn("netbox_sync_interfaces_for_ip.json.results", task)
        self.assertNotIn("netbox.netbox.netbox_ip_address:", task)
        self.assertIn("def find_duplicate_interface_names(", filters)

    def test_release_version_matches_newest_changelog_entry(self):
        version = (ROOT / "RELEASE_VERSION").read_text().strip()
        changelog = (ROOT / "CHANGELOG.md").read_text()
        first = next(line for line in changelog.splitlines() if line.startswith("## v"))
        self.assertTrue(first.startswith(f"## v{version} "), (version, first))

    def test_device_form_has_netbox_mapping_fields(self):
        html = (ROOT / "webui/index.html").read_text()
        for label in ("Площадка NetBox (slug)", "Роль NetBox (slug)", "Тип устройства NetBox (slug)"):
            self.assertIn(label, html)
        for field in ('id="dnb-site"', 'id="dnb-role"', 'id="dnb-type"'):
            self.assertIn(field, html)
        for key in ("netbox_site", "netbox_role", "netbox_device_type_slug"):
            self.assertIn(key, html)

    def test_netbox_device_module_uses_device_role_parameter(self):
        task = (ROOT / "roles/netbox_sync/tasks/sync_to_netbox.yml").read_text()
        self.assertIn('device_role: "{{ netbox_role }}"', task)
        self.assertNotIn('      role: "{{ netbox_role }}"', task)

    def test_device_type_slug_is_derived_from_selected_model(self):
        import ast
        source = (ROOT / "webui/app.py").read_text()
        tree = ast.parse(source)
        wanted = [n for n in tree.body if (isinstance(n, ast.FunctionDef) and n.name == "_derive_device_type_slug")
                  or (isinstance(n, ast.Assign) and any(getattr(t, "id", "") in {"_MODEL_VENDOR_PREFIXES", "_LEGACY_MODEL_ALIASES"} for t in n.targets))]
        namespace = {"re": __import__("re")}
        exec(compile(ast.Module(wanted, []), "app_slug", "exec"), namespace)
        derive = namespace["_derive_device_type_slug"]
        self.assertEqual(derive("Huawei USG6670"), "usg6670")
        self.assertEqual(derive("Huawei S5735-L48P4X-A"), "s5735-l48p4x-a")
        self.assertEqual(derive("Eltex ESR200"), "esr200")
        self.assertEqual(derive("Cisco Catalyst 9410R"), "catalyst9410r")
        self.assertEqual(derive("Cisco Catalyst 9410"), "catalyst9410r")  # legacy stored model name
        self.assertEqual(derive("ESR-200"), "esr-200")
        self.assertEqual(derive("SNR S5311G-48TX-POE"), "s5311g-48tx-poe")
        self.assertEqual(derive(""), "")

    def test_sync_loop_labels_tolerate_incomplete_items(self):
        import yaml
        try:
            import jinja2
        except ImportError:
            self.skipTest("jinja2 is not installed")
        tasks = yaml.safe_load((ROOT / "roles/netbox_sync/tasks/sync_to_netbox.yml").read_text())
        env = jinja2.Environment(undefined=jinja2.StrictUndefined)
        cases = {
            "Create LLDP cable only when both endpoints are explicitly resolved": {"chassis_id": "7079-b3f2-4140", "local_interface": "Gi3/0/9", "neighbor_interface": "Te5/0/3"},
            "Create or update VLANs (site-scoped)": {},
            "Look up existing IP objects before synchronization": {"ip": "192.0.2.1", "prefix": 24},
        }
        for name, item in cases.items():
            task = next(t for t in tasks if t.get("name") == name)
            env.from_string(task["loop_control"]["label"]).render(item=item)
        lldp = next(t for t in tasks if t.get("name") == next(iter(cases)))
        self.assertIn("sync_lldp", lldp["loop"])

    def test_netbox_auto_sync_is_opt_in_and_after_successful_collection_only(self):
        app = (ROOT / "webui/app.py").read_text()
        self.assertIn('_get_app_setting("netbox_auto_sync_enabled", "false")', app)
        self.assertIn('if mode == "collect" and job_succeeded:', app)
        self.assertIn('if not (sync_enabled and auto_enabled):', app)
        self.assertIn('netbox_api_token_enc', app)
        self.assertIn('netbox_sync_enabled', app)
        site = (ROOT / "site.yml").read_text()
        self.assertIn("lookup('env', 'NETBOX_TOKEN')", site)

    def test_dashboard_is_focused_on_collection_and_netbox_sync_not_availability(self):
        app = (ROOT / "webui/app.py").read_text()
        html = (ROOT / "webui/index.html").read_text()
        self.assertIn("last_fact_collection", app)
        self.assertIn("collection_errors", app)
        self.assertIn('id="autocollectcount"', html)
        self.assertIn('id="lastcollection"', html)
        self.assertIn('id="lastsync"', html)
        self.assertNotIn("/api/checks", app)
        self.assertNotIn("open-checks", html)
        self.assertNotIn("Недоступные устройства", html)
        self.assertNotIn("Устройства с расхождениями", html)
        self.assertNotIn("Проверки доступности", html)

if __name__ == '__main__':
    unittest.main()

    def test_usg6670_profile_contains_only_read_only_display_commands(self):
        task_file = ROOT / "roles" / "netbox_sync" / "tasks" / "huawei_usg6670.yml"
        text = task_file.read_text(encoding="utf-8").lower()
        self.assertIn("display version", text)
        self.assertIn("display device", text)
        self.assertIn("display interface brief", text)
        self.assertIn("display hrp state", text)
        self.assertIn("display esn", text)
        self.assertIn("display current-configuration | include sysname", text)
        self.assertNotIn("screen-length 0 temporary", text)
        self.assertNotRegex(text, r"(?m)^\s*command:\s*(?:system-view|save|commit|undo|shutdown|reboot)\b")
