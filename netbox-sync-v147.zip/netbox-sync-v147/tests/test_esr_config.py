import unittest
from webui.esr_config import parse_esr_running_config


SAMPLE = '''hostname AR1-COMERCIAL
security zone COMMERCE
  description "Commercial Production"
exit
security zone UNTRUST
  description "Internet Providers"
exit
security zone-pair COMMERCE UNTRUST
  rule 9999
    description "Allow Internet"
    action permit
    match protocol tcp
    match source-address CLIENTS
    match destination-port https
    enable
  exit
exit
interface gigabitethernet 1/0/2.1040
  description "Prod. Autoimport"
  security-zone COMMERCE
  ip address 10.10.40.251/24
  vrrp id 40
  vrrp ip 10.10.40.1/24
  vrrp priority 200
  vrrp group 10
  ip policy route-map PBRtoISP_02
exit
route-map PBRtoISP_02
  rule 20
    match ip access-group VM_CLIENT_01_ACL
    action set ip next-hop verify-availability 78.85.15.1 10
  exit
exit
object-group network CLIENTS
  description "Client network"
  ip prefix 10.10.40.0/24
exit
object-group service https
  port-range 443
exit
ip route 0.0.0.0/0 10.0.0.1 251 name DEFAULT
nat destination
  pool WEB
    ip address 10.10.1.10
    ip port 443
  exit
  ruleset DNAT
    from interface gigabitethernet 1/0/1.10
    rule 10
      match protocol tcp
      match destination-port https
      action destination-nat pool WEB
      enable
    exit
  exit
exit
nat source
  ruleset DEFAULT
    to zone UNTRUST
    rule 9999
      action source-nat interface
      enable
    exit
  exit
exit

'''


class ESRConfigParserTests(unittest.TestCase):
    def test_vlan_list_and_named_vlan_block_merge_without_duplicates(self):
        parsed = parse_esr_running_config('''hostname ESR-200
vlan 2,23
exit
vlan 23
 name "Management"
exit
''')
        self.assertEqual(parsed["vlans"], [
            {"id": 2, "name": None},
            {"id": 23, "name": "Management"},
        ])

    def test_parses_zones_zone_pair_rules_and_matches(self):
        parsed = parse_esr_running_config(SAMPLE)
        self.assertEqual([x['name'] for x in parsed['zones']], ['COMMERCE', 'UNTRUST'])
        rule = parsed['zone_pairs'][0]['rules'][0]
        self.assertEqual((parsed['zone_pairs'][0]['from_zone'], parsed['zone_pairs'][0]['to_zone']), ('COMMERCE', 'UNTRUST'))
        self.assertEqual(rule['action'], 'permit')
        self.assertEqual(rule['protocol'], 'tcp')
        self.assertEqual(rule['source_address'], 'CLIENTS')
        self.assertEqual(rule['destination_port'], 'https')
        self.assertTrue(rule['enabled'])

    def test_parses_object_group_qualified_zone_rule_matches(self):
        config = """object-group network LAN\n ip prefix 192.168.1.0/24\nexit\nobject-group service SSH\n port-range 22\nexit\nsecurity zone-pair LAN self\n rule 10\n  match source-address object-group network LAN\n  match destination-port object-group SSH\n  match source-port object-group SSH\n exit\nexit\n"""
        rule = parse_esr_running_config(config)["zone_pairs"][0]["rules"][0]
        self.assertEqual(rule["source_address"], "LAN")
        self.assertEqual(rule["destination_port"], "SSH")
        self.assertEqual(rule["source_port"], "SSH")

    def test_parses_interface_address_zone_vrrp_and_pbr(self):
        interface = parse_esr_running_config(SAMPLE)['interfaces'][0]
        self.assertEqual(interface['address'], '10.10.40.251/24')
        self.assertEqual(interface['zone'], 'COMMERCE')
        self.assertEqual(interface['policy_route_map'], 'PBRtoISP_02')
        self.assertEqual([x['field'] for x in interface['vrrp']], ['id', 'ip', 'priority', 'group'])
        self.assertEqual(interface['vrrp_groups'], [{'id': '40', 'ip': '10.10.40.1/24', 'priority': '200', 'group': '10'}])

    def test_parses_route_map_objects_and_static_routes(self):
        parsed = parse_esr_running_config(SAMPLE)
        self.assertEqual(parsed['route_maps'][0]['name'], 'PBRtoISP_02')
        self.assertIn('VM_CLIENT_01_ACL', parsed['route_maps'][0]['rules'][0]['match'][0])
        self.assertEqual(parsed['network_objects'][0]['entries'], ['ip prefix 10.10.40.0/24'])
        self.assertTrue(any('match source-address CLIENTS' in x for x in parsed['network_objects'][0]['used_in']))
        self.assertEqual(parsed['service_objects'][0]['entries'], ['port-range 443'])
        self.assertEqual(parsed['static_routes'][0]['distance'], 251)
        self.assertEqual(parsed['static_routes'][0]['name'], 'DEFAULT')

    def test_parses_nat_pools_rulesets_and_rules(self):
        parsed = parse_esr_running_config(SAMPLE)
        self.assertEqual(len(parsed["nat_pools"]), 1)
        self.assertEqual(parsed["nat_pools"][0]["name"], "WEB")
        self.assertEqual(parsed["nat_pools"][0]["address"], "10.10.1.10")
        self.assertEqual(len(parsed["nat_rulesets"]), 2)
        dnat = next(x for x in parsed["nat_rules"] if x["nat_type"] == "destination")
        self.assertEqual(dnat["pool"], "WEB")
        self.assertTrue(dnat["enabled"])
        self.assertEqual(parsed["statistics"]["nat_rules"], 2)

    def test_unknown_commands_do_not_break_parse(self):
        parsed = parse_esr_running_config(SAMPLE + '\nfeature future-command alpha\n')
        self.assertEqual(parsed['statistics']['interfaces'], 1)

class ESRVrfParserTests(unittest.TestCase):
    def test_default_and_named_vrfs_are_parsed_for_interfaces_routes_and_zones(self):
        config = '''ip vrf VRF1
  description "ITS_Upravtodor"
exit
security zone TRUST
  description "Default zone"
exit
security zone VRF1_TRUST
  ip vrf forwarding VRF1
exit
security zone-pair TRUST self
  rule 1
    action permit
  exit
exit
security zone-pair VRF1_TRUST self
  rule 2
    action permit
  exit
exit
interface gigabitethernet 1/0/1
  ip address 10.0.0.1/24
exit
interface gigabitethernet 1/0/2.49
  ip vrf forwarding VRF1
  ip address 192.168.49.1/24
exit
ip route 0.0.0.0/0 10.0.0.254 251 name DEFAULT
ip route vrf VRF1 0.0.0.0/0 192.168.49.254 250 name VRF1_DEFAULT
'''
        parsed = parse_esr_running_config(config)
        self.assertEqual([v['name'] for v in parsed['vrfs']], ['VRF0', 'VRF1'])
        self.assertEqual({i['name']: i['vrf'] for i in parsed['interfaces']}, {
            'gigabitethernet 1/0/1': 'VRF0',
            'gigabitethernet 1/0/2.49': 'VRF1',
        })
        self.assertEqual({r['name']: r['vrf'] for r in parsed['static_routes']}, {
            'DEFAULT': 'VRF0', 'VRF1_DEFAULT': 'VRF1',
        })
        self.assertEqual({z['name']: z['vrf'] for z in parsed['zones']}, {
            'TRUST': 'VRF0', 'VRF1_TRUST': 'VRF1',
        })
        self.assertEqual({(z['from_zone'], z['vrf']) for z in parsed['zone_pairs']}, {
            ('TRUST', 'VRF0'), ('VRF1_TRUST', 'VRF1'),
        })

    def test_user_supplied_esr_config_has_expected_vrf1_interfaces_and_routes(self):
        from pathlib import Path
        config_path = Path('/mnt/data/Вставленный текст.txt')
        if not config_path.exists():
            self.skipTest('Uploaded ESR configuration is not mounted in this test environment')
        parsed = parse_esr_running_config(config_path.read_text(encoding='utf-8'))
        self.assertIn('VRF1', [v['name'] for v in parsed['vrfs']])
        vrf1_interfaces = [x for x in parsed['interfaces'] if x['vrf'] == 'VRF1']
        self.assertEqual({x['name'] for x in vrf1_interfaces}, {
            'gigabitethernet 1/0/2.49', 'gigabitethernet 1/0/2.200',
        })
        vrf1_routes = [x for x in parsed['static_routes'] if x['vrf'] == 'VRF1']
        self.assertEqual(len(vrf1_routes), 4)
        self.assertTrue(all(x['vrf'] == 'VRF0' for x in parsed['static_routes'] if x not in vrf1_routes))
        self.assertTrue(any(x['from_zone'] == 'VRF1_TRUST' and x['vrf'] == 'VRF1' for x in parsed['zone_pairs']))


class ESR1000BridgeVlanTests(unittest.TestCase):
    def test_parses_uploaded_esr1000_bridge_and_vlan_configuration(self):
        from pathlib import Path
        config_path = Path('/mnt/data/esr1000.txt')
        if not config_path.exists():
            self.skipTest('Uploaded ESR1000 configuration is not mounted')
        parsed = parse_esr_running_config(config_path.read_text(encoding='utf-8'))
        bridges = [item for item in parsed['interfaces'] if item.get('type') == 'bridge']
        self.assertEqual(len(bridges), 8)
        bridge72 = next(item for item in bridges if item['name'] == 'bridge 72')
        self.assertEqual(bridge72['vlan'], '720')
        self.assertEqual(bridge72['address'], '10.7.20.1/24')
        self.assertEqual(bridge72['zone'], 'trusted')
        self.assertTrue(bridge72['enabled'])
        self.assertEqual(next(item['name'] for item in parsed['vlans'] if item['id'] == 723), 'RMIAC_NET_Mgmnt')
        self.assertIn(4093, [item['id'] for item in parsed['vlans']])
        self.assertIn(4094, [item['id'] for item in parsed['vlans']])

    def test_parses_switchport_pvid_and_allowed_vlan_membership(self):
        config = """interface gigabitethernet 1/0/1
  mode switchport
  switchport general pvid 2
  switchport general allowed vlan add 81-82 tagged
  switchport general allowed vlan add 2 untagged
exit
"""
        interface = parse_esr_running_config(config)['interfaces'][0]
        self.assertEqual(interface['pvid'], '2')
        self.assertEqual(interface['allowed_vlans'], ['81-82 tagged', '2 untagged'])
        self.assertEqual(interface['type'], 'physical')


class ESRDependencyGraphTests(unittest.TestCase):
    def test_parser_exposes_typed_dependencies_for_interfaces_pbr_zones_vrrp_and_nat(self):
        config = """security zone trusted
exit
interface gigabitethernet 1/0/1
  security-zone trusted
  ip policy route-map PBR_MAIN
  vrrp id 78
  vrrp ip 192.0.2.1/30
  vrrp priority 200
  vrrp group 10
exit
route-map PBR_MAIN
  rule 10
    match ip address LAN
    action set ip next-hop 192.0.2.2
  exit
exit
nat destination
  pool PUBLIC_POOL
    ip address 192.0.2.10
    ip port 443
  exit
  ruleset DNAT
    rule 10
      action destination-nat pool PUBLIC_POOL
      enable
    exit
  exit
exit
"""
        parsed = parse_esr_running_config(config)
        edges = parsed['dependencies']
        self.assertIn({'source_type':'interface','source_id':'gigabitethernet 1/0/1','relation':'belongs_to','target_type':'security_zone','target_id':'trusted'}, edges)
        self.assertIn({'source_type':'interface','source_id':'gigabitethernet 1/0/1','relation':'uses_policy','target_type':'route_map','target_id':'PBR_MAIN'}, edges)
        self.assertIn({'source_type':'interface','source_id':'gigabitethernet 1/0/1','relation':'has_vrrp','target_type':'vrrp_group','target_id':'78'}, edges)
        self.assertIn({'source_type':'nat_rule','source_id':'DNAT:10','relation':'uses_pool','target_type':'nat_pool','target_id':'PUBLIC_POOL'}, edges)
        self.assertEqual(parsed['route_maps'][0]['used_in'], ['gigabitethernet 1/0/1'])
        self.assertEqual(parsed['nat_pools'][0]['used_in'], ['DNAT:10'])
        self.assertIn('gigabitethernet 1/0/1', parsed['zones'][0]['used_in'])


class ESRAccessListUsageTests(unittest.TestCase):
    def test_acl_records_where_used_and_typed_dependency(self):
        config = """ip access-list extended MGMT_ACL
  rule 10
    action permit
  exit
exit
interface gigabitethernet 1/0/1
  ip access-group MGMT_ACL in
exit
"""
        parsed = parse_esr_running_config(config)
        acl = parsed['access_lists'][0]
        self.assertIn('ip access-group MGMT_ACL in', acl['used_in'])
        self.assertTrue(any(edge['target_type'] == 'access_list' and edge['target_id'] == 'MGMT_ACL'
                            for edge in parsed['dependencies']))
