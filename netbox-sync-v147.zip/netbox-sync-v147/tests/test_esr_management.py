import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from webui.esr_management import (ConfigurationError, parse_config_operations, parse_operations,
                                  plan_configuration_changes, plan_vlan_changes)  # noqa: E402


class ESRVlanPlanningTests(unittest.TestCase):
    def test_add_vlan_generates_cli_and_candidate_diff(self):
        plan = plan_vlan_changes("hostname ESR1\n", parse_operations([{"action": "upsert", "id": 20, "name": "Office"}]))
        self.assertEqual(plan["change_commands"], ["vlan 20", 'name "Office"', "exit"])
        self.assertIn('+vlan 20', plan["diff"])
        self.assertIn('+ name "Office"', plan["diff"])
        self.assertIn('+system config-confirm timeout 120', plan["diff"])
        self.assertIn("system config-confirm timeout {timeout}", plan["commands"])

    def test_update_vlan_replaces_name_without_touching_other_config(self):
        original = 'hostname ESR1\nvlan 20\n name "Old"\nexit\nvlan 30\n name "Keep"\nexit\n'
        plan = plan_vlan_changes(original, parse_operations([{"action": "upsert", "id": 20, "name": "New"}]))
        self.assertIn(' name "New"', plan["candidate"])
        self.assertNotIn(' name "Old"', plan["candidate"])
        self.assertIn(' name "Keep"', plan["candidate"])
        self.assertIn('- name "Old"', plan["diff"])

    def test_vlan_without_name_does_not_generate_empty_name_command(self):
        plan = plan_vlan_changes("hostname ESR1\n", parse_operations([{"action": "upsert", "id": 22, "name": ""}]))
        self.assertEqual(plan["change_commands"], ["vlan 22", "exit"])
        self.assertNotIn('name ""', plan["candidate"])

    def test_delete_vlan_only_removes_selected_block(self):
        original = "hostname ESR1\nvlan 20\n name Office\nexit\nvlan 30\nexit\n"
        plan = plan_vlan_changes(original, parse_operations([{"action": "delete", "id": 20}]))
        self.assertEqual(plan["change_commands"], ["no vlan 20"])
        self.assertNotIn("vlan 20", plan["candidate"])
        self.assertIn("vlan 30", plan["candidate"])

    def test_noop_delete_and_duplicate_operations_are_rejected(self):
        with self.assertRaises(ConfigurationError):
            plan_vlan_changes("hostname ESR1\n", parse_operations([{"action": "delete", "id": 20}]))
        with self.assertRaises(ConfigurationError):
            parse_operations([{"action": "delete", "id": 20}, {"action": "upsert", "id": 20, "name": "x"}])

    def test_delete_uses_esr_no_vlan_command_even_when_vlan_is_referenced(self):
        current = "interface gigabitethernet 1/0/1\n switchport access vlan 20\nexit\nvlan 20\nexit\n"
        plan = plan_vlan_changes(current, parse_operations([{"action": "delete", "id": 20}]))
        self.assertEqual(plan["change_commands"], ["no vlan 20"])
        self.assertNotIn("\nvlan 20\nexit", plan["candidate"])

    def test_vlan_in_shared_range_is_not_rewritten(self):
        with self.assertRaisesRegex(ConfigurationError, "общей декларации диапазона"):
            plan_vlan_changes("hostname ESR1\nvlan 20-30\nexit\n", parse_operations([{"action": "delete", "id": 22}]))

    def test_vlan_in_explicit_list_can_be_named_individually(self):
        original = "hostname ESR1\nvlan 2,23\nexit\n"
        plan = plan_vlan_changes(original, parse_operations([{"action": "upsert", "id": 23, "name": "Management"}]))
        self.assertEqual(plan["change_commands"], ["vlan 23", 'name "Management"', "exit"])
        self.assertIn("vlan 2,23", plan["candidate"])
        self.assertIn('vlan 23\n name "Management"\nexit', plan["candidate"])

    def test_delete_vlan_from_explicit_list_removes_only_that_id(self):
        plan = plan_vlan_changes("hostname ESR1\nvlan 2,23\nexit\n", parse_operations([{"action": "delete", "id": 23}]))
        self.assertEqual(plan["change_commands"], ["no vlan 23"])
        self.assertIn("vlan 2\nexit", plan["candidate"])
        self.assertNotIn("vlan 2,23", plan["candidate"])

    def test_delete_last_vlan_in_list_removes_its_declaration_block(self):
        plan = plan_vlan_changes("hostname ESR1\nvlan 23\nexit\n", parse_operations([{"action": "delete", "id": 23}]))
        self.assertEqual(plan["change_commands"], ["no vlan 23"])
        self.assertNotIn("vlan 23", plan["candidate"])

    def test_invalid_ids_and_multiline_names_are_rejected(self):
        for value in (0, 1, 4095, "bad"):
            with self.subTest(value=value), self.assertRaises(ConfigurationError):
                parse_operations([{"action": "delete", "id": value}])
        with self.assertRaises(ConfigurationError):
            parse_operations([{"action": "upsert", "id": 20, "name": "safe\ncommit"}])


class ESRZonePlanningTests(unittest.TestCase):
    CURRENT = '''hostname ESR1
security zone TRUST
  description "Old"
exit
security zone UNTRUST
exit
security zone-pair TRUST UNTRUST
  rule 1
    action deny
  exit
  rule 2
    action permit
  exit
exit
'''

    def plan(self, operations):
        return plan_configuration_changes(self.CURRENT, parse_config_operations(operations))

    def test_zone_update_preserves_other_blocks_and_emits_candidate(self):
        plan = self.plan([{"type": "zone", "action": "upsert", "name": "TRUST", "description": "Updated"}])
        self.assertIn('description "Updated"', plan["candidate"])
        self.assertIn("security zone UNTRUST", plan["candidate"])
        self.assertIn('-  description "Old"', plan["diff"])

    def test_zone_delete_refuses_references_from_interfaces_and_pairs(self):
        with self.assertRaisesRegex(ConfigurationError, "используется zone-pair"):
            self.plan([{"type": "zone", "action": "delete", "name": "TRUST"}])
        raw = self.CURRENT.replace("security zone-pair TRUST UNTRUST", "interface gigabitethernet 1/0/1\n security-zone TRUST\nexit\nsecurity zone-pair TRUST UNTRUST")
        with self.assertRaisesRegex(ConfigurationError, "назначена интерфейсу"):
            plan_configuration_changes(raw, parse_config_operations([{"type": "zone", "action": "delete", "name": "TRUST"}]))

    def test_create_network_and_service_object_groups_generates_esr_cli(self):
        plan = plan_configuration_changes(self.CURRENT, parse_config_operations([
            {"type": "object_group", "object_kind": "network", "action": "upsert", "name": "CLIENTS", "entries": ["ip prefix 10.0.0.0/24"]},
            {"type": "object_group", "object_kind": "service", "action": "upsert", "name": "HTTPS", "entries": ["port-range 443"]},
        ]))
        self.assertIn("object-group network CLIENTS", plan["change_commands"])
        self.assertIn("ip prefix 10.0.0.0/24", plan["change_commands"])
        self.assertIn("object-group service HTTPS", plan["change_commands"])
        self.assertIn("port-range 443", plan["candidate"])

    def test_rule_uses_existing_or_staged_objects_and_emits_match_cli(self):
        current = self.CURRENT + "object-group network CLIENTS\n ip prefix 10.0.0.0/24\nexit\nobject-group service WEB\n port-range 443\nexit\n"
        plan = plan_configuration_changes(current, parse_config_operations([
            {"type": "zone_pair", "action": "upsert", "source": "TRUST", "destination": "UNTRUST",
             "rule": {"number": 10, "action": "permit", "protocol": "tcp", "source_address": "CLIENTS", "destination_address": "CLIENTS", "source_port": "WEB", "destination_port": "WEB"}}
        ]))
        self.assertIn("match source-address CLIENTS", plan["change_commands"])
        self.assertIn("match destination-address CLIENTS", plan["change_commands"])
        self.assertIn("match source-port WEB", plan["change_commands"])
        self.assertIn("match destination-port WEB", plan["candidate"])

    def test_new_object_groups_precede_rules_even_if_rule_was_staged_first(self):
        operations = [
            {"type": "zone_pair", "action": "upsert", "source": "TRUST", "destination": "UNTRUST",
             "rule": {"number": 15, "action": "permit", "protocol": "tcp", "source_address": "CLIENTS", "source_port": "HTTPS", "destination_port": "HTTPS"}},
            {"type": "object_group", "object_kind": "network", "action": "upsert", "name": "CLIENTS", "entries": ["ip prefix 10.0.0.0/24"]},
            {"type": "object_group", "object_kind": "service", "action": "upsert", "name": "HTTPS", "entries": ["port-range 443"]},
        ]
        plan = plan_configuration_changes(self.CURRENT, parse_config_operations(operations))
        self.assertLess(plan["change_commands"].index("object-group network CLIENTS"), plan["change_commands"].index("security zone-pair TRUST UNTRUST"))
        self.assertLess(plan["change_commands"].index("object-group service HTTPS"), plan["change_commands"].index("security zone-pair TRUST UNTRUST"))
        self.assertLess(plan["candidate"].index("object-group network CLIENTS"), plan["candidate"].index("security zone-pair TRUST UNTRUST"))
        self.assertLess(plan["candidate"].index("object-group service HTTPS"), plan["candidate"].index("security zone-pair TRUST UNTRUST"))
        self.assertIn("match source-address CLIENTS", plan["candidate"])
        self.assertIn("match source-port HTTPS", plan["candidate"])
        self.assertIn("match destination-port HTTPS", plan["candidate"])

    def test_deleting_referenced_object_group_is_refused(self):
        current = "security zone-pair TRUST UNTRUST\n rule 1\n  match source-address CLIENTS\n exit\nexit\nobject-group network CLIENTS\n ip prefix 10.0.0.0/24\nexit\n"
        with self.assertRaisesRegex(ConfigurationError, "используется в конфигурации"):
            plan_configuration_changes(current, parse_config_operations([
                {"type": "object_group", "object_kind": "network", "action": "delete", "name": "CLIENTS"}
            ]))

    def test_hostname_update_generates_cli_and_replaces_only_hostname(self):
        original = "hostname ESR1\nvlan 23\nexit\n"
        plan = plan_configuration_changes(original, parse_config_operations([
            {"type": "hostname", "action": "upsert", "name": "ESR-200-NEW"}
        ]))
        self.assertEqual(plan["change_commands"], ["hostname ESR-200-NEW"])
        self.assertIn("hostname ESR-200-NEW", plan["candidate"])
        self.assertNotIn("hostname ESR1", plan["candidate"])
        self.assertIn("vlan 23", plan["candidate"])

    def test_hostname_validation_rejects_invalid_names(self):
        for name in ("-bad", "bad-", "bad..name", "bad name", "x" * 64):
            with self.subTest(name=name), self.assertRaises(ConfigurationError):
                parse_config_operations([{"type": "hostname", "action": "upsert", "name": name}])

    def test_zone_pair_rule_update_preserves_unrelated_rules(self):
        plan = self.plan([{"type": "zone_pair", "action": "upsert", "source": "TRUST", "destination": "UNTRUST",
                           "rule": {"number": 1, "action": "permit", "protocol": "tcp", "description": "Updated"}}])
        self.assertIn('description "Updated"', plan["candidate"])
        self.assertIn("match protocol tcp", plan["candidate"])
        self.assertIn("match protocol tcp", plan["change_commands"])
        self.assertIn("rule 2", plan["candidate"])

    def test_zone_pair_rule_delete_removes_only_selected_rule(self):
        plan = self.plan([{"type": "zone_pair_rule", "action": "delete", "source": "TRUST",
                           "destination": "UNTRUST", "number": 1}])
        self.assertEqual(plan["change_commands"], ["security zone-pair TRUST UNTRUST", "no rule 1", "exit"])
        self.assertNotIn("rule 1", plan["candidate"])
        self.assertIn("rule 2", plan["candidate"])

    def test_zone_pair_rule_delete_can_remove_multiple_rules(self):
        plan = self.plan([
            {"type": "zone_pair_rule", "action": "delete", "source": "TRUST", "destination": "UNTRUST", "number": 1},
            {"type": "zone_pair_rule", "action": "delete", "source": "TRUST", "destination": "UNTRUST", "number": 2},
        ])
        self.assertNotIn("rule 1", plan["candidate"])
        self.assertNotIn("rule 2", plan["candidate"])
        self.assertEqual(plan["change_commands"], ["security zone-pair TRUST UNTRUST", "no rule 1", "no rule 2", "exit"])
        self.assertIn("security zone-pair TRUST UNTRUST", plan["change_commands"])

    def test_create_and_delete_zone_pair(self):
        create = self.plan([{"type": "zone_pair", "action": "upsert", "source": "UNTRUST", "destination": "TRUST"}])
        self.assertIn("security zone-pair UNTRUST TRUST", create["candidate"])
        create_rule = self.plan([{"type": "zone_pair", "action": "upsert", "source": "UNTRUST", "destination": "TRUST",
                                  "rule": {"number": 4, "action": "permit", "protocol": "udp"}}])
        self.assertIn("match protocol udp", create_rule["candidate"])
        self.assertIn("enable", create_rule["candidate"])
        delete = self.plan([{"type": "zone_pair", "action": "delete", "source": "TRUST", "destination": "UNTRUST"}])
        self.assertNotIn("security zone-pair TRUST UNTRUST", delete["candidate"])

    def test_combined_vlan_and_zone_changes_share_one_candidate(self):
        plan = plan_configuration_changes(self.CURRENT, parse_config_operations([
            {"type": "vlan", "action": "upsert", "id": 22, "name": "Office"},
            {"type": "zone", "action": "upsert", "name": "DMZ", "description": "Public"},
        ]))
        self.assertIn("vlan 22", plan["candidate"])
        self.assertIn("security zone DMZ", plan["candidate"])
        self.assertIn("system config-confirm timeout 120", plan["candidate"])

    def test_vlan_only_change_works_through_generic_configuration_planner(self):
        current = 'hostname ESR1\nvlan 23\n name "Old"\nexit\n'
        plan = plan_configuration_changes(current, parse_config_operations([
            {"type": "vlan", "action": "upsert", "id": 23, "name": "Management"},
        ]))
        self.assertIn('name "Management"', plan["candidate"])
        self.assertEqual(plan["change_commands"], ["vlan 23", 'name "Management"', "exit"])
        self.assertTrue(plan["changed"])

    def test_rejects_invalid_zone_names_and_rule_actions(self):
        with self.assertRaises(ConfigurationError):
            parse_config_operations([{"type": "zone", "action": "upsert", "name": "ZONE_NAME_TOO_LONG"}])
        with self.assertRaises(ConfigurationError):
            parse_config_operations([{"type": "zone_pair", "action": "upsert", "source": "A", "destination": "B",
                                      "rule": {"number": 1, "action": "allow"}}])
        with self.assertRaisesRegex(ConfigurationError, "протокол"):
            parse_config_operations([{"type": "zone_pair", "action": "upsert", "source": "A", "destination": "B",
                                      "rule": {"number": 1, "action": "permit", "protocol": "https"}}])


if __name__ == "__main__":
    unittest.main()
