# Production acceptance checklist

- [x] Target NetBox version recorded: 4.5.10 (API integration still requires a test instance).
- [x] Local device registry is the source of device addresses and credentials for collection; credentials are encrypted at rest.
- [x] Collect and sync are separate workflows; sync loads saved facts instead of polling devices again.
- [x] Manual sync requires explicit UI confirmation, the Administration write-enable setting, a configured NetBox URL/token, fresh reports, one matching collection batch, and explicit NetBox site/role/device-type mappings.
- [x] NetBox API token is encrypted at rest; Administration never returns the token value.
- [x] Automatic sync is independently configurable and disabled by default; it runs only after a successful collection and for the same target set.
- [x] NetBox object deletion remains disabled; reverse configuration workflow is removed from UI and playbook.
- [x] Parser unit tests cover supplied Huawei USG/VRP and Eltex MES CLI samples.
- [x] Added Cisco IOS/IOS XE and SNR eNOS collection paths with parser unit tests; actual hardware output validation remains pending.
- [x] Web UI selects an exact model profile; unknown models are registry/TCP-only and blocked from CLI collection.
- [x] Separate Huawei USG and S5735 task entry points are selected by model profile.
- [ ] Run `ansible-playbook --syntax-check` in the deployment image with installed collections.
- [ ] Verify exact Ansible Core and collection versions installed from local artifacts.
- [ ] Verify Cisco IOS XE terminal handling and SNR eNOS SSH prompt/terminal handling in the deployment image.
- [ ] Run read-only collection against reachable and unreachable Huawei USG6670/USG6635E, Huawei S5735 models, Eltex MES-5324A, Cisco Catalyst 9410 (IOS XE 16.06.04), and SNR S5311G48TXPOE (eNOS 1.23.0) devices.
- [ ] Validate all NetBox device type, site, role and interface type mappings against NetBox 4.5.10.
- [ ] Test sync against a disposable NetBox instance and review each created/updated object.
- [ ] Test stack member and serial-number modeling; physical stack topology is not fully implemented yet.
- [x] Add local logical-device grouping with explicit physical-member association and optional ESR-200 VRRP fact collection; actual CLI output validation and NetBox modeling remain pending.
- [ ] Validate LLDP/CDP neighbor parsing and cable mapping before enabling topology sync.
- [ ] Verify external network access is not required during normal operation.


## ESR administration v121
- Opening the ESR administration section loads the current ESR device registry automatically.
- The ESR registry refreshes automatically while the section is active; no manual refresh button is shown.
- The selected device remains selected if it remains eligible.
- The selected device's saved configuration is reloaded only when the registry/selection changes; SSH collection remains an explicit user action.
- Parsed data includes typed dependency edges for interfaces, zones, VRRP, PBR, bridge/VLAN, NAT pools and VRFs.
- Object drill-down shows related interfaces, rules or zone-pairs where applicable.
- VLAN changes are limited to IDs 2–4094; deletion is refused while interface or bridge references remain in running-config.
- Zone create/update/delete and zone-pair create/delete are available in the Zones pane; a zone cannot be deleted while interfaces or zone-pairs reference it. Existing zone-pair rule updates replace only the selected rule number.
- Zone creation and zone-pair creation use separate dialogs. VRF and zone selectors are populated from the saved ESR configuration; queued new zones are available for pair creation in the same pending plan.
- Each existing zone-pair has a rule action. Rule creation/edit includes permit/deny and an explicit protocol (`any`, TCP, UDP, ICMP, and the other CLI-supported IP protocol types); generated CLI and candidate diff include the selected `match protocol`.
- The pending-change notice and ESR operation status remain beside the Commit/Confirm controls when navigating between panes. Confirm stays visible but disabled until commit creates a confirmable pending state.
- The first Commit opens the command/diff dialog; the dialog's Commit applies the preview, and operation errors are visible even while another ESR pane is selected.
- VLAN controls are in the VLAN pane; the top-right Commit opens a preview dialog, and the dialog's second Commit applies. Queued local changes display «Примените настройки».
- A fresh running-config is fetched for preview; generated commands and a unified diff are shown before apply.
- Apply re-fetches configuration and refuses a stale preview; only the explicitly selected ESR is targeted.
- The confirmation timer is configured in Administration, defaults to 120 seconds and is checked against the ESR range.
- Candidate commands stop at the first CLI rejection; rollback is attempted before commit when staging fails.
- Native commit starts the ESR timer; manual `confirm` is sent only after user action, followed by `save`.
- The UI countdown is advisory; after timeout, rollback is reported only after running-config verification.
- SSH loss or ambiguous CLI response is never marked confirmed or successful; a pending operation is represented by temporary application state, not operation history.
- ESR configuration apply, manual confirmation and automatic rollback have only been verified with local tests/mocked CLI. Physical ESR-200 1.14.5 acceptance is still pending.


### v119 — dependency disclosure

- Zone and route-map/PBR interface dependencies are displayed as counts and expand to exact names only on demand.
- Zone-pair, NAT pool, ACL and network/service-object references use the same compact disclosure pattern.
- Empty dependency lists explicitly report «Не используется».

### v120 — VLAN inventory and Security Zone navigation

- VLAN inventory is available as a separate sidebar pane; the Interfaces pane no longer prints the complete VLAN list inline.
- VLAN rows show ID/name and expandable bridge, PVID and allowed-port membership. VLAN ranges in switchport allowed-VLAN declarations are evaluated when matching membership.
- Security Zone names in the Security zones table open their detail disclosure, consistent with zone references from Interfaces.
