#!/usr/bin/env python3
"""Run commands on an Eltex ESR CLI over an interactive SSH shell.

This deliberately bypasses Ansible network_cli's IOS terminal/prompt handling,
which is not a suitable platform match for ESR. Configuration mode is exposed
only through the internal JSON command plan used by the authenticated v121 API.
"""
from __future__ import annotations

import json
import os
import re
import sys
import time


ANSI_RE = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")


def clean(text: str) -> str:
    text = ANSI_RE.sub("", text).replace("\r\n", "\n").replace("\r", "\n")
    # Remove terminal control bytes (backspaces, NUL, bell, etc.) while
    # preserving line structure and tabs used by the configuration output.
    return "".join(ch for ch in text if ch in "\n\t" or ord(ch) >= 32 and ord(ch) != 127)


PAGER_RE = re.compile(r"[ \t]*-{1,2}\s*More\s*-{1,2}[ \t]*(?:\x08+[ \t\x08]*)?", re.IGNORECASE)
PAGER_TAIL_RE = re.compile(r"-{1,2}\s*More\s*-{1,2}[ \t\x08]*$", re.IGNORECASE)


def strip_pager(text: str) -> str:
    """Remove `--More--` markers (and the erase sequence that follows them) left by a paged long output."""
    return PAGER_RE.sub("", text)


CONFIG_START_RE = re.compile(
    r"^(?:hostname|object-group|syslog|username|boot|vlan|bridge|security\s+zone|"
    r"interface|nat|ip\s+(?:vrf|route|dhcp|ssh)|route-map|clock|ntp|"
    r"spanning-tree|lldp|aaa|logging|snmp|crypto)\b",
    re.IGNORECASE,
)


def strip_running_config_preamble(text: str) -> str:
    """Drop terminal echo/prompt debris before the first real config directive."""
    normalized = clean(text)
    lines = normalized.splitlines()
    for index, line in enumerate(lines):
        if CONFIG_START_RE.match(line.strip()):
            return "\n".join(lines[index:]).strip() + "\n"
    return normalized.strip() + ("\n" if normalized.strip() else "")


def receive_initial_prompt(channel: paramiko.Channel, timeout: float = 20.0) -> tuple[str, str]:
    """Read login/banner output until quiet, then identify the final prompt line."""
    data = bytearray()
    deadline = time.monotonic() + timeout
    last_data_at: float | None = None
    while time.monotonic() < deadline:
        if channel.recv_ready():
            chunk = channel.recv(65535)
            if not chunk:
                break
            data.extend(chunk)
            last_data_at = time.monotonic()
            continue
        if data and last_data_at is not None and time.monotonic() - last_data_at >= 0.6:
            text = clean(data.decode("utf-8", errors="replace"))
            lines = [line.strip() for line in text.split("\n") if line.strip()]
            if lines and re.search(r"[>#]\s*$", lines[-1]):
                return text, lines[-1]
        time.sleep(0.05)
    text = clean(data.decode("utf-8", errors="replace"))
    lines = [line.strip() for line in text.split("\n") if line.strip()]
    if lines and re.search(r"[>#]\s*$", lines[-1]):
        return text, lines[-1]
    raise RuntimeError("Could not identify the ESR CLI prompt after SSH login; check that the account opens the interactive CLI.")


def _prompt_pattern(initial_prompt: str) -> re.Pattern[str]:
    """Accept the device's prompt even if ESR adds a CLI context suffix."""
    match = re.match(r"^(.+?)(?:\s*\([^)]*\))?\s*[>#]\s*$", initial_prompt.strip())
    if not match:
        raise RuntimeError("The initial ESR CLI prompt has an unsupported format.")
    host = match.group(1).strip()
    # Some ESR releases insert a space before the context suffix, for example
    # `AR1 (config)#`, and some redraw the prompt without a trailing newline.
    return re.compile(r"^" + re.escape(host) + r"\s*(?:\([^()\r\n]*\))?\s*[>#]\s*$", re.IGNORECASE)


def run_command(channel: paramiko.Channel, prompt: str, command: str, timeout: float) -> str:
    """Collect a complete command response, tolerating pager and prompt variations.

    ESR firmware can redraw its prompt or add a context suffix after a long
    command. We therefore identify the final prompt by its hostname and wait
    for a short quiet interval before accepting it. This avoids requiring an
    exact byte-for-byte match with the login prompt.
    """
    channel.send(command + "\n")
    data = bytearray()
    deadline = time.monotonic() + timeout
    paged_at = -1
    prompt_re = _prompt_pattern(prompt)
    prompt_candidate_at: float | None = None
    # A short settle window is enough to distinguish a completed prompt from
    # a prompt-like string in the body, without adding half a second per run.
    prompt_settle = 0.12

    while time.monotonic() < deadline:
        if channel.recv_ready():
            chunk = channel.recv(65535)
            if not chunk:
                break
            data.extend(chunk)
            prompt_candidate_at = None
            normalized = clean(data.decode("utf-8", errors="replace")).strip()
            if PAGER_TAIL_RE.search(normalized) and len(data) != paged_at:
                paged_at = len(data)
                channel.send(" ")
                continue
            normalized = strip_pager(normalized)
            lines = [line.strip() for line in normalized.split("\n") if line.strip()]
            if lines and prompt_re.fullmatch(lines[-1]):
                prompt_candidate_at = time.monotonic()
            continue

        if prompt_candidate_at is not None and time.monotonic() - prompt_candidate_at >= prompt_settle:
            normalized = strip_pager(clean(data.decode("utf-8", errors="replace")))
            lines = normalized.split("\n")
            if lines and lines[0].strip() == command.strip():
                lines = lines[1:]
            while lines and not lines[-1].strip():
                lines.pop()
            if lines and prompt_re.fullmatch(lines[-1].strip()):
                lines.pop()
            output = "\n".join(lines).strip() + ("\n" if lines else "")
            if command.strip().lower() in {"show running-config", "show running config", "do sh run"}:
                output = strip_running_config_preamble(output)
            return output
        time.sleep(0.01)

    # Keep a bounded tail in the error for diagnosis; never include config text
    # because it may contain sensitive values.
    received = len(data)
    suffix = f" Received {received} bytes, but the final CLI prompt was not recognized." if received else " No output received."
    raise TimeoutError(f"Timed out waiting for the ESR CLI prompt after command: {command}.{suffix}")


CLI_ERROR_RE = re.compile(
    r"(?:invalid\s+(?:input|command)|incomplete\s+command|unknown\s+command|"
    r"unrecognized\s+command|command\s+not\s+found|not\s+permitted|permission\s+denied|"
    r"%\s*error\b|configuration\s+error|неверн\w*\s+команд|ошибк\w*\s+конфигурац|"
    r"неизвестн\w*\s+команд|неполнот\w*\s+команд|недопустим\w*\s+команд)",
    re.IGNORECASE,
)


def run_commands(channel: paramiko.Channel, prompt: str, commands: list[str], timeout: float,
                 stop_on_error: bool = False) -> list[dict[str, str]]:
    """Run commands sequentially on one authenticated CLI channel."""
    results = []
    for command in commands:
        sent_at = time.time()
        output = run_command(channel, prompt, command, timeout)
        result = {"command": command, "stdout": output, "sent_at": sent_at}
        results.append(result)
        if stop_on_error and CLI_ERROR_RE.search(output):
            break
    return results


def main() -> int:
    batch_mode = len(sys.argv) >= 2 and sys.argv[1] == "--batch-json"
    config_mode = len(sys.argv) == 2 and sys.argv[1] == "--config-json"
    if config_mode:
        try:
            supplied = json.load(sys.stdin)
            commands = [str(item).strip() for item in supplied]
        except (ValueError, TypeError):
            print("Invalid internal ESR command plan.", file=sys.stderr)
            return 2
    else:
        commands = [item.strip() for item in (sys.argv[2:] if batch_mode else sys.argv[1:]) if item.strip()]
    if not commands or (not (batch_mode or config_mode) and len(commands) != 1):
        print("Usage: eltex_esr_cli.py COMMAND | --batch-json COMMAND ... | --config-json", file=sys.stderr)
        return 2
    host = os.environ.get("ESR_SSH_HOST", "").strip()
    username = os.environ.get("ESR_SSH_USER", "")
    password = os.environ.get("ESR_SSH_PASSWORD", "")
    if not host or not username:
        print("Missing ESR_SSH_HOST or ESR_SSH_USER environment variable.", file=sys.stderr)
        return 2
    try:
        port = int(os.environ.get("ESR_SSH_PORT", "22"))
        connect_timeout = float(os.environ.get("ESR_SSH_CONNECT_TIMEOUT", "15"))
        command_timeout = float(os.environ.get("ESR_SSH_COMMAND_TIMEOUT", "60"))
        import paramiko
        client = paramiko.SSHClient()
        known_hosts = os.environ.get("ESR_SSH_KNOWN_HOSTS", "").strip()
        if not known_hosts or not os.path.isfile(known_hosts):
            raise RuntimeError("The approved SSH known_hosts file is unavailable.")
        client.load_host_keys(known_hosts)
        # Never trust an unknown or changed host key during configuration collection.
        client.set_missing_host_key_policy(paramiko.RejectPolicy())
        client.connect(
            hostname=host,
            port=port,
            username=username,
            password=password or None,
            timeout=connect_timeout,
            banner_timeout=connect_timeout,
            auth_timeout=connect_timeout,
            allow_agent=not bool(password),
            look_for_keys=not bool(password),
        )
        try:
            # A tall pseudo-terminal prevents paging on long running-config output
            # on firmware that honours the requested terminal dimensions.
            channel = client.invoke_shell(term="dumb", width=240, height=10000)
            try:
                _, prompt = receive_initial_prompt(channel, timeout=connect_timeout)
                if batch_mode or config_mode:
                    results = run_commands(channel, prompt, commands, command_timeout, stop_on_error=config_mode)
                    sys.stdout.write(json.dumps(results, ensure_ascii=False))
                else:
                    output = run_command(channel, prompt, commands[0], command_timeout)
                    sys.stdout.write(output)
                return 0
            finally:
                channel.close()
        finally:
            client.close()
    except Exception as exc:  # noqa: BLE001 - surface concise diagnostics to Ansible
        print(f"ESR SSH CLI collection failed: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
