"""Read-only parser for the supported subset of Eltex ESR running-config."""
from __future__ import annotations

import re
from typing import Any


def _top_blocks(text: str, pattern: str) -> list[tuple[str, str]]:
    lines = text.replace("\r\n", "\n").replace("\r", "\n").splitlines()
    result: list[tuple[str, str]] = []
    i = 0
    rx = re.compile(pattern, re.IGNORECASE)
    while i < len(lines):
        match = rx.match(lines[i])
        if not match:
            i += 1
            continue
        header = lines[i].strip()
        body: list[str] = []
        i += 1
        while i < len(lines):
            line = lines[i]
            if line.strip() == "exit" and not line[:1].isspace():
                i += 1
                break
            if line and not line[:1].isspace() and re.match(r"^[A-Za-z][\w-]*(?:\s|$)", line):
                break
            body.append(line)
            i += 1
        result.append((header, "\n".join(body)))
    return result


def _value(body: str, key: str) -> str | None:
    match = re.search(rf"^\s*{re.escape(key)}\s+(.+?)\s*$", body, re.I | re.M)
    return match.group(1).strip().strip('"') if match else None


def _rule_blocks(body: str) -> list[tuple[str, str]]:
    lines = body.splitlines()
    rules: list[tuple[str, str]] = []
    i = 0
    while i < len(lines):
        m = re.match(r"^\s*rule\s+(\S+)\s*$", lines[i], re.I)
        if not m:
            i += 1
            continue
        number, chunk = m.group(1), []
        i += 1
        while i < len(lines) and not re.match(r"^\s*rule\s+\S+\s*$", lines[i], re.I):
            if lines[i].strip().lower() not in {"exit"}:
                chunk.append(lines[i].strip())
            i += 1
        rules.append((number, "\n".join(chunk)))
    return rules



def _child_blocks(body: str, pattern: str) -> list[tuple[str, str]]:
    """Extract indented child blocks, ending at their own indentation level."""
    lines = body.splitlines()
    rx = re.compile(pattern, re.IGNORECASE)
    result: list[tuple[str, str]] = []
    i = 0
    while i < len(lines):
        match = rx.match(lines[i])
        if not match:
            i += 1
            continue
        header = lines[i].strip()
        indent = len(lines[i]) - len(lines[i].lstrip())
        child: list[str] = []
        i += 1
        while i < len(lines):
            line = lines[i]
            stripped = line.strip()
            current_indent = len(line) - len(line.lstrip())
            if stripped.lower() == "exit" and current_indent <= indent:
                i += 1
                break
            child.append(line)
            i += 1
        result.append((header, "\n".join(child)))
    return result

def _canonical_interface_name(name: str) -> str:
    """Expand the short names used by ``show interfaces description``."""
    value = re.sub(r"\s+", " ", name.strip())
    aliases = {
        "gi": "gigabitethernet", "ge": "gigabitethernet",
        "te": "tengigabitethernet", "xe": "tengigabitethernet",
        "fa": "fastethernet", "eth": "ethernet",
    }
    match = re.fullmatch(r"([A-Za-z]+)\s*(\d+(?:/\d+)*(?:\.\d+)*)", value)
    if match:
        prefix, suffix = match.groups()
        value = f"{aliases.get(prefix.lower(), prefix.lower())} {suffix}"
    return value


def _merge_interface_descriptions(interfaces: list[dict[str, Any]], output: str) -> None:
    """Add inventory-only ports and live link state from the ESR show command."""
    by_name = {_canonical_interface_name(item["name"]).casefold(): item for item in interfaces}
    for line in output.replace("\r", "").splitlines():
        fields = line.split()
        if len(fields) < 4:
            continue
        if fields[0].casefold() == "bridge" and len(fields) >= 5:
            raw_name, admin, link, description = f"bridge {fields[1]}", fields[2], fields[3], " ".join(fields[4:])
        else:
            raw_name, admin, link, description = fields[0], fields[1], fields[2], " ".join(fields[3:])
        if admin.casefold() not in {"up", "down", "enable", "disable"} or link.casefold() not in {"up", "down"}:
            continue
        name = _canonical_interface_name(raw_name)
        key = name.casefold()
        item = by_name.get(key)
        if item is None:
            is_bridge = name.casefold().startswith("bridge ")
            item = {
                "name": name, "type": "bridge" if is_bridge else "physical",
                "parent": None, "vlan_id": None, "bridge_id": name.split()[-1] if is_bridge else None,
                "vrf": "VRF0", "description": None, "address": None, "zone": None,
                "shutdown": admin.casefold() in {"down", "disable"},
                # ESR omits default routerport interfaces from running-config.
                "mode": "bridge" if is_bridge else "routerport", "pvid": None,
                "allowed_vlans": [], "forbidden_default_vlan": False,
                "enabled": admin.casefold() not in {"down", "disable"},
                "policy_route_map": None, "vrrp": [], "vrrp_groups": [], "raw": "",
            }
            interfaces.append(item)
            by_name[key] = item
        item["admin_state"] = admin
        item["link_state"] = link
        item["live_description"] = None if description in {"--", "—"} else description
        if not item.get("description") and item["live_description"]:
            item["description"] = item["live_description"]


def parse_esr_running_config(config: str, interface_descriptions: str = "") -> dict[str, Any]:
    """Parse zones, zone-pairs, interfaces, routes, PBR and network/service objects.

    Unknown commands remain available in the raw snapshot; this parser never rewrites
    or normalizes the source configuration.
    """
    hostname_match = re.search(r"^\s*hostname\s+(\S+)\s*$", config, re.I | re.M)
    hostname = hostname_match.group(1) if hostname_match else ""
    # ESR uses VRF0 as the implicit/default routing table. A zone can be
    # explicitly bound to another VRF with `ip vrf forwarding NAME`.
    vrfs = [{"name": "VRF0", "description": "Таблица маршрутизации по умолчанию"}]
    for header, body in _top_blocks(config, r"^ip\s+vrf\s+(\S+)"):
        name = header.split()[-1]
        if name.upper() != "VRF0":
            vrfs.append({"name": name, "description": _value(body, "description")})
    vrf_names = {item["name"].upper() for item in vrfs}

    zones = []
    zone_vrfs = {}
    for header, body in _top_blocks(config, r"^security\s+zone\s+(\S+)"):
        name = header.split()[-1]
        vrf = _value(body, "ip vrf forwarding") or "VRF0"
        zone_vrfs[name.upper()] = vrf
        zones.append({"name": name, "description": _value(body, "description"), "vrf": vrf})

    zone_pairs = []
    for header, body in _top_blocks(config, r"^security\s+zone-pair\s+(\S+)\s+(\S+)"):
        parts = header.split()
        rules = []
        for number, rule_body in _rule_blocks(body):
            action = _value(rule_body, "action")
            protocol = _value(rule_body, "match protocol")
            rules.append({
                "number": number,
                "description": _value(rule_body, "description"),
                "action": action,
                "protocol": protocol,
                "source_address": re.sub(r"^object-group\s+network\s+", "", _value(rule_body, "match source-address") or "", flags=re.I) or None,
                "destination_address": re.sub(r"^object-group\s+network\s+", "", _value(rule_body, "match destination-address") or "", flags=re.I) or None,
                "source_port": re.sub(r"^object-group\s+", "", _value(rule_body, "match source-port") or "", flags=re.I) or None,
                "destination_port": re.sub(r"^object-group\s+", "", _value(rule_body, "match destination-port") or "", flags=re.I) or None,
                "enabled": bool(re.search(r"^\s*enable\s*$", rule_body, re.I | re.M)),
                "raw": rule_body,
            })
        from_zone, to_zone = parts[-2], parts[-1]
        from_vrf = zone_vrfs.get(from_zone.upper(), "VRF0")
        to_vrf = zone_vrfs.get(to_zone.upper(), from_vrf)
        # A pair is associated with the non-default VRF when either endpoint
        # is bound to it. Conflicting explicit VRFs are preserved for review.
        pair_vrf = from_vrf if from_vrf != "VRF0" else to_vrf
        zone_pairs.append({"from_zone": from_zone, "to_zone": to_zone, "vrf": pair_vrf,
                           "vrf_conflict": from_vrf != "VRF0" and to_vrf not in ("VRF0", from_vrf),
                           "rules": rules})

    # VLAN declarations are independent L2 objects, referenced by bridge
    # interfaces and switchport membership.
    vlan_by_id: dict[int, dict[str, Any]] = {}
    for header, body in _top_blocks(config, r"^vlan\s+(.+?)\s*$"):
        vlan_spec = header[len("vlan "):].strip()
        vlan_name = _value(body, "name")
        vlan_ids: list[int] = []
        for token in vlan_spec.split(","):
            token = token.strip()
            range_match = re.fullmatch(r"(\d+)\s*-\s*(\d+)", token)
            if range_match:
                start, end = map(int, range_match.groups())
                if end >= start and end - start <= 4094:
                    vlan_ids.extend(range(start, end + 1))
            elif token.isdigit():
                vlan_ids.append(int(token))
        for vlan_id in vlan_ids:
            # ESR lists unnamed VLANs together (for example ``vlan 2,23``),
            # then emits a named VLAN as its own block. Merge both forms into
            # one UI row, letting an explicit name override the list entry.
            current = vlan_by_id.get(vlan_id)
            if current is None:
                vlan_by_id[vlan_id] = {"id": vlan_id, "name": vlan_name}
            elif vlan_name:
                current["name"] = vlan_name
    vlans = list(vlan_by_id.values())

    interfaces = []
    for header, body in _top_blocks(config, r"^interface\s+(.+?)\s*$"):
        name = header[len("interface "):].strip()
        address = _value(body, "ip address")
        vrf = _value(body, "ip vrf forwarding") or "VRF0"
        vrrp = []
        vrrp_groups = []
        current_vrrp = None
        for line in body.splitlines():
            match = re.match(r"^\s*vrrp(?:\s+(id|ip|priority|group)\s+(.+?))?\s*$", line, re.I)
            if not match:
                continue
            field, value = match.group(1), match.group(2)
            if field:
                field = field.lower()
                value = value.strip()
                vrrp.append({"field": field, "value": value})
                if field == "id" or current_vrrp is None:
                    current_vrrp = {"id": None, "ip": None, "priority": None, "group": None}
                    vrrp_groups.append(current_vrrp)
                current_vrrp[field] = value
            elif current_vrrp is None:
                current_vrrp = {"id": None, "ip": None, "priority": None, "group": None}
                vrrp_groups.append(current_vrrp)
        interfaces.append({
            "name": name,
            "type": "subinterface" if re.search(r"\.\d+(?:\.\d+)?$", name) else "physical",
            "parent": name.rsplit(".", 1)[0] if re.search(r"\.\d+(?:\.\d+)?$", name) else None,
            "vlan_id": int(name.rsplit(".", 1)[-1]) if re.search(r"\.\d+(?:\.\d+)?$", name) else None,
            "vrf": vrf,
            "description": _value(body, "description"),
            "address": address,
            "zone": _value(body, "security-zone"),
            "shutdown": bool(re.search(r"^\s*shutdown\s*$", body, re.I | re.M)),
            "mode": _value(body, "mode"),
            "pvid": _value(body, "switchport general pvid"),
            "allowed_vlans": re.findall(r"^\s*switchport general allowed vlan add\s+(.+?)\s*$", body, re.I | re.M),
            "forbidden_default_vlan": bool(re.search(r"^\\s*switchport forbidden default-vlan\\s*$", body, re.I | re.M)),
            "enabled": bool(re.search(r"^\s*enable\s*$", body, re.I | re.M)),
            "policy_route_map": _value(body, "ip policy route-map"),
            "vrrp": vrrp,
            "vrrp_groups": vrrp_groups,
            "raw": body,
        })

    # ESR1000 configurations may use logical bridge interfaces instead of
    # routed `interface` blocks. Keep them in the same interface inventory,
    # but identify their type explicitly.
    for header, body in _top_blocks(config, r"^bridge\s+(\S+)\s*$"):
        bridge_id = header.split()[-1]
        bridge_vlan = _value(body, "vlan")
        bridge_address = _value(body, "ip address")
        interfaces.append({
            "name": f"bridge {bridge_id}",
            "type": "bridge",
            "bridge_id": bridge_id,
            "vrf": "VRF0",
            "description": _value(body, "description"),
            "address": bridge_address,
            "zone": _value(body, "security-zone"),
            "shutdown": not bool(re.search(r"^\s*enable\s*$", body, re.I | re.M)),
            "enabled": bool(re.search(r"^\s*enable\s*$", body, re.I | re.M)),
            "mode": "bridge",
            "vlan": bridge_vlan,
            "pvid": None,
            "allowed_vlans": [],
            "forbidden_default_vlan": False,
            "policy_route_map": _value(body, "ip policy route-map"),
            "vrrp": [],
            "vrrp_groups": [],
            "raw": body,
        })

    if interface_descriptions:
        _merge_interface_descriptions(interfaces, interface_descriptions)

    routes = []
    for line in config.splitlines():
        # Both `ip route PREFIX ...` and `ip route vrf NAME PREFIX ...`
        # are valid. Routes without an explicit VRF belong to VRF0.
        m = re.match(r"^\s*ip route\s+(?:vrf\s+(\S+)\s+)?(\S+)\s+(\S+)(.*)$", line, re.I)
        if m:
            tail = m.group(4).strip()
            name_match = re.search(r"\bname\s+(?:\"([^\"]+)\"|(\S+))", tail, re.I)
            route_name = (name_match.group(1) or name_match.group(2)) if name_match else None
            if name_match: tail = (tail[:name_match.start()] + tail[name_match.end():]).strip()
            distance_match = re.fullmatch(r"\d+", tail)
            routes.append({"vrf": m.group(1) or "VRF0", "prefix": m.group(2), "next_hop": m.group(3), "name": route_name, "distance": int(tail) if distance_match else None})

    route_maps = []
    for header, body in _top_blocks(config, r"^route-map\s+(\S+)"):
        rules = []
        for number, rule_body in _rule_blocks(body):
            rules.append({"number": number, "match": re.findall(r"^match\s+(.+)$", rule_body, re.I | re.M), "action": _value(rule_body, "action"), "raw": rule_body})
        route_maps.append({"name": header.split()[-1], "rules": rules})

    network_objects, service_objects = [], []
    object_blocks = _top_blocks(config, r"^object-group\s+(network|service)\s+(\S+)")
    source_lines = config.splitlines()
    for header, body in object_blocks:
        parts = header.split()
        kind, name = parts[1].lower(), parts[2]
        entries = [line.strip() for line in body.splitlines() if line.strip() and line.strip().lower() != "exit" and not re.match(r"^\s*description\s+", line, re.I)]
        references = []
        token = re.compile(rf"(?<![A-Za-z0-9_.-]){re.escape(name)}(?![A-Za-z0-9_.-])", re.I)
        for line in source_lines:
            stripped = line.strip()
            if not stripped or stripped.lower().startswith("object-group ") or stripped.lower().startswith("description "):
                continue
            if token.search(stripped) and stripped not in entries:
                references.append(stripped)
        item = {"name": name, "description": _value(body, "description"), "entries": entries, "used_in": list(dict.fromkeys(references))}
        (network_objects if kind == "network" else service_objects).append(item)

    acls = []
    for header, body in _top_blocks(config, r"^ip access-list\s+(\S+)\s+(\S+)"):
        parts = header.split()
        acl_name = parts[-1]
        token = re.compile(rf"(?<![A-Za-z0-9_.-]){re.escape(acl_name)}(?![A-Za-z0-9_.-])", re.I)
        used_in = [line.strip() for line in source_lines
                   if token.search(line.strip()) and not line.strip().lower().startswith("ip access-list ")]
        acls.append({"name": acl_name, "type": parts[-2],
                     "rules": [{"number": n, "raw": b} for n, b in _rule_blocks(body)],
                     "used_in": list(dict.fromkeys(used_in))})

    nat_sections = []
    nat_pools = []
    nat_rulesets = []
    nat_rules = []
    for nat_header, nat_body in _top_blocks(config, r"^nat\s+(destination|source)\s*$"):
        nat_type = nat_header.split()[-1].lower()
        nat_sections.append(nat_type)
        for pool_header, pool_body in _child_blocks(nat_body, r"^\s*pool\s+(\S+)"):
            pool_name = pool_header.split()[-1]
            pool = {
                "nat_type": nat_type,
                "name": pool_name,
                "address": _value(pool_body, "ip address"),
                "address_range": _value(pool_body, "ip address-range"),
                "port": _value(pool_body, "ip port"),
            }
            nat_pools.append(pool)
        for set_header, set_body in _child_blocks(nat_body, r"^\s*ruleset\s+(\S+)"):
            set_name = set_header.split()[-1]
            ruleset = {
                "nat_type": nat_type,
                "name": set_name,
                "interface": _value(set_body, "from interface"),
                "to_zone": _value(set_body, "to zone"),
                "description": _value(set_body, "description"),
                "rules": [],
            }
            for rule_header, rule_body in _child_blocks(set_body, r"^\s*rule\s+(\S+)"):
                rule_number = rule_header.split()[-1]
                raw_action = _value(rule_body, "action") or ""
                action_parts = raw_action.split()
                nat_action = " ".join(action_parts[:2]) if len(action_parts) >= 2 else raw_action
                nat_parameter = action_parts[2] if len(action_parts) >= 3 else None
                rule = {
                    "nat_type": nat_type,
                    "ruleset": set_name,
                    "number": rule_number,
                    "description": _value(rule_body, "description"),
                    "protocol": _value(rule_body, "match protocol"),
                    "source_address": re.sub(r"^object-group\s+network\s+", "", _value(rule_body, "match source-address") or "", flags=re.I) or None,
                    "destination_address": re.sub(r"^object-group\s+network\s+", "", _value(rule_body, "match destination-address") or "", flags=re.I) or None,
                    "destination_port": re.sub(r"^object-group\s+(?:service\s+)?", "", _value(rule_body, "match destination-port") or "", flags=re.I) or None,
                    "source_port": re.sub(r"^object-group\s+(?:service\s+)?", "", _value(rule_body, "match source-port") or "", flags=re.I) or None,
                    "action": raw_action,
                    "nat_action": nat_action,
                    "pool": nat_parameter if nat_action.endswith("pool") else None,
                    "netmap": nat_parameter if nat_action.endswith("netmap") else None,
                    "enabled": bool(re.search(r"^\s*enable\s*$", rule_body, re.I | re.M)),
                    "raw": rule_body.strip(),
                }
                ruleset["rules"].append(rule)
                nat_rules.append(rule)
            nat_rulesets.append(ruleset)

    # A normalized dependency graph for the UI and future safe editing.
    # It is derived from the read-only snapshot; it never emits device commands.
    dependencies: list[dict[str, str]] = []
    def add_dependency(source_type: str, source_id: str, relation: str,
                       target_type: str, target_id: str) -> None:
        if source_id and target_id:
            dependencies.append({
                "source_type": source_type, "source_id": str(source_id),
                "relation": relation, "target_type": target_type,
                "target_id": str(target_id),
            })

    for iface in interfaces:
        if iface.get("zone"):
            add_dependency("interface", iface["name"], "belongs_to", "security_zone", iface["zone"])
        if iface.get("policy_route_map"):
            add_dependency("interface", iface["name"], "uses_policy", "route_map", iface["policy_route_map"])
        if iface.get("type") == "bridge" and iface.get("vlan"):
            add_dependency("interface", iface["name"], "bridges_vlan", "vlan", iface["vlan"])
        for group in iface.get("vrrp_groups", []):
            if group.get("id"):
                add_dependency("interface", iface["name"], "has_vrrp", "vrrp_group", group["id"])
    for pair in zone_pairs:
        add_dependency("zone_pair", f'{pair["from_zone"]}->{pair["to_zone"]}', "from_zone", "security_zone", pair["from_zone"])
        add_dependency("zone_pair", f'{pair["from_zone"]}->{pair["to_zone"]}', "to_zone", "security_zone", pair["to_zone"])
    for rule in nat_rules:
        if rule.get("pool"):
            add_dependency("nat_rule", f'{rule["ruleset"]}:{rule["number"]}', "uses_pool", "nat_pool", rule["pool"])
    for route in routes:
        add_dependency("static_route", f'{route["vrf"]}:{route["prefix"]}', "belongs_to", "vrf", route["vrf"])

    for pool in nat_pools:
        pool["used_in"] = [f'{edge["source_id"]}' for edge in dependencies
                           if edge["target_type"] == "nat_pool" and edge["target_id"] == pool["name"]]
    for route_map in route_maps:
        route_map["used_in"] = [edge["source_id"] for edge in dependencies
                                if edge["target_type"] == "route_map" and edge["target_id"] == route_map["name"]]
    for zone in zones:
        zone["used_in"] = [edge["source_id"] for edge in dependencies
                           if edge["target_type"] == "security_zone" and edge["target_id"] == zone["name"]]
    for acl in acls:
        for use in acl.get("used_in", []):
            add_dependency("configuration_line", use, "references_acl", "access_list", acl["name"])

    return {
        "hostname": hostname,
        "dependencies": dependencies,
        "vrfs": vrfs,
        "zones": zones,
        "zone_pairs": zone_pairs,
        "interfaces": interfaces,
        "vlans": vlans,
        "static_routes": routes,
        "route_maps": route_maps,
        "network_objects": network_objects,
        "service_objects": service_objects,
        "access_lists": acls,
        "nat_sections": nat_sections,
        "nat_pools": nat_pools,
        "nat_rulesets": nat_rulesets,
        "nat_rules": nat_rules,
        "statistics": {
            "vrfs": len(vrfs), "zones": len(zones), "zone_pairs": len(zone_pairs),
            "zone_pair_rules": sum(len(x["rules"]) for x in zone_pairs),
            "interfaces": len(interfaces), "vlans": len(vlans), "static_routes": len(routes),
            "route_maps": len(route_maps), "network_objects": len(network_objects),
            "service_objects": len(service_objects),
            "nat_pools": len(nat_pools), "nat_rulesets": len(nat_rulesets),
            "nat_rules": len(nat_rules),
        },
    }
