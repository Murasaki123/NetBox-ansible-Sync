"""Small, extensible ESR configuration planner used by the v121 UI/API."""
from __future__ import annotations

import difflib
import ipaddress
import re
from dataclasses import dataclass
from typing import Any


class ConfigurationError(ValueError):
    pass


@dataclass(frozen=True)
class VlanOperation:
    action: str
    vlan_id: int
    name: str | None = None


def parse_operations(payload: Any) -> list[VlanOperation]:
    if not isinstance(payload, list) or not payload or len(payload) > 100:
        raise ConfigurationError("Укажите от 1 до 100 операций с VLAN.")
    result: list[VlanOperation] = []
    seen: set[int] = set()
    for item in payload:
        if not isinstance(item, dict):
            raise ConfigurationError("Операция должна быть объектом.")
        action = str(item.get("action", "")).strip().lower()
        try:
            vlan_id = int(item.get("id"))
        except (TypeError, ValueError) as exc:
            raise ConfigurationError("VLAN ID должен быть числом от 1 до 4094.") from exc
        if action not in {"upsert", "delete"} or not 2 <= vlan_id <= 4094:
            raise ConfigurationError("Допустимы операции upsert/delete и VLAN ID от 2 до 4094.")
        if vlan_id in seen:
            raise ConfigurationError(f"VLAN {vlan_id} указан более одного раза.")
        seen.add(vlan_id)
        name = item.get("name")
        if action == "upsert":
            name = str(name or "").strip()
            if len(name) > 64 or any(ord(ch) < 32 for ch in name):
                raise ConfigurationError("Имя VLAN должно содержать не более 64 печатных символов.")
        else:
            name = None
        result.append(VlanOperation(action, vlan_id, name))
    return result


def _vlan_blocks(config: str) -> dict[int, tuple[int, int, str | None]]:
    lines = config.replace("\r\n", "\n").replace("\r", "\n").splitlines()
    blocks: dict[int, tuple[int, int, str | None]] = {}
    i = 0
    while i < len(lines):
        match = re.fullmatch(r"vlan\s+(\d+)", lines[i].strip(), re.I)
        if not match or lines[i][:1].isspace():
            i += 1
            continue
        vlan_id = int(match.group(1))
        start = i
        i += 1
        name = None
        while i < len(lines):
            line = lines[i]
            if line.strip().lower() == "exit" and not line[:1].isspace():
                i += 1
                break
            if line and not line[:1].isspace() and re.match(r"^[A-Za-z][\w-]*(?:\s|$)", line):
                break
            named = re.match(r"^\s*name\s+(.+?)\s*$", line, re.I)
            if named:
                name = named.group(1).strip().strip('"')
            i += 1
        if vlan_id in blocks:
            raise ConfigurationError(f"В running-config несколько блоков VLAN {vlan_id}; изменение отменено.")
        blocks[vlan_id] = (start, i, name)
    return blocks


def _references_vlan(config: str, vlan_id: int) -> bool:
    for line in config.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        if re.search(rf"\b(?:pvid|native-vlan|access\s+vlan)\s+{vlan_id}(?:\b|$)", stripped, re.I):
            return True
        if "switchport" in stripped.lower() and "allowed vlan" in stripped.lower():
            spec = re.search(r"allowed\s+vlan\s+(?:add\s+|remove\s+)?([\d,\s-]+)", stripped, re.I)
            if spec:
                for token in re.findall(r"\d+(?:\s*-\s*\d+)?", spec.group(1)):
                    ends = [int(part.strip()) for part in token.split("-")]
                    if len(ends) == 1 and ends[0] == vlan_id or len(ends) == 2 and ends[0] <= vlan_id <= ends[1]:
                        return True
        if line[:1].isspace() and re.fullmatch(rf"vlan\s+{vlan_id}", stripped, re.I):
            return True
    return False


def _vlan_range_contains(config: str, vlan_id: int) -> bool:
    """Return true only for VLANs covered by an actual interval declaration.

    A comma-separated list such as ``vlan 2,23`` is a collection of individual
    VLAN declarations. ESR accepts a separate ``vlan 23`` block to configure
    one member of that list, so it must not be treated as an unmanageable range.
    """
    for line in config.splitlines():
        if line[:1].isspace():
            continue
        match = re.fullmatch(r"vlan\s+(.+)", line.strip(), re.I)
        if not match:
            continue
        spec = match.group(1).strip()
        for token in spec.split(","):
            token = token.strip()
            range_match = re.fullmatch(r"(\d+)\s*-\s*(\d+)", token)
            if range_match:
                first, last = map(int, range_match.groups())
                if first <= vlan_id <= last:
                    return True
    return False


def _vlan_declared_in_config(config: str, vlan_id: int) -> bool:
    """Return true when an ID appears in a top-level VLAN list or interval."""
    for line in config.splitlines():
        if line[:1].isspace():
            continue
        match = re.fullmatch(r"vlan\s+(.+)", line.strip(), re.I)
        if not match:
            continue
        for token in match.group(1).split(","):
            token = token.strip()
            interval = re.fullmatch(r"(\d+)\s*-\s*(\d+)", token)
            if interval:
                first, last = map(int, interval.groups())
                if first <= vlan_id <= last:
                    return True
            elif token.isdigit() and int(token) == vlan_id:
                return True
    return False


def _vlan_list_replacements(lines: list[str], vlan_ids: set[int]) -> list[tuple[int, int, list[str]]]:
    """Remove deleted IDs from comma-separated unnamed VLAN declarations."""
    replacements: list[tuple[int, int, list[str]]] = []
    i = 0
    while i < len(lines):
        line = lines[i]
        match = re.fullmatch(r"vlan\s+(.+)", line.strip(), re.I) if not line[:1].isspace() else None
        if not match or "," not in match.group(1):
            i += 1
            continue
        tokens = [token.strip() for token in match.group(1).split(",")]
        if any(re.fullmatch(r"\d+\s*-\s*\d+", token) for token in tokens):
            i += 1
            continue
        remaining = [token for token in tokens if not (token.isdigit() and int(token) in vlan_ids)]
        if len(remaining) != len(tokens):
            end = i + 1
            while end < len(lines) and not (lines[end].strip().lower() == "exit" and not lines[end][:1].isspace()):
                if lines[end] and not lines[end][:1].isspace() and re.match(r"^[A-Za-z][\w-]*(?:\s|$)", lines[end]):
                    break
                end += 1
            if not remaining:
                if end < len(lines) and lines[end].strip().lower() == "exit" and not lines[end][:1].isspace():
                    end += 1
                replacements.append((i, end, []))
            else:
                replacements.append((i, i + 1, [f"vlan {','.join(remaining)}"]))
        i += 1
    return replacements


def plan_vlan_changes(config: str, operations: list[VlanOperation], confirm_timeout: int = 120) -> dict[str, Any]:
    lines = config.replace("\r\n", "\n").replace("\r", "\n").splitlines()
    blocks = _vlan_blocks(config)
    command_blocks: list[list[str]] = []
    replacements: list[tuple[int, int, list[str]]] = []
    deleted_vlan_ids: set[int] = set()
    warnings: list[str] = []
    for op in operations:
        if _vlan_range_contains(config, op.vlan_id):
            raise ConfigurationError(f"VLAN {op.vlan_id} задан в общей декларации диапазона. Управление такими декларациями не поддерживается.")
        existing = blocks.get(op.vlan_id)
        if op.action == "delete":
            declared = _vlan_declared_in_config(config, op.vlan_id)
            if not existing and not declared:
                warnings.append(f"VLAN {op.vlan_id} отсутствует и будет пропущен.")
                continue
            command_blocks.append([f"no vlan {op.vlan_id}"])
            deleted_vlan_ids.add(op.vlan_id)
            if existing:
                replacements.append((existing[0], existing[1], []))
            continue
        old_name = existing[2] if existing else None
        if existing and old_name == (op.name or None):
            warnings.append(f"VLAN {op.vlan_id} уже имеет заданное имя; изменений нет.")
            continue
        command_block = [f"vlan {op.vlan_id}"]
        new_block = [f"vlan {op.vlan_id}"]
        if op.name:
            escaped = op.name.replace('\\', '\\\\').replace('"', '\\"')
            command_block.append(f'name "{escaped}"')
            new_block.append(f' name "{escaped}"')
        elif existing and old_name:
            command_block.append("no name")
        command_block.append("exit")
        new_block.append("exit")
        command_blocks.append(command_block)
        if existing:
            replacements.append((existing[0], existing[1], new_block))
        else:
            replacements.append((len(lines), len(lines), new_block))
    if not command_blocks:
        raise ConfigurationError("Изменений для применения нет.")
    replacements.extend(_vlan_list_replacements(lines, deleted_vlan_ids))
    for start, end, replacement in sorted(replacements, key=lambda x: x[0], reverse=True):
        if start == len(lines) and end == len(lines):
            if lines and lines[-1].strip():
                lines.append("")
            lines.extend(replacement)
        else:
            lines[start:end] = replacement
    timer_indices = [index for index, line in enumerate(lines)
                     if re.fullmatch(r"\s*system\s+config-confirm\s+timeout\s+\d+\s*", line, re.I)]
    if len(timer_indices) > 1:
        raise ConfigurationError("В running-config найдено несколько настроек таймера confirm; изменение отменено.")
    timer_command = f"system config-confirm timeout {confirm_timeout}"
    if timer_indices:
        lines[timer_indices[0]] = timer_command
    else:
        if lines and lines[-1].strip():
            lines.append("")
        lines.append(timer_command)
    candidate = "\n".join(lines).rstrip() + "\n"
    diff = "".join(difflib.unified_diff(
        config.replace("\r\n", "\n").replace("\r", "\n").splitlines(keepends=True),
        candidate.splitlines(keepends=True), fromfile="running-config", tofile="предполагаемая-конфигурация",
    ))
    return {
        "commands": ["configure terminal", "system config-confirm timeout {timeout}"] +
                    [line for block in command_blocks for line in block] + ["end", "commit"],
        "change_commands": [line for block in command_blocks for line in block],
        "candidate": candidate,
        "diff": diff,
        "warnings": warnings,
        "changed": bool(diff),
    }


def parse_config_operations(payload: Any) -> list[dict[str, Any]]:
    """Validate mixed VLAN, zone and zone-pair operations from the ESR UI."""
    if not isinstance(payload, list) or not payload or len(payload) > 100:
        raise ConfigurationError("Укажите от 1 до 100 изменений конфигурации.")
    result = []
    keys = set()
    safe_name = re.compile(r"^[A-Za-z0-9_.-]{1,64}$")
    for item in payload:
        if not isinstance(item, dict):
            raise ConfigurationError("Операция должна быть объектом.")
        source_item = item
        kind = source_item.get("type", "vlan")
        action = str(source_item.get("action", "")).lower()
        if kind == "vlan":
            op = parse_operations([source_item])[0]
            key = (kind, op.vlan_id)
            item = {"type": kind, "action": op.action, "id": op.vlan_id, "name": op.name}
        elif kind == "hostname":
            if action != "upsert":
                raise ConfigurationError("Для hostname поддерживается только задание нового имени.")
            name = str(source_item.get("name", "")).strip()
            if (not name or len(name) > 63 or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9.-]*[A-Za-z0-9]|[A-Za-z0-9]", name)
                    or ".." in name or "-." in name or ".-" in name):
                raise ConfigurationError("Hostname ESR должен содержать 1–63 буквы, цифры, точки или дефисы и не начинаться/заканчиваться точкой или дефисом.")
            key = (kind,)
            item = {"type": kind, "action": action, "name": name}
        elif kind == "object_group":
            object_kind = str(source_item.get("object_kind", "")).lower()
            if object_kind not in {"network", "service"} or action not in {"upsert", "delete"}:
                raise ConfigurationError("Для object-group укажите тип network/service и действие upsert/delete.")
            name = str(source_item.get("name", "")).strip()
            if not re.fullmatch(r"[A-Za-z0-9_.]{1,31}", name):
                raise ConfigurationError("Имя сетевого или сервисного объекта должно содержать 1–31 латинскую букву, цифру, точку или подчёркивание; дефис запрещён, используйте подчёркивание.")
            key = (kind, object_kind, name.lower())
            item = {"type": kind, "object_kind": object_kind, "action": action, "name": name}
            if action == "upsert":
                description = str(source_item.get("description", "")).strip()
                if len(description) > 255 or any(ord(ch) < 32 for ch in description):
                    raise ConfigurationError("Описание object-group должно быть не длиннее 255 печатных символов.")
                raw_entries = source_item.get("entries", [])
                if not isinstance(raw_entries, list) or len(raw_entries) > 256:
                    raise ConfigurationError("Состав object-group должен быть списком не более чем из 256 записей.")
                entries = []
                for raw_entry in raw_entries:
                    entry = " ".join(str(raw_entry).strip().split())
                    if object_kind == "network":
                        match = re.fullmatch(r"ip prefix (\S+)", entry, re.I)
                        address_range = re.fullmatch(r"ip address-range (\S+)", entry, re.I)
                        try:
                            if match:
                                network = ipaddress.ip_network(match.group(1), strict=False)
                                if network.version != 4:
                                    raise ValueError
                            elif address_range:
                                ends = address_range.group(1).split("-", 1)
                                parsed_addresses = [ipaddress.ip_address(value) for value in ends]
                                if any(value.version != 4 for value in parsed_addresses) or (len(parsed_addresses) == 2 and int(parsed_addresses[0]) > int(parsed_addresses[1])):
                                    raise ValueError
                            else:
                                raise ValueError
                        except ValueError as exc:
                            raise ConfigurationError("Сетевой объект поддерживает записи 'ip prefix IPv4/маска' и 'ip address-range IPv4[-IPv4]'.") from exc
                    else:
                        match = re.fullmatch(r"port-range (\d+(?:-\d+)?(?:,\d+(?:-\d+)?)*)", entry, re.I)
                        if not match:
                            raise ConfigurationError("Сервисный объект поддерживает записи port-range: порт, диапазон или список портов.")
                        for part in match.group(1).split(","):
                            bounds = [int(value) for value in part.split("-")]
                            if any(value < 1 or value > 65535 for value in bounds) or (len(bounds) == 2 and bounds[0] > bounds[1]):
                                raise ConfigurationError("Порты должны быть в диапазоне 1–65535.")
                    if entry not in entries:
                        entries.append(entry)
                item.update(description=description, entries=entries)
        elif kind == "subinterface":
            name = " ".join(str(source_item.get("name", "")).split())
            match = re.fullmatch(r"(gigabitethernet|tengigabitethernet|port-channel)\s+(\d+(?:/\d+){1,2})\.(\d{1,4})", name, re.I)
            if not match or not 1 <= int(match.group(3)) <= 4094:
                raise ConfigurationError("Саб-интерфейс должен иметь формат gigabitethernet 1/0/1.23 и VLAN ID от 1 до 4094.")
            if action not in {"upsert", "delete"}:
                raise ConfigurationError("Для саб-интерфейса допустимы upsert/delete.")
            item = {"type": kind, "action": action, "name": name}
            key = (kind, name.lower())
            if action == "upsert":
                address = str(source_item.get("address", "")).strip()
                if address:
                    try:
                        parsed = ipaddress.ip_interface(address)
                        if parsed.version != 4:
                            raise ValueError
                    except ValueError as exc:
                        raise ConfigurationError("Адрес саб-интерфейса должен быть IPv4 с маской, например 192.0.2.1/24.") from exc
                description = str(source_item.get("description", "")).strip()
                if len(description) > 128 or any(ord(ch) < 32 for ch in description):
                    raise ConfigurationError("Описание саб-интерфейса должно быть не длиннее 128 печатных символов.")
                zone = str(source_item.get("zone", "")).strip()
                vrf = str(source_item.get("vrf", "VRF0")).strip() or "VRF0"
                if (zone and not safe_name.fullmatch(zone)) or not safe_name.fullmatch(vrf):
                    raise ConfigurationError("Некорректное имя зоны или VRF саб-интерфейса.")
                item.update(address=address, description=description, zone=zone, vrf=vrf)
        elif kind == "interface_mode":
            name = " ".join(str(source_item.get("name", "")).split())
            if not re.fullmatch(r"(?:gigabitethernet|tengigabitethernet|port-channel)\s+\d+(?:/\d+){1,2}", name, re.I):
                raise ConfigurationError("Выберите существующий физический интерфейс.")
            mode = str(source_item.get("mode", "")).lower()
            if mode not in {"routerport", "switchport"}: raise ConfigurationError("Режим должен быть routerport или switchport.")
            key = (kind, name.lower()); item = {"type": kind, "action": "upsert", "name": name, "mode": mode}
        elif kind == "bridge":
            try: bridge_id = int(source_item.get("id"))
            except (TypeError, ValueError) as exc: raise ConfigurationError("ID bridge должен быть числом от 1 до 4094.") from exc
            if not 1 <= bridge_id <= 4094 or action not in {"upsert", "delete"}: raise ConfigurationError("Для bridge допустимы upsert/delete и ID от 1 до 4094.")
            key = (kind, bridge_id); item = {"type": kind, "action": action, "id": bridge_id}
            if action == "upsert":
                vlan = str(source_item.get("vlan", "")).strip()
                if vlan and (not vlan.isdigit() or not 1 <= int(vlan) <= 4094): raise ConfigurationError("VLAN bridge должен быть от 1 до 4094.")
                address = str(source_item.get("address", "")).strip()
                if address:
                    try:
                        if ipaddress.ip_interface(address).version != 4: raise ValueError
                    except ValueError as exc: raise ConfigurationError("Адрес bridge должен быть IPv4 с маской.") from exc
                zone = str(source_item.get("zone", "")).strip(); description = str(source_item.get("description", "")).strip()
                if zone and not safe_name.fullmatch(zone): raise ConfigurationError("Некорректное имя Security zone.")
                if len(description) > 128 or any(ord(ch) < 32 for ch in description): raise ConfigurationError("Описание bridge должно быть до 128 печатных символов.")
                item.update(vlan=vlan, address=address, zone=zone, description=description, enabled=bool(source_item.get("enabled", True)))
        elif kind == "static_route":
            if action not in {"upsert", "delete"}: raise ConfigurationError("Для маршрута допустимы upsert/delete.")
            try:
                network = ipaddress.ip_network(str(source_item.get("prefix", "")).strip(), strict=False)
                next_hop = str(source_item.get("next_hop", "")).strip()
                ipaddress.ip_address(next_hop)
                if network.version != 4: raise ValueError
            except ValueError as exc: raise ConfigurationError("Укажите IPv4-префикс и IPv4 next-hop.") from exc
            vrf = str(source_item.get("vrf", "VRF0")).strip() or "VRF0"
            if not safe_name.fullmatch(vrf): raise ConfigurationError("Некорректное имя VRF.")
            try: distance = int(source_item["distance"]) if source_item.get("distance") not in (None, "") else None
            except (TypeError, ValueError) as exc: raise ConfigurationError("Distance должен быть от 1 до 255.") from exc
            if distance is not None and not 1 <= distance <= 255: raise ConfigurationError("Distance должен быть от 1 до 255.")
            route_name = str(source_item.get("name", "")).strip()
            if route_name and not re.fullmatch(r"[A-Za-z0-9_.-]{1,64}", route_name): raise ConfigurationError("Имя маршрута должно содержать до 64 латинских букв, цифр, точки, подчёркивания или дефиса.")
            key = (kind, vrf.lower(), str(network), next_hop)
            item = {"type": kind, "action": action, "vrf": vrf, "prefix": str(network), "next_hop": next_hop, "distance": distance, "name": route_name}
        elif kind == "nat_pool":
            nat_type, name = str(source_item.get("nat_type", "")).lower(), str(source_item.get("name", "")).strip()
            if nat_type not in {"source", "destination"} or action not in {"upsert", "delete"} or not safe_name.fullmatch(name): raise ConfigurationError("Укажите направление, имя NAT pool и действие.")
            key = (kind, nat_type, name.lower()); item = {"type": kind, "action": action, "nat_type": nat_type, "name": name}
            if action == "upsert":
                address, address_range, port = (str(source_item.get(k, "")).strip() for k in ("address", "address_range", "port"))
                if bool(address) == bool(address_range): raise ConfigurationError("Укажите один IP или диапазон NAT pool.")
                try:
                    if address: ipaddress.IPv4Address(address)
                    else:
                        first, last = map(ipaddress.IPv4Address, address_range.split("-"))
                        if int(first) > int(last): raise ValueError
                except ValueError as exc: raise ConfigurationError("Укажите корректный IPv4-адрес или диапазон.") from exc
                if port and (not port.isdigit() or not 1 <= int(port) <= 65535): raise ConfigurationError("Порт NAT pool должен быть от 1 до 65535.")
                item.update(address=address, address_range=address_range, port=port)
        elif kind == "nat_ruleset":
            nat_type, name = str(source_item.get("nat_type", "")).lower(), str(source_item.get("name", "")).strip()
            if nat_type not in {"source", "destination"} or action not in {"upsert", "delete"} or not safe_name.fullmatch(name): raise ConfigurationError("Укажите направление, имя NAT ruleset и действие.")
            key = (kind, nat_type, name.lower()); item = {"type": kind, "action": action, "nat_type": nat_type, "name": name}
            if action == "upsert":
                interface, zone, description = (str(source_item.get(k, "")).strip() for k in ("interface", "to_zone", "description"))
                if interface and not re.fullmatch(r"(?:gigabitethernet|tengigabitethernet|port-channel)\s+[\w./-]+", interface, re.I): raise ConfigurationError("Некорректный интерфейс NAT ruleset.")
                if zone and not safe_name.fullmatch(zone): raise ConfigurationError("Некорректная зона NAT ruleset.")
                if len(description) > 128 or any(ord(ch) < 32 for ch in description): raise ConfigurationError("Описание NAT ruleset должно быть до 128 печатных символов.")
                item.update(interface=interface, to_zone=zone, description=description)
        elif kind == "nat_rule":
            nat_type, ruleset = str(source_item.get("nat_type", "")).lower(), str(source_item.get("ruleset", "")).strip()
            if nat_type not in {"source", "destination"} or not safe_name.fullmatch(ruleset) or action not in {"upsert", "delete"}: raise ConfigurationError("Укажите source/destination, ruleset и действие.")
            try: number = int(source_item.get("number"))
            except (TypeError, ValueError) as exc: raise ConfigurationError("Номер NAT правила должен быть от 1 до 10000.") from exc
            if not 1 <= number <= 10000: raise ConfigurationError("Номер NAT правила должен быть от 1 до 10000.")
            key = (kind, nat_type, ruleset.lower(), number); item = {"type": kind, "action": action, "nat_type": nat_type, "ruleset": ruleset, "number": number}
            if action == "upsert":
                protocol = str(source_item.get("protocol", "")).lower()
                if protocol not in {"", "tcp", "udp", "icmp"}: raise ConfigurationError("Недопустимый протокол NAT.")
                source_address, destination_address = (str(source_item.get(k, "")).strip() for k in ("source_address", "destination_address"))
                destination_port = str(source_item.get("destination_port", "")).strip()
                source_port = str(source_item.get("source_port", "")).strip()
                for val in (source_address, destination_address, source_port, destination_port):
                    if val and not safe_name.fullmatch(val): raise ConfigurationError("Фильтры NAT должны ссылаться на object-group.")
                nat_action = str(source_item.get("nat_action", "")).strip(); pool = str(source_item.get("pool", "")).strip(); netmap = str(source_item.get("netmap", "")).strip()
                allowed = {"source-nat interface", "source-nat off", "source-nat pool", "destination-nat pool", "destination-nat netmap"}
                if nat_action not in allowed: raise ConfigurationError("Недопустимое действие NAT.")
                if (nat_type == "source" and not nat_action.startswith("source-nat")) or (nat_type == "destination" and not nat_action.startswith("destination-nat")):
                    raise ConfigurationError("Действие NAT должно соответствовать выбранному направлению.")
                if "pool" in nat_action and not safe_name.fullmatch(pool): raise ConfigurationError("Для выбранного действия требуется имя NAT pool.")
                if nat_action == "destination-nat netmap":
                    try:
                        if ipaddress.ip_network(netmap, strict=False).version != 4: raise ValueError
                    except ValueError as exc: raise ConfigurationError("Netmap должен быть IPv4-префиксом.") from exc
                description = str(source_item.get("description", "")).strip()
                if len(description) > 128 or any(ord(ch) < 32 for ch in description): raise ConfigurationError("Описание NAT правила должно быть до 128 печатных символов.")
                item.update(protocol=protocol, source_address=source_address, destination_address=destination_address,
                            source_port=source_port, destination_port=destination_port, nat_action=nat_action, pool=pool, netmap=netmap, description=description)
        elif kind in {"zone", "zone_pair"}:
            if action not in {"upsert", "delete"}:
                raise ConfigurationError("Для зон и zone-pair допустимы upsert/delete.")
            fields = ("name",) if kind == "zone" else ("source", "destination")
            values = [str(source_item.get(field, "")).strip() for field in fields]
            if any(not safe_name.fullmatch(value) for value in values):
                raise ConfigurationError("Имя зоны и zone-pair должно содержать 1–64 латинских букв, цифр, '.', '_' или '-'.")
            vrf = str(source_item.get("vrf", "VRF0")).strip() or "VRF0"
            if not safe_name.fullmatch(vrf):
                raise ConfigurationError("Некорректное имя VRF.")
            if kind == "zone" and len(values[0]) > 12:
                raise ConfigurationError("Имя Security zone ESR ограничено 12 символами.")
            key = (kind, *values)
            item = {"type": kind, "action": action, **dict(zip(fields, values)), "vrf": vrf}
            if kind == "zone" and action == "upsert":
                description = str(source_item.get("description", ""))
                if len(description) > 128 or any(ord(ch) < 32 for ch in description):
                    raise ConfigurationError("Описание зоны должно быть не длиннее 128 печатных символов.")
                item["description"] = description
            if kind == "zone_pair" and action == "upsert":
                # Pair-level updates are deliberately additive: an optional rule is
                # replaced by its number while every other existing rule is retained.
                if source_item.get("rule") is not None:
                    if not isinstance(source_item["rule"], dict):
                        raise ConfigurationError("Параметры правила должны быть объектом.")
                    rule = dict(source_item["rule"])
                    try:
                        number = int(rule.get("number"))
                    except (TypeError, ValueError) as exc:
                        raise ConfigurationError("Номер правила должен быть числом 1–10000.") from exc
                    if not 1 <= number <= 10000 or rule.get("action") not in {"permit", "deny"}:
                        raise ConfigurationError("Правило требует номер 1–10000 и действие permit/deny.")
                    protocol = str(rule.get("protocol", "any")).lower()
                    allowed_protocols = {"any", "esp", "icmp", "ah", "eigrp", "ospf", "igmp", "ipip", "tcp", "pim", "udp", "vrrp", "rdp", "l2tp", "gre"}
                    if protocol not in allowed_protocols:
                        raise ConfigurationError("Недопустимый протокол правила zone-pair.")
                    item["rule"] = {"number": number, "action": rule["action"], "protocol": protocol}
                    for field in ("source_address", "destination_address", "source_port", "destination_port"):
                        if field in rule:
                            value = str(rule.get(field) or "").strip()
                            if value and not safe_name.fullmatch(value):
                                raise ConfigurationError(f"Некорректное имя объекта для {field}.")
                            item["rule"][field] = value
                    desc = str(rule.get("description", ""))
                    if len(desc) > 128 or any(ord(ch) < 32 for ch in desc):
                        raise ConfigurationError("Описание правила должно быть не длиннее 128 печатных символов.")
                    item["rule"]["description"] = desc
        elif kind == "zone_pair_rule":
            if action != "delete":
                raise ConfigurationError("Для правила zone-pair поддерживается только удаление.")
            fields = ("source", "destination")
            values = [str(source_item.get(field, "")).strip() for field in fields]
            if any(not safe_name.fullmatch(value) for value in values):
                raise ConfigurationError("Некорректные имена зон для правила zone-pair.")
            vrf = str(source_item.get("vrf", "VRF0")).strip() or "VRF0"
            if not safe_name.fullmatch(vrf):
                raise ConfigurationError("Некорректное имя VRF.")
            try:
                number = int(source_item.get("number"))
            except (TypeError, ValueError) as exc:
                raise ConfigurationError("Номер удаляемого правила должен быть числом 1–10000.") from exc
            if not 1 <= number <= 10000:
                raise ConfigurationError("Номер удаляемого правила должен быть числом 1–10000.")
            key = (kind, *values, vrf.lower(), number)
            item = {"type": kind, "action": action, **dict(zip(fields, values)), "vrf": vrf, "number": number}
        else:
            raise ConfigurationError("Неизвестный тип операции конфигурации.")
        if key in keys:
            raise ConfigurationError("Объект указан более одного раза.")
        keys.add(key)
        result.append(item)
    return result


def _top_blocks(config: str, pattern: re.Pattern[str]) -> dict[tuple[str, ...], tuple[int, int]]:
    lines = config.replace("\r\n", "\n").replace("\r", "\n").splitlines()
    found = {}
    i = 0
    while i < len(lines):
        match = pattern.fullmatch(lines[i].strip()) if not lines[i][:1].isspace() else None
        if not match:
            i += 1
            continue
        key = tuple((part or "").lower() for part in match.groups())
        start = i
        i += 1
        while i < len(lines):
            if lines[i].strip().lower() == "exit" and not lines[i][:1].isspace():
                i += 1
                break
            if lines[i] and not lines[i][:1].isspace():
                break
            i += 1
        if key in found:
            raise ConfigurationError("В конфигурации найдено несколько одинаковых блоков; изменение отменено.")
        found[key] = (start, i)
    return found


def _section_span(lines: list[str], heading: str) -> tuple[int, int] | None:
    start = next((i for i, line in enumerate(lines) if line.strip().lower() == heading.lower() and not line[:1].isspace()), None)
    if start is None: return None
    end = next((i + 1 for i in range(start + 1, len(lines)) if lines[i].strip().lower() == "exit" and not lines[i][:1].isspace()), len(lines))
    return start, end


def _child_span(lines: list[str], parent: tuple[int, int], pattern: re.Pattern[str]) -> tuple[int, int] | None:
    start, end = parent
    for i in range(start + 1, end):
        if not lines[i][:1].isspace(): continue
        match = pattern.fullmatch(lines[i].strip())
        if not match: continue
        indent = len(lines[i]) - len(lines[i].lstrip())
        finish = next((j + 1 for j in range(i + 1, end)
                       if lines[j].strip().lower() == "exit" and (len(lines[j]) - len(lines[j].lstrip())) <= indent), end)
        return i, finish
    return None


def _nat_rule_block_and_commands(op: dict[str, Any]) -> tuple[list[str], list[str]]:
    """Render a NAT rule as candidate-config lines and nested CLI commands."""
    block = [f"  rule {op['number']}"]
    commands = [f"rule {op['number']}"]
    if op.get("description"):
        description = op["description"].replace(chr(34), chr(92) + chr(34))
        block.append(f'    description "{description}"'); commands.append(f'description "{description}"')
    for key, cli in (("protocol", "match protocol"), ("source_address", "match source-address"),
                     ("destination_address", "match destination-address"), ("source_port", "match source-port"),
                     ("destination_port", "match destination-port")):
        if op.get(key): block.append(f"    {cli} {op[key]}"); commands.append(f"{cli} {op[key]}")
    action = op["nat_action"] + (f" {op['pool']}" if op["nat_action"].endswith("pool") else f" {op['netmap']}" if op["nat_action"].endswith("netmap") else "")
    block.extend([f"    action {action}", "    enable", "  exit"])
    commands.extend([f"action {action}", "enable", "exit"])
    return block, commands


def plan_configuration_changes(config: str, operations: list[dict[str, Any]], confirm_timeout: int = 120) -> dict[str, Any]:
    """Plan targeted CRUD edits while preserving unrelated configuration blocks."""
    vlan_ops = [VlanOperation(op["action"], op["id"], op.get("name")) for op in operations if op["type"] == "vlan"]
    vlan_plan = None
    if vlan_ops:
        try:
            vlan_plan = plan_vlan_changes(config, vlan_ops, confirm_timeout)
        except ConfigurationError as exc:
            if str(exc) != "Изменений для применения нет.":
                raise
    lines = (vlan_plan["candidate"] if vlan_plan else config).replace("\r\n", "\n").replace("\r", "\n").splitlines()
    original_lines = config.replace("\r\n", "\n").replace("\r", "\n").splitlines()
    if vlan_ops:
        # Reparse the VLAN candidate so block offsets remain correct after its edits.
        base = "\n".join(lines) + "\n"
    else:
        base = config
    replacements = []
    commands = []
    object_commands = []
    warnings = list(vlan_plan["warnings"] if vlan_plan else [])
    zones = _top_blocks(base, re.compile(r"security\s+zone\s+([A-Za-z0-9_.-]+)", re.I))
    pairs = _top_blocks(base, re.compile(r"security\s+zone-pair\s+([A-Za-z0-9_.-]+)\s+([A-Za-z0-9_.-]+)(?:\s+vrf\s+([A-Za-z0-9_.-]+))?", re.I))
    object_groups = _top_blocks(base, re.compile(r"object-group\s+(network|service)\s+([A-Za-z0-9_.-]+)", re.I))
    interfaces = _top_blocks(base, re.compile(r"interface\s+(.+)", re.I))
    bridges = _top_blocks(base, re.compile(r"bridge\s+(\d+)", re.I))
    object_insert_at = min((start for start, _end in pairs.values()), default=len(lines))
    available_network_objects = {key[1] for key in object_groups if key[0] == "network"}
    available_service_objects = {key[1] for key in object_groups if key[0] == "service"}
    for op in operations:
        if op["type"] == "object_group":
            target = available_network_objects if op["object_kind"] == "network" else available_service_objects
            if op["action"] == "delete": target.discard(op["name"].lower())
            else: target.add(op["name"].lower())
    for op in operations:
        rule = op.get("rule")
        if op["type"] != "zone_pair" or op["action"] != "upsert" or not rule:
            continue
        for field in ("source_address", "destination_address"):
            value = rule.get(field)
            if value and value.lower() not in available_network_objects:
                raise ConfigurationError(f"Объект {value} из поля {field} не найден среди сетевых object-group.")
        for field in ("source_port", "destination_port"):
            value = rule.get(field)
            if value and value.lower() not in available_service_objects:
                raise ConfigurationError(f"Объект {value} из поля {field} не найден среди сервисных object-group.")
    available_nat_pools: set[tuple[str, str]] = set()
    available_nat_rulesets: set[tuple[str, str]] = set()
    for nat_type in ("source", "destination"):
        span = _section_span(lines, f"nat {nat_type}")
        if not span: continue
        for line in lines[span[0]+1:span[1]-1]:
            pool_match = re.fullmatch(r"\s+pool\s+(\S+)", line, re.I)
            set_match = re.fullmatch(r"\s+ruleset\s+(\S+)", line, re.I)
            if pool_match: available_nat_pools.add((nat_type, pool_match.group(1).lower()))
            if set_match: available_nat_rulesets.add((nat_type, set_match.group(1).lower()))
    available_nat_pools.update((op["nat_type"], op["name"].lower()) for op in operations if op["type"] == "nat_pool" and op["action"] == "upsert")
    available_nat_rulesets.update((op["nat_type"], op["name"].lower()) for op in operations if op["type"] == "nat_ruleset" and op["action"] == "upsert")
    for op in operations:
        if op["type"] != "nat_rule" or op["action"] != "upsert": continue
        if (op["nat_type"], op["ruleset"].lower()) not in available_nat_rulesets:
            raise ConfigurationError(f"NAT ruleset {op['ruleset']} ещё не создан. Сначала подготовьте и примените его.")
        for field in ("source_address", "destination_address"):
            if op.get(field) and op[field].lower() not in available_network_objects:
                raise ConfigurationError(f"Сетевой object-group {op[field]} для NAT правила не найден.")
        for field in ("source_port", "destination_port"):
            if op.get(field) and op[field].lower() not in available_service_objects:
                raise ConfigurationError(f"Сервисный object-group {op[field]} для NAT правила не найден.")
        if "pool" in op.get("nat_action", "") and (op["nat_type"], op["pool"].lower()) not in available_nat_pools:
            raise ConfigurationError(f"NAT pool {op['pool']} ещё не создан для направления {op['nat_type']}.")
    planned_zones = {key[0] for key in zones}
    planned_zone_deletes = {op["name"].lower() for op in operations if op["type"] == "zone" and op["action"] == "delete"}
    planned_zones.update(op["name"].lower() for op in operations if op["type"] == "zone" and op["action"] == "upsert")
    planned_zones.difference_update(planned_zone_deletes)
    deleted_pairs = {(op["source"].lower(), op["destination"].lower()) for op in operations
                     if op["type"] == "zone_pair" and op["action"] == "delete"}
    processed_rule_delete_pairs: set[tuple[str, str, str]] = set()
    ordered_operations = [op for op in operations if op["type"] == "object_group"] + [op for op in operations if op["type"] != "object_group"]
    priority = {"nat_ruleset": 0, "nat_pool": 1, "nat_rule": 2}
    ordered_operations.sort(key=lambda op: priority.get(op["type"], 1))
    created_nat_sections: dict[str, list[str]] = {}
    created_nat_rulesets: dict[tuple[str, str], tuple[list[str], str]] = {}
    for op in ordered_operations:
        if op["type"] == "vlan":
            continue
        kind = op["type"]
        if kind == "interface_mode":
            name, mode = op["name"], op["mode"]
            existing = interfaces.get((name.lower(),))
            if not existing: warnings.append(f"Интерфейс {name} не найден."); continue
            start, end = existing; block = lines[start:end]
            mode_rx = re.compile(r"\s*mode\s+(\S+)", re.I)
            old = next((m.group(1).lower() for line in block if (m := mode_rx.fullmatch(line))), "")
            if old == mode: warnings.append(f"Интерфейс {name} уже работает в режиме {mode}."); continue
            index = next((i for i, line in enumerate(block) if mode_rx.fullmatch(line)), None)
            if index is None: block.insert(1, f"  mode {mode}")
            else: block[index] = re.sub(r"mode\s+\S+", f"mode {mode}", block[index], flags=re.I)
            replacements.append((start, end, block)); commands.extend([f"interface {name}", f"mode {mode}", "exit"]); continue
        if kind == "bridge":
            bridge_id = op["id"]; existing = bridges.get((str(bridge_id),))
            if op["action"] == "delete":
                if not existing: warnings.append(f"Bridge {bridge_id} отсутствует."); continue
                if re.search(rf"^\s*bridge-group\s+{bridge_id}\s*$", base, re.I | re.M): raise ConfigurationError(f"Bridge {bridge_id} используется интерфейсом; сначала удалите его привязку.")
                replacements.append((*existing, [])); commands.append(f"no bridge {bridge_id}"); continue
            new = [f"bridge {bridge_id}"]
            if op.get("vlan"): new.append(f"  vlan {op['vlan']}")
            if op.get("address"): new.append(f"  ip address {op['address']}")
            if op.get("zone"): new.append(f"  security-zone {op['zone']}")
            if op.get("description"): new.append(f'  description "{op["description"].replace(chr(34), chr(92)+chr(34))}"')
            new.append("  enable" if op.get("enabled", True) else "  shutdown"); new.append("exit")
            if existing:
                start, end = existing; oldblock = lines[start:end]
                managed_rx = re.compile(r"\s*(?:vlan\s+|ip address\s+|security-zone\s+|description\s+|enable\s*$|shutdown\s*$)", re.I)
                retained = [line for line in oldblock[1:-1] if not managed_rx.match(line)]
                replacements.append((start, end, [new[0], *retained, *new[1:-1], "exit"]))
                cli = [new[0]]
                for field, value in (("vlan", op.get("vlan", "")), ("ip address", op.get("address", "")),
                                     ("security-zone", op.get("zone", "")), ("description", op.get("description", ""))):
                    old = next((m.group(1).strip().strip('"') for line in oldblock
                                if (m := re.match(rf"\s*{re.escape(field)}\s+(.+)", line, re.I))), "")
                    if old == str(value): continue
                    command_name = field
                    if old and not value: cli.append(f"no {command_name}")
                    elif value: cli.append(f'{command_name} "{value.replace(chr(34), chr(92)+chr(34))}"' if field == "description" else f"{command_name} {value}")
                cli.append("enable" if op.get("enabled", True) else "shutdown")
                cli.append("exit"); commands.extend(cli)
            else:
                replacements.append((len(lines), len(lines), new)); commands.extend([new[0], *[line.strip() for line in new[1:-1]], "exit"])
            continue
        if kind == "static_route":
            prefix, hop, vrf = op["prefix"], op["next_hop"], op["vrf"]
            route = "ip route " + (f"vrf {vrf} " if vrf != "VRF0" else "") + f"{prefix} {hop}"
            if op.get("name"): route += f" name {op['name']}"
            if op.get("distance") is not None: route += f" {op['distance']}"
            matches = [i for i, line in enumerate(lines) if re.match(r"^\s*ip route\s+", line, re.I)
                       and re.search(rf"\b{re.escape(prefix)}\s+{re.escape(hop)}(?:\s|$)", line)
                       and ((vrf == "VRF0" and not re.search(r"\bvrf\s+\S+", line, re.I)) or re.search(rf"\bvrf\s+{re.escape(vrf)}\b", line, re.I))]
            if op["action"] == "delete":
                if not matches: warnings.append(f"Маршрут {prefix} через {hop} отсутствует."); continue
                for idx in matches: replacements.append((idx, idx + 1, []))
                commands.append("no " + (f"ip route vrf {vrf} " if vrf != "VRF0" else "ip route ") + prefix)
            else:
                if len(matches) > 1: raise ConfigurationError(f"Маршрут {prefix} через {hop} найден несколько раз.")
                if matches and lines[matches[0]].strip() == route: warnings.append("Маршрут не изменился."); continue
                replacements.append((matches[0], matches[0]+1, [route]) if matches else (len(lines), len(lines), [route]))
                if matches: commands.append("no " + (f"ip route vrf {vrf} " if vrf != "VRF0" else "ip route ") + prefix)
                commands.append(route)
            continue
        if kind in {"nat_pool", "nat_ruleset", "nat_rule"}:
            nat_type = op["nat_type"]; heading = f"nat {nat_type}"; section = _section_span(lines, heading)
            staged_set = created_nat_rulesets.get((nat_type, op.get("ruleset", "").lower())) if kind == "nat_rule" else None
            if kind == "nat_rule" and op["action"] == "upsert" and staged_set is not None:
                rule_block, rule_commands = _nat_rule_block_and_commands(op)
                candidate_block, staged_name = staged_set
                set_header = f" ruleset {staged_name}"
                set_start = next((i for i, line in enumerate(candidate_block) if line.strip().lower() == set_header.strip().lower()), None)
                if set_start is None: raise ConfigurationError(f"Не удалось добавить правило в NAT ruleset {staged_name}.")
                set_end = next((i for i in range(set_start + 1, len(candidate_block)) if candidate_block[i] == " exit"), None)
                if set_end is None: raise ConfigurationError(f"Структура NAT ruleset {staged_name} повреждена.")
                candidate_block[set_end:set_end] = rule_block
                commands.extend([heading, f"ruleset {op['ruleset']}", *rule_commands, "exit", "exit"])
                continue
            if not section:
                if op["action"] == "delete": warnings.append(f"Раздел {heading} отсутствует."); continue
                if kind == "nat_rule": raise ConfigurationError("Сначала создайте NAT ruleset.")
                section_block = created_nat_sections.get(nat_type)
                if section_block is None:
                    section_block = [heading, "exit"]
                    created_nat_sections[nat_type] = section_block
                    replacements.append((len(lines), len(lines), section_block))
                if kind == "nat_pool":
                    child_block = [f" pool {op['name']}"]
                    if op.get("address"): child_block.append(f"  ip address {op['address']}")
                    if op.get("address_range"): child_block.append(f"  ip address-range {op['address_range']}")
                    if op.get("port"): child_block.append(f"  ip port {op['port']}")
                    child_block.append(" exit")
                    section_block[-1:-1] = child_block
                    commands.extend([heading, f"pool {op['name']}", *([f"ip address {op['address']}"] if op.get("address") else []), *([f"ip address-range {op['address_range']}"] if op.get("address_range") else []), *([f"ip port {op['port']}"] if op.get("port") else []), "exit", "exit"])
                    continue
                child_block = [f" ruleset {op['name']}"]
                if op.get("interface"): child_block.append(f"  from interface {op['interface']}")
                if op.get("to_zone"): child_block.append(f"  to zone {op['to_zone']}")
                if op.get("description"): child_block.append(f'  description "{op["description"].replace(chr(34), chr(92)+chr(34))}"')
                child_block.append(" exit")
                section_block[-1:-1] = child_block
                created_nat_rulesets[(nat_type, op["name"].lower())] = (section_block, op["name"])
                commands.extend([heading, f"ruleset {op['name']}", *([f"from interface {op['interface']}"] if op.get("interface") else []), *([f"to zone {op['to_zone']}"] if op.get("to_zone") else []), *([f'description "{op["description"].replace(chr(34), chr(92)+chr(34))}"'] if op.get("description") else []), "exit", "exit"])
                continue
            child_type = "pool" if kind == "nat_pool" else "ruleset"
            child = _child_span(lines, section, re.compile(rf"{child_type}\s+{re.escape(op['name'] if kind != 'nat_rule' else op['ruleset'])}", re.I)) if kind != "nat_rule" else _child_span(lines, _child_span(lines, section, re.compile(rf"ruleset\s+{re.escape(op['ruleset'])}", re.I)) or section, re.compile(rf"rule\s+{op['number']}", re.I))
            target_name = op["name"] if kind != "nat_rule" else str(op["number"])
            if op["action"] == "delete":
                if not child: warnings.append(f"{child_type} {target_name} отсутствует."); continue
                if kind == "nat_pool" and re.search(rf"\b(?:action\s+(?:destination|source)-nat\s+pool|pool\s+){re.escape(op['name'])}\b", base, re.I):
                    references = [line.strip() for line in lines if re.search(rf"\b{re.escape(op['name'])}\b", line, re.I) and not re.match(r"\s*pool\s+", line, re.I)]
                    if references: raise ConfigurationError(f"NAT pool {op['name']} используется правилом: {references[0]}")
                replacements.append((*child, [])); commands.extend([heading, f"ruleset {op['ruleset']}" if kind == "nat_rule" else f"no {child_type} {target_name}", f"no rule {op['number']}" if kind == "nat_rule" else "exit", "exit"] if kind == "nat_rule" else [heading, f"no {child_type} {target_name}", "exit"]); continue
            if kind == "nat_pool":
                block = [f" pool {op['name']}"]
                if op.get("address"): block.append(f"  ip address {op['address']}")
                if op.get("address_range"): block.append(f"  ip address-range {op['address_range']}")
                if op.get("port"): block.append(f"  ip port {op['port']}")
                block.append(" exit")
                command = [heading, f"pool {op['name']}"]
                if child:
                    old_pool = lines[child[0]:child[1]]
                    if any(re.match(r"\s*ip address\s+", x, re.I) for x in old_pool): command.append("no ip address")
                    if any(re.match(r"\s*ip address-range\s+", x, re.I) for x in old_pool): command.append("no ip address-range")
                    if any(re.match(r"\s*ip port\s+", x, re.I) for x in old_pool): command.append("no ip port")
                command.extend([*[x.strip() for x in block[1:-1]], "exit", "exit"])
            elif kind == "nat_ruleset":
                block = [f" ruleset {op['name']}"]
                if op.get("interface"): block.append(f"  from interface {op['interface']}")
                if op.get("to_zone"): block.append(f"  to zone {op['to_zone']}")
                if op.get("description"): block.append(f'  description "{op["description"].replace(chr(34), chr(92)+chr(34))}"')
                block.append(" exit")
                command = [heading, f"ruleset {op['name']}"]
                if child:
                    old_set = lines[child[0]:child[1]]
                    for cmd, pattern in (("from interface", r"\s*from interface\s+"), ("to zone", r"\s*to zone\s+"), ("description", r"\s*description\s+")):
                        if any(re.match(pattern, x, re.I) for x in old_set) and not any(re.match(pattern, x, re.I) for x in block): command.append("no " + cmd)
                command.extend([*[x.strip() for x in block[1:-1]], "exit", "exit"])
                if child:
                    old_set = lines[child[0]:child[1]]
                    managed = re.compile(r"\s*(?:from interface\s+|to zone\s+|description\s+)", re.I)
                    preserved = [x for x in old_set[1:-1] if not managed.match(x)]
                    block = [block[0], *preserved, *block[1:-1], " exit"]
            else:
                block = [f"  rule {op['number']}"]
                if op.get("description"): block.append(f'    description "{op["description"].replace(chr(34), chr(92)+chr(34))}"')
                if op.get("protocol"): block.append(f"    match protocol {op['protocol']}")
                if op.get("source_address"): block.append(f"    match source-address {op['source_address']}")
                if op.get("destination_address"): block.append(f"    match destination-address {op['destination_address']}")
                if op.get("destination_port"): block.append(f"    match destination-port {op['destination_port']}")
                if op.get("source_port"): block.append(f"    match source-port {op['source_port']}")
                action = op["nat_action"] + (f" {op['pool']}" if op["nat_action"].endswith("pool") else f" {op['netmap']}" if op["nat_action"].endswith("netmap") else "")
                block.extend([f"    action {action}", "    enable", "  exit"])
                command = [heading, f"ruleset {op['ruleset']}", f"rule {op['number']}", *[x.strip() for x in block[1:-1]], "exit", "exit", "exit"]
                if child:
                    old_rule = lines[child[0]:child[1]]
                    cli = [heading, f"ruleset {op['ruleset']}", f"rule {op['number']}"]
                    for cmd, pattern in (("description", r"\s*description\s+"), ("match protocol", r"\s*match protocol\s+"), ("match source-address", r"\s*match source-address\s+"), ("match destination-address", r"\s*match destination-address\s+"), ("match source-port", r"\s*match source-port\s+"), ("match destination-port", r"\s*match destination-port\s+")):
                        if any(re.match(pattern, x, re.I) for x in old_rule): cli.append("no " + cmd)
                    cli.extend([*[x.strip() for x in block[1:-1]], "exit", "exit", "exit"]); command = cli
                    managed = re.compile(r"\s*(?:description\s+|match\s+(?:protocol|source-address|destination-address|source-port|destination-port)\s+|action\s+|enable\s*$)", re.I)
                    preserved = [x for x in old_rule[1:-1] if not managed.match(x)]
                    block = [block[0], *preserved, *block[1:-1], "  exit"]
            if kind == "nat_ruleset" and not child:
                created_nat_rulesets[(nat_type, op["name"].lower())] = (block, op["name"])
            if child: replacements.append((*child, block))
            else:
                if kind == "nat_rule":
                    ruleset_span = _child_span(lines, section, re.compile(rf"ruleset\s+{re.escape(op['ruleset'])}", re.I))
                    if not ruleset_span: raise ConfigurationError(f"NAT ruleset {op['ruleset']} отсутствует; создайте его сначала.")
                    insert = ruleset_span[1]-1; replacements.append((insert, insert, block))
                else: replacements.append((section[1]-1, section[1]-1, block))
            commands.extend(command)
            continue
        if kind == "subinterface":
            name = op["name"]
            key = (name.lower(),)
            existing = interfaces.get(key)
            if op["action"] == "delete":
                if not existing:
                    warnings.append(f"Саб-интерфейс {name} отсутствует и будет пропущен.")
                    continue
                replacements.append((*existing, []))
                commands.append(f"no interface {name}")
                continue
            address, description = op.get("address", ""), op.get("description", "")
            zone, vrf = op.get("zone", ""), op.get("vrf", "VRF0")
            new = [f"interface {name}"]
            if description: new.append(f'  description "{description.replace(chr(34), chr(92)+chr(34))}"')
            if vrf != "VRF0": new.append(f"  ip vrf forwarding {vrf}")
            if address: new.append(f"  ip address {address}")
            if zone: new.append(f"  security-zone {zone}")
            new.append("exit")
            if existing:
                start, end = existing
                old_block = lines[start:end]
                def field_value(pattern):
                    return next((m.group(1).strip().strip('"') for line in old_block if (m := re.match(pattern, line, re.I))), "")
                old_address = field_value(r"\s*ip address\s+(.+)")
                old_description = field_value(r"\s*description\s+(.+)")
                old_zone = field_value(r"\s*security-zone\s+(\S+)")
                old_vrf = field_value(r"\s*ip vrf forwarding\s+(\S+)") or "VRF0"
                managed = re.compile(r"\s*(?:description\s+|ip address\s+|ip vrf forwarding\s+|security-zone\s+)", re.I)
                retained = [line for line in old_block[1:-1] if not managed.match(line)]
                candidate = [new[0], *retained, *new[1:-1], "exit"]
                if (old_address, old_description, old_zone, old_vrf) == (address, description, zone, vrf):
                    warnings.append(f"Саб-интерфейс {name} не изменился.")
                    continue
                replacements.append((start, end, candidate))
                cli = [f"interface {name}"]
                if old_description and not description: cli.append("no description")
                elif description != old_description: cli.append(f'description "{description.replace(chr(34), chr(92)+chr(34))}"')
                if old_vrf != vrf: cli.append("no ip vrf forwarding" if vrf == "VRF0" else f"ip vrf forwarding {vrf}")
                if old_address != address: cli.append("no ip address" if not address else f"ip address {address}")
                if old_zone != zone: cli.append("no security-zone" if not zone else f"security-zone {zone}")
                commands.extend([*cli, "exit"])
            else:
                replacements.append((len(lines), len(lines), new))
                commands.extend([new[0], *[line.strip() for line in new[1:-1]], "exit"])
            continue
        if kind == "hostname":
            matches = [i for i, line in enumerate(lines) if re.fullmatch(r"\s*hostname\s+\S+\s*", line, re.I)]
            if len(matches) > 1:
                raise ConfigurationError("В running-config несколько настроек hostname; изменение отменено.")
            if matches and lines[matches[0]].strip().split(None, 1)[1] == op["name"]:
                warnings.append("Hostname ESR уже задан; изменений нет.")
                continue
            hostname_line = f"hostname {op['name']}"
            if matches:
                replacements.append((matches[0], matches[0] + 1, [hostname_line]))
            else:
                replacements.append((0, 0, [hostname_line]))
            commands.append(hostname_line)
            continue
        if kind == "object_group":
            object_kind, name = op["object_kind"], op["name"]
            key = (object_kind.lower(), name.lower())
            existing = object_groups.get(key)
            if op["action"] == "delete":
                if not existing:
                    warnings.append(f"Object-group {object_kind} {name} отсутствует и будет пропущен.")
                    continue
                start, end = existing
                token = re.compile(rf"(?<![A-Za-z0-9_.-]){re.escape(name)}(?![A-Za-z0-9_.-])", re.I)
                references = [line.strip() for i, line in enumerate(lines) if token.search(line)
                              and not (start <= i < end) and not line.strip().lower().startswith("no object-group ")]
                if references:
                    raise ConfigurationError(f"Object-group {name} используется в конфигурации; сначала удалите ссылки: {references[0]}")
                replacements.append((start, end, []))
                object_commands.append(f"no object-group {object_kind} {name}")
                continue
            new_block = [f"object-group {object_kind} {name}"]
            if op.get("description"):
                escaped_description = op["description"].replace('"', '\\"')
                new_block.append(f'  description "{escaped_description}"')
            new_block.extend(f"  {entry}" for entry in op["entries"])
            new_block.append("exit")
            if existing:
                start, end = existing
                old_block = lines[start:end]
                old_description = next((line.strip().split(None, 1)[1].strip().strip('"') for line in old_block
                                        if re.match(r"\s*description\s+", line, re.I)), "")
                old_entries = [line.strip() for line in old_block if re.match(r"\s*(?:ip prefix|ip address-range|port-range)\s+", line, re.I)]
                new_entries = op["entries"]
                if old_description == op.get("description", "") and old_entries == new_entries:
                    warnings.append(f"Object-group {object_kind} {name} не изменилась.")
                    continue
                replacements.append((start, end, new_block))
                cli_block = [f"object-group {object_kind} {name}"]
                if old_description and not op.get("description"):
                    cli_block.append("no description")
                elif op.get("description") != old_description:
                    cli_block.append(f'description "{op["description"].replace(chr(34), chr(92)+chr(34))}"')
                cli_block.extend(f"no {entry}" for entry in old_entries if entry not in new_entries)
                cli_block.extend(entry for entry in new_entries if entry not in old_entries)
                cli_block.append("exit")
                object_commands.extend(cli_block)
            else:
                replacements.append((object_insert_at, object_insert_at, new_block))
                object_commands.extend([new_block[0], *op["entries"], "exit"])
            continue
        if kind == "zone":
            name = op["name"]
            key = (name.lower(),)
            existing = zones.get(key)
            if op["action"] == "delete":
                if re.search(rf"^\s*security-zone\s+{re.escape(name)}\s*$", base, re.I | re.M):
                    raise ConfigurationError(f"Зона {name} назначена интерфейсу; сначала измените его привязку.")
                if any(name.lower() in k[:2] and k[:2] not in deleted_pairs for k in pairs):
                    raise ConfigurationError(f"Зона {name} используется zone-pair; сначала удалите связанные zone-pair.")
                if not existing:
                    warnings.append(f"Security zone {name} отсутствует и будет пропущена.")
                    continue
                replacements.append((*existing, [])); commands.append(f"no security zone {name}")
            else:
                new = [f"security zone {name}"]
                if op.get("description"):
                    desc = op["description"].replace('"', '\\"')
                    new.append(f'  description "{desc}"')
                if op.get("vrf", "VRF0") != "VRF0":
                    new.append(f"  ip vrf forwarding {op['vrf']}")
                new.append("exit")
                if existing:
                    old_block = lines[existing[0]:existing[1]]
                    old = "\n".join(old_block)
                    if old == "\n".join(new):
                        warnings.append(f"Security zone {name} не изменилась."); continue
                    replacements.append((*existing, new))
                    cli_block = [f"security zone {name}"]
                    old_has_description = any(re.match(r"\s*description\s+", line, re.I) for line in old_block)
                    old_has_vrf = any(re.match(r"\s*ip\s+vrf\s+forwarding\s+", line, re.I) for line in old_block)
                    if old_has_description and not op.get("description"):
                        cli_block.append("no description")
                    if old_has_vrf and op.get("vrf", "VRF0") == "VRF0":
                        cli_block.append("no ip vrf forwarding")
                    cli_block.extend(line.strip() for line in new[1:-1])
                    cli_block.append("exit")
                    commands.extend(cli_block)
                else:
                    replacements.append((len(lines), len(lines), new))
                    commands.extend(new)
        elif kind == "zone_pair_rule":
            source, dest, vrf = op["source"], op["destination"], op.get("vrf", "VRF0")
            pair_id = (source.lower(), dest.lower(), vrf.lower())
            if pair_id in processed_rule_delete_pairs:
                continue
            processed_rule_delete_pairs.add(pair_id)
            key = (source.lower(), dest.lower(), vrf.lower()) if vrf != "VRF0" else (source.lower(), dest.lower(), "")
            existing = pairs.get(key)
            if not existing:
                warnings.append(f"Zone-pair {source} → {dest} отсутствует; правила пропущены.")
                continue
            start, end = existing
            block = lines[start:end]
            selected = [candidate for candidate in operations
                        if candidate["type"] == "zone_pair_rule"
                        and candidate["source"].lower() == source.lower()
                        and candidate["destination"].lower() == dest.lower()
                        and candidate.get("vrf", "VRF0").lower() == vrf.lower()]
            removed_numbers: list[int] = []
            rule_spans: list[tuple[int, int, int]] = []
            for candidate in selected:
                number = candidate["number"]
                match = next((i for i, line in enumerate(block)
                              if re.fullmatch(rf"\s+rule\s+{number}", line, re.I)), None)
                if match is None:
                    warnings.append(f"Правило {number} в zone-pair {source} → {dest} отсутствует и будет пропущено.")
                    continue
                finish = next((j + 1 for j in range(match + 1, len(block))
                               if block[j].strip().lower() == "exit" and block[j][:1].isspace()), match + 1)
                rule_spans.append((match, finish, number))
            for rule_start, rule_end, number in sorted(rule_spans, reverse=True):
                del block[rule_start:rule_end]
                removed_numbers.append(number)
            if removed_numbers:
                replacements.append((start, end, block))
                header = f"security zone-pair {source} {dest}" + (f" vrf {vrf}" if vrf != "VRF0" else "")
                commands.extend([header, *(f"no rule {number}" for number in sorted(removed_numbers)), "exit"])
        else:
            source, dest, vrf = op["source"], op["destination"], op.get("vrf", "VRF0")
            key = (source.lower(), dest.lower(), vrf.lower()) if vrf != "VRF0" else (source.lower(), dest.lower(), "")
            existing = pairs.get(key)
            if op["action"] == "delete":
                if not existing:
                    warnings.append(f"Zone-pair {source} → {dest} отсутствует и будет пропущен."); continue
                replacements.append((*existing, [])); commands.append(f"no security zone-pair {source} {dest}" + (f" vrf {vrf}" if vrf != "VRF0" else ""))
            elif not existing:
                if source.lower() not in planned_zones or dest.lower() not in planned_zones:
                    raise ConfigurationError("Перед созданием zone-pair добавьте обе Security zone.")
                header = f"security zone-pair {source} {dest}" + (f" vrf {vrf}" if vrf != "VRF0" else "")
                new = [header]
                if op.get("rule"):
                    rule = op["rule"]; new += [f"  rule {rule['number']}"]
                    if rule.get("description"): new.append(f'    description "{rule["description"].replace(chr(34), chr(92)+chr(34))}"')
                    new += [f"    action {rule['action']}", f"    match protocol {rule['protocol']}"]
                    for field, command in (("source_address", "match source-address"), ("destination_address", "match destination-address"), ("source_port", "match source-port"), ("destination_port", "match destination-port")):
                        if rule.get(field): new.append(f"    {command} {rule[field]}")
                    new += ["    enable", "  exit"]
                new.append("exit"); replacements.append((len(lines), len(lines), new)); commands.extend(new)
            elif op.get("rule"):
                # Keep existing rules and replace only the selected number.
                start, end = existing
                block = lines[start:end]
                rule = op["rule"]; number = rule["number"]
                match = next((i for i, line in enumerate(block) if re.fullmatch(rf"\s+rule\s+{number}", line, re.I)), None)
                replacement = [f"  rule {number}"]
                if rule.get("description"): replacement.append(f'    description "{rule["description"].replace(chr(34), chr(92)+chr(34))}"')
                replacement += [f"    action {rule['action']}", "  exit"]
                if match is not None:
                    finish = next((j+1 for j in range(match+1, len(block)) if block[j].strip().lower()=="exit" and block[j][:1].isspace()), match+1)
                    old_rule = block[match:finish]
                    # Updating action/protocol/description must not discard address,
                    # port, or other supported match criteria already in the rule.
                    managed_matches = {"source_address": r"match\s+(?:not\s+)?source-address\s+", "destination_address": r"match\s+(?:not\s+)?destination-address\s+", "source_port": r"match\s+(?:not\s+)?source-port\s+", "destination_port": r"match\s+(?:not\s+)?destination-port\s+"}
                    managed_rx = [re.compile(rf"\s*{managed_matches[field]}", re.I) for field in managed_matches if rule.get(field) is not None]
                    retained = [line for line in old_rule[1:-1]
                                if not re.match(r"\s*(?:description\s+|action\s+|match\s+(?:not\s+)?protocol\s+|enable\s*$)", line, re.I)
                                and not any(rx.match(line) for rx in managed_rx)]
                    new_rule = [replacement[0], *replacement[1:-2], *retained,
                                f"    action {rule['action']}", f"    match protocol {rule['protocol']}"]
                    for field, command in (("source_address", "match source-address"), ("destination_address", "match destination-address"), ("source_port", "match source-port"), ("destination_port", "match destination-port")):
                        if rule.get(field): new_rule.append(f"    {command} {rule[field]}")
                    new_rule += ["    enable", "  exit"]
                    block[match:finish] = new_rule
                else:
                    rule_lines = [*replacement[:-1], f"    match protocol {rule['protocol']}"]
                    for field, command in (("source_address", "match source-address"), ("destination_address", "match destination-address"), ("source_port", "match source-port"), ("destination_port", "match destination-port")):
                        if rule.get(field): rule_lines.append(f"    {command} {rule[field]}")
                    block[-1:-1] = [*rule_lines, "    enable", "  exit"]
                replacements.append((start, end, block))
                rule_commands = [f"security zone-pair {source} {dest}" + (f" vrf {vrf}" if vrf != "VRF0" else ""),
                                 f"rule {number}",
                                 *( [f'description "{rule["description"].replace(chr(34), chr(92)+chr(34))}"'] if rule.get("description") else ["no description"] ),
                                 f"action {rule['action']}", f"match protocol {rule['protocol']}"]
                for field, command in (("source_address", "match source-address"), ("destination_address", "match destination-address"), ("source_port", "match source-port"), ("destination_port", "match destination-port")):
                    if rule.get(field): rule_commands.append(f"{command} {rule[field]}")
                rule_commands.extend(["enable", "exit", "exit"])
                commands.extend(rule_commands)
            else:
                warnings.append(f"Zone-pair {source} → {dest} уже существует; изменений нет.")
    for start, end, replacement in (item[1] for item in sorted(enumerate(replacements), key=lambda item: (item[1][0], item[0]), reverse=True)):
        if start == len(lines) and end == len(lines):
            if lines and lines[-1].strip(): lines.append("")
            lines.extend(replacement)
        else:
            lines[start:end] = replacement
    if vlan_ops and vlan_plan:
        # Create/update object groups before rules that may reference them.
        commands = vlan_plan["change_commands"] + object_commands + commands
    else:
        commands = object_commands + commands
    if not commands:
        raise ConfigurationError("Изменений для применения нет.")
    timer = f"system config-confirm timeout {confirm_timeout}"
    timer_re = re.compile(r"^\s*system\s+config-confirm\s+timeout\s+\d+\s*$", re.I)
    timer_indices = [i for i, line in enumerate(lines) if timer_re.fullmatch(line)]
    if len(timer_indices) > 1: raise ConfigurationError("В running-config несколько настроек таймера confirm.")
    if timer_indices: lines[timer_indices[0]] = timer
    else:
        if lines and lines[-1].strip(): lines.append("")
        lines.append(timer)
    candidate = "\n".join(lines).rstrip()+"\n"
    diff = "".join(difflib.unified_diff(config.replace("\r\n", "\n").replace("\r", "\n").splitlines(keepends=True), candidate.splitlines(keepends=True), fromfile="running-config", tofile="предполагаемая-конфигурация"))
    return {"commands": ["configure terminal", timer, *commands, "end", "commit"], "change_commands": commands,
            "candidate": candidate, "diff": diff, "warnings": warnings, "changed": bool(diff)}

