## v147 — Отложенный выбор новых NAT pools
- NAT rule editor now includes staged NAT pools before device commit; NAT pool changes and dependent rules can be prepared together and applied in one commit.

## v146 — Выбор исходящего интерфейса в NAT ruleset

- Поле «Исходящий интерфейс» в форме NAT ruleset заменено выпадающим списком интерфейсов из текущей конфигурации ESR.
- При редактировании существующего ruleset ранее выбранный интерфейс сохраняется; если его уже нет в текущей конфигурации, он явно помечается как отсутствующий, чтобы случайно не очистить значение.

## v145 — Доработки списка интерфейсов и NAT

- Интерфейсы сортируются естественно по номеру, саб-интерфейс располагается после родительского порта.
- В NAT ruleset целевая зона выбирается из существующих зон, включая `any`; для NAT-правила ruleset и NAT pool доступны из текущей конфигурации и неотправленных изменений.
- Разрешено создавать несколько объектов в ещё отсутствующем разделе NAT за один Commit; правило можно добавить к новому ruleset до его применения.
- Удалена избыточная подсказка под заголовком NAT.

## v144 — Сбор интерфейсов ESR

- Добавлен сбор `show interfaces description`, чтобы показывать порты и bridge, отсутствующие в `show running-config`.

## v143 — Исправление кнопок маршрутов и NAT

- Кнопки изменения, удаления и отмены для статических маршрутов, NAT pools, rulesets и правил NAT теперь отображаются как кнопки и обрабатывают нажатия.

## v142 — Список интерфейсов из оперативного состояния ESR

- При сборе конфигурации дополнительно запрашивается `show interfaces description`. Состояние портов и bridge сохраняется со снимком и объединяется с running-config, чтобы интерфейсы, отсутствующие в `show running-config`, оставались в списке.
- Для порта, найденного только в выводе интерфейсов, отображается режим `routerport`, соответствующий режиму ESR по умолчанию.

## v141 — Исправление кнопки режима интерфейса

- Исправлен вывод действий в таблице интерфейсов: кнопки переключения физических портов между `routerport` и `switchport` отображаются как кнопки, а не как текст HTML.

## v140 — Управление интерфейсами, NAT и статическими маршрутами

- Добавлено переключение физических/агрегированных портов между `routerport` и `switchport`. При создании саб-интерфейса порт, выбранный в `switchport`, автоматически переводится в `routerport` в том же плане Commit-confirm.
- Кнопка «Создать интерфейс» позволяет выбрать саб-интерфейс или bridge-интерфейс. Для bridge доступны VLAN, IPv4-адрес, Security zone и описание; существующие bridge можно изменять и удалять.
- Добавлены создание, изменение и удаление статических IPv4-маршрутов с выбором VRF, next-hop, distance и имени.
- Добавлены создание, изменение и удаление NAT pools, rulesets и правил Source/Destination NAT. NAT-фильтры используют существующие сетевые и сервисные object-group; перед изменением показываются CLI и diff.
- Команды режима порта и статического маршрута сверены с руководством Eltex ESR CLI. Работа на физическом ESR не проверялась.

## v139 — Саб-интерфейсы и подсказка для object-group

- Добавлена памятка: в именах сетевых и сервисных объектов нельзя использовать дефис `-`; используйте подчёркивание `_`. Ограничение проверяется и интерфейсом, и серверным планировщиком.
- Добавлено создание, изменение и удаление саб-интерфейсов. Настройки адреса IPv4, VRF, Security zone и описания проходят общий предварительный просмотр CLI-команд и diff перед Commit-confirm.
- Парсер теперь отдельно отмечает саб-интерфейсы по суффиксу VLAN.
- NAT пока остаётся доступным для просмотра; его управление будет следующим этапом после уточнения и проверки поддерживаемых ESR-команд для пулов, ruleset и правил.

## v138 — Сохранение ссылок правила при создании нескольких объектов

- Исправил потерю ранее выбранного объекта, когда при заполнении одного правила подряд создаются несколько object-group. После каждого создания остальные выбранные сетевые/сервисные объекты сохраняются в форме.
- Если предпросмотр Commit устарел или токен отсутствует, интерфейс теперь показывает сообщение с действием вместо молчаливого выхода.
- Добавил проверку правила, использующего одновременно вновь созданные сетевой и сервисный объекты; проверяется порядок объектов перед правилом.

## v137 — Состояние Commit/Confirm и состав object-group

- Восстановил статус в заголовке ESR после успешного Commit: до Commit показывается «Есть неотправленная конфигурация», между Commit и Confirm — «Есть не примененная конфигурация».
- Заменил ручной ввод CLI-состава объектов на строки формы: для сетевых объектов выбирается `ip prefix` или `ip address-range`, для сервисных вводятся порты, а команда `port-range` добавляется автоматически.
- Исправил формат match-команд для ESR 1.14.x: ссылки на сетевые и сервисные object-group передаются по имени без синтаксиса `object-group network` новых версий.
- Гарантировал порядок создания новых object-group перед правилами и согласовал с этим порядок блоков в diff-кандидате.
- Добавил регрессионные тесты уведомления, новых полей состава, match-ссылок и порядка object-group/правил.

## v136 — Объекты ESR в правилах и автообновление после отката

- Исправил отображение пустого статуса Security zone, которое могло выводиться как `[object Object]`; колонка теперь называется «Изменения».
- В редактор правил zone-pair добавлены выбор сетевых объектов для источника/назначения и сервисных объектов для портов источника/назначения.
- Добавил в разделе «Объекты и ACL» подготовку, изменение и удаление сетевых и сервисных object-group. Новый объект можно создать из списка выбора прямо в редакторе правила.
- Планировщик формирует команды ESR для `ip prefix`, `ip address-range`, `port-range` и match-ссылок; перед удалением проверяет, что объект не используется.
- Когда таймер commit-confirm истекает и ESR сообщает об откате, интерфейс повторно собирает `running-config` и обновляет снимок.
- Добавил проверки планирования object-group, match-условий, парсинга ссылок объектов, отображения зон и обновления после rollback.

## v135 — Упрощение ESR-разделов и hostname

- Переместил «Дашборд» на первое место в меню ESR и переименовал бывший раздел «Конфигурация».
- Убрал общий список неподтверждённых операций с кнопками исправления и удаления. В заголовке оставлена короткая отметка «Есть не отправленная конфигурация»; после успешного Commit она исчезает, а изменения остаются в списках самих объектов до Confirm.
- Добавил подготовку hostname устройства через общий Commit/Confirm.
- Разместил hostname и таймер подтверждения в двух компактных плитках рядом; на узких экранах они складываются в одну колонку.
- Добавил проверки планирования hostname и расположения/состояния элементов интерфейса.

## v134 — Zone-pair rule deletion and ESR settings sections

- Added staged deletion of an individual zone-pair rule. The plan uses ESR's supported `no rule <ORDER>` command inside the selected zone-pair and preserves its other rules.
- Zone-pair headers now show the source and destination zone VRFs separately, such as `VRF1 → VRF0`.
- Moved the commit-confirm timeout setting from general Administration into the first ESR sidebar section, “Основные настройки”. Added an “Учетные записи” placeholder section for later work.
- Added regression coverage for single and multiple rule deletions, menu/settings placement, and the new UI actions.

## v133 — Highlight staged ESR changes

- Added a persistent pending-changes panel with amber status labels and per-item edit/remove actions before Commit.
- Staged VLANs, zones, zone-pairs, and zone-pair rules now appear in their respective lists with a clear “Не применено” marker; staged deletions are marked separately.
- Added direct editing for staged VLANs, zones, zone-pairs, and rules, and made rules added to a new staged zone-pair stay attached to that pending pair.
- Added static regression checks for pending-state and edit controls.

## v132 — ESR selection refresh and clearer VLAN diff

- Selecting an ESR now triggers an SSH collection of its current `running-config`; removed the manual collect button. The registry refresh does not recollect repeatedly for an unchanged selection.
- The commit preview now explains that a unified diff shows textual configuration representation (for example, shrinking `vlan 2,224`), while the actual deletion command sent to ESR is `no vlan 224`.
- Clicking Confirm immediately stops the local countdown and suppresses background status polling during the confirmation request, preventing the timer display from continuing while Confirm is processed.
- Added regression coverage for the revised UI wiring.

## v131 — Refresh after Confirm and delete VLANs by ID

- After a successful ESR `confirm`, the UI now collects a fresh `running-config` and reloads the parsed configuration so confirmed changes appear immediately. If collection fails, the UI reports that separately from the successful confirm.
- VLAN deletion now emits `no vlan <VID>` for either an unnamed VLAN from a comma-separated declaration or a named standalone VLAN block, and updates the preview candidate accordingly.
- Added regression coverage for both VLAN representations and the post-confirm collection wiring.

## v130 — Merge ESR VLAN declarations in the UI

- Fixed VLAN display when ESR reports unnamed IDs in a comma-separated declaration and named VLANs in individual blocks. The parser now merges both forms into one row and applies the explicit name without duplicating or hiding the VLAN.
- Added a regression test for `vlan 2,23` plus the individual `vlan 23` named block.

## v129 — VLAN list member configuration

- Fixed VLAN planning for explicit top-level lists such as `vlan 2,23`. A listed VLAN can now be configured individually with its own `vlan <VID>` block, while true interval declarations such as `vlan 20-30` remain protected.
- Deleting a VLAN that is still present in a top-level list now returns a specific instruction to edit that declaration, rather than treating it as missing.
- Added regression coverage for individual updates and guarded deletes from explicit VLAN lists.

## v128 — ESR SSH input handling fix

- Fixed the preview failure found in the server traceback: ordinary `show running-config` subprocess calls now use `stdin=DEVNULL`; only configuration-plan calls receive JSON through `input`. This avoids passing an integer sentinel to `subprocess.run(input=...)` and failing before SSH starts.
- Added regression guards for the separate stdin/input paths.

## v127 — VLAN-only Commit preview fix

- Fixed the generic ESR planner to add generated VLAN commands before checking whether a configuration plan contains changes. VLAN-only create/update/delete operations now reach the Commit preview, while true no-op requests remain rejected.
- Added regression coverage for changing VLAN 23's name through the same generic planner used by the preview API.

## v126 — API response parsing and ESR header cleanup

- Read each API response body once, then parse that text as JSON when possible. Plain-text or HTML error responses now produce a readable message instead of a consumed-body error.
- Removed the initial device-selection message from the Commit/Confirm area and removed the stale v121 caption and explanatory ESR subtitle.

## v125 — visible ESR commit workflow

- Positioned the pending-change notice beside Commit and Confirm and moved ESR operation status out of the hidden Configuration pane so preview/apply errors remain visible from every ESR subsection.
- Kept Confirm visible beside Commit and disabled it until the device reports a confirmable pending change; it becomes available after commit and returns to disabled after confirmation/rollback.
- Hardened the first Commit action to open the command-and-diff dialog, with a modeless fallback if the browser cannot open a native dialog.

## v123 — zone dialogs and protocol-aware rules

- Added dedicated dialogs for creating Security zones and zone-pairs. VRF, source zone, and destination zone are selectable from the current ESR configuration; newly queued zones also appear in pair selectors.
- Added per-zone-pair “Добавить правило” and rule edit controls. Rule forms include permit/deny, description, and an explicit protocol selector from the ESR CLI protocol set; generated candidate config and SSH commands include `match protocol` and preserve other match criteria in edited rules.

## v122 — ESR workspace layout correction

- Kept every ESR content pane inside the shared `.esr-content` workspace container. This removes the empty center panel and restores the selected pane directly beside the left navigation.
- No configuration behavior or other product features changed.

## v121 — ESR VLAN configuration with native commit-confirm

- Added create/update/delete operations for VLANs and Security zones, plus create/delete zone-pairs and targeted zone-pair rule updates. Zone deletion is refused while an interface or zone-pair references it; rule edits retain other rules in that pair. VLANs in shared range declarations are left untouched and VLAN deletion is refused while interfaces or bridges reference it.
- Moved VLAN controls into the VLAN pane and zone/zone-pair controls into the zones pane. A small “Примените настройки” notice appears when local changes are queued. The top-right Commit button opens a command and diff preview; the second Commit in that dialog applies it. Confirm remains beside the heading.
- Preview displays generated CLI commands and a unified running-config diff before applying.
- Preview is based on a fresh SSH `show running-config`; apply fetches it again and rejects stale previews. Commands are scoped to the selected ESR-200 and use the existing approved SSH host-key database.
- Applies candidate changes over SSH, sets the ESR confirmation timer from the application setting (default 120 seconds), and issues native `commit`. The UI shows a countdown and exposes a manual `confirm` action; after confirmation, `save` persists the candidate.
- ESR performs its own automatic rollback on timeout. The app only reports rollback after reconnecting and verifying the running-config matches the pre-change snapshot. SSH loss or an ambiguous CLI response is shown as unknown and never as successful.
- Added regression tests for VLAN command planning, diff generation, input validation and stopping command execution after a CLI rejection. No operation-history or backup subsystem was added; no topology changes were made.

## v120 — separate VLAN inventory and clickable Security Zones

- Added a dedicated **VLAN'ы** pane to ESR administration; removed the long VLAN-name enumeration from the Interfaces pane.
- The VLAN inventory shows VLAN ID and name, plus expandable lists of bridge interfaces, physical ports using the VLAN as PVID, and ports where it is allowed (including ranges).
- Security Zone names in the Security zones table are now clickable and open the same detail disclosure used by interface references, including VRF, description, interface count and zone-pairs.
- ESR administration remains read-only; no configuration-changing commands were added.

## v119 — compact expandable object dependencies

- Security Zone details now show an interface count; clicking the count expands the exact interface names. Zone-pair references use the same compact disclosure.
- Route-map / PBR details show the number of interfaces using the policy, with the exact interface list collapsed by default.
- NAT pools, ACLs, and network/service objects show usage counts with expandable references instead of long always-visible lists.
- Objects without references explicitly show «Не используется».
- No device configuration commands or write operations were added; ESR administration remains read-only.

## v118 — automatic ESR registry and object relationships
- Removed the manual “Обновить” button from ESR administration. The device list is loaded when the section opens and refreshed automatically every 15 seconds while the section is active; visibility restoration also triggers a refresh. Selection is retained where possible, and the saved configuration is reloaded only when the selected device or registry entry changes.
- Added a normalized, typed dependency graph to parsed ESR data for interface-to-zone, interface-to-PBR, interface-to-VRRP, bridge-to-VLAN, zone-pair-to-zone, NAT-rule-to-pool and route-to-VRF relationships. This is read-only metadata and does not generate or apply commands.
- Expanded object drill-down: Security Zone references show VRF, description, attached interfaces and related zone-pairs; PBR shows interfaces using the policy; NAT pools show referencing rules; network/service objects retain their “Где используется” information.
- Kept the existing read-only boundary: no edit, command generation, commit or confirm functionality was introduced.

## v117 — ESR1000 bridge/VLAN support and running-config echo cleanup
- Fixed the leading terminal echo/prompt debris that could appear before the first line of the raw `running-config`. The ESR CLI collector now strips non-configuration preamble before storing the snapshot and uses a `dumb` terminal type to avoid VT100 redraw artifacts.
- Extended the ESR parser to recognize logical `bridge` interfaces, their VLAN association, IP address, security zone and enabled state.
- Added VLAN inventory parsing, including named VLANs and comma/range declarations.
- Extended physical switchport parsing with PVID, allowed VLAN membership and default-VLAN exclusion; the Interfaces view now distinguishes physical interfaces from bridges and displays VLAN/PVID information.
- Added regression tests using the supplied ESR1000 configuration. No configuration write operations were introduced.

## v116 — compact VRRP and interface PBR details
- VRRP in the interface table is now collapsed to its ID. Expanding the ID shows separate `id`, `ip`, `priority` and `group` fields; the parser groups those values per VRRP ID to support multiple groups on one interface.
- PBR details are expanded from the interface's policy route-map reference, with separate `rule`, `match` and `action` rows. Removed the duplicate Route-map/PBR list from the Routing pane; route-map parsing remains available for interface drill-down and object references.
- NAT ruleset names are now plain text in the NAT rules table because their rules are already visible there. NAT pool references remain clickable and show pool parameters.
- No configuration editing or write commands were added. Tests cover VRRP field grouping and the revised interface/NAT/PBR presentation.

## v115 — faster fact collection and ESR object drill-down
- Fact collection now runs up to 10 devices in parallel; the NetBox sync workflow remains serial to preserve ordering and avoid cross-device write conflicts.
- ESR fact collection now batches the base read-only CLI commands through one authenticated SSH session instead of reconnecting for every command. VRRP detail queries, when needed, are batched in a second session.
- Removed the full `show running-config` read from routine ESR fact collection; interface security zones are parsed from the narrower `show running-config interfaces` output.
- Moved the parsed summary above the raw configuration and reduced the raw output viewport to 180 px; renamed the interface heading to “Интерфейсы и саб-интерфейсы”.
- NAT is now presented as one rules table. Ruleset and pool names expand inline to show their configuration, and referenced network/service objects can be opened from NAT and zone-pair rules. Object names are also expandable in the Objects section.
- Added VRF-aware parsing and independent VRF selectors for Interfaces and Routes. Entries without an explicit VRF are assigned to VRF0; `ip vrf forwarding NAME` interfaces and `ip route vrf NAME ...` routes are shown only in the selected VRF. Security zones and zone-pairs inherit their VRF from zone bindings. Validated against the supplied AR2-COMERCIAL configuration (VRF1 interfaces/routes).
- Collection remains read-only; no configuration-changing commands, commit or confirm were introduced.

## v114 — ESR prompt detection and faster collection
- Fixed prompt matching for ESR CLI variants that insert whitespace before a context suffix (for example, `AR1 (config)#`) or omit the trailing newline. Non-printing terminal control bytes are removed before prompt detection.
- Reduced prompt settle time and receive polling interval to avoid unnecessary delay after the final output. Increased the pseudo-terminal height to reduce paging on long configurations.
- Reduced the running-config command timeout from 210 to 60 seconds and the API subprocess limit from 235 to 75 seconds; connection timeout reduced from 15 to 10 seconds.
- Kept collection strictly read-only; configuration contents are not included in timeout diagnostics.
- Added regression tests for spaced context prompts, prompts without a trailing newline and terminal control bytes.

## v113 — ESR workspace layout and CLI collection reliability
- Reworked ESR administration into a left-hand collapsible navigation with a dedicated content workspace; added NAT as a separate section.
- Extended the read-only parser to extract destination/source NAT pools, rulesets and rules, including interface/zone, match fields, action, pool and enabled state.
- Hardened ESR interactive CLI collection: recognize the prompt by device identity rather than exact prompt bytes, tolerate a CLI context suffix, and wait for a short quiet interval before accepting the final prompt. Pager continuation remains supported.
- Increased the `show running-config` command budget to 210 seconds (235 seconds at the API subprocess boundary). Timeout diagnostics report byte count only and never echo received configuration text.
- No configuration-changing commands are introduced; `commit` and `confirm` remain unavailable.
- Added regression tests for context-suffixed prompts, safe timeout diagnostics and NAT parsing.

## v112 — ESR administration foundation (read-only)
- The "Администрирование ESR" section now selects only Eltex ESR200 SSH devices from the primary device registry; the separate legacy `esr_managed_devices` table is no longer the source of truth for the module counter.
- Added read-only `show running-config` collection through the existing ESR SSH CLI helper. Collection requires the device host key to exist in the application's approved `known_hosts`; unknown or changed keys are rejected. The result is stored as a configuration snapshot with collection timestamp.
- Added a structured parser for security zones, zone-pairs/rules, interfaces/subinterfaces (IP, zone, description, VRRP, shutdown, mode, PBR policy), static routes, route-maps, network/service object groups and ACLs. Objects include a basic "where used" reference list. The original sanitized configuration remains available alongside parsed data.
- The UI has tabs for configuration, zones, interfaces, routing and objects. Configuration-changing commands, pending-change generation, `commit` and `confirm` are deliberately not implemented in v112.
- Extended secret sanitization to redact credentials embedded in SCP/SFTP/HTTP/FTP URLs before snapshots are persisted. Tests: `tests/test_esr_config.py`, `tests/test_webui_api.py`, `tests/test_project_safety.py`.

## v111 — VLAN field of new prefixes
- A new prefix gets its NetBox VLAN filled in: the VLAN id is taken from the interface names of the network's addresses (`Vlanif100`, `gi1/0/2.1010`, `Eth-Trunk1.640`), and the VLAN object is looked up among the VLANs of the same site. It is set only when all addresses of the network point to one VLAN id and exactly one such VLAN exists on the site; otherwise the field stays empty (nothing is guessed). VLANs without a name are not in NetBox (v105), so their prefixes stay without a VLAN. Existing prefixes are never modified. The job log shows how many new prefixes got a VLAN. Tests: tests/test_netbox_prefix_sync.py.

## v110 — ESR security zones: paging and diagnostics
- Fix: `interface_zones` stayed empty on an ESR (the facts report showed `{}`), so no `Zone:` line was written. A long `show running-config` is paged by the ESR (`--More--`) and the CLI helper waited for the prompt until the timeout. The helper now answers the pager with a space and removes the markers from the output (read-only, no configuration change).
- A second, shorter command (`show running-config interfaces`) is tried as well and the outputs are combined; a command the firmware does not know is harmless.
- The job log now has a line "security zones found for N interfaces" with the result code, output size and error of each command, so an empty result can be told from a failed command. Tests: tests/test_eltex_esr_cli.py (paged output).
- Collect the ESR facts again to get zones; prefixes that already exist keep their old comment.

## v109 — Security zone in the prefix comment
- Zones are collected read-only: Huawei USG (`display zone`, both USG6670 and USG6635E; a node that refuses the command gives no zones) and ESR (`security-zone <name>` in the interface blocks of `show running-config`, timeout 120 s, optional). They are stored in the facts report as `interface_zones` and restored for synchronization.
- The comment of a new prefix gets a `Zone: <name>` line when the zone of the interface is known (interface names are matched case-insensitively). Existing prefixes are still never modified.
- Collect the facts again to get zones. Tests: tests/test_zones.py (your real `display zone` and ESR config samples).

## v108 — Comment on new prefixes (source device, VLAN)
- A prefix created from interface addresses now carries a comment: `Источник: <device> (<interface>, <ip>/<mask>)` for each address of the network found on that device, and `Vlan: <id>` when the interface name carries one (`Vlanif100`, `vlan 100` -> 100; `gi1/0/2.1010`, `Eth-Trunk1.640` -> 1010, 640). Existing prefixes are never modified, so the comment is written only at creation.
- `Zone:` is not written yet: no firewall-zone data is collected from Huawei/ESR so far, and the output formats are not guessed.

## v107 — ESR: VRRP virtual address (VIP) in NetBox
- The VRRP virtual address of an Eltex ESR is now written to NetBox: it is taken from `show vrrp <id>` (`Virtual IP address` on the group's interface) and created as an IP address with role `vrrp` on that interface. Before, only the routers' own addresses were synchronized, because `show ip interface` does not list the VIP.
- The VIP is never taken over from the other node: an object with this address on another interface is left alone, the one on this interface (or a free one) is reused and gets the `vrrp` role, otherwise a new one is created (NetBox allows duplicates for role vrrp). If both ESR nodes are members of one registry virtual chassis, the existing shared-address rule applies and the first member writes the VIP once.
- To see the VIP, collect the facts again first (the reports of v106 and older do not contain it). Tests: tests/test_esr_vrrp_ip.py.

## v106 — Prefixes from interface addresses
- After the IP addresses, the networks they imply are created as NetBox prefixes (10.1.2.5/24 -> 10.1.2.0/24): once per distinct network, status active, global table, scoped to the selected site (`scope` on NetBox 4.2+, `site` on older versions). A prefix NetBox already has, in any VRF or site, is only counted and never changed. Host addresses (/32, /128), loopback, link-local and the default route are not prefixes and are skipped. A failure is reported in the log and does not stop the device. Switch: `sync_prefixes` (default true, needs `sync_ip_addresses`). Tests: tests/test_netbox_prefix_sync.py.
- IP ranges are not created: an address and a mask say nothing about which part of a network is a pool.

## v105 — VLANs without a name are not written
- A VLAN that the switch reports without a name (empty or the placeholder `-`, as Eltex prints it) is no longer created in NetBox; the job log shows how many were skipped for that reason. VLANs already in NetBox are never touched or deleted, so remove the earlier nameless ones by hand if you want them gone. Tests: tests/test_netbox_vlan_sync.py.

## v104 — Eltex MES: interface descriptions
- Fix: descriptions of Eltex MES5324A interfaces (stack and standalone) never reached NetBox. The role ran `show interfaces Port-Channel`, which MES refuses ("Wrong number of parameters"), and the error was silently ignored, so every description stayed empty. It now runs `show interfaces description`, whose two tables (ports and port-channels) the parser already understands. Tests: tests/test_eltex_descriptions.py.
- Side effect to expect on the first run: the table also gives the real administrative state, so `enabled` in NetBox now follows the admin state (a port that is configured up but has no link is enabled; before, link-down ports were written as disabled). Only ports whose state differs are updated.

## v103 — Bulk VLAN synchronization, map fix
- Fix: a job timed out after 1800 s on a standalone Eltex with ~1500 VLANs, because every VLAN was a separate `netbox_vlan` call. VLANs are now written by the new `netbox_vlan_sync` module: one site lookup, one read of the site's VLANs, bulk creation of only the missing ones (same rule as before: vid + name; existing VLANs are never changed or deleted). The site is matched by name or slug, case-insensitively. A rejected VLAN is reported and the rest continues. Tests: tests/test_netbox_vlan_sync.py.
- Map, "Подробности" mode: the `Po ↔ Po` badge is now drawn also when only one cable of a confirmed aggregate is known (the "Сборный" mode already did this).

## v102 — Eltex MES5324A stacks (one NetBox device per unit + virtual chassis)
- A stack (one management address, several units) is written to NetBox as one device per unit, each with its own serial number (from `show inventory`), plus a virtual chassis named like the stack. Unit 1 (the lowest unit, the master) keeps the stack name; the other units are named `<name>-2`, `<name>-3`, ...
- Physical ports `te2/0/N` etc. are created on the device of their own unit; port-channels and other logical interfaces stay on the master. LLDP cables are attached to the device that owns the port. A port-channel whose members sit on several units is assigned after the virtual chassis exists.
- The virtual chassis of a stack is created automatically. Do NOT add such a device to a registry virtual chassis (the registry chassis is only for separate devices with their own addresses, e.g. Huawei HA); a registry chassis that contains a stack is not written and a note is printed.
- A standalone MES5324A (one unit in `show inventory`) is unchanged: one plain device, all interfaces on it, no chassis.
- Migration: if a stack was synchronized earlier, its `te2/0/*` interfaces sit on the unit-1 device. Nothing is deleted or moved automatically; delete them there by hand, the next run creates them on the `<name>-2` device.
- Tests: tests/test_eltex_stack.py (filters, standalone, Python/filter parity, virtual chassis and cross-unit LAG against a fake NetBox, static wiring). No real Ansible/NetBox/FastAPI run in this environment.

## v101 — Same IP on both HA members (optional)
- New switch in the NetBox connection settings: "Одинаковые IP на обоих узлах HA" (off by default). When on, an address reported by several members of one virtual chassis is stored for each member as its own IP object on that member's interface, instead of once by the first member. Requires duplicate addresses to be allowed in NetBox (Admin -> Configuration History -> ENFORCE_GLOBAL_UNIQUE off).
- The IP planner, in this mode, never moves an object that sits on another interface: it reuses the object on its own interface (or a free one with the same address) and otherwise creates a second object. Repeated runs are stable. If NetBox refuses a duplicate the answer is reported and the device continues.
- With the switch off nothing changes: shared addresses are written once, by the first member.

## v100 — IP planner no longer second-guesses NetBox's duplicate setting
- v99 skipped an IP whenever the same host address existed with another mask on another interface, even after duplicates were allowed in NetBox (ENFORCE_GLOBAL_UNIQUE off / VRFs). Now the planner only decides between exact matches (assign), a free/own object with another mask (fix mask) and "create"; for a host used elsewhere it attempts the POST and NetBox is the judge. If NetBox refuses, its message is reported and the device continues; the other object is never changed or taken over.
- Two objects with the same host and different masks (allowed when duplicates are enabled) are handled on repeated runs without being reported as ambiguous.
- Shared HA addresses reported by both members of one virtual chassis are still synchronized once, by the first member (unchanged).

## v99 — HRP standby nodes and LLDP
- A Huawei USG in HRP standby state refuses LLDP commands ("The device is in HRP stanby state, so this command can not be executed."). This is expected and never fails the collection: the neighbor list stays empty and an informational message is printed.
- The refusal text (carried in the module `msg`, not in `stdout`) is now kept in the facts report as `lldp_raw`, so the reason is visible instead of an empty field. Applied to both the USG6635E and USG6670 profiles.
- Links of a standby node come from the active node and from the neighbors' own LLDP reports (they see the firewall's chassis MAC).

- IP synchronization no longer fails the whole device when NetBox already has the same host address with another mask (e.g. 10.255.255.2/24 exists, 10.255.255.2/30 is collected: "Duplicate IP address found in global table"). The search is now by host address (mask-insensitive) and the new `plan_ip_assignments` filter decides per IP: create; update/assign (also fixing the mask when the existing object is unassigned or already on this interface); or skip with an explicit reason when the host belongs to another interface or several objects match. Nothing is taken over from another interface.
- An IP rejected by NetBox (HTTP 400/409) is reported with NetBox's message and the remaining IPs, interfaces, virtual chassis and cables continue.
- Fixed the HRP-standby detection pattern (`stand?by` matches both "standby" and the firmware's "stanby").

## v98 — LLDP collection for Huawei USG6635E
- The USG6635E profile (generic `huawei.yml`) never ran an LLDP command, so no neighbors or LLDP cables appeared for it. It now runs the same read-only `display lldp neighbor brief` as the USG6670 profile and parses it with `parse_huawei_lldp`.
- The raw output is stored in the facts report as `lldp_raw`, so an empty answer can be told apart from a parser mismatch. A device without LLDP or a command error leaves the neighbor list empty and does not fail the collection.
- Regression test with the real USG6635E output (7 neighbors across XGigabitEthernet, MEth and GigabitEthernet ports; interfaces with 0 neighbors are ignored).
- Neighbors from this output carry chassis MAC and remote port but no system name; the network map resolves them through the collected reports of the peer devices (same as for the USG6670).

## v97 — NetBox site/role selection and rename-by-serial
- Device form: NetBox site and device role are now chosen from drop-down lists read from NetBox (`/api/dcim/sites/`, `/api/dcim/device-roles/`) instead of typing slugs; the stored settings are still the slugs, so existing devices and sync are unchanged.
- Presets are always offered: site `P24`; roles `sw`, `l3-sw`, `core-sw`, `router`, `fw`. A preset missing in NetBox is marked "будет создана" and is created when the device is saved.
- "＋ Новая…" creates a new site/role in NetBox (Latin letters, digits, `-`, `_`; slug derived in lower case). Creation is idempotent (matched by slug, then name; never duplicated or overwritten). If NetBox is unreachable the presets and the reason are shown; a slug already stored on a device stays in the list.
- New API: `GET /api/netbox/choices`, `POST /api/netbox/sites`, `POST /api/netbox/roles`.
- Renaming a device in netbox-sync no longer creates a second NetBox device. Before "Create or update device record" the new role module `netbox_device_rename` looks for a NetBox device with the new name; if none exists but exactly one device has the same serial number, that device is renamed (`PATCH /api/dcim/devices/<id>/`, numeric id).
- Safety: empty/placeholder serials (`unknown`, `N/A`, …) are never used; several devices with one serial -> warning, nothing renamed; a device whose name still belongs to another netbox-sync device is protected (full registry names are passed as `netbox_sync_registry_names`, independent of `--limit`); an API error stops that device's sync instead of silently creating a duplicate. Nothing is deleted.
- Tests: `tests/test_netbox_choices.py`, `tests/test_netbox_device_rename.py`.

## v96 — SNR eNOS LLDP wrapped-row parsing
- Fixed the SNR eNOS 1.23.x LLDP brief parser for terminal-wrapped table rows. It now reconstructs remote Port IDs split across physical lines and correctly separates PID subtype, Time Mark and System-name.
- Added regression fixtures from the supplied v95 reports: SNR-171 ge47 → SNR-170 ge47, SNR-171 ge48 → Huawei GigabitEthernet0/0/22, and the reciprocal SNR-170 ge47 → SNR-171 ge47 observation.
- The parser now produces normalized neighbor records with the advertised device names and chassis IDs, enabling the existing topology resolver to build the ge47 ↔ ge47 edge without relying on descriptions or link state.
- No device configuration commands, NetBox sync behavior, interface parsing, VLAN handling or other vendor workflows were changed.

## v95 — SNR eNOS LLDP collection
- Added read-only collection of `show lldp neighbors brief` for the SNR-S5311G-48TX-POE profile and a dedicated parser for the eNOS table format observed on SNR eNOS 1.23.x.
- Normalized local interface, remote port and Chassis ID into the project's common `lldp_neighbors` structure. A real System-name is included as `neighbor_device`; `-` is deliberately treated as unknown and never guessed from interface descriptions.
- Saved the raw SNR LLDP output and basic collection diagnostics into the facts report so an empty/unsupported response can be distinguished from a parser mismatch.
- Updated the «Карта сети» LLDP resolver to use an explicitly advertised `neighbor_device`/System Name when the peer MAC is not available in the peer report. This allows a single authoritative LLDP observation (for example, Huawei Gi0/0/22 → SNR ge48) to create a topology edge without requiring a reciprocal report. Chassis-MAC matching remains preferred; reciprocal port matching remains the fallback.
- The SNR↔SNR case with System-name `-` still requires the peer to advertise its name or its chassis MAC to be identifiable in another device report; no cable is fabricated from port descriptions or link state.
- Added parser regression coverage based on the supplied SNR eNOS `show lldp neighbors brief` output.

## v94 — IP lookup no longer depends on netaddr
- Fixed the failure of "Look up existing IP objects before synchronization" right after a successful interface sync: the `ansible.utils.ipaddr` filter needs the `netaddr` Python package, which is not in the project requirements. Replaced with the stdlib filter `is_valid_ip_with_prefix` (also accepts IPv6 with prefixes up to /128; previously prefixes above 32 were silently excluded).
- Removed `no_log` from the IP lookup/create/update tasks so a real API error is shown instead of "output hidden"; the token is only sent in request headers and is not part of the task result.

## v93 — Interface sync by numeric NetBox IDs
- Fixed `More than one result returned for <interface>` on Huawei USG 6670 HA members (`DTC-HUW2_23-1`, `DTC-P24-HUW-23-1`): identical interface names on different devices are valid.
- Interfaces are no longer synchronized with `netbox.netbox.netbox_device_interface` (its internal name lookup is outside our control). New role module `netbox_interface_sync` works through the NetBox REST API: exact device name -> exactly one `device_id`; `GET /api/dcim/interfaces/?device_id=<id>` with full pagination (follows `next`, checks `count`); every returned row is also verified client-side to belong to that `device_id`.
- Per collected interface: 0 matches -> `POST` with `device_id`; 1 match -> `PATCH /api/dcim/interfaces/<id>/` (only changed fields, idempotent); more than one on the same device -> skipped with a warning listing device, name and all IDs (nothing deleted, renamed or chosen at random). Other interfaces continue; per-interface HTTP errors are reported and do not stop the rest.
- LAG membership is applied by numeric parent interface ID. Legacy `mac_address` is retried without that field if NetBox rejects it.
- IP assignment keeps its logic (IPv4/IPv6, subinterfaces, several IPs, HA shared-IP exclusions, existing IP objects, no duplicates) and now takes interface IDs from the module result instead of a second unpaginated query.
- Added `tests/test_netbox_interface_sync.py` (fake NetBox: HA members with identical names, VC-sibling leakage, pagination, duplicates, errors).

## v87 — Unambiguous IP-to-interface assignment
- Resolve the NetBox device once and fetch its interfaces by numeric device ID.
- Assign IP addresses through the NetBox REST API using the exact numeric interface ID, avoiding ambiguous lookup by repeated interface names across devices.
- Create a missing IP object or update a single exact match. If NetBox returns multiple IP objects for the same address, skip it and report the ambiguity rather than selecting one arbitrarily.
- Detect duplicate interface names within one physical device; skip only those ambiguous interface updates and report the conflicting object IDs. Do not create duplicate records, delete records, or merge objects.
- Identical interface names on the two members of a Huawei HA virtual chassis remain valid. Shared HA IP exclusions and virtual chassis post-sync behavior are preserved.

