from __future__ import annotations

import hashlib
import ipaddress
from contextlib import contextmanager
import hmac
import os
import secrets
import sqlite3
import subprocess
import threading
import time
import tempfile
import socket
import json
import logging
import re
import difflib
import uuid
import ssl
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import yaml
from fastapi import Depends, FastAPI, HTTPException, Request, Response, status
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field, ConfigDict
from starlette.middleware.sessions import SessionMiddleware
from cryptography.fernet import Fernet, InvalidToken

logger = logging.getLogger(__name__)

ROOT = Path(__file__).resolve().parents[1]
DATA = Path(os.getenv("WEBUI_DATA_DIR", str(ROOT / "local_data"))).resolve()
REPORTS, BACKUPS = (DATA / name for name in ("reports", "backups"))
DB_PATH = DATA / "webui.sqlite3"
VAULT_PASSWORD_PATH = DATA / "vault_pass"
VAULT_DATA_PATH = DATA / "vault.yml"
SSH_DIR = DATA / ".ssh"
KNOWN_HOSTS_PATH = SSH_DIR / "known_hosts"
SSH_DIR.mkdir(parents=True, exist_ok=True)
try:
    SSH_DIR.chmod(0o700)
except OSError:
    pass
# One-time migration from the previous read-only OpenSSH known_hosts mount.
_LEGACY_KNOWN_HOSTS = ROOT / "deploy" / "known_hosts"
if not KNOWN_HOSTS_PATH.exists() and _LEGACY_KNOWN_HOSTS.is_file():
    import shutil
    shutil.copyfile(_LEGACY_KNOWN_HOSTS, KNOWN_HOSTS_PATH)
    KNOWN_HOSTS_PATH.chmod(0o600)
for directory in (DATA, REPORTS, BACKUPS):
    directory.mkdir(parents=True, exist_ok=True)
    try:
        directory.chmod(0o700)
    except OSError:
        pass
# Migrate a legacy project-root vault file into persistent application data once.
# The project tree can remain read-only in Docker while secrets stay in local_data.
if not VAULT_DATA_PATH.exists():
    _legacy_vault = ROOT / "vault.yml"
    if _legacy_vault.is_file():
        import shutil
        shutil.copyfile(_legacy_vault, VAULT_DATA_PATH)
        VAULT_DATA_PATH.chmod(0o600)

BIND_HOST = os.getenv("WEBUI_HOST", "0.0.0.0")
JOB_TIMEOUT = int(os.getenv("WEBUI_JOB_TIMEOUT", "1800"))
SESSION_SECRET_PATH = DATA / "session_secret"
if os.getenv("WEBUI_SESSION_SECRET"):
    SESSION_SECRET = os.environ["WEBUI_SESSION_SECRET"]
elif SESSION_SECRET_PATH.exists():
    SESSION_SECRET = SESSION_SECRET_PATH.read_text(encoding="utf-8").strip()
else:
    SESSION_SECRET = secrets.token_urlsafe(48)
    SESSION_SECRET_PATH.write_text(SESSION_SECRET + "\n", encoding="utf-8")
    SESSION_SECRET_PATH.chmod(0o600)

CREDENTIAL_KEY_PATH = DATA / "device_credentials.key"
if CREDENTIAL_KEY_PATH.exists():
    CREDENTIAL_KEY = CREDENTIAL_KEY_PATH.read_bytes().strip()
    CREDENTIAL_KEY_PATH.chmod(0o600)
else:
    # Never silently rotate a missing key if encrypted device credentials already exist.
    if DB_PATH.exists():
        try:
            _probe = sqlite3.connect(DB_PATH)
            _has_devices_table = _probe.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='devices'").fetchone()
            _device_count = _probe.execute("SELECT COUNT(*) FROM devices").fetchone()[0] if _has_devices_table else 0
            _probe.close()
            if _device_count:
                raise RuntimeError("Device credential key is missing while encrypted device credentials exist. Restore local_data/device_credentials.key from backup.")
        except sqlite3.DatabaseError:
            pass
    CREDENTIAL_KEY = Fernet.generate_key()
    CREDENTIAL_KEY_PATH.write_bytes(CREDENTIAL_KEY + b"\n")
    CREDENTIAL_KEY_PATH.chmod(0o600)
_CIPHER = Fernet(CREDENTIAL_KEY)
SESSION_SECRET_PATH.chmod(0o600)

app = FastAPI(title="NetBox Sync Local", docs_url=None, redoc_url=None)
app.add_middleware(SessionMiddleware, secret_key=SESSION_SECRET, session_cookie="netbox_sync_session", max_age=8 * 60 * 60, same_site="strict", https_only=True)

@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Cache-Control"] = "no-store"
    response.headers["Strict-Transport-Security"] = "max-age=31536000; includeSubDomains"
    return response
_job_lock = threading.Lock()
_jobs_lock = threading.Lock()
_jobs: dict[str, dict[str, Any]] = {}
_active_job: str | None = None
_login_attempts: dict[str, list[float]] = {}
_scheduler_started = False
_scheduler_stop = threading.Event()


@contextmanager
def db():
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _get_app_setting(key: str, default: str = "") -> str:
    with db() as conn:
        row = conn.execute("SELECT value FROM app_settings WHERE key=?", (key,)).fetchone()
    return str(row["value"]) if row else default


def _set_app_setting(key: str, value: str) -> None:
    with db() as conn:
        conn.execute("INSERT INTO app_settings(key,value,updated_at) VALUES(?,?,?) "
                     "ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at",
                     (key, value, now()))


def _netbox_token() -> str:
    if _get_app_setting("netbox_api_token_disabled", "false").lower() == "true":
        return ""
    encrypted = _get_app_setting("netbox_api_token_enc")
    if encrypted:
        try:
            return _CIPHER.decrypt(encrypted.encode("ascii")).decode("utf-8")
        except (InvalidToken, UnicodeError) as exc:
            raise RuntimeError("Не удалось расшифровать сохранённый API-токен NetBox. Проверьте local_data/device_credentials.key из резервной копии.") from exc
    if os.getenv("NETBOX_TOKEN", "").strip():
        return os.getenv("NETBOX_TOKEN", "").strip()
    # Backward compatibility with existing Ansible Vault configuration.
    if VAULT_DATA_PATH.is_file():
        try:
            if _vault_file_encrypted():
                if not VAULT_PASSWORD_PATH.is_file():
                    return ""
                proc = subprocess.run(["ansible-vault", "view", "--vault-password-file", str(VAULT_PASSWORD_PATH), str(VAULT_DATA_PATH)],
                                      cwd=ROOT, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                      stderr=subprocess.DEVNULL, text=True, timeout=15, check=False)
                if proc.returncode != 0:
                    return ""
                vault_data = yaml.safe_load(proc.stdout) or {}
            else:
                vault_data = yaml.safe_load(VAULT_DATA_PATH.read_text(encoding="utf-8")) or {}
            if isinstance(vault_data, dict):
                return str(vault_data.get("vault_netbox_token", "") or "")
        except (OSError, ValueError, yaml.YAMLError, subprocess.TimeoutExpired, FileNotFoundError):
            return ""
    return ""


def _netbox_sync_flags() -> tuple[bool, bool]:
    enabled = _get_app_setting("netbox_sync_enabled", "false").lower() == "true"
    automatic = _get_app_setting("netbox_auto_sync_enabled", "false").lower() == "true"
    return enabled, automatic


def _validate_netbox_url(value: str) -> str:
    url = value.strip().rstrip("/")
    parsed = urllib.parse.urlsplit(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname or parsed.username or parsed.password or parsed.query or parsed.fragment:
        raise ValueError("Укажите корректный адрес NetBox с http:// или https://, без логина, пароля, query и fragment.")
    try:
        _ = parsed.port
    except ValueError as exc:
        raise ValueError("В адресе NetBox указан некорректный порт.") from exc
    if any(ch.isspace() for ch in url):
        raise ValueError("Адрес NetBox не должен содержать пробелы.")
    return url


def hash_password(password: str, salt: bytes | None = None) -> str:
    if len(password) < 12:
        raise ValueError("Password must contain at least 12 characters.")
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2**14, r=8, p=1, dklen=32)
    return f"scrypt${salt.hex()}${digest.hex()}"


def verify_password(password: str, encoded: str) -> bool:
    try:
        scheme, salt_hex, digest_hex = encoded.split("$", 2)
        if scheme != "scrypt":
            return False
        salt, expected = bytes.fromhex(salt_hex), bytes.fromhex(digest_hex)
        actual = hashlib.scrypt(password.encode("utf-8"), salt=salt, n=2**14, r=8, p=1, dklen=len(expected))
        return hmac.compare_digest(actual, expected)
    except (ValueError, TypeError):
        return False


def init_db() -> None:
    with db() as conn:
        conn.execute("""CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'admin' CHECK(role IN ('admin','operator','viewer')),
            enabled INTEGER NOT NULL DEFAULT 1,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )""")
        # Compatibility with older DBs: roles remain only as an internal legacy column;
        # all authenticated accounts now have identical permissions.
        conn.execute("UPDATE users SET role='admin'")
        conn.execute("""CREATE TABLE IF NOT EXISTS devices (
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, vendor TEXT NOT NULL,
            address TEXT NOT NULL, device_type TEXT NOT NULL, protocol TEXT NOT NULL,
            port INTEGER NOT NULL, username TEXT NOT NULL, credentials_enc TEXT NOT NULL,
            settings_json TEXT NOT NULL DEFAULT '{}', created_at TEXT NOT NULL, updated_at TEXT NOT NULL
        )""")
        conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_devices_name ON devices(name COLLATE NOCASE)")
        conn.execute("CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TEXT NOT NULL)")
        # Independent inventory for the future Eltex ESR administration module.
        # It is intentionally separate from NetBox Sync's fact-collection devices.
        conn.execute("""CREATE TABLE IF NOT EXISTS esr_managed_devices (
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE COLLATE NOCASE,
            address TEXT NOT NULL, port INTEGER NOT NULL DEFAULT 22,
            created_at TEXT NOT NULL, updated_at TEXT NOT NULL
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS virtual_chassis (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL UNIQUE COLLATE NOCASE,
            vendor TEXT NOT NULL DEFAULT 'Other',
            logical_data_json TEXT NOT NULL DEFAULT '{}',
            notes TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS virtual_chassis_members (
            chassis_id INTEGER NOT NULL REFERENCES virtual_chassis(id) ON DELETE CASCADE,
            device_id INTEGER NOT NULL UNIQUE REFERENCES devices(id) ON DELETE CASCADE,
            created_at TEXT NOT NULL,
            PRIMARY KEY(chassis_id, device_id)
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS host_key_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT, device_id INTEGER NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
            address TEXT NOT NULL, port INTEGER NOT NULL, event TEXT NOT NULL,
            old_fingerprints_json TEXT NOT NULL DEFAULT '[]', new_fingerprints_json TEXT NOT NULL DEFAULT '[]',
            created_at TEXT NOT NULL
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS config_snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT, device_id INTEGER NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
            captured_at TEXT NOT NULL, config_text TEXT NOT NULL, source TEXT NOT NULL DEFAULT 'manual'
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS topology_links (
            id INTEGER PRIMARY KEY AUTOINCREMENT, local_device_id INTEGER NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
            local_interface TEXT NOT NULL, remote_device_id INTEGER NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
            remote_interface TEXT NOT NULL, source TEXT NOT NULL DEFAULT 'manual', created_at TEXT NOT NULL,
            CHECK(local_device_id != remote_device_id), UNIQUE(local_device_id,local_interface,remote_device_id,remote_interface)
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS topology_positions (
            device_id INTEGER PRIMARY KEY REFERENCES devices(id) ON DELETE CASCADE,
            x REAL NOT NULL, y REAL NOT NULL, updated_at TEXT NOT NULL
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS topology_interface_aliases (
            device_id INTEGER NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
            interface_name TEXT NOT NULL,
            display_name TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            PRIMARY KEY(device_id, interface_name)
        )""")
        conn.execute("""CREATE TABLE IF NOT EXISTS topology_label_positions (
            label_key TEXT PRIMARY KEY,
            x REAL NOT NULL DEFAULT 0,
            y REAL NOT NULL DEFAULT 0,
            angle REAL NOT NULL DEFAULT 0,
            updated_at TEXT NOT NULL
        )""")
        label_position_columns = {row[1] for row in conn.execute("PRAGMA table_info(topology_label_positions)").fetchall()}
        if "angle" not in label_position_columns:
            conn.execute("ALTER TABLE topology_label_positions ADD COLUMN angle REAL NOT NULL DEFAULT 0")
        count = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        bootstrap_user = os.getenv("WEBUI_BOOTSTRAP_USER", "admin").strip()
        bootstrap_password = os.getenv("WEBUI_BOOTSTRAP_PASSWORD", "")
        if count == 0:
            if not bootstrap_user or not bootstrap_password or "CHANGE_TO_" in bootstrap_password:
                raise RuntimeError("No web UI accounts exist. Set WEBUI_BOOTSTRAP_USER and WEBUI_BOOTSTRAP_PASSWORD for the first start (12+ characters), then remove the bootstrap password from the environment.")
            if len(bootstrap_user) > 64 or not all(c.isalnum() or c in "._-@" for c in bootstrap_user):
                raise RuntimeError("WEBUI_BOOTSTRAP_USER contains unsupported characters.")
            encoded = hash_password(bootstrap_password)
            stamp = now()
            conn.execute("INSERT INTO users(username,password_hash,role,enabled,created_at,updated_at) VALUES(?,?, 'admin',1,?,?)", (bootstrap_user, encoded, stamp, stamp))
        try:
            DB_PATH.chmod(0o600)
        except OSError:
            pass



# Explicit model profiles. Unknown/custom models may be registered and TCP-checked,
# but are deliberately not admitted to CLI collection until a model-specific profile exists.
MODEL_PROFILES: dict[str, dict[str, str]] = {
    "Huawei USG6670": {"vendor": "huawei", "platform": "huawei", "device_type": "firewall", "profile": "huawei_usg6670", "network_os": "community.network.ce"},
    "Huawei USG6635E": {"vendor": "huawei", "platform": "huawei", "device_type": "firewall", "profile": "huawei_usg6635e", "network_os": "community.network.ce"},
    "Huawei S5735-L48P4X-A": {"vendor": "huawei", "platform": "huawei", "device_type": "switch", "profile": "huawei_s5735_l48p4x_a", "network_os": "community.network.ce"},
    "Huawei S5735-S24T4X": {"vendor": "huawei", "platform": "huawei", "device_type": "switch", "profile": "huawei_s5735_s24t4x", "network_os": "community.network.ce"},
    "Eltex MES-5324A": {"vendor": "eltex", "platform": "eltex", "device_type": "switch", "profile": "eltex_mes5324a", "network_os": "cisco.ios.ios"},
    "Eltex ESR200": {"vendor": "eltex", "platform": "eltex", "device_type": "router", "profile": "eltex_esr200", "network_os": "local"},
    "Cisco Catalyst 9410": {"vendor": "cisco", "platform": "cisco", "device_type": "switch", "profile": "cisco_catalyst_9410", "network_os": "cisco.ios.ios"},
    "SNR S5311G-48TX-POE": {"vendor": "snr", "platform": "snr", "device_type": "switch", "profile": "snr_s5311g48txpoe", "network_os": "cisco.ios.ios"},
}

class LoginRequest(BaseModel):
    username: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=1024)


class JobRequest(BaseModel):
    mode: str = Field(pattern="^(collect|sync)$")
    limit: str | None = Field(default=None, max_length=128)
    confirm_sync: bool = False


class UserCreate(BaseModel):
    username: str = Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9_.@-]+$")
    password: str = Field(min_length=12, max_length=1024)


class UserUpdate(BaseModel):
    password: str | None = Field(default=None, min_length=12, max_length=1024)
    enabled: bool | None = None


class NetBoxSettingsUpdate(BaseModel):
    netbox_url: str = Field(min_length=8, max_length=512)
    api_token: str = Field(default="", max_length=4096)
    clear_token: bool = False
    sync_enabled: bool = False
    auto_sync_enabled: bool = False


class VaultPasswordUpdate(BaseModel):
    current_password: str = Field(default="", max_length=1024)
    new_password: str = Field(min_length=12, max_length=1024)
    confirm_password: str = Field(min_length=12, max_length=1024)


class DeviceCreate(BaseModel):
    name: str = Field(min_length=1, max_length=128, pattern=r"^[A-Za-z0-9_.:@-]+$")
    vendor: str = Field(min_length=1, max_length=64)
    address: str = Field(min_length=1, max_length=253)
    device_type: str = Field(pattern="^(switch|firewall|router|other)$")
    protocol: str = Field(pattern="^(ssh|telnet|tcp)$")
    port: int = Field(default=22, ge=1, le=65535)
    username: str = Field(default="", max_length=128)
    password: str = Field(default="", max_length=1024)
    settings: dict[str, Any] = Field(default_factory=dict)
    virtual_chassis_id: int | None = Field(default=None, ge=1)


class DeviceUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str | None = Field(default=None, min_length=1, max_length=128, pattern=r"^[A-Za-z0-9_.:@-]+$")
    vendor: str | None = Field(default=None, min_length=1, max_length=64)
    address: str | None = Field(default=None, min_length=1, max_length=253)
    device_type: str | None = Field(default=None, pattern="^(switch|firewall|router|other)$")
    protocol: str | None = Field(default=None, pattern="^(ssh|telnet|tcp)$")
    port: int | None = Field(default=None, ge=1, le=65535)
    username: str | None = Field(default=None, max_length=128)
    password: str | None = Field(default=None, max_length=1024)
    settings: dict[str, Any] | None = None
    virtual_chassis_id: int | None = Field(default=None, ge=1)


class ConfigCapture(BaseModel):
    config_text: str = Field(min_length=1, max_length=2_000_000)
    source: str = Field(default="manual", max_length=64)


class TopologyLinkCreate(BaseModel):
    local_device_id: int
    local_interface: str = Field(min_length=1, max_length=128)
    remote_device_id: int
    remote_interface: str = Field(min_length=1, max_length=128)

class TopologyPositionUpdate(BaseModel):
    x: float = Field(ge=-10000, le=10000)
    y: float = Field(ge=-10000, le=10000)


class TopologyInterfaceAliasUpdate(BaseModel):
    display_name: str = Field(default="", max_length=128)

class TopologyLabelPositionUpdate(BaseModel):
    x: float = Field(default=0, ge=-10000, le=10000)
    y: float = Field(default=0, ge=-10000, le=10000)
    angle: float = Field(default=0, ge=-180, le=180)


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def sanitize_config(config_text: str) -> str:
    """Redact credential-bearing CLI lines before persisting snapshots or generating diffs."""
    import re
    sensitive = re.compile(r"(?i)(\b(?:password|passwd|secret|community|pre-shared-key|authentication-key|private-key|cipher)\b)(\s+)(.+)$")
    cleaned = []
    for line in config_text.splitlines():
        match = sensitive.search(line)
        if match:
            line = line[:match.start(3)] + "<REDACTED>"
        cleaned.append(line)
    return "\n".join(cleaned) + ("\n" if config_text.endswith("\n") else "")


def redact_output(output: str, env: dict[str, str], extra_secrets: list[str] | None = None) -> str:
    """Redact known environment and per-device secrets from captured Ansible output."""
    secrets_to_redact = {env.get("NETWORK_PASS", ""), env.get("WEBUI_BOOTSTRAP_PASSWORD", "")}
    secrets_to_redact.update(extra_secrets or [])
    vault_path = env.get("ANSIBLE_VAULT_PASSWORD_FILE", str(VAULT_PASSWORD_PATH))
    if vault_path:
        try:
            if Path(vault_path).is_file():
                secrets_to_redact.add(Path(vault_path).read_text(encoding="utf-8").strip())
        except OSError:
            pass
    for secret in sorted((x for x in secrets_to_redact if x and len(x) >= 3), key=len, reverse=True):
        output = output.replace(secret, "[REDACTED]")
    return output


def build_runtime_inventory(limit: str | None = None) -> tuple[dict[str, Any], list[str]]:
    """Build an ephemeral Ansible inventory from the local device registry.

    Passwords are decrypted only for the duration of a job, written to a 0600
    temporary inventory, then removed. NetBox is not the source of equipment access.
    """
    hosts: dict[str, Any] = {}
    secrets_to_redact: list[str] = []
    with db() as conn:
        rows = conn.execute("SELECT * FROM devices ORDER BY name COLLATE NOCASE").fetchall()
    allowed_names = {name.strip().casefold() for name in limit.split(",") if name.strip()} if limit else None
    for row in rows:
        if allowed_names is not None and row["name"].casefold() not in allowed_names:
            continue
        # TCP-only records remain available for reachability checks but are not CLI inventory targets.
        if row["protocol"] != "ssh":
            continue
        try:
            settings = json.loads(row["settings_json"] or "{}")
        except (TypeError, ValueError):
            settings = {}
        if not isinstance(settings, dict):
            settings = {}
        model = str(settings.get("device_model", "")).strip()
        profile_info = MODEL_PROFILES.get(model)
        profile = str(settings.get("device_profile", "")).strip() or (profile_info or {}).get("profile", "")
        if not profile_info or profile != profile_info["profile"]:
            raise RuntimeError(
                f"Device '{row['name']}' has model '{model or '(not selected)'}' without a supported model-specific CLI profile. "
                "Edit the device and select an implemented exact model. Custom models can be registered and TCP-checked, but not collected by Ansible."
            )
        vendor = row["vendor"].strip().lower()
        if vendor != profile_info["vendor"]:
            raise RuntimeError(
                f"Device '{row['name']}' vendor '{row['vendor']}' does not match selected model '{model}'. "
                "Edit the device and choose the correct model."
            )
        platform = profile_info["platform"]
        network_os = str(settings.get("ansible_network_os", profile_info["network_os"]))
        password = _CIPHER.decrypt(row["credentials_enc"].encode()).decode()
        if password:
            secrets_to_redact.append(password)
        host_vars: dict[str, Any] = {
            "ansible_host": row["address"],
            "ansible_port": int(row["port"]),
            "ansible_connection": "local" if profile == "eltex_esr200" else "ansible.netcommon.network_cli",
            "ansible_network_os": network_os,
            "ansible_user": row["username"],
            "ansible_password": password,
            "platform": platform,
            "device_profile": profile,
            "netbox_site": settings.get("netbox_site", ""),
            "netbox_role": settings.get("netbox_role", ""),
            "netbox_device_type_slug": settings.get("netbox_device_type_slug", ""),
            "netbox_device_model": model,
        }
        # Use Paramiko for all network_cli devices so older network equipment can negotiate
        # legacy SSH KEX/host-key algorithms where required. ESR200 uses its dedicated local
        # Paramiko runner and is intentionally excluded from network_cli.
        if host_vars["ansible_connection"] == "ansible.netcommon.network_cli":
            host_vars["ansible_network_cli_ssh_type"] = "paramiko"
        # Eltex stack CLI commands can take longer than the generic 45-second timeout.
        # Keep this scoped to Eltex; an explicit per-device setting can override it below.
        if platform == "eltex":
            host_vars["ansible_command_timeout"] = 120
        # Explicitly supported extra connection/collection variables only.
        for key in ("ansible_become", "ansible_become_method", "ansible_command_timeout", "ansible_connect_timeout",
                    "sync_device", "sync_interfaces", "sync_vlans", "sync_lag"):
            if key in settings:
                host_vars[key] = settings[key]
        hosts[row["name"]] = host_vars
    if not hosts:
        raise RuntimeError("The local device inventory is empty. Add devices in the Devices section before collecting facts.")
    supported = ("huawei", "eltex", "cisco", "snr")
    return {"all": {"children": {
        "huawei": {"hosts": {n: v for n, v in hosts.items() if v["platform"] == "huawei"}},
        "eltex": {"hosts": {n: v for n, v in hosts.items() if v["platform"] == "eltex"}},
        "cisco": {"hosts": {n: v for n, v in hosts.items() if v["platform"] == "cisco"}},
        "snr": {"hosts": {n: v for n, v in hosts.items() if v["platform"] == "snr"}},
        "other": {"hosts": {n: v for n, v in hosts.items() if v["platform"] not in supported}},
    }}}, secrets_to_redact


def cleanup_old_fact_reports(retention_days: int = 30) -> int:
    """Delete only generated fact JSON reports older than the retention period."""
    cutoff = time.time() - retention_days * 86400
    removed = 0
    for path in REPORTS.glob("*-facts.json"):
        try:
            if path.is_symlink() or not path.is_file():
                continue
            if path.stat().st_mtime < cutoff:
                path.unlink()
                removed += 1
        except OSError:
            logger.warning("Could not remove expired fact report %s", path.name)
    return removed


def _auto_collect_device_names() -> list[str]:
    names: list[str] = []
    with db() as conn:
        rows = conn.execute("SELECT name,protocol,settings_json FROM devices ORDER BY name COLLATE NOCASE").fetchall()
    for row in rows:
        if row["protocol"] != "ssh":
            continue
        try:
            settings = json.loads(row["settings_json"] or "{}")
        except (TypeError, ValueError):
            settings = {}
        if isinstance(settings, dict) and settings.get("auto_collect") is True:
            names.append(row["name"])
    return names


def _scheduler_loop() -> None:
    """Run opted-in device collection once per UTC day (02:00) and prune reports."""
    last_cleanup = 0.0
    while not _scheduler_stop.wait(30):
        try:
            if time.time() - last_cleanup >= 3600:
                cleanup_old_fact_reports(30)
                last_cleanup = time.time()
            current = datetime.now(timezone.utc)
            if current.hour < 2:
                continue
            day = current.date().isoformat()
            with db() as conn:
                row = conn.execute("SELECT value FROM app_settings WHERE key='last_auto_collect_date'").fetchone()
                already_ran = bool(row and row["value"] == day)
            if already_ran:
                continue
            names = _auto_collect_device_names()
            if not names:
                continue
            if not _job_lock.acquire(blocking=False):
                continue
            job_id = str(uuid.uuid4())
            job = {"id": job_id, "mode": "collect", "limit": ",".join(names), "requested_by": "Автосбор",
                   "status": "running", "created_at": now(), "finished_at": None, "return_code": None,
                   "output": "Автоматический сбор фактов для устройств с включённой галочкой автосбора."}
            global _active_job
            with _jobs_lock:
                _jobs[job_id] = job
                _active_job = job_id
            with db() as conn:
                conn.execute("INSERT INTO app_settings(key,value,updated_at) VALUES('last_auto_collect_date',?,?) "
                             "ON CONFLICT(key) DO UPDATE SET value=excluded.value,updated_at=excluded.updated_at", (day, now()))
            threading.Thread(target=run_job, args=(job_id, "collect", ",".join(names)), daemon=True).start()
        except Exception:
            logger.exception("Automatic collection scheduler iteration failed")


@app.on_event("startup")
def start_background_scheduler() -> None:
    global _scheduler_started
    cleanup_old_fact_reports(30)
    if not _scheduler_started:
        _scheduler_started = True
        threading.Thread(target=_scheduler_loop, name="netbox-sync-scheduler", daemon=True).start()


init_db()


def current_user(request: Request) -> dict[str, Any] | None:
    user_id = request.session.get("user_id")
    if not user_id:
        return None
    with db() as conn:
        row = conn.execute("SELECT id,username,enabled,updated_at FROM users WHERE id=?", (user_id,)).fetchone()
    if not row or not row["enabled"] or request.session.get("user_updated_at") != row["updated_at"]:
        request.session.clear()
        return None
    return dict(row)


def require_user(request: Request) -> dict[str, Any]:
    user = current_user(request)
    if not user:
        raise HTTPException(status_code=401, detail="Authentication required")
    return user


def require_admin(user: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    # Backward-compatible dependency name; every authenticated account has equal permissions.
    return user


def require_csrf(request: Request) -> None:
    expected = request.session.get("csrf_token", "")
    supplied = request.headers.get("x-csrf-token", "")
    if not expected or not supplied or not hmac.compare_digest(expected, supplied):
        raise HTTPException(status_code=403, detail="CSRF validation failed; reload the page and try again.")


def _vault_file_encrypted(path: Path = VAULT_DATA_PATH) -> bool:
    try:
        with path.open("rb") as handle:
            return handle.readline(128).startswith(b"$ANSIBLE_VAULT;")
    except OSError:
        return False


def _vault_status() -> dict[str, Any]:
    password_file_ok = VAULT_PASSWORD_PATH.is_file()
    try:
        password_file_ok = password_file_ok and bool(VAULT_PASSWORD_PATH.read_text(encoding="utf-8").strip())
    except OSError:
        password_file_ok = False
    vault_exists = VAULT_DATA_PATH.is_file()
    encrypted = _vault_file_encrypted() if vault_exists else False
    if not password_file_ok:
        message = "Пароль Vault не задан. Установите его ниже."
    elif vault_exists and encrypted:
        message = "Пароль задан; файл vault.yml зашифрован."
    elif vault_exists:
        message = "Пароль задан, но vault.yml не зашифрован или содержит шаблон. Проверьте файл перед синхронизацией."
    else:
        message = "Пароль задан. Файл vault.yml пока отсутствует; для синхронизации NetBox он потребуется."
    return {"configured": password_file_ok, "vault_file_exists": vault_exists, "vault_file_encrypted": encrypted,
            "password_file_is_regular": VAULT_PASSWORD_PATH.is_file(), "message": message}


def _write_secret_temp(value: str, prefix: str) -> Path:
    fd, name = tempfile.mkstemp(prefix=prefix, dir=str(DATA))
    path = Path(name)
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write(value)
            handle.write("\n")
        return path
    except Exception:
        try:
            os.close(fd)
        except OSError:
            pass
        path.unlink(missing_ok=True)
        raise


def _legacy_vault_password() -> str:
    candidates = [VAULT_PASSWORD_PATH, ROOT / "deploy" / "vault_pass", ROOT / ".vault_pass"]
    configured = os.getenv("ANSIBLE_VAULT_PASSWORD_FILE", "")
    if configured:
        candidates.insert(0, Path(configured))
    for path in candidates:
        try:
            if path.is_file():
                value = path.read_text(encoding="utf-8").strip()
                if value:
                    return value
        except OSError:
            continue
    return ""


def ansible_collections_path(base_env: dict[str, str] | None = None) -> str:
    """Return readable collection roots before run_job redirects HOME to DATA.

    Docker historically installed collections under /root/.ansible/collections;
    native installs now use /usr/share/ansible/collections. Keep both supported.
    """
    source_env = os.environ if base_env is None else base_env
    candidates: list[str] = []
    configured = source_env.get("ANSIBLE_COLLECTIONS_PATH") or source_env.get("ANSIBLE_COLLECTIONS_PATHS") or ""
    candidates.extend(path for path in configured.split(os.pathsep) if path)
    candidates.append("/usr/share/ansible/collections")
    original_home = source_env.get("HOME") or str(Path.home())
    candidates.append(str(Path(original_home) / ".ansible" / "collections"))
    candidates.append("/root/.ansible/collections")

    readable: list[str] = []
    for candidate in candidates:
        path = Path(candidate).expanduser()
        value = str(path)
        if value not in readable and path.is_dir() and os.access(path, os.R_OK | os.X_OK):
            readable.append(value)
    # Keep the stable location in the configured list even during first-time setup;
    # Ansible safely ignores it if it has not been created yet.
    if "/usr/share/ansible/collections" not in readable:
        readable.insert(0, "/usr/share/ansible/collections")
    return os.pathsep.join(readable)


def project_config() -> dict[str, Any]:
    path = ROOT / "group_vars" / "all.yml"
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        if not isinstance(data, dict):
            data = {}
        configured_url = _get_app_setting("netbox_url", "").strip()
        if configured_url:
            data["netbox_url"] = configured_url
        return data
    except (OSError, yaml.YAMLError):
        return {}


def _normalize_huawei_subinterface_config(lines: Any) -> list[str]:
    if isinstance(lines, str):
        lines = lines.splitlines()
    if not isinstance(lines, list):
        return []
    return [re.sub(r"\s+", " ", str(line).strip()).lower() for line in lines
            if str(line).strip() and str(line).strip().lower() not in {"return", "quit"}]


def _refresh_virtual_chassis_from_reports() -> dict[str, int]:
    """Refresh report-derived logical data after a successful facts collection.

    Updates only when every member has a valid report from the same collection run.
    This prevents a partial collection from clearing previously known logical data.
    """
    updated = 0
    skipped = 0
    with db() as conn:
        chassis_rows = conn.execute("SELECT * FROM virtual_chassis ORDER BY id").fetchall()
        for chassis in chassis_rows:
            members = conn.execute("""SELECT d.id,d.name,d.vendor FROM virtual_chassis_members m
                JOIN devices d ON d.id=m.device_id WHERE m.chassis_id=? ORDER BY d.name COLLATE NOCASE""", (chassis["id"],)).fetchall()
            if not members:
                continue
            reports: dict[str, dict[str, Any]] = {}
            try:
                for member in members:
                    safe_name = re.sub(r"[^A-Za-z0-9_.-]", "_", member["name"])
                    report = json.loads((REPORTS / f"{safe_name}-facts.json").read_text(encoding="utf-8"))
                    if report.get("device") != member["name"] or not report.get("collection_id") or not isinstance(report.get("interfaces"), dict) or not report["interfaces"]:
                        raise ValueError("incomplete member report")
                    reports[member["name"]] = report
            except (OSError, ValueError, TypeError, json.JSONDecodeError):
                skipped += 1
                continue
            collection_ids = {str(r.get("collection_id")) for r in reports.values()}
            if len(reports) != len(members) or len(collection_ids) != 1:
                skipped += 1
                continue
            try:
                logical = json.loads(chassis["logical_data_json"] or "{}")
                if not isinstance(logical, dict): logical = {}
            except (TypeError, json.JSONDecodeError):
                logical = {}
            interfaces = [i for i in logical.get("interfaces", []) if isinstance(i, dict)]
            vendor = str(chassis["vendor"]).strip().casefold()
            if vendor == "eltex":
                vrrp: dict[tuple[str, str], dict[str, Any]] = {}
                for member_name, report in reports.items():
                    for item in (report.get("vrrp_details") or report.get("vrrp_summary") or []):
                        if not isinstance(item, dict): continue
                        vip = str(item.get("virtual_ip", "")).strip()
                        group_id = str(item.get("id", "")).strip()
                        if not vip or not group_id: continue
                        entry = vrrp.setdefault((group_id, vip), {"id": item.get("id"), "virtual_ip": vip,
                            "interface": str(item.get("interface", "")), "members": []})
                        entry["members"].append(member_name)
                        if not entry.get("interface") and item.get("interface"): entry["interface"] = item["interface"]
                auto_names = {str(i.get("name", "")).casefold() for i in interfaces if i.get("source") == "auto-vrrp-report"}
                interfaces = [i for i in interfaces if i.get("source") != "auto-vrrp-report"]
                for (group_id, vip), item in sorted(vrrp.items()):
                    try: ipaddress.ip_interface(vip)
                    except ValueError: continue
                    name = "vrrp" + group_id
                    interfaces.append({"name": name, "ip_addresses": [vip], "source": "auto-vrrp-report",
                                       "source_devices": sorted(item["members"]), "source_interface": item.get("interface", "")})
                logical["interfaces"] = interfaces
                logical["vrrp_groups"] = [{"id": item["id"], "virtual_ip": item["virtual_ip"],
                    "interface": item.get("interface", ""), "members": sorted(item["members"])} for item in vrrp.values()]
            elif vendor == "huawei":
                if len(members) != 2 or any(r.get("device_profile") not in {"huawei_usg6670", "huawei_usg6635e"} for r in reports.values()):
                    continue
                names = [m["name"] for m in members]
                # Only operationally UP Eth-Trunk subinterfaces are eligible.
                # Both reports must agree on normalized interface name, status and
                # the complete IP-address list. An empty list is valid only when
                # both members report no address. Full config comparison is not used.
                member_interfaces = {name: reports[name].get("interfaces", {}) for name in names}
                if not all(isinstance(member_interfaces[name], dict) and member_interfaces[name] for name in names):
                    skipped += 1
                    continue
                normalized = {}
                for name in names:
                    normalized[name] = {}
                    for raw_name, data in member_interfaces[name].items():
                        if not re.match(r"(?i)^Eth-Trunk\d+\.\d+$", str(raw_name).replace(" ", "")) or not isinstance(data, dict):
                            continue
                        ifname = str(raw_name).replace(" ", "").casefold()
                        addresses = data.get("ip_addresses", [])
                        if not isinstance(addresses, list):
                            addresses = []
                        normalized[name][ifname] = {
                            "name": str(raw_name).replace(" ", ""),
                            "operstatus": str(data.get("operstatus", "unknown")).casefold(),
                            "ip_addresses": sorted(str(ip).strip() for ip in addresses if str(ip).strip()),
                        }
                common = []
                for ifname in sorted(set(normalized[names[0]]) & set(normalized[names[1]])):
                    left, right = normalized[names[0]][ifname], normalized[names[1]][ifname]
                    if left["operstatus"] == "up" and right["operstatus"] == "up" and left["ip_addresses"] == right["ip_addresses"]:
                        parent_name = re.sub(r"\.\d+$", "", left["name"])
                        common.append({"name": left["name"], "parent": parent_name,
                                       "source": "auto-huawei-common-eth-trunk-subinterface",
                                       "source_devices": names, "operstatus": left["operstatus"],
                                       "ip_addresses": left["ip_addresses"]})
                # Represent the shared Eth-Trunk itself as a parent interface as well.
                # Only include it when it is explicitly present and UP in both reports;
                # child subinterfaces are never allowed to create a fictitious parent.
                parent_names = sorted({item["parent"] for item in common}, key=lambda x: int(re.search(r"(?i)eth-trunk(\d+)", x).group(1)))
                common_parents = []
                for parent_name in parent_names:
                    parent_values = []
                    for member_name in names:
                        parent_data = member_interfaces[member_name].get(parent_name)
                        if parent_data is None:
                            parent_data = next((value for key, value in member_interfaces[member_name].items()
                                                if str(key).replace(" ", "").casefold() == parent_name.casefold()), None)
                        if not isinstance(parent_data, dict):
                            parent_values = []
                            break
                        parent_values.append(parent_data)
                    if len(parent_values) != 2 or any(str(item.get("operstatus", "unknown")).casefold() != "up" for item in parent_values):
                        continue
                    parent_addresses = []
                    for item in parent_values:
                        addresses = item.get("ip_addresses", [])
                        if not isinstance(addresses, list): addresses = []
                        if item.get("ip_address") and not addresses: addresses = [item["ip_address"]]
                        parent_addresses.append(sorted(str(ip).strip() for ip in addresses if str(ip).strip()))
                    if parent_addresses[0] != parent_addresses[1]:
                        continue
                    # Preserve physical members from each device report. A shared
                    # Eth-Trunk parent is represented once, with per-device member
                    # mappings so operators can see which physical ports form it.
                    member_map = {}
                    for member_name in names:
                        raw_members = (reports[member_name].get("lag_members") or {}).get(parent_name, [])
                        if not raw_members:
                            raw_members = next((value for key, value in (reports[member_name].get("lag_members") or {}).items()
                                                if str(key).casefold() == parent_name.casefold()), [])
                        member_map[member_name] = sorted({str(port).strip() for port in raw_members if str(port).strip()})
                    common_parents.append({"name": parent_name, "source": "auto-huawei-common-eth-trunk-parent",
                                           "source_devices": names, "operstatus": "up",
                                           "ip_addresses": parent_addresses[0],
                                           "physical_members": member_map})
                # Replace only report-generated records; preserve manually entered data.
                auto_sources = {"auto-huawei-common-eth-trunk-subinterface", "auto-huawei-common-eth-trunk-parent"}
                interfaces = [i for i in interfaces if i.get("source") not in auto_sources]
                interfaces.extend(common_parents)
                interfaces.extend(common)
                logical["interfaces"] = interfaces
                logical["huawei_eth_trunk_parents"] = common_parents
                logical["huawei_eth_trunk_subinterfaces"] = common
            else:
                continue
            conn.execute("UPDATE virtual_chassis SET logical_data_json=?,updated_at=? WHERE id=?",
                         (json.dumps(logical, ensure_ascii=False), now(), chassis["id"]))
            updated += 1
    return {"updated_virtual_chassis": updated, "skipped_virtual_chassis": skipped}


def run_job(job_id: str, mode: str, limit: str | None) -> None:
    global _active_job
    job_succeeded = False
    inventory_path: Path | None = None
    extra_secrets: list[str] = []
    try:
        inventory, extra_secrets = build_runtime_inventory(limit=limit)
        host_names = set()
        for group in inventory.get("all", {}).get("children", {}).values():
            host_names.update((group.get("hosts") or {}).keys())
        if limit:
            targets = [name.strip() for name in limit.split(",") if name.strip()]
            if not targets or any(name not in host_names for name in targets):
                missing = [name for name in targets if name not in host_names]
                raise RuntimeError("Unknown SSH-capable inventory device(s): " + ", ".join(missing or targets) + ". TCP-only devices are excluded from CLI collection.")
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", prefix="netbox-sync-inventory-", suffix=".yml", delete=False) as handle:
            inventory_path = Path(handle.name)
            yaml.safe_dump(inventory, handle, allow_unicode=True, sort_keys=False)
        inventory_path.chmod(0o600)
        inventory_arg = str(inventory_path)
        command = ["ansible-playbook", "-i", inventory_arg, "site.yml", "-e", f"workflow_mode={mode}"]
        if mode == "sync":
            configured_netbox_url = project_config().get("netbox_url", "")
            if configured_netbox_url:
                command.extend(["-e", f"netbox_url={configured_netbox_url}"])
        if mode == "collect":
            command.extend(["-e", f"collection_id={job_id}"])
        if limit:
            if not all(ch.isalnum() or ch in "._- ," for ch in limit) or any(not name.strip() for name in limit.split(",")):
                with _jobs_lock:
                    _jobs[job_id].update(status="failed", finished_at=now(), output="Invalid inventory limit syntax.")
                return
            command.extend(["--limit", limit])
        env = os.environ.copy()
        env["ANSIBLE_CONFIG"] = str(ROOT / "ansible.cfg")
        # Keep collection discovery independent from HOME, which is redirected below
        # so SSH known_hosts and Vault files remain in persistent local data.
        env["ANSIBLE_COLLECTIONS_PATH"] = ansible_collections_path(env)
        # Make OpenSSH/libssh resolve ~/.ssh/known_hosts to the persistent local data directory
        # in both Docker and the native systemd deployment.
        env["HOME"] = str(DATA)
        # Always use the persistent password file managed by the Administration UI.
        env["ANSIBLE_VAULT_PASSWORD_FILE"] = str(VAULT_PASSWORD_PATH)
        env["NETBOX_VAULT_FILE"] = str(VAULT_DATA_PATH)
        if mode == "sync":
            api_token = _netbox_token()
            if api_token:
                env["NETBOX_TOKEN"] = api_token
                extra_secrets.append(api_token)
        proc = subprocess.run(command, cwd=ROOT, env=env, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT, text=True, timeout=JOB_TIMEOUT, check=False)
        output = redact_output(proc.stdout, env, extra_secrets)[-50000:]
        state = "succeeded" if proc.returncode == 0 else "failed"
        job_succeeded = state == "succeeded"
        if state == "succeeded" and mode == "collect":
            try:
                refresh = _refresh_virtual_chassis_from_reports()
                output += ("\n\nАвтообновление виртуальных шасси по отчётам: "
                           f"обновлено {refresh['updated_virtual_chassis']}, "
                           f"пропущено без полного согласованного набора отчётов {refresh['skipped_virtual_chassis']}. ")
            except Exception as refresh_error:
                output += f"\n\nПредупреждение: не удалось автоматически обновить логические данные виртуальных шасси: {refresh_error}"
        if "vault" in output.lower() and ("vault password" in output.lower() or "decrypt" in output.lower()):
            output += "\n\nHint: open Администрирование → Пароль Ansible Vault and check its status."
        with _jobs_lock:
            _jobs[job_id].update(status=state, finished_at=now(), return_code=proc.returncode, output=output)
    except subprocess.TimeoutExpired as exc:
        out = exc.stdout or ""
        if isinstance(out, bytes):
            out = out.decode(errors="replace")
        out = redact_output(out, os.environ.copy(), extra_secrets)
        with _jobs_lock:
            _jobs[job_id].update(status="failed", finished_at=now(), output=f"Job timed out after {JOB_TIMEOUT}s.\n{out[-50000:]}")
    except (OSError, RuntimeError, InvalidToken, ValueError) as exc:
        with _jobs_lock:
            _jobs[job_id].update(status="failed", finished_at=now(), output=f"Could not start Ansible job: {exc}")
    finally:
        if inventory_path is not None:
            try:
                inventory_path.unlink(missing_ok=True)
            except OSError:
                pass
        with _jobs_lock:
            _active_job = None
        _job_lock.release()
    if mode == "collect" and job_succeeded:
        _maybe_start_automatic_sync(limit, job_id)


def _maybe_start_automatic_sync(limit: str | None, source_job_id: str) -> None:
    """Start a separate NetBox sync only after a successful collection and explicit opt-in."""
    sync_enabled, auto_enabled = _netbox_sync_flags()
    if not (sync_enabled and auto_enabled):
        return
    try:
        if not project_config().get("netbox_url") or not _netbox_token():
            raise RuntimeError("Автосинхронизация включена, но адрес NetBox или API-токен не настроен.")
        sync_preflight(limit)
        if not _job_lock.acquire(blocking=False):
            raise RuntimeError("Не удалось запустить автосинхронизацию: другая операция ещё выполняется.")
        sync_id = str(uuid.uuid4())
        job = {"id": sync_id, "mode": "sync", "limit": limit, "requested_by": "Автоматическая синхронизация",
               "status": "running", "created_at": now(), "finished_at": None, "return_code": None,
               "output": f"Автосинхронизация после успешного сбора фактов (задача {source_job_id})."}
        global _active_job
        with _jobs_lock:
            _jobs[sync_id] = job
            _active_job = sync_id
        threading.Thread(target=run_job, args=(sync_id, "sync", limit), daemon=True).start()
    except Exception as exc:
        logger.warning("Automatic NetBox sync skipped after collection %s: %s", source_job_id, exc)
        skipped_id = str(uuid.uuid4())
        stamp = now()
        with _jobs_lock:
            _jobs[skipped_id] = {"id": skipped_id, "mode": "sync", "limit": limit,
                                 "requested_by": "Автоматическая синхронизация", "status": "failed",
                                 "created_at": stamp, "finished_at": stamp, "return_code": None,
                                 "output": f"Автосинхронизация не запущена: {exc}"}


@app.get("/", response_class=HTMLResponse)
def index() -> str:
    return (ROOT / "webui" / "index.html").read_text(encoding="utf-8")


@app.get("/api/session")
def session_info(request: Request) -> dict[str, Any]:
    user = current_user(request)
    if not user:
        return {"authenticated": False}
    token = request.session.get("csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        request.session["csrf_token"] = token
    return {"authenticated": True, "user": user, "csrf_token": token}


@app.post("/api/login")
def login(payload: LoginRequest, request: Request, response: Response) -> dict[str, Any]:
    # Small per-client throttle; production deployments should additionally rate-limit at the reverse proxy/firewall.
    import time
    client = request.client.host if request.client else "unknown"
    attempts = [t for t in _login_attempts.get(client, []) if time.time() - t < 300]
    if len(attempts) >= 10:
        raise HTTPException(status_code=429, detail="Too many login attempts. Try again in five minutes.")
    with db() as conn:
        row = conn.execute("SELECT id,username,password_hash,enabled,updated_at FROM users WHERE username=? COLLATE NOCASE", (payload.username,)).fetchone()
    if not row or not row["enabled"] or not verify_password(payload.password, row["password_hash"]):
        attempts.append(time.time())
        _login_attempts[client] = attempts
        raise HTTPException(status_code=401, detail="Invalid username or password")
    _login_attempts.pop(client, None)
    request.session.clear()
    request.session["user_id"] = row["id"]
    request.session["user_updated_at"] = row["updated_at"]
    request.session["csrf_token"] = secrets.token_urlsafe(32)
    return {"authenticated": True, "user": {"id": row["id"], "username": row["username"]}, "csrf_token": request.session["csrf_token"]}


@app.post("/api/logout")
def logout(request: Request, _: dict[str, Any] = Depends(require_user)) -> dict[str, bool]:
    require_csrf(request)
    request.session.clear()
    return {"ok": True}


@app.get("/api/status")
def status_page(_: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    cfg = project_config()
    with _jobs_lock:
        active = _jobs.get(_active_job) if _active_job else None
        all_jobs = sorted(_jobs.values(), key=lambda j: j.get("created_at", ""), reverse=True)
        recent = all_jobs[:10]
        last_successful_sync = next((j.get("finished_at") or j.get("created_at") for j in all_jobs if j.get("mode") == "sync" and j.get("status") == "succeeded"), None)
    with db() as conn:
        devices = conn.execute("SELECT id,settings_json FROM devices").fetchall()
        auto_collect = 0
        for device in devices:
            try:
                settings = json.loads(device["settings_json"] or "{}")
            except (TypeError, json.JSONDecodeError):
                settings = {}
            if isinstance(settings, dict) and settings.get("auto_collect") is True:
                auto_collect += 1
    last_fact_collection = next((j.get("finished_at") or j.get("created_at") for j in all_jobs
                                 if j.get("mode") == "collect" and j.get("status") == "succeeded"), None)
    collection_errors = sum(1 for j in recent if j.get("mode") == "collect" and j.get("status") == "failed")
    return {"project": "NetBox Sync Local", "netbox_url": cfg.get("netbox_url", "not configured"),
            "workflow_default": cfg.get("workflow_mode", "collect"), "active_job": active, "jobs": recent,
            "artifacts": {"reports": len(list(REPORTS.glob("*-facts.json")))},
            "device_summary": {"total": len(devices), "auto_collect": auto_collect},
            "last_fact_collection": last_fact_collection,
            "last_successful_sync": last_successful_sync,
            "collection_errors": collection_errors,
            "netbox_sync_enabled": _netbox_sync_flags()[0],
            "netbox_auto_sync_enabled": _netbox_sync_flags()[1],
            "configuration_push_enabled": False}


@app.get("/api/reports")
def list_fact_reports(_: dict[str, Any] = Depends(require_user)) -> list[dict[str, Any]]:
    """Return only generated fact reports; never expose configs, credentials, or arbitrary files."""
    reports: list[dict[str, Any]] = []
    for path in sorted(REPORTS.glob("*-facts.json"), key=lambda p: p.stat().st_mtime, reverse=True)[:100]:
        try:
            if not path.is_file() or path.stat().st_size > 2_000_000:
                continue
            data = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(data, dict) or not isinstance(data.get("interfaces", {}), dict):
                continue
            reports.append({
                "file": path.name,
                "device": str(data.get("device", "")),
                "platform": str(data.get("platform", "")),
                "model": str(data.get("model", "")),
                "version": str(data.get("version", "")),
                "serial": str(data.get("serial", "")),
                "collection_id": str(data.get("collection_id", "")),
                "interface_count": len(data.get("interfaces", {})),
                "vlan_count": len(data.get("vlans", [])),
                "lldp_count": len(data.get("lldp_neighbors", [])),
                "modified_at": datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat(timespec="seconds"),
                "facts": data,
            })
        except (OSError, ValueError, TypeError):
            continue
    return reports


@app.delete("/api/reports/{filename}", status_code=204)
def delete_fact_report(filename: str, req: Request, _: dict[str, Any] = Depends(require_user)) -> Response:
    require_csrf(req)
    if not re.fullmatch(r"[A-Za-z0-9_.-]+-facts\.json", filename) or Path(filename).name != filename:
        raise HTTPException(400, "Можно удалять только отчёты сбора фактов.")
    target = REPORTS / filename
    if target.is_symlink() or not target.is_file():
        raise HTTPException(404, "Отчёт не найден.")
    target.unlink()
    return Response(status_code=204)


def sync_preflight(limit: str | None) -> None:
    """Validate every target before starting a job so a bad later host cannot cause partial writes."""
    with db() as conn:
        rows = conn.execute("SELECT * FROM devices WHERE protocol='ssh' ORDER BY name COLLATE NOCASE").fetchall()
    if limit:
        targets = {name.strip() for name in limit.split(",") if name.strip()}
        rows = [row for row in rows if row["name"] in targets]
    if not rows:
        raise RuntimeError("No SSH-capable local inventory devices match the synchronization target.")
    cfg = project_config()
    type_map = cfg.get("netbox_device_type_map", {}) if isinstance(cfg, dict) else {}
    now_ts = datetime.now(timezone.utc).timestamp()
    batch_ids: set[str] = set()
    for row in rows:
        safe_name = re.sub(r"[^A-Za-z0-9_.-]", "_", row["name"])
        report_path = REPORTS / f"{safe_name}-facts.json"
        if not report_path.is_file() or now_ts - report_path.stat().st_mtime >= 86400:
            raise RuntimeError(f"Missing or stale facts report for {row['name']}; collect and review facts for all target devices first.")
        try:
            report = json.loads(report_path.read_text(encoding="utf-8"))
            settings = json.loads(row["settings_json"] or "{}")
        except (OSError, ValueError, TypeError):
            raise RuntimeError(f"Facts report or local settings for {row['name']} are not valid JSON.")
        if report.get("device") != row["name"] or not report.get("model") or not isinstance(report.get("interfaces"), dict) or not report["interfaces"] or not report.get("collection_id"):
            raise RuntimeError(f"Facts report for {row['name']} is incomplete, mismatched or from an untracked collection; no NetBox writes were started.")
        batch_ids.add(str(report["collection_id"]))
        if report.get("platform") not in {"huawei", "eltex", "cisco", "snr"}:
            raise RuntimeError(f"Unsupported platform in facts report for {row['name']}.")
        if not isinstance(settings, dict): settings = {}
        expected_profile = str(settings.get("device_profile", "")).strip() or (MODEL_PROFILES.get(str(settings.get("device_model", "")).strip()) or {}).get("profile", "")
        if not expected_profile or report.get("device_profile") != expected_profile:
            raise RuntimeError(f"Facts report for {row['name']} was collected with a different or unsupported model profile; recollect and review before sync.")
        site = settings.get("netbox_site")
        role = settings.get("netbox_role")
        device_type = settings.get("netbox_device_type_slug") or type_map.get(report["model"])
        if not all(isinstance(value, str) and value.strip() for value in (site, role, device_type)):
            raise RuntimeError(f"Set exact netbox_site, netbox_role and netbox_device_type_slug (or model mapping) for {row['name']} before synchronization.")
    if len(batch_ids) != 1:
        raise RuntimeError("Target devices have reports from different collection runs. Collect facts for the same target set, review them, then synchronize that same target set.")


@app.post("/api/jobs", status_code=202)
def create_job(request: JobRequest, req: Request, user: dict[str, Any] = Depends(require_user)) -> dict[str, str]:
    global _active_job
    require_csrf(req)
    if request.mode == "sync":
        if not request.confirm_sync:
            raise HTTPException(400, "Explicit sync confirmation is required.")
        sync_enabled, _ = _netbox_sync_flags()
        if not sync_enabled:
            raise HTTPException(403, "Запись в NetBox выключена. Включите её в разделе Администрирование → Подключение к NetBox.")
        if not project_config().get("netbox_url") or not _netbox_token():
            raise HTTPException(409, "Сначала задайте адрес NetBox и API-токен в разделе Администрирование.")
        try:
            sync_preflight(request.limit)
        except RuntimeError as exc:
            raise HTTPException(409, str(exc)) from exc
    if not _job_lock.acquire(blocking=False):
        raise HTTPException(409, "Another job is already running.")
    job_id = str(uuid.uuid4())
    job = {"id": job_id, "mode": request.mode, "limit": request.limit, "requested_by": user["username"], "status": "running",
           "created_at": now(), "finished_at": None, "return_code": None, "output": "Job started. Output will appear when Ansible exits."}
    with _jobs_lock:
        _jobs[job_id] = job
        _active_job = job_id
    threading.Thread(target=run_job, args=(job_id, request.mode, request.limit), daemon=True).start()
    return {"id": job_id, "status": "running"}


@app.get("/api/jobs/{job_id}")
def get_job(job_id: str, _: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    with _jobs_lock:
        job = _jobs.get(job_id)
        if not job:
            raise HTTPException(404, "Job not found; job history is held in memory until the service restarts.")
        return job


@app.get("/api/admin/netbox")
def get_netbox_settings(_: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    sync_enabled, auto_enabled = _netbox_sync_flags()
    return {"netbox_url": _get_app_setting("netbox_url", project_config().get("netbox_url", "")),
            "token_configured": bool(_netbox_token()), "sync_enabled": sync_enabled,
            "auto_sync_enabled": auto_enabled,
            "auto_sync_trigger": "После каждого успешного ручного или автоматического сбора фактов."}


@app.post("/api/admin/netbox")
def save_netbox_settings(payload: NetBoxSettingsUpdate, req: Request,
                         _: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    require_csrf(req)
    try:
        netbox_url = _validate_netbox_url(payload.netbox_url)
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc
    current_token = _get_app_setting("netbox_api_token_enc", "")
    if payload.clear_token:
        current_token = ""
    if payload.api_token.strip():
        current_token = _CIPHER.encrypt(payload.api_token.strip().encode("utf-8")).decode("ascii")
    effective_token_exists = bool(current_token) or (not payload.clear_token and bool(_netbox_token()))
    if payload.sync_enabled and not effective_token_exists:
        raise HTTPException(400, "Для включения записи в NetBox сначала сохраните API-токен.")
    if payload.auto_sync_enabled and not payload.sync_enabled:
        raise HTTPException(400, "Автоматическая синхронизация требует включённой записи в NetBox.")
    if current_token:
        _set_app_setting("netbox_api_token_enc", current_token)
    elif payload.clear_token:
        _set_app_setting("netbox_api_token_enc", "")
    if payload.api_token.strip():
        _set_app_setting("netbox_api_token_disabled", "false")
    elif payload.clear_token:
        _set_app_setting("netbox_api_token_disabled", "true")
    _set_app_setting("netbox_url", netbox_url)
    _set_app_setting("netbox_sync_enabled", "true" if payload.sync_enabled else "false")
    _set_app_setting("netbox_auto_sync_enabled", "true" if payload.auto_sync_enabled else "false")
    return get_netbox_settings(_)


@app.post("/api/admin/netbox/test")
def test_netbox_connection(req: Request, _: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    require_csrf(req)
    url = _get_app_setting("netbox_url", project_config().get("netbox_url", ""))
    token = _netbox_token()
    if not url:
        raise HTTPException(400, "Сначала укажите адрес NetBox.")
    if not token:
        raise HTTPException(400, "API-токен не найден. Сохраните его в настройках подключения.")
    endpoint = url.rstrip("/") + "/api/dcim/devices/?limit=1"
    last_error = None
    for scheme in ("Token", "Bearer"):
        request_obj = urllib.request.Request(endpoint, headers={"Authorization": f"{scheme} {token}", "Accept": "application/json"})
        try:
            validate_certs = bool(project_config().get("netbox_validate_certs", False))
            context = ssl.create_default_context() if validate_certs else ssl._create_unverified_context()
            with urllib.request.urlopen(request_obj, timeout=10, context=context) as response:
                if 200 <= response.status < 300:
                    return {"ok": True, "message": "Подключение к NetBox успешно; API-токен принят."}
                last_error = f"HTTP {response.status}"
        except urllib.error.HTTPError as exc:
            last_error = f"HTTP {exc.code}"
            if exc.code not in {401, 403}:
                break
        except (urllib.error.URLError, TimeoutError, OSError, ValueError) as exc:
            last_error = str(exc.reason if isinstance(exc, urllib.error.URLError) else exc)
            break
    raise HTTPException(502, f"Не удалось проверить NetBox: {last_error or 'неизвестная ошибка'}. Проверьте URL, сертификат и права API-токена.")


@app.get("/api/admin/vault")
def get_vault_status(_: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    return _vault_status()


@app.post("/api/admin/vault-password")
def update_vault_password(payload: VaultPasswordUpdate, req: Request,
                          _: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    require_csrf(req)
    if payload.new_password != payload.confirm_password:
        raise HTTPException(400, "Новый пароль и подтверждение не совпадают.")
    if "\x00" in payload.new_password or "\n" in payload.new_password or "\r" in payload.new_password:
        raise HTTPException(400, "Пароль не должен содержать символы перевода строки.")

    current = payload.current_password or _legacy_vault_password()
    vault_exists = VAULT_DATA_PATH.is_file()
    encrypted = _vault_file_encrypted() if vault_exists else False
    temp_new: Path | None = None
    temp_current: Path | None = None
    backup: Path | None = None
    try:
        if VAULT_PASSWORD_PATH.exists() and not VAULT_PASSWORD_PATH.is_file():
            raise HTTPException(409, "Путь local_data/vault_pass занят каталогом. Удалите или переименуйте этот каталог и повторите операцию.")
        temp_new = _write_secret_temp(payload.new_password, ".vault-pass-new-")
        if vault_exists and encrypted:
            if not current:
                raise HTTPException(400, "vault.yml уже зашифрован. Введите текущий пароль Vault, чтобы безопасно сменить его.")
            temp_current = _write_secret_temp(current, ".vault-pass-current-")
            backup = DATA / f"vault.yml.before-rekey-{uuid.uuid4().hex}"
            import shutil
            shutil.copy2(VAULT_DATA_PATH, backup)
            backup.chmod(0o600)
            proc = subprocess.run(["ansible-vault", "rekey", "--vault-password-file", str(temp_current),
                                   "--new-vault-password-file", str(temp_new), str(VAULT_DATA_PATH)],
                                  cwd=ROOT, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                  stderr=subprocess.STDOUT, text=True, timeout=60, check=False)
            if proc.returncode != 0:
                shutil.copy2(backup, VAULT_DATA_PATH)
                VAULT_DATA_PATH.chmod(0o600)
                raise HTTPException(400, "Не удалось сменить пароль Vault: текущий пароль неверен или ansible-vault завершился с ошибкой. Проверьте журнал задачи/установку Ansible.")
        elif vault_exists:
            content = VAULT_DATA_PATH.read_text(encoding="utf-8", errors="replace")
            if "CHANGE_ME" not in content and "vault_netbox_token:" in content:
                import shutil
                backup = DATA / f"vault.yml.before-encrypt-{uuid.uuid4().hex}"
                shutil.copy2(VAULT_DATA_PATH, backup)
                backup.chmod(0o600)
                proc = subprocess.run(["ansible-vault", "encrypt", "--vault-password-file", str(temp_new), str(VAULT_DATA_PATH)],
                                      cwd=ROOT, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                      stderr=subprocess.STDOUT, text=True, timeout=60, check=False)
                if proc.returncode != 0:
                    shutil.copy2(backup, VAULT_DATA_PATH)
                    VAULT_DATA_PATH.chmod(0o600)
                    raise HTTPException(400, "Не удалось зашифровать vault.yml. Файл восстановлен без изменений.")
        # Atomic replacement: Ansible never sees a partially written password file.
        temp_new.replace(VAULT_PASSWORD_PATH)
        VAULT_PASSWORD_PATH.chmod(0o600)
        if backup:
            backup.unlink(missing_ok=True)
        return _vault_status()
    except HTTPException:
        raise
    except FileNotFoundError as exc:
        raise HTTPException(503, "Команда ansible-vault недоступна в окружении приложения.") from exc
    except subprocess.TimeoutExpired as exc:
        if backup and backup.exists():
            import shutil
            shutil.copy2(backup, VAULT_DATA_PATH)
            VAULT_DATA_PATH.chmod(0o600)
        raise HTTPException(503, "Операция Vault превысила лимит времени; исходный файл восстановлен.") from exc
    except OSError as exc:
        if backup and backup.exists():
            import shutil
            try:
                shutil.copy2(backup, VAULT_DATA_PATH)
                VAULT_DATA_PATH.chmod(0o600)
            except OSError:
                pass
        raise HTTPException(500, "Не удалось записать защищённые файлы Vault. Проверьте права на local_data.") from exc
    finally:
        for path in (temp_new, temp_current):
            if path:
                path.unlink(missing_ok=True)
        if backup:
            backup.unlink(missing_ok=True)


@app.get("/api/users")
def list_users(_: dict[str, Any] = Depends(require_admin)) -> list[dict[str, Any]]:
    with db() as conn:
        rows = conn.execute("SELECT id,username,enabled,created_at,updated_at FROM users ORDER BY username COLLATE NOCASE").fetchall()
    return [dict(row) for row in rows]


@app.post("/api/users", status_code=201)
def create_user(payload: UserCreate, req: Request, admin: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    require_csrf(req)
    stamp = now()
    try:
        encoded = hash_password(payload.password)
        with db() as conn:
            cur = conn.execute("INSERT INTO users(username,password_hash,role,enabled,created_at,updated_at) VALUES(?,?,'admin',1,?,?)",
                               (payload.username, encoded, stamp, stamp))
            user_id = cur.lastrowid
    except sqlite3.IntegrityError:
        raise HTTPException(409, "Username already exists.")
    return {"id": user_id, "username": payload.username, "enabled": True, "created_at": stamp, "updated_at": stamp}


@app.patch("/api/users/{user_id}")
def update_user(user_id: int, payload: UserUpdate, req: Request, admin: dict[str, Any] = Depends(require_admin)) -> dict[str, Any]:
    require_csrf(req)
    if payload.password is None and payload.enabled is None:
        raise HTTPException(400, "No changes supplied.")
    with db() as conn:
        row = conn.execute("SELECT id,username,role,enabled FROM users WHERE id=?", (user_id,)).fetchone()
        if not row:
            raise HTTPException(404, "User not found.")
        new_enabled = int(payload.enabled) if payload.enabled is not None else row["enabled"]
        if row["id"] == admin["id"] and not new_enabled:
            raise HTTPException(400, "You cannot disable your own account.")
        encoded = hash_password(payload.password) if payload.password is not None else None
        if encoded:
            conn.execute("UPDATE users SET password_hash=?,enabled=?,updated_at=? WHERE id=?", (encoded,new_enabled,now(),user_id))
        else:
            conn.execute("UPDATE users SET enabled=?,updated_at=? WHERE id=?", (new_enabled,now(),user_id))
        updated = conn.execute("SELECT id,username,enabled,created_at,updated_at FROM users WHERE id=?", (user_id,)).fetchone()
    return dict(updated)


@app.delete("/api/users/{user_id}", status_code=204)
def delete_user(user_id: int, req: Request, admin: dict[str, Any] = Depends(require_admin)) -> Response:
    require_csrf(req)
    with db() as conn:
        row = conn.execute("SELECT id,username FROM users WHERE id=?", (user_id,)).fetchone()
        if not row:
            raise HTTPException(404, "User not found.")
        if row["id"] == admin["id"]:
            raise HTTPException(400, "You cannot delete your own account.")
        conn.execute("DELETE FROM users WHERE id=?", (user_id,))
    return Response(status_code=204)


@app.post("/api/account/password")
def change_own_password(payload: dict[str, str], req: Request, user: dict[str, Any] = Depends(require_user)) -> dict[str, bool]:
    require_csrf(req)
    old_password, new_password = payload.get("old_password", ""), payload.get("new_password", "")
    with db() as conn:
        row = conn.execute("SELECT password_hash FROM users WHERE id=?", (user["id"],)).fetchone()
        if not row or not verify_password(old_password, row["password_hash"]):
            raise HTTPException(400, "Current password is incorrect.")
        try:
            encoded = hash_password(new_password)
        except ValueError as exc:
            raise HTTPException(400, str(exc))
        conn.execute("UPDATE users SET password_hash=?,updated_at=? WHERE id=?", (encoded,now(),user["id"]))
    req.session.clear()
    return {"ok": True}


# SSH host keys are persisted in the same directory mounted at /root/.ssh so Ansible's
# Paramiko network_cli transport can use them. First use is TOFU; changed keys are never
# silently replaced.
_HOSTKEY_LOCK = threading.Lock()

def _known_host_token(address: str, port: int) -> str:
    return address if int(port) == 22 else f"[{address}]:{int(port)}"

def _scan_paramiko_ssh_key(address: str, port: int) -> list[str]:
    """Negotiate an SSH host key with Paramiko, including legacy algorithms used by network gear.

    This performs key exchange only: no username/password authentication and no device commands.
    Modern algorithms retain preference; legacy SHA-1 KEX and ssh-rsa/ssh-dss remain available
    as fallbacks for older firmware. The returned key is still handled by the existing TOFU flow.
    """
    try:
        import paramiko
        with socket.create_connection((address, int(port)), timeout=10) as sock:
            transport = paramiko.Transport(sock)
            try:
                transport.banner_timeout = 10
                transport.auth_timeout = 10
                security = transport.get_security_options()
                # Preserve Paramiko's modern-first preference order while ensuring common legacy
                # exchanges remain enabled for firmware that offers no modern KEX algorithm.
                legacy_kex = (
                    "diffie-hellman-group14-sha1",
                    "diffie-hellman-group-exchange-sha1",
                    "diffie-hellman-group1-sha1",
                )
                supported_kex = tuple(paramiko.Transport._preferred_kex)
                security.kex = tuple(dict.fromkeys((*security.kex, *(k for k in legacy_kex if k in supported_kex))))
                # Add older ciphers/MACs and host-key types only when this Paramiko build supports
                # them. Modern algorithms remain first; legacy choices are fallbacks, not defaults.
                supported_ciphers = tuple(paramiko.Transport._preferred_ciphers)
                legacy_ciphers = ("aes128-cbc", "aes192-cbc", "aes256-cbc", "3des-cbc")
                security.ciphers = tuple(dict.fromkeys((*security.ciphers, *(k for k in legacy_ciphers if k in supported_ciphers))))
                supported_macs = tuple(paramiko.Transport._preferred_macs)
                legacy_macs = ("hmac-sha1", "hmac-sha1-96", "hmac-md5", "hmac-md5-96")
                security.digests = tuple(dict.fromkeys((*security.digests, *(k for k in legacy_macs if k in supported_macs))))
                supported_keys = tuple(paramiko.Transport._preferred_keys)
                legacy_keys = ("ssh-rsa", "ssh-dss", "ecdsa-sha2-nistp521")
                security.key_types = tuple(dict.fromkeys((*security.key_types, *(k for k in legacy_keys if k in supported_keys))))
                transport.start_client(timeout=10)
                key = transport.get_remote_server_key()
                if key is None:
                    return []
                return [f"{_known_host_token(address, port)} {key.get_name()} {key.get_base64()}"]
            finally:
                transport.close()
    except ImportError:
        logger.error("Paramiko is not installed; cannot scan SSH host key for %s:%s", address, port)
        return []
    except Exception:
        logger.exception("Could not scan SSH host key with Paramiko for %s:%s", address, port)
        return []

def _scan_ssh_keys(address: str, port: int) -> list[str]:
    # Pass address as a separate argument; reject option-like values before any network operation.
    if not re.fullmatch(r"[A-Za-z0-9_.:-]+", address) or address.startswith("-"):
        raise RuntimeError("Некорректный IP/DNS для SSH-проверки.")
    return _scan_paramiko_ssh_key(address, port)


def _fingerprints(lines: list[str]) -> list[str]:
    import base64
    result=set()
    for line in lines:
        parts=line.split()
        if len(parts)<3:
            continue
        try:
            blob=base64.b64decode(parts[2].encode(), validate=True)
        except (ValueError, TypeError):
            continue
        digest=base64.b64encode(hashlib.sha256(blob).digest()).decode().rstrip("=")
        result.add("SHA256:"+digest)
    return sorted(result)

def _host_key_status(address: str, port: int, candidates: list[str], *, replace: bool = False) -> dict[str, Any]:
    token=_known_host_token(address, port)
    SSH_DIR.mkdir(parents=True, exist_ok=True)
    try: SSH_DIR.chmod(0o700)
    except OSError: pass
    with _HOSTKEY_LOCK:
        if not KNOWN_HOSTS_PATH.exists():
            KNOWN_HOSTS_PATH.touch(mode=0o600)
        try: KNOWN_HOSTS_PATH.chmod(0o600)
        except OSError: pass
        existing=[]
        try:
            for raw in KNOWN_HOSTS_PATH.read_text(encoding="utf-8", errors="replace").splitlines():
                line=raw.strip()
                if not line or line.startswith("#") or line.startswith("@"):
                    continue
                parts=line.split()
                if len(parts)>=3 and token in parts[0].split(","):
                    existing.append(f"{token} {parts[1]} {parts[2]}")
        except OSError:
            pass
        # ssh-keygen -F also resolves hashed OpenSSH known_hosts entries; keep a parser fallback
        # for minimal test environments where the binary is not installed.
        import shutil
        if not existing and shutil.which("ssh-keygen"):
            try:
                lookup=subprocess.run(["ssh-keygen", "-F", token, "-f", str(KNOWN_HOSTS_PATH)], capture_output=True, text=True, timeout=5, check=False)
                for raw in lookup.stdout.splitlines():
                    line=raw.strip()
                    if not line or line.startswith("#") or line.startswith("@"):
                        continue
                    parts=line.split()
                    if len(parts)>=3:
                        existing.append(f"{token} {parts[-2]} {parts[-1]}")
            except (OSError, subprocess.TimeoutExpired):
                pass
        old_fps=_fingerprints(existing)
        new_fps=_fingerprints(candidates)
        old_keys={(line.split()[1],line.split()[2]) for line in existing if len(line.split())>=3}
        new_keys={(line.split()[1],line.split()[2]) for line in candidates if len(line.split())>=3}
        if not candidates:
            return {"state":"unavailable", "message":"SSH-порт доступен, но получить SSH host key не удалось.", "old_fingerprints":old_fps, "new_fingerprints":[]}
        if not existing:
            with KNOWN_HOSTS_PATH.open("a", encoding="utf-8") as f:
                f.write("\n".join(candidates)+"\n")
            KNOWN_HOSTS_PATH.chmod(0o600)
            return {"state":"added", "message":"Новый SSH host key автоматически добавлен в known_hosts (TOFU).", "old_fingerprints":[], "new_fingerprints":new_fps}
        if old_keys == new_keys or new_keys.issubset(old_keys):
            return {"state":"trusted", "message":"SSH host key совпадает с известным.", "old_fingerprints":old_fps, "new_fingerprints":new_fps}
        if not replace:
            return {"state":"changed", "message":"SSH host key изменился. SSH-операции требуют явного подтверждения нового ключа.", "old_fingerprints":old_fps, "new_fingerprints":new_fps}
        import shutil
        if shutil.which("ssh-keygen"):
            try:
                subprocess.run(["ssh-keygen", "-R", token, "-f", str(KNOWN_HOSTS_PATH)], capture_output=True, text=True, timeout=5, check=False)
            except (OSError, subprocess.TimeoutExpired):
                pass
        kept=[]
        for raw in KNOWN_HOSTS_PATH.read_text(encoding="utf-8", errors="replace").splitlines():
            parts=raw.strip().split()
            if len(parts)>=3 and token in parts[0].split(","):
                continue
            kept.append(raw)
        with KNOWN_HOSTS_PATH.open("w", encoding="utf-8") as f:
            f.write("\n".join(kept + candidates)+"\n")
        KNOWN_HOSTS_PATH.chmod(0o600)
        return {"state":"replaced", "message":"SSH host key обновлён после явного подтверждения.", "old_fingerprints":old_fps, "new_fingerprints":new_fps}

class HostKeyReplace(BaseModel):
    confirm_fingerprint: str = Field(min_length=1, max_length=256)

def _record_host_key_event(device_id: int, address: str, port: int, event: str, result: dict[str, Any]) -> None:
    with db() as conn:
        conn.execute("INSERT INTO host_key_events(device_id,address,port,event,old_fingerprints_json,new_fingerprints_json,created_at) VALUES(?,?,?,?,?,?,?)",
                     (device_id, address, int(port), event,
                      json.dumps(result.get("old_fingerprints", [])), json.dumps(result.get("new_fingerprints", [])), now()))

# Device-management and topology APIs. Credentials are encrypted at rest
# and deliberately omitted from every API response, job log and report.
def _device_public(row: sqlite3.Row, conn: sqlite3.Connection | None = None) -> dict[str, Any]:
    result = {k: row[k] for k in ("id", "name", "vendor", "address", "device_type", "protocol", "port", "username", "settings_json", "created_at", "updated_at")}
    result["virtual_chassis_id"] = None
    result["virtual_chassis_name"] = None
    result["virtual_chassis_role"] = None
    if conn is not None:
        membership = conn.execute("SELECT m.chassis_id,v.name FROM virtual_chassis_members m JOIN virtual_chassis v ON v.id=m.chassis_id WHERE m.device_id=?", (row["id"],)).fetchone()
        if membership:
            result["virtual_chassis_id"] = membership["chassis_id"]
            result["virtual_chassis_name"] = membership["name"]
            result["virtual_chassis_role"] = "member"
    return result

def _assign_device_virtual_chassis(conn: sqlite3.Connection, device_id: int, chassis_id: int | None) -> None:
    if chassis_id is None:
        conn.execute("DELETE FROM virtual_chassis_members WHERE device_id=?", (device_id,))
        return
    chassis = conn.execute("SELECT id,vendor FROM virtual_chassis WHERE id=?", (chassis_id,)).fetchone()
    if not chassis:
        raise HTTPException(400, "Выбранное общее логическое устройство не найдено.")
    device = conn.execute("SELECT vendor FROM devices WHERE id=?", (device_id,)).fetchone()
    if not device or str(device["vendor"]).strip().casefold() != str(chassis["vendor"]).strip().casefold():
        raise HTTPException(400, "Производитель участника должен совпадать с производителем логического объекта.")
    occupied = conn.execute("SELECT chassis_id FROM virtual_chassis_members WHERE device_id=?", (device_id,)).fetchone()
    if occupied and occupied["chassis_id"] != chassis_id:
        conn.execute("DELETE FROM virtual_chassis_members WHERE device_id=?", (device_id,))
    try:
        conn.execute("INSERT OR IGNORE INTO virtual_chassis_members(chassis_id,device_id,created_at) VALUES(?,?,?)", (chassis_id, device_id, now()))
    except sqlite3.IntegrityError:
        raise HTTPException(409, "Не удалось связать устройство с общим логическим объектом.")

def _device_secret(row: sqlite3.Row) -> str:
    try:
        return _CIPHER.decrypt(row["credentials_enc"].encode()).decode()
    except (InvalidToken, ValueError, TypeError):
        raise HTTPException(500, "Stored device credential cannot be decrypted; check the protected key file.")

@app.get("/api/devices")
def list_devices(_: dict[str, Any] = Depends(require_user)) -> list[dict[str, Any]]:
    with db() as conn:
        rows = conn.execute("SELECT * FROM devices ORDER BY name COLLATE NOCASE").fetchall()
        return [_device_public(r, conn) for r in rows]

@app.post("/api/devices", status_code=201)
def create_device(payload: DeviceCreate, req: Request, _: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    require_csrf(req)
    stamp = now()
    encrypted = _CIPHER.encrypt(payload.password.encode()).decode()
    try:
        with db() as conn:
            cur = conn.execute("""INSERT INTO devices(name,vendor,address,device_type,protocol,port,username,credentials_enc,settings_json,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?,?,?,?)""", (payload.name.strip(),payload.vendor.strip(),payload.address.strip(),payload.device_type,payload.protocol,payload.port,payload.username,encrypted,json.dumps(payload.settings,ensure_ascii=False),stamp,stamp))
            if payload.virtual_chassis_id is not None:
                _assign_device_virtual_chassis(conn, cur.lastrowid, payload.virtual_chassis_id)
            row = conn.execute("SELECT * FROM devices WHERE id=?", (cur.lastrowid,)).fetchone()
    except sqlite3.IntegrityError:
        raise HTTPException(409, "Устройство с таким именем уже существует.")
    with db() as conn:
        result = _device_public(row, conn)
    if payload.protocol == "ssh":
        candidates = _scan_ssh_keys(payload.address.strip(), payload.port)
        key_status = _host_key_status(payload.address.strip(), payload.port, candidates)
        result["host_key"] = key_status
        if key_status["state"] in {"added", "changed", "unavailable"}:
            _record_host_key_event(row["id"], payload.address.strip(), payload.port, key_status["state"], key_status)
    return result

@app.patch("/api/devices/{device_id}")
def update_device(device_id: int, payload: DeviceUpdate, req: Request, _: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    require_csrf(req)
    data = payload.model_dump(exclude_unset=True)
    if not data:
        raise HTTPException(400, "Не указаны изменения.")
    with db() as conn:
        old = conn.execute("SELECT * FROM devices WHERE id=?", (device_id,)).fetchone()
        if not old: raise HTTPException(404, "Устройство не найдено.")
        fields=[]; values=[]
        chassis_id = data.pop("virtual_chassis_id", ...)
        for key,value in data.items():
            if key == "password":
                if value == "": continue
                key="credentials_enc"; value=_CIPHER.encrypt(value.encode()).decode()
            elif key == "settings":
                key="settings_json"; value=json.dumps(value,ensure_ascii=False)
            fields.append(f"{key}=?"); values.append(value)
        fields.append("updated_at=?"); values.extend([now(), device_id])
        try:
            conn.execute(f"UPDATE devices SET {','.join(fields)} WHERE id=?", values)
        except sqlite3.IntegrityError:
            raise HTTPException(409, "Устройство с таким именем уже существует.")
        if chassis_id is not ...:
            _assign_device_virtual_chassis(conn, device_id, chassis_id)
        row=conn.execute("SELECT * FROM devices WHERE id=?",(device_id,)).fetchone()
        return _device_public(row, conn)

@app.delete("/api/devices/{device_id}", status_code=204)
def delete_device(device_id: int, req: Request, _: dict[str, Any] = Depends(require_user)) -> Response:
    require_csrf(req)
    with db() as conn:
        cur=conn.execute("DELETE FROM devices WHERE id=?",(device_id,))
        if cur.rowcount == 0: raise HTTPException(404,"Устройство не найдено.")
    return Response(status_code=204)

@app.post("/api/devices/{device_id}/test")
def test_device(device_id: int, req: Request, _: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    require_csrf(req)
    with db() as conn:
        row=conn.execute("SELECT * FROM devices WHERE id=?",(device_id,)).fetchone()
        if not row: raise HTTPException(404,"Устройство не найдено.")
    # On-demand SSH host-key diagnostic only; no availability state or check history is stored.
    if row["protocol"] != "ssh":
        raise HTTPException(400, "Проверка SSH host key доступна только для SSH-устройств.")
    started=datetime.now(timezone.utc)
    host_key = None
    try:
        with socket.create_connection((row["address"],row["port"]),timeout=4): pass
        state="ok"; message=f"TCP-порт {row['port']} доступен. Аутентификация и CLI не проверялись."
        if row["protocol"] == "ssh":
            candidates=_scan_ssh_keys(row["address"], row["port"])
            host_key=_host_key_status(row["address"], row["port"], candidates)
            if host_key["state"] in {"added", "changed", "unavailable"}:
                _record_host_key_event(device_id, row["address"], row["port"], host_key["state"], host_key)
            message += " " + host_key["message"]
            if host_key["state"] == "changed": state="hostkey_changed"
    except (OSError, TimeoutError) as exc:
        raise HTTPException(502, f"SSH/TCP diagnostic failed ({type(exc).__name__}).") from exc
    elapsed = int((datetime.now(timezone.utc)-started).total_seconds()*1000)
    result={"device_id":device_id,"status":state,"message":message,"elapsed_ms":elapsed}
    if host_key: result["host_key"] = host_key
    return result

@app.post("/api/devices/{device_id}/host-key/replace")
def replace_device_host_key(device_id: int, payload: HostKeyReplace, req: Request, _: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    require_csrf(req)
    with db() as conn:
        row=conn.execute("SELECT * FROM devices WHERE id=?",(device_id,)).fetchone()
    if not row: raise HTTPException(404,"Устройство не найдено.")
    if row["protocol"] != "ssh": raise HTTPException(400,"Устройство не использует SSH.")
    candidates=_scan_ssh_keys(row["address"], row["port"])
    new_fingerprints=_fingerprints(candidates)
    if not candidates or payload.confirm_fingerprint not in new_fingerprints:
        raise HTTPException(409,"SSH host key изменился после просмотра или не удалось подтвердить указанный отпечаток. Повторите проверку.")
    result=_host_key_status(row["address"], row["port"], candidates, replace=True)
    _record_host_key_event(device_id, row["address"], row["port"], "replaced", result)
    return {"device_id":device_id, **result}

@app.get("/api/devices/{device_id}/host-key/events")
def list_host_key_events(device_id: int, _: dict[str, Any] = Depends(require_user)) -> list[dict[str, Any]]:
    with db() as conn:
        if not conn.execute("SELECT id FROM devices WHERE id=?", (device_id,)).fetchone():
            raise HTTPException(404, "Устройство не найдено.")
        rows=conn.execute("SELECT id,address,port,event,old_fingerprints_json,new_fingerprints_json,created_at FROM host_key_events WHERE device_id=? ORDER BY id DESC LIMIT 50", (device_id,)).fetchall()
    return [{"id":r["id"],"address":r["address"],"port":r["port"],"event":r["event"],"old_fingerprints":json.loads(r["old_fingerprints_json"]),"new_fingerprints":json.loads(r["new_fingerprints_json"]),"created_at":r["created_at"]} for r in rows]

@app.get("/api/devices/{device_id}/configs")
def list_configs(device_id: int, _: dict[str, Any] = Depends(require_user)) -> list[dict[str, Any]]:
    with db() as conn:
        if not conn.execute("SELECT id FROM devices WHERE id=?",(device_id,)).fetchone(): raise HTTPException(404,"Устройство не найдено.")
        rows=conn.execute("SELECT id,captured_at,source FROM config_snapshots WHERE device_id=? ORDER BY id DESC LIMIT 20",(device_id,)).fetchall()
    return [dict(r) for r in rows]

@app.post("/api/devices/{device_id}/configs", status_code=201)
def capture_config(device_id: int, payload: ConfigCapture, req: Request, _: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    require_csrf(req)
    with db() as conn:
        if not conn.execute("SELECT id FROM devices WHERE id=?",(device_id,)).fetchone(): raise HTTPException(404,"Устройство не найдено.")
        safe_config = sanitize_config(payload.config_text)
        cur=conn.execute("INSERT INTO config_snapshots(device_id,captured_at,config_text,source) VALUES(?,?,?,?)",(device_id,now(),safe_config,payload.source))
        rows=conn.execute("SELECT id,captured_at,config_text FROM config_snapshots WHERE device_id=? ORDER BY id DESC LIMIT 2",(device_id,)).fetchall()
    diff=[]
    if len(rows)>1:
        previous=rows[1]["config_text"].splitlines(keepends=True); current=rows[0]["config_text"].splitlines(keepends=True)
        diff=list(difflib.unified_diff(previous,current,fromfile=f"snapshot-{rows[1]['id']}",tofile=f"snapshot-{rows[0]['id']}",lineterm=""))
    return {"id":cur.lastrowid,"captured_at":now(),"previous_snapshot_id":rows[1]["id"] if len(rows)>1 else None,"has_changes":bool(diff),"diff":diff}

@app.get("/api/devices/{device_id}/configs/{snapshot_id}/diff")
def config_diff(device_id: int, snapshot_id: int, _: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    with db() as conn:
        rows=conn.execute("SELECT id,captured_at,config_text FROM config_snapshots WHERE device_id=? AND id<=? ORDER BY id DESC LIMIT 2",(device_id,snapshot_id)).fetchall()
    if not rows or rows[0]["id"] != snapshot_id: raise HTTPException(404,"Снимок конфигурации не найден.")
    diff=[]
    if len(rows)>1: diff=list(difflib.unified_diff(rows[1]["config_text"].splitlines(),rows[0]["config_text"].splitlines(),fromfile=rows[1]["captured_at"],tofile=rows[0]["captured_at"],lineterm=""))
    return {"snapshot_id":snapshot_id,"captured_at":rows[0]["captured_at"],"previous_snapshot_id":rows[1]["id"] if len(rows)>1 else None,"has_changes":bool(diff),"diff":diff}

class VirtualChassisCreate(BaseModel):
    name: str = Field(min_length=1, max_length=128, pattern=r"^[A-Za-z0-9_.:@ -]+$")
    vendor: str = Field(default="Other", min_length=1, max_length=64)
    member_device_ids: list[int] = Field(default_factory=list, max_length=16)
    logical_data: dict[str, Any] = Field(default_factory=dict)
    notes: str = Field(default="", max_length=2000)


class VirtualChassisUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str | None = Field(default=None, min_length=1, max_length=128, pattern=r"^[A-Za-z0-9_.:@ -]+$")
    vendor: str | None = Field(default=None, min_length=1, max_length=64)
    member_device_ids: list[int] | None = Field(default=None, max_length=16)
    logical_data: dict[str, Any] | None = None
    notes: str | None = Field(default=None, max_length=2000)


def _virtual_chassis_public(conn: sqlite3.Connection, row: sqlite3.Row) -> dict[str, Any]:
    members = conn.execute("""SELECT d.id,d.name,d.vendor,d.address,d.device_type,d.settings_json
        FROM virtual_chassis_members m JOIN devices d ON d.id=m.device_id
        WHERE m.chassis_id=? ORDER BY d.name COLLATE NOCASE""", (row["id"],)).fetchall()
    try:
        logical_data = json.loads(row["logical_data_json"] or "{}")
    except (TypeError, json.JSONDecodeError):
        logical_data = {}
    return {"id": row["id"], "name": row["name"], "vendor": row["vendor"], "role": "logical",
            "logical_data": logical_data, "notes": row["notes"],
            "members": [dict(m) for m in members], "created_at": row["created_at"], "updated_at": row["updated_at"]}


def _set_virtual_chassis_members(conn: sqlite3.Connection, chassis_id: int, member_ids: list[int]) -> None:
    ids = list(dict.fromkeys(int(x) for x in member_ids))
    if len(ids) != len(member_ids):
        raise HTTPException(400, "Один физический узел указан несколько раз.")
    if len(ids) > 16:
        raise HTTPException(400, "В виртуальном шасси допускается не более 16 узлов.")
    if ids:
        placeholders = ",".join("?" for _ in ids)
        found = conn.execute(f"SELECT id,vendor FROM devices WHERE id IN ({placeholders})", ids).fetchall()
        if len(found) != len(ids):
            raise HTTPException(400, "Один или несколько физических узлов не найдены в реестре устройств.")
        chassis = conn.execute("SELECT vendor FROM virtual_chassis WHERE id=?", (chassis_id,)).fetchone()
        expected_vendor = str(chassis["vendor"] if chassis else "").strip().casefold()
        mismatched = [str(row["vendor"]) for row in found if str(row["vendor"]).strip().casefold() != expected_vendor]
        if mismatched:
            raise HTTPException(400, "Производитель каждого участника должен совпадать с производителем логического объекта.")
        occupied = conn.execute(f"SELECT device_id,chassis_id FROM virtual_chassis_members WHERE device_id IN ({placeholders}) AND chassis_id!=?", (*ids, chassis_id)).fetchall()
        if occupied:
            raise HTTPException(409, "Физический узел уже включён в другое виртуальное шасси.")
    conn.execute("DELETE FROM virtual_chassis_members WHERE chassis_id=?", (chassis_id,))
    stamp = now()
    conn.executemany("INSERT INTO virtual_chassis_members(chassis_id,device_id,created_at) VALUES(?,?,?)", [(chassis_id, x, stamp) for x in ids])


@app.get("/api/virtual-chassis")
def list_virtual_chassis(_: dict[str, Any] = Depends(require_user)) -> list[dict[str, Any]]:
    with db() as conn:
        rows = conn.execute("SELECT * FROM virtual_chassis ORDER BY name COLLATE NOCASE").fetchall()
        return [_virtual_chassis_public(conn, row) for row in rows]


@app.post("/api/virtual-chassis", status_code=201)
def create_virtual_chassis(payload: VirtualChassisCreate, req: Request, _: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    require_csrf(req)
    stamp = now()
    try:
        with db() as conn:
            cur = conn.execute("INSERT INTO virtual_chassis(name,vendor,logical_data_json,notes,created_at,updated_at) VALUES(?,?,?,?,?,?)",
                (payload.name.strip(), payload.vendor.strip(), json.dumps(payload.logical_data, ensure_ascii=False), payload.notes, stamp, stamp))
            chassis_id = cur.lastrowid
            _set_virtual_chassis_members(conn, chassis_id, payload.member_device_ids)
            row = conn.execute("SELECT * FROM virtual_chassis WHERE id=?", (chassis_id,)).fetchone()
            return _virtual_chassis_public(conn, row)
    except sqlite3.IntegrityError:
        raise HTTPException(409, "Виртуальное шасси с таким именем уже существует или узел уже занят.")


@app.patch("/api/virtual-chassis/{chassis_id}")
def update_virtual_chassis(chassis_id: int, payload: VirtualChassisUpdate, req: Request, _: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    require_csrf(req)
    data = payload.model_dump(exclude_unset=True)
    if not data:
        raise HTTPException(400, "Не указаны изменения.")
    with db() as conn:
        current_chassis = conn.execute("SELECT id,vendor FROM virtual_chassis WHERE id=?", (chassis_id,)).fetchone()
        if not current_chassis:
            raise HTTPException(404, "Виртуальное шасси не найдено.")
        requested_vendor = str(data.get("vendor", current_chassis["vendor"])).strip().casefold()
        current_members = conn.execute("SELECT d.vendor FROM virtual_chassis_members m JOIN devices d ON d.id=m.device_id WHERE m.chassis_id=?", (chassis_id,)).fetchall()
        if any(str(member["vendor"]).strip().casefold() != requested_vendor for member in current_members) and "member_device_ids" not in data:
            raise HTTPException(400, "При смене производителя нужно выбрать участников того же производителя.")
        members = data.pop("member_device_ids", None)
        if "logical_data" in data:
            data["logical_data_json"] = json.dumps(data.pop("logical_data"), ensure_ascii=False)
        if data:
            data["updated_at"] = now()
            fields = ",".join(f"{key}=?" for key in data)
            try:
                conn.execute(f"UPDATE virtual_chassis SET {fields} WHERE id=?", (*data.values(), chassis_id))
            except sqlite3.IntegrityError:
                raise HTTPException(409, "Виртуальное шасси с таким именем уже существует.")
        if members is not None:
            _set_virtual_chassis_members(conn, chassis_id, members)
            conn.execute("UPDATE virtual_chassis SET updated_at=? WHERE id=?", (now(), chassis_id))
        row = conn.execute("SELECT * FROM virtual_chassis WHERE id=?", (chassis_id,)).fetchone()
        return _virtual_chassis_public(conn, row)


@app.get("/api/virtual-chassis/{chassis_id}/vrrp-candidates")
def virtual_chassis_vrrp_candidates(chassis_id: int, _: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    """Aggregate read-only VRRP observations from each member's latest local fact report."""
    with db() as conn:
        chassis = conn.execute("SELECT id,name FROM virtual_chassis WHERE id=?", (chassis_id,)).fetchone()
        if not chassis:
            raise HTTPException(404, "Общее логическое устройство не найдено.")
        members = conn.execute("SELECT d.id,d.name FROM virtual_chassis_members m JOIN devices d ON d.id=m.device_id WHERE m.chassis_id=? ORDER BY d.name COLLATE NOCASE", (chassis_id,)).fetchall()
    observed: dict[tuple[int | str, str], dict[str, Any]] = {}
    missing_reports: list[str] = []
    for member in members:
        safe_name = re.sub(r"[^A-Za-z0-9_.-]", "_", member["name"])
        path = REPORTS / f"{safe_name}-facts.json"
        try:
            report = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            missing_reports.append(member["name"])
            continue
        if report.get("device") != member["name"]:
            missing_reports.append(member["name"])
            continue
        details = report.get("vrrp_details") or []
        summary = report.get("vrrp_summary") or []
        facts = details if details else summary
        for fact in facts:
            vip = str(fact.get("virtual_ip", "")).strip()
            if not vip:
                continue
            raw_id = fact.get("id", "unknown")
            key = (raw_id, vip)
            entry = observed.setdefault(key, {"id": raw_id, "virtual_ip": vip, "interface": fact.get("interface", ""), "members": []})
            if not entry.get("interface") and fact.get("interface"):
                entry["interface"] = fact["interface"]
            entry["members"].append({"device": member["name"], "state": fact.get("state", ""), "priority": fact.get("priority"), "source_ip": fact.get("source_ip", "")})
    candidates = []
    expected_members = {member["name"] for member in members}
    for entry in observed.values():
        vip = entry["virtual_ip"]
        address, slash, prefix = vip.partition("/")
        entry["ip_addresses"] = [f"{address}/{prefix}"] if slash and prefix.isdigit() else [vip]
        warnings: list[str] = []
        try:
            vip_iface = ipaddress.ip_interface(vip)
        except ValueError:
            vip_iface = None
            warnings.append(f"Некорректный формат виртуального IP: {vip}")
        observed_members = {member["device"] for member in entry["members"]}
        missing_members = sorted(expected_members - observed_members)
        if missing_members:
            warnings.append("Нет наблюдения этой VRRP-группы от участников: " + ", ".join(missing_members))
        for member in entry["members"]:
            source_ip = str(member.get("source_ip", "")).strip()
            if not source_ip:
                warnings.append(f"{member['device']}: в отчёте не указан source_ip")
                continue
            try:
                ipaddress.ip_interface(source_ip) if "/" in source_ip else ipaddress.ip_address(source_ip)
            except ValueError:
                warnings.append(f"{member['device']}: некорректный source_ip {source_ip}")
        entry["warnings"] = warnings
        candidates.append(entry)
    candidates.sort(key=lambda item: (str(item["id"]), item["virtual_ip"]))
    return {"chassis_id": chassis_id, "chassis_name": chassis["name"], "candidates": candidates, "members_without_fresh_report": missing_reports, "note": "Кандидаты рассчитаны только по последним локальным отчётам; импорт не изменяет устройство и не отправляет данные в NetBox."}


def _huawei_eth_trunk_subinterfaces(config_text: str) -> dict[str, list[str]]:
    """Return normalized configuration blocks for Huawei Eth-Trunk subinterfaces."""
    found: dict[str, list[str]] = {}
    current_name: str | None = None
    current_lines: list[str] = []
    pattern = re.compile(r"(?i)^\s*interface\s+(eth-trunk\s*\d+\.\d+)\s*$")
    any_interface = re.compile(r"(?i)^\s*interface\s+\S+")
    def flush() -> None:
        if current_name:
            # Ignore empty lines and normalize whitespace/case for robust comparison.
            found[current_name] = [re.sub(r"\s+", " ", line.strip()).lower() for line in current_lines if line.strip()]
    for line in config_text.splitlines():
        match = pattern.match(line)
        if match:
            flush()
            current_name = re.sub(r"\s+", "", match.group(1)).lower()
            current_lines = []
        elif any_interface.match(line):
            flush()
            current_name = None
            current_lines = []
        elif current_name:
            # Huawei configuration blocks usually end with 'return' or 'quit'; retain
            # commands only, not terminal prompts or separators.
            if line.strip().lower() not in {"return", "quit"}:
                current_lines.append(line)
    flush()
    return found


@app.get("/api/virtual-chassis/{chassis_id}/eth-trunk-subinterfaces")
def virtual_chassis_eth_trunk_subinterfaces(chassis_id: int, _: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    """Compare the latest saved Huawei configs and report identical Eth-Trunk subinterfaces."""
    with db() as conn:
        chassis = conn.execute("SELECT id,name,vendor FROM virtual_chassis WHERE id=?", (chassis_id,)).fetchone()
        if not chassis:
            raise HTTPException(404, "Общее логическое устройство не найдено.")
        if str(chassis["vendor"]).strip().lower() != "huawei":
            raise HTTPException(400, "Сравнение Eth-Trunk саб-интерфейсов доступно только для Huawei.")
        members = conn.execute("""SELECT d.id,d.name FROM virtual_chassis_members m
            JOIN devices d ON d.id=m.device_id WHERE m.chassis_id=? ORDER BY d.name COLLATE NOCASE""", (chassis_id,)).fetchall()
        snapshots = {}
        for member in members:
            snap = conn.execute("SELECT id,captured_at,config_text FROM config_snapshots WHERE device_id=? ORDER BY id DESC LIMIT 1", (member["id"],)).fetchone()
            if snap:
                snapshots[member["name"]] = dict(snap)
    if len(members) != 2:
        raise HTTPException(400, "Для сравнения Huawei выберите ровно два физических узла.")
    missing = [m["name"] for m in members if m["name"] not in snapshots]
    if missing:
        return {"chassis_id": chassis_id, "chassis_name": chassis["name"], "candidates": [], "different_config": [],
                "members_without_config": missing, "note": "Сохраните снимок конфигурации обоих узлов и повторите сравнение."}
    names = [m["name"] for m in members]
    parsed = {name: _huawei_eth_trunk_subinterfaces(snapshots[name]["config_text"]) for name in names}
    common = sorted(set(parsed[names[0]]) & set(parsed[names[1]]), key=lambda x: (int(re.search(r"eth-trunk(\d+)", x, re.I).group(1)), int(x.rsplit(".", 1)[1])))
    candidates = []
    different = []
    for name in common:
        item = {"name": name, "members": names, "config": parsed[names[0]][name],
                "source_snapshot_ids": {n: snapshots[n]["id"] for n in names}}
        if parsed[names[0]][name] == parsed[names[1]][name]:
            candidates.append(item)
        else:
            different.append({"name": name, "reason": "Имя саб-интерфейса совпадает, но конфигурационные команды различаются."})
    return {"chassis_id": chassis_id, "chassis_name": chassis["name"], "candidates": candidates,
            "different_config": different, "members_without_config": [],
            "snapshots": {n: {"id": snapshots[n]["id"], "captured_at": snapshots[n]["captured_at"]} for n in names},
            "note": "В кандидаты попали только саб-интерфейсы с одинаковым именем и одинаковыми командами в последних сохранённых конфигурациях. Результат пока не отправляется в NetBox."}


@app.delete("/api/virtual-chassis/{chassis_id}", status_code=204)
def delete_virtual_chassis(chassis_id: int, req: Request, _: dict[str, Any] = Depends(require_user)) -> Response:
    require_csrf(req)
    with db() as conn:
        cur = conn.execute("DELETE FROM virtual_chassis WHERE id=?", (chassis_id,))
        if not cur.rowcount:
            raise HTTPException(404, "Виртуальное шасси не найдено.")
    return Response(status_code=204)


def _normalise_mac(value: Any) -> str:
    raw = re.sub(r"[^0-9a-fA-F]", "", str(value or ""))
    return raw.lower() if len(raw) == 12 and re.fullmatch(r"[0-9a-fA-F]{12}", raw) else ""


def _normalise_interface(value: Any) -> str:
    text = re.sub(r"\s+", "", str(value or "")).lower()
    aliases = (("gigabitethernet", "gi"), ("tengigabitethernet", "te"), ("fastethernet", "fa"),
               ("fortygigabitethernet", "fo"), ("hundredgigabitethernet", "hu"), ("ethernet", "eth"))
    for long_name, short_name in aliases:
        if text.startswith(long_name):
            text = short_name + text[len(long_name):]
            break
    return text


def _report_own_macs(report: dict[str, Any]) -> set[str]:
    """Collect MACs explicitly attached to this device/interface, never neighbor records."""
    found: set[str] = set()
    def walk(value: Any, parent_key: str = "") -> None:
        if isinstance(value, dict):
            for key, child in value.items():
                lowered = str(key).lower()
                if "lldp" in lowered or "neighbor" in lowered:
                    continue
                if any(token in lowered for token in ("mac_address", "macaddress", "base_mac", "chassis_mac", "hardware_address")):
                    mac = _normalise_mac(child)
                    if mac:
                        found.add(mac)
                walk(child, lowered)
        elif isinstance(value, list):
            for child in value:
                walk(child, parent_key)
    walk(report)
    return found


def _lldp_topology_links(devices: list[dict[str, Any]], manual_links: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    """Derive read-only topology edges from latest fact reports; do not persist guesses."""
    by_name = {str(d["name"]).casefold(): d for d in devices}
    reports: dict[int, dict[str, Any]] = {}
    own_mac_to_device: dict[str, int] = {}
    # Interface -> configured aggregate, derived only from explicit collected membership.
    # VLAN membership and parallel cable count are deliberately not used as evidence.
    aggregate_by_device_interface: dict[int, dict[str, str]] = {}
    def add_aggregate_members(device_id: int, aggregate_name: Any, members: Any) -> None:
        if not isinstance(members, (list, tuple, set)):
            return
        aggregate = str(aggregate_name or "").strip()
        if not re.match(r"(?i)^(?:eth-trunk\d+|port-channel\d+|po\d+)$", aggregate):
            return
        target = aggregate_by_device_interface.setdefault(device_id, {})
        for member in members:
            key = _normalise_interface(member)
            if key:
                # If the same port is reported under conflicting aggregates, mark it ambiguous.
                previous = target.get(key)
                target[key] = aggregate if previous in (None, aggregate) else ""
    for device in devices:
        safe_name = re.sub(r"[^A-Za-z0-9_.-]", "_", str(device["name"]))
        path = REPORTS / f"{safe_name}-facts.json"
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(data, dict) or str(data.get("device", "")).casefold() != str(device["name"]).casefold():
                continue
        except (OSError, ValueError, TypeError):
            continue
        device_id = int(device["id"])
        reports[device_id] = data
        for mac in _report_own_macs(data):
            own_mac_to_device.setdefault(mac, device_id)
        # USG6670 compact report; generic platform reports use lag_members.
        compact = data.get("report", {})
        if isinstance(compact, dict):
            trunks = compact.get("eth_trunks", {})
            if isinstance(trunks, dict):
                for agg_name, details in trunks.items():
                    if isinstance(details, dict):
                        add_aggregate_members(device_id, agg_name, details.get("members", []))
        lag_members = data.get("lag_members", {})
        if isinstance(lag_members, dict):
            for agg_name, members in lag_members.items():
                add_aggregate_members(device_id, agg_name, members)
        # Some reports expose a generic interface map with explicit lag parent metadata.
        interfaces = data.get("interfaces", {})
        if isinstance(interfaces, dict):
            inferred: dict[str, list[str]] = {}
            for iface_name, details in interfaces.items():
                if isinstance(details, dict):
                    parent = details.get("lag") or details.get("lag_interface") or details.get("aggregate")
                    if parent:
                        inferred.setdefault(str(parent), []).append(str(iface_name))
            for agg_name, members in inferred.items():
                add_aggregate_members(device_id, agg_name, members)

    manual_keys = set()
    for link in manual_links:
        manual_keys.add((int(link["local_device_id"]), _normalise_interface(link["local_interface"]),
                         int(link["remote_device_id"]), _normalise_interface(link["remote_interface"])))
        manual_keys.add((int(link["remote_device_id"]), _normalise_interface(link["remote_interface"]),
                         int(link["local_device_id"]), _normalise_interface(link["local_interface"])))

    observations: list[dict[str, Any]] = []
    unmatched: list[dict[str, str]] = []
    for source_id, report in reports.items():
        neighbours = report.get("lldp_neighbors", [])
        if not isinstance(neighbours, list):
            continue
        for item in neighbours:
            if not isinstance(item, dict):
                continue
            local_if = str(item.get("local_interface", "")).strip()
            remote_if = str(item.get("neighbor_interface", item.get("port_id", ""))).strip()
            chassis = _normalise_mac(item.get("chassis_id", ""))
            if not local_if or not remote_if:
                continue
            target_id = own_mac_to_device.get(chassis) if chassis else None
            # If the neighbor's own MAC is not available in its report, use a reciprocal LLDP port pair.
            if target_id is None:
                for other_id, other_report in reports.items():
                    if other_id == source_id:
                        continue
                    other_neighbours = other_report.get("lldp_neighbors", [])
                    if not isinstance(other_neighbours, list):
                        continue
                    reciprocal = any(
                        isinstance(peer, dict)
                        and _normalise_interface(peer.get("local_interface", "")) == _normalise_interface(remote_if)
                        and _normalise_interface(peer.get("neighbor_interface", peer.get("port_id", ""))) == _normalise_interface(local_if)
                        for peer in other_neighbours
                    )
                    if reciprocal:
                        target_id = other_id
                        break
            if target_id is None or target_id == source_id:
                unmatched.append({"device": str(by_name.get(str(report.get("device", "")).casefold(), {}).get("name", report.get("device", ""))),
                                  "local_interface": local_if, "chassis_id": str(item.get("chassis_id", "")), "neighbor_interface": remote_if})
                continue
            key = (source_id, _normalise_interface(local_if), target_id, _normalise_interface(remote_if))
            reverse = (target_id, _normalise_interface(remote_if), source_id, _normalise_interface(local_if))
            if key in manual_keys or reverse in manual_keys:
                continue
            local_aggregate = aggregate_by_device_interface.get(source_id, {}).get(_normalise_interface(local_if), "")
            remote_aggregate = aggregate_by_device_interface.get(target_id, {}).get(_normalise_interface(remote_if), "")
            aggregate_confirmed = bool(local_aggregate and remote_aggregate)
            observations.append({"local_device_id": source_id, "local_interface": local_if,
                                 "remote_device_id": target_id, "remote_interface": remote_if, "source": "lldp",
                                 "local_aggregate": local_aggregate or None,
                                 "remote_aggregate": remote_aggregate or None,
                                 "aggregate_confirmed": aggregate_confirmed})

    unique: dict[tuple[int, str, int, str], dict[str, Any]] = {}
    for link in observations:
        key = (link["local_device_id"], _normalise_interface(link["local_interface"]),
               link["remote_device_id"], _normalise_interface(link["remote_interface"]))
        reverse = (key[2], key[3], key[0], key[1])
        unique.setdefault(min(key, reverse), link)
    names = {int(d["id"]): str(d["name"]) for d in devices}
    auto_links = []
    for link in unique.values():
        auto_links.append({**link, "id": None, "local_name": names.get(link["local_device_id"], ""),
                           "remote_name": names.get(link["remote_device_id"], "")})
    return auto_links, {"reports_with_lldp": sum(1 for r in reports.values() if isinstance(r.get("lldp_neighbors"), list) and r.get("lldp_neighbors")),
                         "auto_links": len(auto_links), "unmatched_neighbors": unmatched}


@app.get("/api/esr/managed-devices/summary")
def esr_managed_devices_summary(_: dict[str, Any] = Depends(require_user)) -> dict[str, int]:
    """Count devices registered in the separate future ESR management module."""
    with db() as conn:
        count = conn.execute("SELECT COUNT(*) FROM esr_managed_devices").fetchone()[0]
    return {"count": int(count)}


@app.get("/api/topology")
def topology(_: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    with db() as conn:
        devices=[dict(d) for d in conn.execute("""SELECT d.id,d.name,d.vendor,d.address,d.device_type,
            v.name AS virtual_chassis_name FROM devices d
            LEFT JOIN virtual_chassis_members m ON m.device_id=d.id
            LEFT JOIN virtual_chassis v ON v.id=m.chassis_id ORDER BY d.name""").fetchall()]
        manual_links=[dict(l) for l in conn.execute("""SELECT l.id,l.local_device_id,l.local_interface,l.remote_device_id,l.remote_interface,l.source,
            a.name AS local_name,b.name AS remote_name FROM topology_links l JOIN devices a ON a.id=l.local_device_id JOIN devices b ON b.id=l.remote_device_id ORDER BY l.id""").fetchall()]
        positions=conn.execute("SELECT device_id,x,y FROM topology_positions").fetchall()
        aliases=conn.execute("SELECT device_id,interface_name,display_name FROM topology_interface_aliases ORDER BY device_id,interface_name").fetchall()
        label_positions=conn.execute("SELECT label_key,x,y,angle FROM topology_label_positions").fetchall()
    auto_links, diagnostics = _lldp_topology_links(devices, manual_links)
    links = manual_links + auto_links
    alias_map = {f"{a['device_id']}|{a['interface_name']}": a['display_name'] for a in aliases}
    note = f"Позиции устройств и подписи портов сохраняются локально. Автоматические LLDP-связи: {diagnostics['auto_links']}; несопоставленные соседи: {len(diagnostics['unmatched_neighbors'])}."
    return {"nodes":devices,"links":links,"positions":{str(p['device_id']):{"x":p['x'],"y":p['y']} for p in positions},"interface_aliases":alias_map,"label_positions":{p["label_key"]:{"x":p["x"],"y":p["y"],"angle":p["angle"]} for p in label_positions},"diagnostics":diagnostics,"note":note}

@app.put("/api/topology/positions/{device_id}")
def update_topology_position(device_id: int, payload: TopologyPositionUpdate, req: Request, _: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    require_csrf(req)
    stamp=now()
    with db() as conn:
        if not conn.execute("SELECT 1 FROM devices WHERE id=?", (device_id,)).fetchone():
            raise HTTPException(404, "Устройство не найдено.")
        conn.execute("INSERT INTO topology_positions(device_id,x,y,updated_at) VALUES(?,?,?,?) ON CONFLICT(device_id) DO UPDATE SET x=excluded.x,y=excluded.y,updated_at=excluded.updated_at", (device_id,payload.x,payload.y,stamp))
    return {"device_id":device_id,"x":payload.x,"y":payload.y,"updated_at":stamp}


@app.put("/api/topology/label-positions")
def update_topology_label_position(payload: TopologyLabelPositionUpdate, req: Request, _: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    require_csrf(req)
    label_key = req.query_params.get("key", "").strip()
    if not label_key or len(label_key) > 512:
        raise HTTPException(400, "Не указан ключ подписи или он слишком длинный.")
    stamp = now()
    with db() as conn:
        conn.execute("INSERT INTO topology_label_positions(label_key,x,y,angle,updated_at) VALUES(?,?,?,?,?) ON CONFLICT(label_key) DO UPDATE SET x=excluded.x,y=excluded.y,angle=excluded.angle,updated_at=excluded.updated_at", (label_key,payload.x,payload.y,payload.angle,stamp))
    return {"label_key":label_key,"x":payload.x,"y":payload.y,"angle":payload.angle,"updated_at":stamp}


@app.put("/api/topology/interface-aliases/{device_id}")
def update_topology_interface_alias(device_id: int, payload: TopologyInterfaceAliasUpdate, req: Request, _: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    require_csrf(req)
    interface_name = req.query_params.get("interface", "").strip()
    if not interface_name or len(interface_name) > 128:
        raise HTTPException(400, "Укажите исходное имя интерфейса длиной до 128 символов.")
    display_name = payload.display_name.strip()
    stamp = now()
    with db() as conn:
        if not conn.execute("SELECT 1 FROM devices WHERE id=?", (device_id,)).fetchone():
            raise HTTPException(404, "Устройство не найдено.")
        if not display_name or display_name == interface_name:
            conn.execute("DELETE FROM topology_interface_aliases WHERE device_id=? AND interface_name=?", (device_id, interface_name))
            return {"device_id": device_id, "interface_name": interface_name, "display_name": interface_name, "updated_at": stamp}
        conn.execute("INSERT INTO topology_interface_aliases(device_id,interface_name,display_name,updated_at) VALUES(?,?,?,?) ON CONFLICT(device_id,interface_name) DO UPDATE SET display_name=excluded.display_name,updated_at=excluded.updated_at", (device_id, interface_name, display_name, stamp))
    return {"device_id": device_id, "interface_name": interface_name, "display_name": display_name, "updated_at": stamp}

@app.post("/api/topology/links",status_code=201)
def create_topology_link(payload: TopologyLinkCreate, req: Request, _: dict[str, Any] = Depends(require_user)) -> dict[str, Any]:
    require_csrf(req)
    if payload.local_device_id == payload.remote_device_id: raise HTTPException(400,"Связь устройства с самим собой запрещена.")
    stamp=now()
    try:
        with db() as conn:
            cur=conn.execute("INSERT INTO topology_links(local_device_id,local_interface,remote_device_id,remote_interface,source,created_at) VALUES(?,?,?,?, 'manual',?)",(payload.local_device_id,payload.local_interface,payload.remote_device_id,payload.remote_interface,stamp))
            row=conn.execute("SELECT * FROM topology_links WHERE id=?",(cur.lastrowid,)).fetchone()
    except sqlite3.IntegrityError: raise HTTPException(409,"Связь уже существует или одно из устройств не найдено.")
    return dict(row)

@app.delete("/api/topology/links/{link_id}",status_code=204)
def delete_topology_link(link_id:int,req:Request,_:dict[str,Any]=Depends(require_user))->Response:
    require_csrf(req)
    with db() as conn:
        cur=conn.execute("DELETE FROM topology_links WHERE id=?",(link_id,))
        if not cur.rowcount: raise HTTPException(404,"Связь не найдена.")
    return Response(status_code=204)
