"""Local web interface for NetBox Sync."""
