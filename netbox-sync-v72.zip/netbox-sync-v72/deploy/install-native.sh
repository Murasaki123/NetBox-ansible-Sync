#!/usr/bin/env bash
set -euo pipefail
APP_DIR="${APP_DIR:-/opt/netbox-sync}"
TLS_NAME="${TLS_NAME:-netbox-sync.local}"
TLS_IP="${TLS_IP:-}"
if [[ "$(id -u)" -ne 0 ]]; then echo "Run as root: sudo APP_DIR=/path/to/netbox-sync $0" >&2; exit 1; fi
if [[ ! -f "$APP_DIR/webui/app.py" ]]; then echo "Project not found under $APP_DIR" >&2; exit 1; fi
getent group netbox-sync >/dev/null || groupadd --system netbox-sync
id netbox-sync >/dev/null 2>&1 || useradd --system --gid netbox-sync --home-dir "$APP_DIR" --shell /usr/sbin/nologin netbox-sync
install -d -o root -g netbox-sync -m 0750 /etc/netbox-sync /etc/netbox-sync/tls
install -d -o netbox-sync -g netbox-sync -m 0700 "$APP_DIR/local_data" "$APP_DIR/local_data/reports" "$APP_DIR/local_data/backups" "$APP_DIR/local_data/.ssh"
if [[ ! -f /etc/netbox-sync/tls/server.crt || ! -f /etc/netbox-sync/tls/server.key ]]; then
  TLS_DIR=/etc/netbox-sync/tls TLS_NAME="$TLS_NAME" TLS_IP="$TLS_IP" "$APP_DIR/deploy/generate-tls.sh"
fi
chown root:netbox-sync /etc/netbox-sync/tls/*
chmod 750 /etc/netbox-sync/tls
chmod 640 /etc/netbox-sync/tls/server.key
chmod 644 /etc/netbox-sync/tls/server.crt /etc/netbox-sync/tls/ca.crt
python3 -m venv "$APP_DIR/.venv"
"$APP_DIR/.venv/bin/pip" install -r "$APP_DIR/requirements.txt" -r "$APP_DIR/webui/requirements.txt"
install -d -o root -g root -m 0755 /usr/share/ansible/collections
"$APP_DIR/.venv/bin/ansible-galaxy" collection install -p /usr/share/ansible/collections -r "$APP_DIR/requirements.yml"
chown -R netbox-sync:netbox-sync "$APP_DIR/local_data"
if [[ ! -f /etc/netbox-sync/webui.env ]]; then
  BOOTSTRAP_PASSWORD="$(python3 -c 'import secrets; print(secrets.token_urlsafe(32))')"
  printf 'WEBUI_BOOTSTRAP_USER=admin\nWEBUI_BOOTSTRAP_PASSWORD=%s\nWEBUI_JOB_TIMEOUT=1800\n' "$BOOTSTRAP_PASSWORD" > /etc/netbox-sync/webui.env
  chmod 0640 /etc/netbox-sync/webui.env
  chown root:netbox-sync /etc/netbox-sync/webui.env
  echo "Initial user password (save it now): $BOOTSTRAP_PASSWORD"
  echo "After the first successful login, remove WEBUI_BOOTSTRAP_PASSWORD from /etc/netbox-sync/webui.env and restart the service."
fi
install -m 0644 "$APP_DIR/deploy/netbox-sync-web.service" /etc/systemd/system/netbox-sync-web.service
systemctl daemon-reload
systemctl enable --now netbox-sync-web.service
systemctl --no-pager --full status netbox-sync-web.service
cat <<EOF

HTTPS is listening on port 8443.
Import /etc/netbox-sync/tls/ca.crt into trusted roots on management workstations.
URL: https://${TLS_NAME}:8443/ (ensure DNS resolves ${TLS_NAME} to this server).
EOF
