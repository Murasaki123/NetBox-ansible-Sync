#!/usr/bin/env bash
set -euo pipefail
# Creates a local CA and a server certificate. Import ca.crt into trusted roots on management workstations.
TLS_DIR="${TLS_DIR:-$(cd "$(dirname "$0")" && pwd)/tls}"
TLS_NAME="${TLS_NAME:-netbox-sync.local}"
TLS_IP="${TLS_IP:-}"
CA_KEY_PATH="${CA_KEY_PATH:-$(dirname "$TLS_DIR")/ca-private/ca.key}"
mkdir -p "$TLS_DIR" "$(dirname "$CA_KEY_PATH")"
chmod 700 "$TLS_DIR" "$(dirname "$CA_KEY_PATH")"
if [[ -e "$CA_KEY_PATH" || -e "$TLS_DIR/server.key" ]]; then
  echo "TLS key already exists in $TLS_DIR; refusing to overwrite." >&2
  exit 1
fi
command -v openssl >/dev/null || { echo "openssl is required" >&2; exit 1; }
openssl genrsa -out "$CA_KEY_PATH" 4096
chmod 600 "$CA_KEY_PATH"
openssl req -x509 -new -nodes -key "$CA_KEY_PATH" -sha256 -days 3650 \
  -subj "/CN=NetBox Sync Local Internal CA" -out "$TLS_DIR/ca.crt"
openssl genrsa -out "$TLS_DIR/server.key" 3072
chmod 600 "$TLS_DIR/server.key"
openssl req -new -key "$TLS_DIR/server.key" -subj "/CN=$TLS_NAME" -out "$TLS_DIR/server.csr"
{
  echo 'basicConstraints=CA:FALSE'
  echo 'keyUsage=digitalSignature,keyEncipherment'
  echo 'extendedKeyUsage=serverAuth'
  echo 'subjectAltName=@alt_names'
  echo '[alt_names]'
  echo "DNS.1=$TLS_NAME"
  if [[ -n "$TLS_IP" ]]; then echo "IP.1=$TLS_IP"; fi
} > "$TLS_DIR/server.ext"
openssl x509 -req -in "$TLS_DIR/server.csr" -CA "$TLS_DIR/ca.crt" -CAkey "$CA_KEY_PATH" \
  -CAcreateserial -out "$TLS_DIR/server.crt" -days 825 -sha256 -extfile "$TLS_DIR/server.ext"
rm -f "$TLS_DIR/server.csr" "$TLS_DIR/server.ext" "$TLS_DIR/ca.srl"
chmod 644 "$TLS_DIR/ca.crt" "$TLS_DIR/server.crt"
echo "TLS certificate created in $TLS_DIR"
echo "CA private key stored separately at $CA_KEY_PATH; back it up securely and do not copy it to the application host/container if not required."
echo "Import $TLS_DIR/ca.crt into the trusted root certificate store on management workstations."
echo "Open https://$TLS_NAME:8443/ (ensure this name resolves to the server IP)."
