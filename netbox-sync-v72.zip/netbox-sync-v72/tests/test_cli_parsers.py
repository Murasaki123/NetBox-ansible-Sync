import re
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "filter_plugins"))
from netbox_sync_parsers import (  # noqa: E402
    parse_eltex_interfaces,
    parse_eltex_esr_version,
    parse_eltex_esr_system,
    parse_eltex_esr_interfaces,
    parse_eltex_esr_descriptions,
    parse_eltex_esr_ip_interfaces,
    parse_eltex_esr_vlans,
    parse_eltex_esr_vrrp,
    parse_eltex_esr_routes,
    parse_eltex_esr_failover,
    parse_eltex_version,
    parse_eltex_system,
    parse_eltex_inventory,
    parse_eltex_interface_descriptions,
    parse_eltex_lag_members,
    parse_eltex_lag_states,
    apply_eltex_lag_states,
    parse_eltex_lldp,
    parse_eltex_vlans,
    validate_eltex_vlan_memberships,
    filter_eltex_configured_port_channels,
    filter_eltex_vlan_port_channels,
    parse_cisco_interfaces,
    parse_cisco_interface_descriptions,
    parse_cisco_inventory,
    parse_cisco_lag_members,
    parse_cisco_lldp,
    parse_cisco_version,
    parse_snr_interfaces,
    parse_snr_running_config,
    parse_snr_vlans,
    parse_snr_lag_members,
    parse_snr_version,
    parse_huawei_device_model,
    parse_huawei_hostname,
    build_huawei_usg6670_report,
    parse_huawei_interfaces,
    parse_huawei_ip_interface_brief,
    FilterModule,
    parse_huawei_lag_members,
    parse_huawei_running_config,
    parse_huawei_vlans,
    parse_huawei_lldp,
    parse_huawei_version,
    parse_vlans,
)


class CliParserTests(unittest.TestCase):
    def test_huawei_ip_interface_filter_is_registered_for_ansible(self):
        filters = FilterModule().filters()
        self.assertIn("parse_huawei_ip_interface_brief", filters)
        self.assertIs(filters["parse_huawei_ip_interface_brief"], parse_huawei_ip_interface_brief)

    def test_huawei_usg_version(self):
        parsed = parse_huawei_version("""Huawei Versatile Routing Platform Software
VRP (R) Software, Version 5.170 (USG6600E V600R007C20SPC600)
USG6635E uptime is 24 weeks, 3 days, 16 hours
""")
        self.assertEqual(parsed["model"], "USG6635E")
        self.assertIn("V600R007C20SPC600", parsed["version"])

    def test_huawei_s5735_esn_output(self):
        parsed = parse_huawei_version("ESN of slot 0: 21980109384EL6000854")
        self.assertEqual(parsed["serial"], "21980109384EL6000854")

    def test_huawei_usg6670_master_esn_output(self):
        parsed = parse_huawei_version("2026-10-28 16:00:19.056 +04:00\nESN of master:210235G7G610KC000008")
        self.assertEqual(parsed["serial"], "210235G7G610KC000008")

    def test_huawei_hostname_and_usg6670_report_sections(self):
        hostname = parse_huawei_hostname("sysname DTC-HUW2_23-1\n")
        self.assertEqual(hostname, "DTC-HUW2_23-1")
        interfaces = {
            "GigabitEthernet1/0/0": {"operstatus": "up", "type": "1000base-t"},
            "GigabitEthernet1/0/1": {"operstatus": "down", "type": "1000base-t"},
            "Eth-Trunk2": {"operstatus": "up", "type": "lag"},
            "Eth-Trunk2.2": {"operstatus": "up", "type": "virtual"},
            "Eth-Trunk2.3164": {"operstatus": "down", "type": "virtual"},
            "LoopBack0": {"operstatus": "up", "type": "virtual"},
        }
        interfaces["Eth-Trunk2.2"]["ip_addresses"] = ["10.20.2.1/24"]
        report = build_huawei_usg6670_report(hostname, "SERIAL123", interfaces, {"Eth-Trunk2": ["GigabitEthernet1/0/0"]}, [{"local_interface": "GigabitEthernet1/0/0", "chassis_id": "7079-b3f2-4140", "neighbor_interface": "Te5/0/3"}])
        self.assertEqual(report["hostname"], "DTC-HUW2_23-1")
        self.assertEqual(report["serial"], "SERIAL123")
        self.assertEqual(set(report["physical_interfaces"]), {"GigabitEthernet1/0/0", "GigabitEthernet1/0/1"})
        self.assertEqual(report["eth_trunks"]["Eth-Trunk2"]["members"], ["GigabitEthernet1/0/0"])
        self.assertEqual(set(report["subinterfaces"]["Eth-Trunk2"]), {"Eth-Trunk2.2", "Eth-Trunk2.3164"})
        self.assertEqual(report["subinterfaces"]["Eth-Trunk2"]["Eth-Trunk2.2"]["ip_addresses"], ["10.20.2.1/24"])
        self.assertNotIn("LoopBack0", report["physical_interfaces"])
        self.assertEqual(report["lldp_neighbors"][0]["chassis_id"], "7079-b3f2-4140")

    def test_huawei_usg6670_subinterfaces_sorted_numerically(self):
        interfaces = {f"Eth-Trunk2.{suffix}": {"operstatus": "up", "type": "virtual"} for suffix in [3164, 12, 2, 9, 3222, 3]}
        report = build_huawei_usg6670_report("fw", "SN", interfaces, {})
        self.assertEqual(list(report["subinterfaces"]["Eth-Trunk2"]), ["Eth-Trunk2.2", "Eth-Trunk2.3", "Eth-Trunk2.9", "Eth-Trunk2.12", "Eth-Trunk2.3164", "Eth-Trunk2.3222"])

    def test_huawei_lldp_neighbor_brief_table(self):
        parsed = parse_huawei_lldp("""Local Intf       Neighbor Dev             Neighbor Intf             Exptime(s)
GE0/0/5          -                        cc9d-a25e-8e82            96
GE0/0/21         DTC-P24-HUW-SW-23-10     GE0/0/9                   105
XGE0/0/4         RIC-9410R-SW             Te7/0/11                  95
""")
        self.assertEqual(len(parsed), 3)
        self.assertEqual(parsed[0]["local_interface"], "GE0/0/5")
        self.assertEqual(parsed[0]["chassis_id"], "cc9d-a25e-8e82")
        self.assertNotIn("neighbor_device", parsed[0])
        self.assertEqual(parsed[1]["neighbor_device"], "DTC-P24-HUW-SW-23-10")
        self.assertEqual(parsed[1]["neighbor_interface"], "GE0/0/9")
        self.assertEqual(parsed[2]["neighbor_device"], "RIC-9410R-SW")
        self.assertEqual(parsed[2]["neighbor_interface"], "Te7/0/11")

    def test_huawei_s5735_expanded_lldp_neighbor_output(self):
        raw = """GigabitEthernet0/0/9 has 1 neighbor(s):
Neighbor index :1
Chassis type   :MAC address
Chassis ID     :6012-3ce8-8130
Port ID type   :Interface name
Port ID        :GigabitEthernet0/0/21
System name    :DTC-P24-HUW-SW-23.102
Management address type  :ipv4
Management address value :192.168.1.253
Expired time   :99s

GigabitEthernet0/0/21 has 1 neighbor(s):
Neighbor index :1
Chassis type   :MAC address
Chassis ID     :a8f9-4bad-a24b
Port ID type   :Locally assigned
Port ID        :gi1/0/1
System name    :AR1-COMERCIAL
Management address type  :ipv4
Management address value :10.10.23.251
Expired time   :106s

XGigabitEthernet0/0/4 has 1 neighbor(s):
Neighbor index :1
Chassis type   :MAC address
Chassis ID     :cc9d-a27a-ac40
Port ID type   :Interface name
Port ID        :te2/0/10
System name    :DTC-P24-ELX-SW
Management address type  :ipv4
Management address value :10.10.23.253
Expired time   :109s
"""
        parsed = parse_huawei_lldp(raw)
        self.assertEqual(len(parsed), 3)
        self.assertEqual(parsed[0]["local_interface"], "GigabitEthernet0/0/9")
        self.assertEqual(parsed[0]["chassis_id"], "6012-3ce8-8130")
        self.assertEqual(parsed[0]["neighbor_interface"], "GigabitEthernet0/0/21")
        self.assertEqual(parsed[0]["neighbor_device"], "DTC-P24-HUW-SW-23.102")
        self.assertEqual(parsed[1]["chassis_id"], "a8f9-4bad-a24b")
        self.assertEqual(parsed[1]["neighbor_interface"], "gi1/0/1")
        self.assertEqual(parsed[2]["local_interface"], "XGigabitEthernet0/0/4")
        self.assertEqual(parsed[2]["chassis_id"], "cc9d-a27a-ac40")
        self.assertEqual(parsed[2]["neighbor_device"], "DTC-P24-ELX-SW")

    def test_huawei_usg6670_expanded_lldp_output(self):
        raw = """Interface GigabitEthernet3/0/9 has 1 Neighbors:
Neighbor 1:
    ChassisIdSubtype: MacAddress
    ChasssisId: 7079-b3f2-4140
    PortIdSubtype: InterfaceName
    PortId: Te5/0/3
    SysCapSupported:
    SysCapEnabled: Bridge/Switch
    SysCapEnabled: Router
Interface GigabitEthernet3/0/8 has 1 Neighbors:
Neighbor 1:
    ChassisIdSubtype: MacAddress
    ChasssisId: cc9d-a27a-ac40
    PortIdSubtype: InterfaceName
    PortId: te2/0/21
    SysCapEnabled: Bridge/Switch
    SysCapEnabled: Router
Interface GigabitEthernet3/0/7 has 0 Neighbors:
Interface GigabitEthernet1/0/0 has 1 Neighbors:
Neighbor 1:
    ChassisIdSubtype: MacAddress
    ChasssisId: 24a5-2cfd-70f3
    PortIdSubtype: InterfaceName
    PortId: GigabitEthernet1/0/0
    SysCapEnabled: Router
"""
        parsed = parse_huawei_lldp(raw)
        self.assertEqual(len(parsed), 3)
        self.assertEqual(parsed[0]["local_interface"], "GigabitEthernet3/0/9")
        self.assertEqual(parsed[0]["chassis_id"], "7079-b3f2-4140")
        self.assertEqual(parsed[0]["neighbor_interface"], "Te5/0/3")
        self.assertEqual(parsed[0]["chassis_id_subtype"], "MacAddress")
        self.assertEqual(parsed[0]["port_id_subtype"], "InterfaceName")
        self.assertEqual(parsed[0]["system_capabilities"], ["Bridge/Switch", "Router"])
        self.assertEqual(parsed[1]["local_interface"], "GigabitEthernet3/0/8")
        self.assertEqual(parsed[2]["chassis_id"], "24a5-2cfd-70f3")

    def test_huawei_display_device_prefers_exact_switch_model(self):
        self.assertEqual(parse_huawei_device_model("S5735-L48P4X-A's Device status:"), "S5735-L48P4X-A")
        self.assertEqual(parse_huawei_device_model("USG6635E's Device status:"), "USG6635E")

    def test_huawei_usg_ip_interface_brief_enriches_subinterface_ip(self):
        interfaces = parse_huawei_interfaces("""Interface PHY Protocol InUti OutUti inErrors outErrors
Eth-Trunk2.2 up up 0% 0% 0 0
Eth-Trunk2.3 down down 0% 0% 0 0
""")
        enriched = parse_huawei_ip_interface_brief("""Interface                         IP Address/Mask      Physical   Protocol
Eth-Trunk2.2                      10.20.2.1/24         up         up
Eth-Trunk2.3                      unassigned           down       down
""", interfaces)
        self.assertEqual(enriched["Eth-Trunk2.2"]["ip_addresses"], ["10.20.2.1/24"])
        self.assertEqual(enriched["Eth-Trunk2.2"]["operstatus"], "up")
        self.assertEqual(enriched["Eth-Trunk2.3"]["ip_addresses"], [])
        self.assertEqual(enriched["Eth-Trunk2.3"]["operstatus"], "down")

    def test_huawei_interfaces_keep_aggregates_subinterfaces_and_physical_members(self):
        parsed = parse_huawei_interfaces("""Interface PHY Protocol InUti OutUti inErrors outErrors
Eth-Trunk0 up up 0.01% 0.12% 0 0
  GigabitEthernet0/0/0 up up 0% 0% 0 0
Eth-Trunk1.640 up up 0% 0% 0 0
Vlanif168 down down -- -- 0 0
MEth0/0/0 up up 0% 0% 0 0
""")
        self.assertEqual(parsed["Eth-Trunk0"]["type"], "lag")
        self.assertEqual(parsed["GigabitEthernet0/0/0"]["type"], "1000base-t")
        self.assertEqual(parsed["Eth-Trunk1.640"]["type"], "virtual")
        self.assertEqual(parsed["Vlanif168"]["operstatus"], "down")
        self.assertIn("MEth0/0/0", parsed)

    def test_huawei_s5735_running_config_enriches_interfaces_and_vlans(self):
        raw = """vlan 23
 description Manage_Network
 name Manage_Network
#
vlan 2716
 description service_OUS
#
interface Vlanif23
 description mgm_RIC-S5735-rack03
 ip address 192.168.23.102 255.255.255.0
#
interface GigabitEthernet0/0/8
 description ADMIN_IN_DC
 shutdown
 port link-type access
 port default vlan 2256
#
interface GigabitEthernet0/0/4
 description NetFlow
 port link-type trunk
 port trunk pvid vlan 2716
 port trunk allow-pass vlan 2716
#
interface GigabitEthernet0/0/14
 description KNGFW1_ETH1
 eth-trunk 3
#
interface XGigabitEthernet0/0/4
 description DTC-P24-CSC-CSW-23-254
 port link-type trunk
 undo port trunk allow-pass vlan 1
 port trunk allow-pass vlan 4 23 100 316 2256 2716 2748
#
"""
        base = {
            "Vlanif23": {"operstatus": "up", "type": "virtual", "description": ""},
            "GigabitEthernet0/0/8": {"operstatus": "down", "type": "1000base-t", "description": ""},
        }
        parsed = parse_huawei_running_config(raw, base)
        self.assertEqual(parsed["interfaces"]["Vlanif23"]["description"], "mgm_RIC-S5735-rack03")
        self.assertEqual(parsed["interfaces"]["Vlanif23"]["ip_addresses"], ["192.168.23.102/24"])
        access = parsed["interfaces"]["GigabitEthernet0/0/8"]
        self.assertEqual(access["description"], "ADMIN_IN_DC")
        self.assertEqual(access["untagged_vlans"], [2256])
        self.assertEqual(access["admin_status"], "disabled")
        trunk = parsed["interfaces"]["GigabitEthernet0/0/4"]
        self.assertEqual(trunk["native_vlan"], 2716)
        self.assertEqual(trunk["tagged_vlans"], [])
        uplink = parsed["interfaces"]["XGigabitEthernet0/0/4"]
        self.assertEqual(uplink["tagged_vlans"], [4, 23, 100, 316, 2256, 2716, 2748])
        self.assertEqual(parsed["interfaces"]["GigabitEthernet0/0/14"]["lag"], "Eth-Trunk3")
        vlans = {item["vid"]: item for item in parsed["vlans"]}
        self.assertEqual(vlans[23]["name"], "Manage_Network")
        self.assertEqual(vlans[23]["description"], "Manage_Network")
        self.assertEqual(vlans[2716]["name"], "VLAN2716")
        self.assertEqual(parse_huawei_vlans(raw), parsed["vlans"])

    def test_huawei_aggregate_members_allow_speed_annotation(self):
        raw = """Eth-Trunk1 up up 18% 17% 0 0
  GigabitEthernet1/0/8(10G) up up 9% 8% 0 0
  GigabitEthernet3/0/8(10G) up up 9% 9% 0 0
Eth-Trunk1.95 up up 1% 2% 0 0
"""
        self.assertEqual(parse_huawei_lag_members(raw), {"Eth-Trunk1": ["GigabitEthernet1/0/8", "GigabitEthernet3/0/8"]})
        self.assertIn("GigabitEthernet1/0/8", parse_huawei_interfaces(raw))

    def test_eltex_mes5324a_active_version_and_stack_system_output(self):
        version = parse_eltex_version("""Active-image: flash://system/images/rs
  Version: 6.6.11.2
  Commit: 5674e940
Inactive-image: flash://system/images/_rs
  Version: 6.6.3
""")
        system = parse_eltex_system("""System Description:                       MES5324A rev.B 24-Port 10G SFP+ Managed Switch
System Up Time (days,hour:min:sec):       166,14:05:49
Unit                            Type
---- ----------------------------------------------------------
 1         MES5324A rev.B 24-Port 10G SFP+ Managed Switch
 2         MES5324A rev.B 24-Port 10G SFP+ Managed Switch
""")
        self.assertEqual(version["version"], "6.6.11.2")
        self.assertEqual(version["model"], "")
        self.assertEqual(system["model"], "MES5324A")
        self.assertEqual(system["unit_count"], 2)
        self.assertEqual(len(system["units"]), 2)

    def test_eltex_inventory_extracts_both_stack_serials_and_transceivers(self):
        parsed = parse_eltex_inventory("""NAME: "1"   DESCR: "24-Port 10G SFP+ Managed Switch"
PID: MES5324A rev.B   VID: 0   SN: ESE7000244

NAME: "TenGigabitEthernet1/0/1"    DESCR: "SFP-10G-LR"
PID: SFP-10G-LR    VID: V01     SN: PJBN771503

NAME: "2"   DESCR: "24-Port 10G SFP+ Managed Switch"
PID: MES5324A rev.B   VID: 0   SN: ESE7000247
""")
        self.assertEqual([u["serial"] for u in parsed["units"]], ["ESE7000244", "ESE7000247"])
        self.assertEqual(parsed["units"][0]["pid"], "MES5324A rev.B")
        self.assertEqual(parsed["transceivers"][0]["serial"], "PJBN771503")

    def test_eltex_interface_details_keep_descriptions_and_not_present_state(self):
        parsed = parse_eltex_interface_descriptions("""Port       Port Mode (VLAN)         Admin Link
te1/0/1    Trunk                    Up    Up          RMIAC-S139-ELX-SW-23-3
te2/0/4    Access (1)               Down  Down
Po1        Trunk                    Up    Up          USG6670_FW1
Po6        Access (1)               Up    Not Present
""")
        self.assertEqual(parsed["te1/0/1"]["description"], "RMIAC-S139-ELX-SW-23-3")
        self.assertEqual(parsed["te2/0/4"]["admin_status"], "disabled")
        self.assertEqual(parsed["Po1"]["type"] if "type" in parsed["Po1"] else "lag", "lag")
        self.assertEqual(parsed["Po6"]["operstatus"], "not_present")

    def test_eltex_vlan_parser_handles_wrapped_membership_ranges(self):
        parsed = parse_eltex_vlans("""Vlan       Name           Tagged Ports      UnTagged Ports      Created by
---- ----------------- ------------------ ------------------ ----------------
1           -                             te1/0/5,te1/0/8,         D
                                             te1/0/11,te1/0/15,
                                            te1/0/23-32,
                                             te2/0/4-5,
9   MFC_Zastava_to_RT    Po1,Po5,Po10                              S
120  Inet_Vid_analit_B    Po11             te1/0/7              S
""")
        vlans = {row["vid"]: row for row in parsed}
        self.assertEqual(vlans[9]["tagged_ports"], ["Po1", "Po5", "Po10"])
        self.assertEqual(vlans[120]["tagged_ports"], ["Po11"])
        self.assertEqual(vlans[120]["untagged_ports"], ["te1/0/7"])
        self.assertIn("te1/0/32", vlans[1]["untagged_ports"])

    def test_eltex_vlan_parser_preserves_wrapped_names_from_real_cli_layout(self):
        raw = """Vlan       Name           Tagged Ports      UnTagged Ports      Created by
---- ----------------- ------------------ ------------------ ----------------
1042 Internal_myudm.ru   te2/0/10,Po3-4                             S
1253 ISP_Megafon_Inter te2/0/10,te2/0/13                            S
            net
2301 MGMT_APK_Safe_cit te1/0/1,te1/0/4,                            S
             y          te2/0/1,Po1,Po5
"""
        parsed = {row["vid"]: row for row in parse_eltex_vlans(raw)}
        self.assertEqual(parsed[1042]["name"], "Internal_myudm.ru")
        self.assertEqual(parsed[1042]["tagged_ports"], ["te2/0/10", "Po3", "Po4"])
        self.assertEqual(parsed[1253]["name"], "ISP_Megafon_Internet")
        self.assertEqual(parsed[1253]["tagged_ports"], ["te2/0/10", "te2/0/13"])
        self.assertEqual(parsed[2301]["name"], "MGMT_APK_Safe_city")
        self.assertEqual(parsed[2301]["tagged_ports"], ["te1/0/1", "te1/0/4", "te2/0/1", "Po1", "Po5"])

    def test_eltex_interfaces_status_keeps_not_present_distinct(self):
        parsed = parse_eltex_interfaces("""Port       Type         Duplex  Speed  Neg      ctrl State
te1/0/22   10G-Fiber    Full    10000  Disabled Off  Up
te1/0/23      --        --      --      --     --  Not Present
te2/0/4    10G-Fiber      --      --      --     --  Down (adm)
""")
        self.assertEqual(parsed["te1/0/22"]["operstatus"], "up")
        self.assertEqual(parsed["te1/0/23"]["operstatus"], "not_present")
        self.assertEqual(parsed["te2/0/4"]["operstatus"], "down")

    def test_eltex_vlan_membership_rejects_ports_not_observed_on_two_unit_stack(self):
        # Regression for the DTC-P24-ELX-SW report: the VLAN table contained
        # te1/0/25-32 and complete te3/0/1-32 ... te8/0/1-32 ranges even though
        # the actual MES-5324A stack has only te1/0/1-24 and te2/0/1-24.
        raw = """Vlan       Name           Tagged Ports      UnTagged Ports      Created by
1           -                             te1/0/23-32,te2/0/23-32,te3/0/1-32,te8/0/1-32,Po1-2 D
120  USERS                 Po11             te2/0/7              S
"""
        parsed = parse_eltex_vlans(raw)
        observed = {f"te{unit}/0/{port}": {} for unit in (1, 2) for port in range(1, 25)}
        observed.update({"Po1": {}, "Po2": {}, "Po11": {}})
        validated = validate_eltex_vlan_memberships(parsed, observed)
        vlans = {row["vid"]: row for row in validated}
        self.assertEqual(vlans[1]["untagged_ports"], ["te1/0/23", "te1/0/24", "te2/0/23", "te2/0/24", "Po1", "Po2"])
        self.assertEqual(vlans[120]["tagged_ports"], ["Po11"])
        self.assertEqual(vlans[120]["untagged_ports"], ["te2/0/7"])
        all_members = [p for row in validated for field in ("tagged_ports", "untagged_ports") for p in row[field]]
        self.assertFalse(any(re.match(r"(?i)^te[3-8]/", p) for p in all_members))
        self.assertFalse(any(re.match(r"(?i)^te[12]/0/(?:2[5-9]|3[0-2])$", p) for p in all_members))

    def test_eltex_filters_unconfigured_placeholder_port_channels(self):
        interfaces = {
            'Po1': {'type': 'lag', 'description': '', 'port_mode': 'Trunk', 'admin_status': 'enabled'},
            'Po2': {'type': 'lag', 'description': '', 'port_mode': 'Trunk', 'admin_status': 'enabled'},
            'Po6': {'type': 'lag', 'description': '', 'port_mode': 'Access (1)', 'admin_status': 'enabled'},
            'Po8': {'type': 'lag', 'description': '', 'port_mode': 'Access (1)', 'admin_status': 'enabled'},
            'Po10': {'type': 'lag', 'description': 'uplink', 'port_mode': 'Access (1)', 'admin_status': 'enabled'},
            'te1/0/1': {'type': '10gbase-x-sfpp', 'description': ''},
        }
        vlans = [
            {'vid': 1, 'name': '-', 'tagged_ports': [], 'untagged_ports': ['Po1', 'Po2', 'Po6', 'Po8', 'Po10']},
            {'vid': 9, 'name': 'uplink', 'tagged_ports': ['Po1'], 'untagged_ports': []},
            {'vid': 644, 'name': 'configured', 'tagged_ports': ['Po8'], 'untagged_ports': []},
        ]
        lag_members = {'Po2': ['te1/0/1']}
        filtered = filter_eltex_configured_port_channels(interfaces, vlans, lag_members)
        self.assertEqual({name for name in filtered if name.startswith('Po')}, {'Po1', 'Po2', 'Po8', 'Po10'})
        filtered_vlans = filter_eltex_vlan_port_channels(vlans, interfaces, lag_members)
        vlan1 = next(row for row in filtered_vlans if row['vid'] == 1)
        self.assertEqual(vlan1['untagged_ports'], ['Po1', 'Po2', 'Po8', 'Po10'])

    def test_eltex_channel_group_only_returns_active_members(self):
        parsed = parse_eltex_lag_members("""Channel  Ports
Po1      Active: te1/0/22,te2/0/22
Po8      Non-candidate: te1/0/18,te2/0/18
Po10     Active: te1/0/17,te2/0/17
Po12
""")
        self.assertEqual(parsed, {"Po1": ["te1/0/22", "te2/0/22"], "Po10": ["te1/0/17", "te2/0/17"]})

    def test_eltex_lag_non_candidate_state_is_preserved_separately_from_link_state(self):
        raw = """Channel  Ports
Po1      Active: te1/0/22,te2/0/22
Po8      Non-candidate: te1/0/18,te2/0/18
Po10     Active: te1/0/17,te2/0/17
"""
        states = parse_eltex_lag_states(raw)
        self.assertEqual(states, {"Po1": "active", "Po8": "non_candidate", "Po10": "active"})
        interfaces = {"Po8": {"operstatus": "down", "type": "lag"}, "Po1": {"operstatus": "up", "type": "lag"}}
        enriched = apply_eltex_lag_states(interfaces, states)
        self.assertEqual(enriched["Po8"]["operstatus"], "down")
        self.assertEqual(enriched["Po8"]["lag_status"], "non_candidate")
        self.assertEqual(enriched["Po1"]["lag_status"], "active")
        # Non-candidate ports are not falsely represented as active LAG members.
        self.assertNotIn("Po8", parse_eltex_lag_members(raw))

    def test_eltex_lldp_parses_device_port_and_wrapped_port_id(self):
        parsed = parse_eltex_lldp("""Port       Device ID          Port ID               System Name           Capabilities  TTL
te1/0/1    e0:d9:e3:1a:d8:40      te1/0/2                                          O        117
te1/0/19   44:a1:91:69:af:15 XGigabitEthernet0        RIC-USG6635-FW3              R        103
                                  /0/1
te1/0/17   54:4b:8c:f4:67:c0     xe-1/2/2          18-IZHK58-AR1.udmvt.ru         B, R      115
te1/0/21   44:a1:91:3f:fb:80 GigabitEthernet1/        DTC-USG6670-FW2              R        90
                                    0/8
""")
        self.assertEqual(len(parsed), 4)
        self.assertEqual(parsed[3]["neighbor_interface"], "GigabitEthernet1/0/8")
        self.assertEqual(parsed[0]["neighbor_interface"], "te1/0/2")
        self.assertEqual(parsed[1]["neighbor_interface"], "XGigabitEthernet0/0/1")
        self.assertEqual(parsed[1]["neighbor_device"], "RIC-USG6635-FW3")
        self.assertEqual(parsed[2]["neighbor_device"], "18-IZHK58-AR1.udmvt.ru")

    def test_eltex_lldp_does_not_treat_capability_letters_as_device_name(self):
        parsed = parse_eltex_lldp("""Port       Device ID          Port ID               System Name           Capabilities  TTL
te1/0/1    e0:d9:e3:1a:d8:40      te1/0/2                                          O
""")
        self.assertEqual(len(parsed), 1)
        self.assertNotIn("neighbor_device", parsed[0])

    def test_eltex_system_parser_handles_missing_model(self):
        self.assertEqual(parse_eltex_system("System Up Time: 1 day")["model"], "")

    def test_eltex_stack_ports_and_port_channels(self):
        parsed = parse_eltex_interfaces("""Port Name Status Speed Duplex Auto Negotiation Flow Control
te1/0/21 Connected 10G Full Enabled Disabled
te2/0/21 NotPresent -- -- -- --
Po1 Up 20G Full Enabled Disabled
""")
        self.assertEqual(parsed["te1/0/21"]["operstatus"], "up")
        self.assertEqual(parsed["te2/0/21"]["operstatus"], "down")
        self.assertEqual(parsed["Po1"]["type"], "lag")

    def test_eltex_mes5324a_show_interfaces_status_real_format(self):
        parsed = parse_eltex_interfaces("""Port       Type         Duplex  Speed  Neg      ctrl State         (d,h:m:s)   Pressure Mode    Port Mode (VLAN)
---------- ------------ ------  ------ -------- ---- ----------- ------------- -------- ------- ------------------------
te1/0/1    10G-Fiber    Full    10000  Disabled Off  Up          73,19:42:28   Disabled Off     Trunk
te1/0/2    10G-Fiber      --      --      --     --  Down (nc)         --         --     --     Access (2770)
te1/0/4    10G-Fiber      --      --      --     --  Down (adm)        --         --     --     Access (1)
te1/0/23       --        --      --      --     --  Not Present       --         --     --     Access (1)
Po1        10G          Full    20000  Enabled  Off  Up            Trunk
Po8        10G            --      --      --     --  Down (nc)     Trunk
Po9           --          --      --      --     --  Not Present   Access (1)
""")
        self.assertEqual(set(parsed), {"te1/0/1", "te1/0/2", "te1/0/4", "te1/0/23", "Po1", "Po8", "Po9"})
        self.assertEqual(parsed["te1/0/1"]["operstatus"], "up")
        self.assertEqual(parsed["te1/0/2"]["operstatus"], "down")
        self.assertEqual(parsed["te1/0/4"]["operstatus"], "down")
        self.assertEqual(parsed["te1/0/23"]["operstatus"], "not_present")
        self.assertEqual(parsed["Po1"]["type"], "lag")
        self.assertEqual(parsed["Po8"]["operstatus"], "down")

    def test_cisco_catalyst_9410_ios_xe_version_inventory_interfaces_and_lag(self):
        version = parse_cisco_version("""Cisco IOS XE Software, Version 16.06.04
cisco C9410R (X86) processor with 123456K bytes of memory
System serial number : FOC1234ABCD
""")
        inventory = parse_cisco_inventory("""NAME: \"Chassis\", DESCR: \"Cisco Catalyst 9410\"
PID: C9410R, VID: V01, SN: FOC1234ABCD""")
        self.assertEqual(version["version"], "16.06.04")
        self.assertEqual(inventory, {"model": "C9410R", "serial": "FOC1234ABCD"})
        interfaces = parse_cisco_interfaces("""Port      Name               Status       Vlan       Duplex Speed Type
Gi1/0/1                      connected    10         a-full a-1000 10/100/1000BaseTX
Fo1/0/1                      notconnect   1          auto   auto   40GBase-SR4
Po1                          connected    trunk      a-full a-40G
""")
        self.assertEqual(interfaces["Gi1/0/1"]["operstatus"], "up")
        self.assertEqual(interfaces["Fo1/0/1"]["type"], "40gbase-x-qsfpp")
        self.assertEqual(interfaces["Po1"]["type"], "lag")
        self.assertEqual(parse_cisco_lag_members("1 Po1(SU) LACP Gi1/0/1(P) Fo1/0/1(P)"), {"Po1": ["Gi1/0/1", "Fo1/0/1"]})

    def test_cisco_interfaces_status_keeps_name_column_and_descriptions(self):
        parsed = parse_cisco_interfaces("""Port      Name                         Status       Vlan       Duplex Speed Type
Gi3/0/47  USG6635_FW4_MGMT             connected    23         a-full a-1000 10/100/1000BaseTX
Te4/0/1   HuwS5735_21                  connected    trunk      a-full a-10000 10GBase-SR
Te4/0/8   Coordinator_ATS_v252         notconnect   1          auto   auto 10GBase-SR
Po14                                   notconnect   trunk      auto   auto -
""")
        self.assertEqual(parsed["Gi3/0/47"]["description"], "USG6635_FW4_MGMT")
        self.assertEqual(parsed["Te4/0/1"]["operstatus"], "up")
        self.assertEqual(parsed["Te4/0/8"]["description"], "Coordinator_ATS_v252")
        self.assertEqual(parsed["Po14"]["type"], "lag")
        self.assertEqual(parsed["Po14"]["operstatus"], "down")

    def test_cisco_interface_descriptions_preserve_full_text(self):
        parsed = parse_cisco_interface_descriptions("""Interface                      Status         Protocol Description
Gi8/0/46                       up             up       DTC-P24-ELX-SW-23-254
Gi8/0/5                        down           down     UserGate_up_to_LogServer
Te4/0/9                        up             up       Coordinator_ATSr_v252
Po14                           down           down     Test Yadro aggregate
""")
        self.assertEqual(parsed["Gi8/0/46"], "DTC-P24-ELX-SW-23-254")
        self.assertEqual(parsed["Gi8/0/5"], "UserGate_up_to_LogServer")
        self.assertEqual(parsed["Te4/0/9"], "Coordinator_ATSr_v252")
        self.assertEqual(parsed["Po14"], "Test Yadro aggregate")

    def test_cisco_lldp_detail_parser(self):
        parsed = parse_cisco_lldp("""Local Intf: Te7/0/9
Chassis id: 6012.3ce8.81c0
Port id: XGigabitEthernet0/0/4
Port Description: DTC-P24-CSC-CSW-23-254
System Name: DTC-P24-HUW-SW-23-129
System Description:
Huawei Switch S5735-S24T4X
Management Addresses:
    IP: 192.168.1.253

Local Intf: Te6/0/4
Chassis id: 24a5.2cfd.70f3
Port id: GigabitEthernet3/0/9
System Name: DTC-USG6670-FW1
Management Addresses:
    IP: 91.230.91.9
""")
        self.assertEqual(len(parsed), 2)
        self.assertEqual(parsed[0]["neighbor_device"], "DTC-P24-HUW-SW-23-129")
        self.assertEqual(parsed[0]["neighbor_interface"], "XGigabitEthernet0/0/4")
        self.assertEqual(parsed[0]["management_ip"], "192.168.1.253")
        self.assertEqual(parsed[1]["local_interface"], "Te6/0/4")

    def test_snr_s5311_enos_version_interfaces_and_lag(self):
        parsed = parse_snr_version("""SNR-S5311G-48TX-POE Ethernet Managed Switch
eNOS software, Compiled on 09/04/26 10:31:23 (d67f5439d)
Software Version 1.23.0
BootRom Version 1.14
HardWare Version 1.0.0
Serial No.: SWBM052189001917
""")
        self.assertEqual(parsed, {"model": "SNR-S5311G-48TX-POE", "version": "1.23.0", "serial": "SWBM052189001917"})
        interfaces = parse_snr_interfaces("""Interface Status VLAN Duplex Speed Type
ge1 up 1 full 1000 copper
ge2 down 1 auto auto copper
xe1 up trunk full 10000 fiber
Port-Channel1 up trunk full 20000 logical
""")
        self.assertEqual(interfaces["ge1"]["operstatus"], "up")
        self.assertEqual(interfaces["ge2"]["operstatus"], "down")
        self.assertEqual(interfaces["xe1"]["type"], "10gbase-x-sfpp")
        self.assertEqual(interfaces["Port-Channel1"]["type"], "lag")
        self.assertEqual(parse_snr_lag_members("1 Port-Channel1(SU) LACP ge1(P) xe1(P)"), {"Port-Channel1": ["ge1", "xe1"]})

    def test_snr_running_config_enriches_descriptions_ip_and_hybrid_vlan_details(self):
        brief = {
            "ge1": {"operstatus": "down", "type": "1000base-t", "description": ""},
            "ge48": {"operstatus": "up", "type": "1000base-t", "description": ""},
            "xe6": {"operstatus": "down", "type": "10gbase-x-sfpp", "description": ""},
            "vlan1": {"operstatus": "up", "type": "virtual", "description": ""},
        }
        config = """hostname test
interface ge1
 description 37_5.1
 switchport mode hybrid
 switchport hybrid native vlan 701
 switchport hybrid allowed vlan 2 tag
 switchport hybrid allowed vlan 701 untag
!
interface ge48
 switchport mode hybrid
 switchport hybrid native vlan 1
 switchport hybrid allowed vlan 2 tag
 switchport hybrid allowed vlan 1 untag
!
interface xe6
 description to_Cisco_9410R
 switchport mode trunk
 switchport trunk allowed vlan 23
 switchport trunk native vlan 1
!
interface vlan1
 ip address 192.168.1.1/24
!
ip route 0.0.0.0/0 192.168.23.1
end
"""
        parsed = parse_snr_running_config(config, brief)
        self.assertEqual(parsed["ge1"]["description"], "37_5.1")
        self.assertEqual(parsed["ge1"]["tagged_vlans"], [2])
        self.assertEqual(parsed["ge1"]["untagged_vlans"], [701])
        self.assertEqual(parsed["ge1"]["native_vlan"], 701)
        self.assertEqual(parsed["xe6"]["description"], "to_Cisco_9410R")
        self.assertEqual(parsed["xe6"]["allowed_vlans"], [23])
        self.assertEqual(parsed["xe6"]["tagged_vlans"], [23])
        self.assertEqual(parsed["xe6"]["untagged_vlans"], [1])
        self.assertEqual(parsed["vlan1"]["ip_addresses"], ["192.168.1.1/24"])
        self.assertEqual(parsed["ge48"]["description"], "")

    def test_huawei_lldp_detail_keeps_remote_port_and_chassis_id(self):
        parsed = parse_huawei_lldp("""Interface GigabitEthernet3/0/9 has 1 Neighbors:
  ChassisId: 7079-b3f2-4140
  PortId: Te6/0/4
  System name: DTC-P24-ELX-SW
""")
        self.assertEqual(len(parsed), 1)
        self.assertEqual(parsed[0]["local_interface"], "GigabitEthernet3/0/9")
        self.assertEqual(parsed[0]["neighbor_interface"], "Te6/0/4")
        self.assertEqual(parsed[0]["chassis_id"], "7079-b3f2-4140")

    def test_snr_vlan_parser_reads_named_vlan_blocks(self):
        parsed = parse_snr_vlans("""vlan 2
 name Phones
!
vlan 23
 name Management
!
vlan 316
 name Tests
!
vlan 701
 name Workers_OUS
!
""")
        self.assertEqual(parsed, [
            {"vid": 2, "name": "Phones", "status": "active"},
            {"vid": 23, "name": "Management", "status": "active"},
            {"vid": 316, "name": "Tests", "status": "active"},
            {"vid": 701, "name": "Workers_OUS", "status": "active"},
        ])

    def test_snr_vlan_parser_removes_trailing_operational_state_from_names(self):
        parsed = parse_snr_vlans("""vlan 2 name Phones state enable
vlan 23
 name Management state enable
!
vlan 316 name Tests state disable
""")
        self.assertEqual(parsed, [
            {"vid": 2, "name": "Phones", "status": "active"},
            {"vid": 23, "name": "Management", "status": "active"},
            {"vid": 316, "name": "Tests", "status": "active"},
        ])

    def test_vlan_parser_skips_headers_and_invalid_ids(self):
        parsed = parse_vlans("VLAN Name Status\n1 default active\n23 users active\n4095 invalid active\n")
        self.assertEqual([x["vid"] for x in parsed], [1, 23])


if __name__ == "__main__":
    unittest.main()


class EltexEsrParserTests(unittest.TestCase):
    def test_esr_version_and_system_identity(self):
        v = parse_eltex_esr_version("Boot version: 1.14.5.2\nSW version: 1.14.5 build 5[596cabe53]")
        self.assertEqual(v["version"], "1.14.5 build 5[596cabe53]")
        self.assertEqual(v["boot_version"], "1.14.5.2")
        system = parse_eltex_esr_system("System type: Eltex ESR-200 Service Router\nSystem name: AR1-COMERCIAL\nSoftware version: 1.14.5 build 5[596cabe53]\nHardware version: 1v8\nMAC: A8:F9:4B:AD:A2:4A\nSerial: NP02003282")
        self.assertEqual(system["hostname"], "AR1-COMERCIAL")
        self.assertEqual(system["serial"], "NP02003282")

    def test_esr_system_parses_actual_show_system_labels(self):
        output = """System type:           Eltex ESR-200 Service Router
System name:           AR1-COMERCIAL
Software version:      1.14.5 build 5[596cabe53] (date 20/04/2022 time 11:45:35)
Hardware version:      1v8
System uptime:         878 days, 23 hours, 48 minutes and 53 seconds
System MAC address:    A8:F9:4B:AD:A2:4A
System serial number:  NP02003282
"""
        parsed = parse_eltex_esr_system(output)
        self.assertEqual(parsed["hostname"], "AR1-COMERCIAL")
        self.assertEqual(parsed["version"], "1.14.5 build 5[596cabe53] (date 20/04/2022 time 11:45:35)")
        self.assertEqual(parsed["uptime"], "878 days, 23 hours, 48 minutes and 53 seconds")
        self.assertEqual(parsed["mac"], "A8:F9:4B:AD:A2:4A")
        self.assertEqual(parsed["serial"], "NP02003282")

    def test_esr_system_serial_label_variants(self):
        for label in ("Serial", "Serial number", "Serial No.", "Serial No"):
            for separator in (": ", " ", " : "):
                with self.subTest(label=label, separator=separator):
                    parsed = parse_eltex_esr_system(f"System name: AR1-COMERCIAL\n{label}{separator}NP02003282")
                    self.assertEqual(parsed["serial"], "NP02003282")

    def test_esr_system_does_not_guess_missing_serial(self):
        parsed = parse_eltex_esr_system("System name: AR1-COMERCIAL\nMAC: A8:F9:4B:AD:A2:4A")
        self.assertEqual(parsed["serial"], "")

    def test_esr_interfaces_and_descriptions(self):
        status = parse_eltex_esr_interfaces("Interface Admin state Link state MTU MAC address Last change Mode\ngi1/0/1 Up Up 1500 a8:f9:4b:ad:a2:4b 878 days routerport\ngi1/0/1.18 Down Down 1500 a8:f9:4b:ad:a2:4b 3 seconds routerport")
        self.assertEqual(status["gi1/0/1"]["operstatus"], "up")
        self.assertEqual(status["gi1/0/1.18"]["type"], "virtual")
        self.assertEqual(status["gi1/0/1.18"]["admin_status"], "disabled")
        desc = parse_eltex_esr_descriptions("Interface Admin State Link State Description\ngi1/0/1 Up Up ISP-Megafon\ngi1/0/1.785 Up Up RT_for_Wi-Fi")
        self.assertEqual(desc["gi1/0/1.785"]["description"], "RT_for_Wi-Fi")

    def test_esr_ip_vlans_vrrp_routes_and_failover(self):
        ips = parse_eltex_esr_ip_interfaces("10.10.23.251/24 gi1/0/1.1023 Up Up static")
        self.assertEqual(ips["gi1/0/1.1023"]["address"], "10.10.23.251/24")
        vlans = parse_eltex_esr_vlans('vlan 1023\n  name "mgm_kommers"\nexit\nvlan 1070\n  name "Guest_VM_Test"\nexit')
        self.assertEqual(vlans, [{"vid":1023,"name":"mgm_kommers","status":"active"},{"vid":1070,"name":"Guest_VM_Test","status":"active"}])
        vrrp = parse_eltex_esr_vrrp("Virtual router   Virtual IP                          Priority   Preemption   State\n10               10.10.10.1/24                       200        Enabled      Master")
        self.assertEqual(vrrp[0]["id"], 10)
        detail = parse_eltex_esr_vrrp("VRRP ID: 10\nInterface: gi1/0/2.1010\nPriority: 200\nState: Master\nSource IP address: 10.10.10.251\nVirtual IP address: 10.10.10.1/24")
        self.assertEqual(detail[0]["interface"], "gi1/0/2.1010")
        routes = parse_eltex_esr_routes("S     * 0.0.0.0/0 [1/251] via 178.176.102.137 on vrrp.30 [static]")
        self.assertEqual(routes[0]["next_hop"], "178.176.102.137")
        failover = parse_eltex_esr_failover("Communication interface: gi1/0/1.1023\nStatus: Running\nSend errors: 387\nReceive errors: 0")
        self.assertEqual(failover["status"], "Running")
        self.assertEqual(failover["send_errors"], 387)
