import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from eltex_esr_cli import clean, run_command  # noqa: E402


class FakeChannel:
    def __init__(self, chunks):
        self.chunks = list(chunks)
        self.sent = []

    def send(self, data):
        self.sent.append(data)

    def recv_ready(self):
        return bool(self.chunks)

    def recv(self, _size):
        return self.chunks.pop(0)


class EltexEsrCliRunnerTests(unittest.TestCase):
    def test_command_output_excludes_echo_and_prompt(self):
        channel = FakeChannel([b"show system\r\nSystem type: Eltex ESR-200 Service Router\r\nSystem name: AR1-COMERCIAL\r\nAR1-COMERCIAL#\r\n"])
        output = run_command(channel, "AR1-COMERCIAL#", "show system", timeout=1)
        self.assertEqual(output, "System type: Eltex ESR-200 Service Router\nSystem name: AR1-COMERCIAL\n")
        self.assertEqual(channel.sent, ["show system\n"])

    def test_clean_removes_terminal_escape_sequences(self):
        self.assertEqual(clean("\x1b[32mAR1-COMERCIAL#\x1b[0m\r\n"), "AR1-COMERCIAL#\n")


if __name__ == "__main__":
    unittest.main()
