"""Isolated API smoke tests. They use a temporary local database and HTTPS test client."""
import os
import sys
import tempfile
import unittest
from unittest.mock import patch, MagicMock
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
_TEST_DATA = tempfile.TemporaryDirectory(prefix="netbox-sync-tests-")
os.environ["WEBUI_DATA_DIR"] = _TEST_DATA.name
os.environ["WEBUI_BOOTSTRAP_USER"] = "testadmin"
os.environ["WEBUI_BOOTSTRAP_PASSWORD"] = "StrongTestPassword123!"
sys.path.insert(0, str(ROOT))
from fastapi.testclient import TestClient
from webui.app import app, build_runtime_inventory, REPORTS, sync_preflight, _host_key_status, _fingerprints, KNOWN_HOSTS_PATH, ansible_collections_path, _auto_collect_device_names, cleanup_old_fact_reports

class WebUiApiTests(unittest.TestCase):
    def test_ansible_collection_path_survives_home_redirect(self):
        with tempfile.TemporaryDirectory(prefix="ansible-home-") as temp_home:
            collection_root = Path(temp_home) / ".ansible" / "collections"
            collection_root.mkdir(parents=True)
            paths = ansible_collections_path({"HOME": temp_home})
            self.assertIn(str(collection_root), paths.split(os.pathsep))
            self.assertIn("/usr/share/ansible/collections", paths.split(os.pathsep))

    @classmethod
    def setUpClass(cls):
        cls.client = TestClient(app, base_url="https://testserver")
        response = cls.client.post("/api/login", json={"username":"testadmin", "password":"StrongTestPassword123!"})
        if response.status_code != 200:
            raise RuntimeError(f"test login failed: {response.text}")
        cls.csrf = response.json()["csrf_token"]
        cls.headers = {"X-CSRF-Token": cls.csrf}

    def create_device(self, name, vendor="Huawei"):
        response = self.client.post("/api/devices", headers=self.headers, json={
            "name": name, "vendor": vendor, "address": "127.0.0.1", "device_type": "switch",
            "protocol": "tcp", "port": 1, "username": "operator", "password": "private-device-secret",
            "settings": {"platform": "vrp"}
        })
        self.assertEqual(response.status_code, 201, response.text)
        self.assertNotIn("password", response.json())
        self.assertNotIn("credentials_enc", response.json())
        self.assertNotIn("private-device-secret", response.text)
        return response.json()["id"]


    def test_esr_management_count_is_independent_from_netbox_sync_devices(self):
        self.create_device("netbox-eltex-esr-record", "Eltex")
        response = self.client.get("/api/esr/managed-devices/summary")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()["count"], 0)
        from webui.app import db
        with db() as conn:
            conn.execute("INSERT INTO esr_managed_devices(name,address,port,created_at,updated_at) VALUES(?,?,?,?,?)",
                         ("managed-esr-01", "192.0.2.90", 22, "now", "now"))
        response = self.client.get("/api/esr/managed-devices/summary")
        self.assertEqual(response.json()["count"], 1)

    def test_auto_collection_is_opt_in_per_ssh_device(self):
        # Existing records are excluded by default; only explicit per-device opt-in is included.
        self.create_device("auto-disabled-default", "Huawei")
        enabled = self.client.post("/api/devices", headers=self.headers, json={
            "name": "auto-enabled-huawei", "vendor": "Huawei", "address": "192.0.2.80", "device_type": "firewall",
            "protocol": "ssh", "port": 22, "username": "operator", "password": "private-device-secret",
            "settings": {"device_model": "Huawei USG6670", "device_profile": "huawei_usg6670", "auto_collect": True}
        })
        self.assertEqual(enabled.status_code, 201, enabled.text)
        disabled = self.client.post("/api/devices", headers=self.headers, json={
            "name": "auto-disabled-huawei", "vendor": "Huawei", "address": "192.0.2.81", "device_type": "firewall",
            "protocol": "ssh", "port": 22, "username": "operator", "password": "private-device-secret",
            "settings": {"device_model": "Huawei USG6670", "device_profile": "huawei_usg6670", "auto_collect": False}
        })
        self.assertEqual(disabled.status_code, 201, disabled.text)
        names = _auto_collect_device_names()
        self.assertIn("auto-enabled-huawei", names)
        self.assertNotIn("auto-disabled-huawei", names)
        self.assertNotIn("auto-disabled-default", names)

    def test_report_can_be_deleted_and_expired_reports_are_pruned(self):
        import json, os, time
        fresh = REPORTS / "manual-delete-facts.json"
        fresh.write_text(json.dumps({"device": "manual-delete", "interfaces": {}}), encoding="utf-8")
        response = self.client.delete("/api/reports/manual-delete-facts.json", headers=self.headers)
        self.assertEqual(response.status_code, 204, response.text)
        self.assertFalse(fresh.exists())
        expired = REPORTS / "expired-retention-facts.json"
        expired.write_text(json.dumps({"device": "expired", "interfaces": {}}), encoding="utf-8")
        old = time.time() - 31 * 86400
        os.utime(expired, (old, old))
        removed = cleanup_old_fact_reports(30)
        self.assertGreaterEqual(removed, 1)
        self.assertFalse(expired.exists())

    def test_virtual_chassis_stores_logical_data_and_members(self):
        first = self.create_device("vc-member-ar1", "Eltex")
        second = self.create_device("vc-member-ar2", "Eltex")
        response = self.client.post("/api/virtual-chassis", headers=self.headers, json={
            "name": "ESR200-AR1-HA", "vendor": "Eltex", "member_device_ids": [first, second],
            "logical_data": {"interfaces": [{"name": "vrrp10", "ip_addresses": ["10.10.10.3/24"]}]},
            "notes": "preliminary model"
        })
        self.assertEqual(response.status_code, 201, response.text)
        body = response.json()
        self.assertEqual({m["id"] for m in body["members"]}, {first, second})
        self.assertEqual(body["logical_data"]["interfaces"][0]["ip_addresses"], ["10.10.10.3/24"])
        self.assertEqual(self.client.get("/api/virtual-chassis").status_code, 200)

    def test_huawei_virtual_chassis_finds_only_identical_eth_trunk_subinterfaces(self):
        first = self.create_device("huawei-vc-member-a", "Huawei")
        second = self.create_device("huawei-vc-member-b", "Huawei")
        chassis = self.client.post("/api/virtual-chassis", headers=self.headers, json={
            "name": "VC-Huawei-EthTrunk", "vendor": "Huawei", "member_device_ids": [first, second]
        })
        self.assertEqual(chassis.status_code, 201, chassis.text)
        config_a = """sysname A
interface Eth-Trunk10.100
 vlan-type dot1q 100
 ip address 10.0.0.1 255.255.255.0
interface Eth-Trunk10.200
 vlan-type dot1q 200
 ip address 10.0.1.1 255.255.255.0
interface GigabitEthernet0/0/1
 undo shutdown
"""
        config_b = """sysname B
interface Eth-Trunk10.100
 vlan-type dot1q 100
 ip address 10.0.0.1 255.255.255.0
interface Eth-Trunk10.200
 vlan-type dot1q 200
 ip address 10.0.1.2 255.255.255.0
interface GigabitEthernet0/0/2
 undo shutdown
"""
        for device_id, config in ((first, config_a), (second, config_b)):
            response = self.client.post(f"/api/devices/{device_id}/configs", headers=self.headers,
                                        json={"config_text": config, "source": "test"})
            self.assertEqual(response.status_code, 201, response.text)
        result = self.client.get(f"/api/virtual-chassis/{chassis.json()['id']}/eth-trunk-subinterfaces")
        self.assertEqual(result.status_code, 200, result.text)
        body = result.json()
        self.assertEqual([x["name"] for x in body["candidates"]], ["eth-trunk10.100"])
        self.assertEqual([x["name"] for x in body["different_config"]], ["eth-trunk10.200"])

    def test_device_can_be_assigned_to_common_logical_object_from_device_api(self):
        member = self.create_device("vc-assigned-from-device-form")
        chassis = self.client.post("/api/virtual-chassis", headers=self.headers, json={
            "name": "VC-assignment-target", "vendor": "Huawei", "member_device_ids": []
        })
        self.assertEqual(chassis.status_code, 201, chassis.text)
        chassis_id = chassis.json()["id"]
        updated = self.client.patch(f"/api/devices/{member}", headers=self.headers, json={"virtual_chassis_id": chassis_id})
        self.assertEqual(updated.status_code, 200, updated.text)
        self.assertEqual(updated.json()["virtual_chassis_id"], chassis_id)
        listed = {d["id"]: d for d in self.client.get("/api/devices").json()}
        self.assertEqual(listed[member]["virtual_chassis_name"], "VC-assignment-target")
        unassigned = self.client.patch(f"/api/devices/{member}", headers=self.headers, json={"virtual_chassis_id": None})
        self.assertEqual(unassigned.status_code, 200, unassigned.text)
        self.assertIsNone(unassigned.json()["virtual_chassis_id"])

    def test_vrrp_candidates_aggregate_latest_member_reports_without_syncing(self):
        first = self.create_device("vrrp-member-ar1", "Eltex")
        second = self.create_device("vrrp-member-ar2", "Eltex")
        chassis = self.client.post("/api/virtual-chassis", headers=self.headers, json={
            "name": "VC-vrrp-candidates", "vendor": "Eltex", "member_device_ids": [first, second]
        })
        self.assertEqual(chassis.status_code, 201, chassis.text)
        for name, state, priority, source_ip in (("vrrp-member-ar1", "Master", 200, "10.10.10.1"), ("vrrp-member-ar2", "Backup", 150, "10.10.10.2")):
            report = {"device": name, "vrrp_details": [{"id": 10, "virtual_ip": "10.10.10.3/24", "interface": "gi1/0/2.1010", "state": state, "priority": priority, "source_ip": source_ip}]}
            (REPORTS / f"{name}-facts.json").write_text(__import__("json").dumps(report), encoding="utf-8")
        response = self.client.get(f"/api/virtual-chassis/{chassis.json()['id']}/vrrp-candidates")
        self.assertEqual(response.status_code, 200, response.text)
        body = response.json()
        self.assertEqual(len(body["candidates"]), 1)
        self.assertEqual(body["candidates"][0]["ip_addresses"], ["10.10.10.3/24"])
        self.assertEqual({m["state"] for m in body["candidates"][0]["members"]}, {"Master", "Backup"})
        self.assertEqual(body["candidates"][0]["warnings"], [])
        self.assertEqual(body["members_without_fresh_report"], [])
        self.assertIn("не отправляет данные в NetBox", body["note"])

    def test_vrrp_candidates_do_not_warn_on_vip_subnet_mismatch_but_warn_on_missing_member(self):
        first = self.create_device("vrrp-warn-ar1", "Eltex")
        second = self.create_device("vrrp-warn-ar2", "Eltex")
        chassis = self.client.post("/api/virtual-chassis", headers=self.headers, json={
            "name": "VC-vrrp-warnings", "vendor": "Eltex", "member_device_ids": [first, second]
        })
        self.assertEqual(chassis.status_code, 201, chassis.text)
        report = {"device": "vrrp-warn-ar1", "vrrp_details": [{
            "id": 30, "virtual_ip": "178.176.102.138/29", "interface": "gi1/0/1.1253",
            "state": "Master", "priority": 200, "source_ip": "10.10.30.251"
        }]}
        (REPORTS / "vrrp-warn-ar1-facts.json").write_text(__import__("json").dumps(report), encoding="utf-8")
        response = self.client.get(f"/api/virtual-chassis/{chassis.json()['id']}/vrrp-candidates")
        self.assertEqual(response.status_code, 200, response.text)
        candidate = response.json()["candidates"][0]
        self.assertFalse(any("не входит в подсеть VIP" in warning for warning in candidate["warnings"]))
        self.assertTrue(any("vrrp-warn-ar2" in warning for warning in candidate["warnings"]))

    def test_virtual_chassis_rejects_member_from_different_vendor(self):
        eltex_member = self.create_device("vc-eltex-member", "Eltex")
        huawei_member = self.create_device("vc-huawei-member", "Huawei")
        response = self.client.post("/api/virtual-chassis", headers=self.headers, json={
            "name": "VC-vendor-enforcement", "vendor": "Eltex", "member_device_ids": [eltex_member, huawei_member]
        })
        self.assertEqual(response.status_code, 400, response.text)
        self.assertIn("Производитель", response.json()["detail"])

    def test_device_assignment_rejects_missing_logical_object(self):
        member = self.create_device("vc-assigned-missing-target")
        response = self.client.patch(f"/api/devices/{member}", headers=self.headers, json={"virtual_chassis_id": 999999})
        self.assertEqual(response.status_code, 400, response.text)

    def test_physical_device_cannot_belong_to_two_virtual_chassis(self):
        member = self.create_device("vc-member-exclusive", "Eltex")
        first = self.client.post("/api/virtual-chassis", headers=self.headers, json={
            "name": "VC-exclusive-a", "vendor": "Eltex", "member_device_ids": [member]})
        self.assertEqual(first.status_code, 201, first.text)
        second = self.client.post("/api/virtual-chassis", headers=self.headers, json={
            "name": "VC-exclusive-b", "vendor": "Eltex", "member_device_ids": [member]})
        self.assertEqual(second.status_code, 409, second.text)

    def test_device_credentials_hidden_and_config_diff(self):
        device_id = self.create_device("test-switch-diff")
        for config in ("sysname test\n password old-secret-value\ninterface X\n description old\n", "sysname test\n password new-secret-value\ninterface X\n description new\n"):
            response = self.client.post(f"/api/devices/{device_id}/configs", headers=self.headers,
                                        json={"config_text": config, "source": "unit-test"})
            self.assertEqual(response.status_code, 201, response.text)
        result = response.json()
        self.assertTrue(result["has_changes"])
        self.assertTrue(any(line.startswith("- description old") for line in result["diff"]))
        self.assertTrue(any(line.startswith("+ description new") for line in result["diff"]))
        self.assertNotIn("new-secret-value", response.text)
        self.assertNotIn("old-secret-value", response.text)

    def test_all_users_have_same_permissions(self):
        response = self.client.post("/api/users", headers=self.headers,
                                    json={"username":"seconduser", "password":"AnotherStrongPassword123!"})
        self.assertEqual(response.status_code, 201, response.text)
        other = TestClient(app, base_url="https://testserver")
        login = other.post("/api/login", json={"username":"seconduser", "password":"AnotherStrongPassword123!"})
        self.assertEqual(login.status_code, 200, login.text)
        other_headers = {"X-CSRF-Token": login.json()["csrf_token"]}
        self.assertEqual(other.get("/api/devices").status_code, 200)
        self.assertEqual(other.post("/api/devices", headers=other_headers, json={
            "name":"test-switch-second", "vendor":"Eltex", "address":"127.0.0.1", "device_type":"switch",
            "protocol":"tcp", "port":1, "username":"u", "password":"secret"
        }).status_code, 201)

    def test_ssh_host_key_tofu_and_explicit_replacement(self):
        # Valid-looking SSH public-key blobs are sufficient for deterministic host-key bookkeeping tests.
        address = "198.51.100.253"
        first = [f"{address} ssh-ed25519 YWJjZGVmZ2hpamtsbW5vcA=="]
        second = [f"{address} ssh-ed25519 YWJjZGVmZ2hpamtsbW5vcQ=="]
        added = _host_key_status(address, 22, first)
        self.assertEqual(added["state"], "added")
        self.assertEqual(_host_key_status(address, 22, first)["state"], "trusted")
        changed = _host_key_status(address, 22, second)
        self.assertEqual(changed["state"], "changed")
        self.assertNotEqual(changed["old_fingerprints"], changed["new_fingerprints"])
        replaced = _host_key_status(address, 22, second, replace=True)
        self.assertEqual(replaced["state"], "replaced")
        self.assertEqual(_host_key_status(address, 22, second)["state"], "trusted")
        self.assertEqual(KNOWN_HOSTS_PATH.stat().st_mode & 0o777, 0o600)

    def test_host_key_event_history_endpoint(self):
        device_id = self.create_device("test-hostkey-events")
        response = self.client.get(f"/api/devices/{device_id}/host-key/events")
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json(), [])

    def test_availability_monitoring_api_is_not_exposed(self):
        device_id = self.create_device("test-no-monitoring")
        response = self.client.get("/api/checks")
        self.assertEqual(response.status_code, 404)
        device = self.client.get("/api/devices").json()[0]
        self.assertNotIn("last_status", device)
        self.assertNotIn("last_checked_at", device)
        self.assertNotIn("private-device-secret", str(device))

    def test_tcp_only_device_cannot_be_used_as_monitoring_target(self):
        device_id = self.create_device("test-tcp-not-monitored")
        response = self.client.post(f"/api/devices/{device_id}/test", headers=self.headers)
        self.assertEqual(response.status_code, 400, response.text)

    def test_dashboard_reports_collection_and_sync_metrics_not_availability(self):
        self.create_device("dashboard-auto-enabled", "Huawei")
        response = self.client.get("/api/status")
        self.assertEqual(response.status_code, 200, response.text)
        data = response.json()
        self.assertIn("auto_collect", data["device_summary"])
        self.assertIn("last_fact_collection", data)
        self.assertIn("last_successful_sync", data)
        self.assertIn("collection_errors", data)
        self.assertNotIn("drift", data["device_summary"])
        self.assertNotIn("unreachable", data["device_summary"])
        self.assertNotIn("latest_success", data["device_summary"])

    def test_runtime_inventory_uses_local_devices_and_keeps_connection_secret_private_from_reports(self):
        self.client.post("/api/devices", headers=self.headers, json={
            "name":"local-huawei-runtime", "vendor":"Huawei", "address":"192.0.2.10", "device_type":"firewall",
            "protocol":"ssh", "port":22, "username":"netops", "password":"runtime-secret-123",
            "settings":{"device_model":"Huawei USG6670", "device_profile":"huawei_usg6670", "netbox_site":"Lab", "netbox_role":"Firewall", "netbox_device_type_slug":"usg6670"}
        }).raise_for_status()
        inventory, secrets_to_redact = build_runtime_inventory()
        host = inventory["all"]["children"]["huawei"]["hosts"]["local-huawei-runtime"]
        self.assertEqual(host["ansible_host"], "192.0.2.10")
        self.assertEqual(host["ansible_network_os"], "community.network.ce")
        self.assertEqual(host["ansible_network_cli_ssh_type"], "paramiko")
        for name, vendor, settings in (("local-cisco-runtime", "Cisco", {"ansible_network_os": "cisco.ios.ios", "device_model":"Cisco Catalyst 9410", "device_profile":"cisco_catalyst_9410"}), ("local-snr-runtime", "SNR", {"device_model":"SNR S5311G-48TX-POE", "device_profile":"snr_s5311g48txpoe"})):
            response = self.client.post("/api/devices", headers=self.headers, json={
                "name": name, "vendor": vendor, "address": "192.0.2.20", "device_type": "switch",
                "protocol": "ssh", "port": 22, "username": "netops", "password": "runtime-secret-456", "settings": settings
            })
            self.assertEqual(response.status_code, 201, response.text)
        inventory, _ = build_runtime_inventory()
        cisco = inventory["all"]["children"]["cisco"]["hosts"]["local-cisco-runtime"]
        snr = inventory["all"]["children"]["snr"]["hosts"]["local-snr-runtime"]
        self.assertEqual(cisco["ansible_network_os"], "cisco.ios.ios")
        self.assertEqual(cisco["platform"], "cisco")
        self.assertEqual(cisco["ansible_network_cli_ssh_type"], "paramiko")
        self.assertEqual(snr["ansible_network_os"], "cisco.ios.ios")
        self.assertEqual(snr["platform"], "snr")
        self.assertEqual(snr["ansible_network_cli_ssh_type"], "paramiko")
        esr_response = self.client.post("/api/devices", headers=self.headers, json={
            "name": "local-esr-runtime", "vendor": "Eltex", "address": "192.0.2.30", "device_type": "router",
            "protocol": "ssh", "port": 22, "username": "netops", "password": "runtime-secret-esr",
            "settings": {"device_model": "Eltex ESR200", "device_profile": "eltex_esr200"}
        })
        self.assertEqual(esr_response.status_code, 201, esr_response.text)
        inventory, _ = build_runtime_inventory()
        esr = inventory["all"]["children"]["eltex"]["hosts"]["local-esr-runtime"]
        self.assertEqual(esr["ansible_connection"], "local")
        self.assertEqual(esr["ansible_network_os"], "local")
        self.assertEqual(esr["platform"], "eltex")
        self.assertEqual(esr["device_profile"], "eltex_esr200")
        self.assertEqual(host["netbox_site"], "Lab")
        self.assertIn("runtime-secret-123", secrets_to_redact)

    def test_sync_preflight_requires_fresh_complete_report_and_explicit_mappings(self):
        name = "local-huawei-preflight"
        response = self.client.post("/api/devices", headers=self.headers, json={
            "name":name, "vendor":"Huawei", "address":"192.0.2.11", "device_type":"firewall",
            "protocol":"ssh", "port":22, "username":"netops", "password":"runtime-secret-456",
            "settings":{"device_model":"Huawei USG6670", "device_profile":"huawei_usg6670", "netbox_site":"Lab", "netbox_role":"Firewall", "netbox_device_type_slug":"usg6670"}
        })
        self.assertEqual(response.status_code, 201, response.text)
        with self.assertRaisesRegex(RuntimeError, "Missing or stale facts report"):
            sync_preflight(name)
        (REPORTS / f"{name}-facts.json").write_text(__import__("json").dumps({
            "device":name, "collection_id":"batch-123", "platform":"huawei", "device_profile":"huawei_usg6670", "model":"USG6670",
            "version":"5.170", "interfaces":{"Eth-Trunk1":{"type":"lag","operstatus":"up"}}
        }), encoding="utf-8")
        sync_preflight(name)

    def test_vault_password_can_be_set_and_changed_from_admin_api(self):
        status = self.client.get("/api/admin/vault")
        self.assertEqual(status.status_code, 200, status.text)
        response = self.client.post("/api/admin/vault-password", headers=self.headers, json={
            "current_password": "", "new_password": "FirstVaultPassword123!", "confirm_password": "FirstVaultPassword123!"
        })
        self.assertEqual(response.status_code, 200, response.text)
        from webui.app import VAULT_PASSWORD_PATH
        self.assertTrue(VAULT_PASSWORD_PATH.is_file())
        self.assertEqual(VAULT_PASSWORD_PATH.read_text(encoding="utf-8").strip(), "FirstVaultPassword123!")
        self.assertEqual(VAULT_PASSWORD_PATH.stat().st_mode & 0o777, 0o600)
        response = self.client.post("/api/admin/vault-password", headers=self.headers, json={
            "current_password": "", "new_password": "SecondVaultPassword456!", "confirm_password": "SecondVaultPassword456!"
        })
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(VAULT_PASSWORD_PATH.read_text(encoding="utf-8").strip(), "SecondVaultPassword456!")

    def test_vault_password_confirmation_must_match(self):
        response = self.client.post("/api/admin/vault-password", headers=self.headers, json={
            "current_password": "", "new_password": "FirstVaultPassword123!", "confirm_password": "DifferentVaultPassword456!"
        })
        self.assertEqual(response.status_code, 400, response.text)

    def test_reverse_render_workflow_is_rejected(self):
        response = self.client.post("/api/jobs", headers=self.headers, json={"mode":"render"})
        self.assertEqual(response.status_code, 422, response.text)

    def test_netbox_settings_default_off_and_token_is_encrypted(self):
        from webui.app import db, _CIPHER
        initial = self.client.get("/api/admin/netbox")
        self.assertEqual(initial.status_code, 200, initial.text)
        self.assertFalse(initial.json()["sync_enabled"])
        self.assertFalse(initial.json()["auto_sync_enabled"])
        saved = self.client.post("/api/admin/netbox", headers=self.headers, json={
            "netbox_url":"https://netbox.example.test", "api_token":"netbox-secret-token",
            "sync_enabled":True, "auto_sync_enabled":True
        })
        self.assertEqual(saved.status_code, 200, saved.text)
        self.assertTrue(saved.json()["token_configured"])
        self.assertTrue(saved.json()["sync_enabled"])
        self.assertTrue(saved.json()["auto_sync_enabled"])
        self.assertNotIn("netbox-secret-token", saved.text)
        with db() as conn:
            encrypted = conn.execute("SELECT value FROM app_settings WHERE key='netbox_api_token_enc'").fetchone()["value"]
        self.assertNotIn("netbox-secret-token", encrypted)
        self.assertEqual(_CIPHER.decrypt(encrypted.encode()).decode(), "netbox-secret-token")
        reloaded = self.client.get("/api/admin/netbox")
        self.assertEqual(reloaded.json()["netbox_url"], "https://netbox.example.test")
        # Keep later tests isolated: the persisted default for fresh installs is disabled.
        self.client.post("/api/admin/netbox", headers=self.headers, json={
            "netbox_url":"https://netbox.example.test", "api_token":"",
            "sync_enabled":False, "auto_sync_enabled":False
        })

    def test_netbox_auto_sync_cannot_be_enabled_without_write_permission(self):
        response = self.client.post("/api/admin/netbox", headers=self.headers, json={
            "netbox_url":"https://netbox.example.test", "api_token":"",
            "sync_enabled":False, "auto_sync_enabled":True
        })
        self.assertEqual(response.status_code, 400, response.text)

    def test_netbox_settings_reject_credentials_in_url(self):
        response = self.client.post("/api/admin/netbox", headers=self.headers, json={
            "netbox_url":"https://user:pass@netbox.example.test", "sync_enabled":False, "auto_sync_enabled":False
        })
        self.assertEqual(response.status_code, 400, response.text)

    def test_netbox_connection_test_uses_saved_token(self):
        self.client.post("/api/admin/netbox", headers=self.headers, json={
            "netbox_url":"https://netbox.example.test", "api_token":"netbox-test-token",
            "sync_enabled":False, "auto_sync_enabled":False
        })
        fake_response = MagicMock()
        fake_response.status = 200
        fake_response.__enter__.return_value = fake_response
        with patch("webui.app.urllib.request.urlopen", return_value=fake_response):
            response = self.client.post("/api/admin/netbox/test", headers=self.headers, json={})
        self.assertEqual(response.status_code, 200, response.text)
        self.assertTrue(response.json()["ok"])

    def test_sync_requires_explicit_confirmation_and_opt_in(self):
        no_confirmation = self.client.post("/api/jobs", headers=self.headers, json={"mode":"sync"})
        self.assertEqual(no_confirmation.status_code, 400, no_confirmation.text)
        confirmed_but_disabled = self.client.post("/api/jobs", headers=self.headers, json={"mode":"sync", "confirm_sync":True})
        self.assertEqual(confirmed_but_disabled.status_code, 403, confirmed_but_disabled.text)

    def test_fact_reports_endpoint_returns_empty_list_when_no_reports(self):
        response = self.client.get("/api/reports")
        self.assertEqual(response.status_code, 200, response.text)
        self.assertEqual(response.json(), [])

    def test_manual_topology_link(self):
        a = self.create_device("test-topology-a")
        b = self.create_device("test-topology-b")
        response = self.client.post("/api/topology/links", headers=self.headers, json={
            "local_device_id":a, "local_interface":"GE1/0/1", "remote_device_id":b, "remote_interface":"GE1/0/2"
        })
        self.assertEqual(response.status_code, 201, response.text)
        topology = self.client.get("/api/topology").json()
        self.assertTrue(any(link["local_interface"] == "GE1/0/1" and link["remote_interface"] == "GE1/0/2" for link in topology["links"]))

    def test_topology_builds_automatic_lldp_link_from_reciprocal_reports(self):
        import json
        a = self.create_device("lldp-auto-topology-a")
        b = self.create_device("lldp-auto-topology-b")
        reports = {
            "lldp-auto-topology-a": {"device": "lldp-auto-topology-a", "lldp_neighbors": [
                {"local_interface": "GigabitEthernet1/0/8", "neighbor_interface": "Te1/0/21", "chassis_id": "cc9d-a27a-ac40"}
            ]},
            "lldp-auto-topology-b": {"device": "lldp-auto-topology-b", "lldp_neighbors": [
                {"local_interface": "TenGigabitEthernet1/0/21", "neighbor_interface": "GigabitEthernet1/0/8", "chassis_id": "0011-2233-4455"}
            ]},
        }
        for name, report in reports.items():
            (REPORTS / f"{name}-facts.json").write_text(json.dumps(report), encoding="utf-8")
        response = self.client.get("/api/topology")
        self.assertEqual(response.status_code, 200, response.text)
        body = response.json()
        link = next((l for l in body["links"] if l["source"] == "lldp"), None)
        self.assertIsNotNone(link, body)
        self.assertEqual({link["local_device_id"], link["remote_device_id"]}, {a, b})
        self.assertEqual(body["diagnostics"]["auto_links"], 1)
        for name in reports:
            (REPORTS / f"{name}-facts.json").unlink(missing_ok=True)

    def test_topology_marks_lag_only_when_both_ports_have_explicit_membership(self):
        import json
        a = self.create_device("lag-topology-a")
        b = self.create_device("lag-topology-b")
        reports = {
            "lag-topology-a": {"device": "lag-topology-a", "lldp_neighbors": [
                {"local_interface": "GigabitEthernet1/0/1", "neighbor_interface": "GigabitEthernet1/0/1", "chassis_id": "0011-2233-4455"},
                {"local_interface": "GigabitEthernet1/0/2", "neighbor_interface": "GigabitEthernet1/0/2", "chassis_id": "0011-2233-4455"},
            ], "lag_members": {"Eth-Trunk1": ["GigabitEthernet1/0/1", "GigabitEthernet1/0/2"]}},
            "lag-topology-b": {"device": "lag-topology-b", "lldp_neighbors": [
                {"local_interface": "GigabitEthernet1/0/1", "neighbor_interface": "GigabitEthernet1/0/1", "chassis_id": "aabb-ccdd-eeff"},
                {"local_interface": "GigabitEthernet1/0/2", "neighbor_interface": "GigabitEthernet1/0/2", "chassis_id": "aabb-ccdd-eeff"},
            ], "lag_members": {"Port-channel7": ["GigabitEthernet1/0/1", "GigabitEthernet1/0/2"]}},
        }
        for name, report in reports.items():
            (REPORTS / f"{name}-facts.json").write_text(json.dumps(report), encoding="utf-8")
        response = self.client.get("/api/topology")
        self.assertEqual(response.status_code, 200, response.text)
        links = [l for l in response.json()["links"] if l["source"] == "lldp" and {l["local_device_id"], l["remote_device_id"]} == {a, b}]
        self.assertEqual(len(links), 2)
        self.assertTrue(all(l["aggregate_confirmed"] for l in links))
        self.assertEqual({l["local_aggregate"] for l in links} | {l["remote_aggregate"] for l in links}, {"Eth-Trunk1", "Port-channel7"})
        for name in reports:
            (REPORTS / f"{name}-facts.json").unlink(missing_ok=True)

    def test_parallel_lldp_links_without_lag_membership_are_not_marked_as_port_channel(self):
        import json
        a = self.create_device("plain-parallel-topology-a")
        b = self.create_device("plain-parallel-topology-b")
        reports = {
            "plain-parallel-topology-a": {"device": "plain-parallel-topology-a", "lldp_neighbors": [
                {"local_interface": "GigabitEthernet1/0/1", "neighbor_interface": "GigabitEthernet1/0/1", "chassis_id": "0011-2233-4455"},
                {"local_interface": "GigabitEthernet1/0/2", "neighbor_interface": "GigabitEthernet1/0/2", "chassis_id": "0011-2233-4455"},
            ]},
            "plain-parallel-topology-b": {"device": "plain-parallel-topology-b", "lldp_neighbors": [
                {"local_interface": "GigabitEthernet1/0/1", "neighbor_interface": "GigabitEthernet1/0/1", "chassis_id": "aabb-ccdd-eeff"},
                {"local_interface": "GigabitEthernet1/0/2", "neighbor_interface": "GigabitEthernet1/0/2", "chassis_id": "aabb-ccdd-eeff"},
            ]},
        }
        for name, report in reports.items():
            (REPORTS / f"{name}-facts.json").write_text(json.dumps(report), encoding="utf-8")
        response = self.client.get("/api/topology")
        self.assertEqual(response.status_code, 200, response.text)
        links = [l for l in response.json()["links"] if l["source"] == "lldp" and {l["local_device_id"], l["remote_device_id"]} == {a, b}]
        self.assertEqual(len(links), 2)
        self.assertTrue(all(l["aggregate_confirmed"] is False for l in links))
        for name in reports:
            (REPORTS / f"{name}-facts.json").unlink(missing_ok=True)

    def test_topology_device_positions_are_saved_and_returned(self):
        device = self.create_device("topology-position-device")
        response = self.client.put(f"/api/topology/positions/{device}", headers=self.headers, json={"x": 321.5, "y": 456.25})
        self.assertEqual(response.status_code, 200, response.text)
        topology = self.client.get("/api/topology").json()
        self.assertEqual(topology["positions"][str(device)], {"x": 321.5, "y": 456.25})

    def test_topology_position_requires_existing_device_and_bounded_coordinates(self):
        missing = self.client.put("/api/topology/positions/999999", headers=self.headers, json={"x": 1, "y": 2})
        self.assertEqual(missing.status_code, 404)
        device = self.create_device("topology-position-bounds")
        invalid = self.client.put(f"/api/topology/positions/{device}", headers=self.headers, json={"x": 10001, "y": 2})
        self.assertEqual(invalid.status_code, 422)

if __name__ == "__main__":
    unittest.main()
