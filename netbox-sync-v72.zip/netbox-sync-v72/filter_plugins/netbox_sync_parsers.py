"""Conservative parsers for observed Huawei VRP/USG, Eltex MES, Cisco IOS/IOS XE and SNR eNOS CLI output.

Unknown or ambiguous lines are skipped rather than converted into guessed inventory.
"""
from __future__ import annotations
import re


def _text(value):
    if isinstance(value, (list, tuple)):
        return "\n".join(str(x) for x in value)
    return str(value or "")


def _iface_type(name):
    n = name.lower()
    # Dot-suffixed subinterfaces (for example Eth-Trunk1.640) are logical L3 interfaces.
    if re.search(r"\.\d+$", n): return "virtual"
    if n.startswith(("eth-trunk", "po", "port-channel")): return "lag"
    if n.startswith(("vlanif", "vlan", "vl", "loopback", "null", "virtual-if", "meth", "tunnel", "lo")): return "virtual"
    if n.startswith(("40ge", "fo", "fortygigabitethernet", "100ge", "hu", "hundredgig")): return "100gbase-x-qsfp28" if n.startswith(("100ge", "hu", "hundredgig")) else "40gbase-x-qsfpp"
    if n.startswith(("xgigabitethernet", "xge", "xe", "te", "tengigabitethernet")): return "10gbase-x-sfpp"
    if n.startswith(("gigabitethernet", "ge", "gi")): return "1000base-t"
    if n.startswith(("fastethernet", "fa")): return "100base-tx"
    return "other"


def parse_huawei_version(value):
    text = _text(value)
    version = re.search(r"Version\s+([^\s\r\n]+(?:\s*\([^\r\n)]*\))?)", text, re.I)
    model = ""
    # Prefer the explicit device model line; otherwise use the platform/version token.
    m = re.search(r"^(USG\d+(?:E)?|S\d{4}[^\s]*)\s+uptime", text, re.I | re.M)
    if m: model = m.group(1)
    if not model:
        m = re.search(r"\((USG\d+(?:E)?|S\d{4}[^\s)]*)\s+V?\d", text, re.I)
        if m: model = m.group(1)
    serial = re.search(r"(?:Device\s+serial\s+number|ESN(?:\s+of\s+(?:slot\s+\d+|master))?)\s*:\s*([^\s]+)", text, re.I)
    return {"model": model, "version": version.group(1).strip() if version else "", "serial": serial.group(1) if serial else ""}


def parse_huawei_device_model(value):
    text = _text(value)
    # Prefer exact product model strings from display device over the generic VRP family.
    m = re.search(r"\b(USG\d+(?:E)?|S\d{4}(?:-[A-Z0-9]+)+)\b", text, re.I)
    return m.group(1) if m else ""


def parse_huawei_hostname(value):
    """Extract the configured sysname from read-only CLI output."""
    text = _text(value)
    m = re.search(r"(?im)^\s*sysname\s+([^\s#]+)\s*$", text)
    return m.group(1).strip() if m else ""


def build_huawei_usg6670_report(hostname, serial, interfaces, lag_members, lldp_neighbors=None):
    """Build the concise USG6670 report while preserving the complete facts separately."""
    interfaces = interfaces if isinstance(interfaces, dict) else {}
    lag_members = lag_members if isinstance(lag_members, dict) else {}
    physical = {}
    trunks = {}
    subinterfaces = {}
    for name, details in sorted(interfaces.items(), key=lambda item: item[0].casefold()):
        details = details if isinstance(details, dict) else {}
        status = str(details.get("operstatus", "unknown"))
        iface_type = str(details.get("type", "other"))
        if re.match(r"(?i)^Eth-Trunk\d+\.\d+$", name):
            parent = name.rsplit(".", 1)[0]
            subinterfaces.setdefault(parent, {})[name] = {
                "operstatus": status,
                "ip_addresses": list(details.get("ip_addresses", [])) if isinstance(details.get("ip_addresses", []), (list, tuple)) else [],
            }
        elif re.match(r"(?i)^Eth-Trunk\d+$", name) or iface_type == "lag":
            trunks[name] = {"operstatus": status, "members": list(lag_members.get(name, []))}
        elif iface_type not in {"virtual", "lag"} and not re.search(r"(?i)\.\d+$", name):
            physical[name] = {"operstatus": status, "type": iface_type}
    # Preserve trunks even if their status row is absent but member data exists.
    for name, members in lag_members.items():
        trunks.setdefault(name, {"operstatus": str((interfaces.get(name) or {}).get("operstatus", "unknown")), "members": list(members)})
    # Sort subinterfaces numerically by suffix (Eth-Trunk2.9 before Eth-Trunk2.12).
    def _subif_key(item):
        match = re.search(r"\.(\d+)$", item[0])
        return (int(match.group(1)) if match else -1, item[0].casefold())
    subinterfaces = {
        parent: dict(sorted(entries.items(), key=_subif_key))
        for parent, entries in sorted(subinterfaces.items(), key=lambda item: item[0].casefold())
    }
    return {
        "hostname": str(hostname or ""),
        "serial": str(serial or ""),
        "physical_interfaces": physical,
        "eth_trunks": trunks,
        "subinterfaces": subinterfaces,
        "lldp_neighbors": list(lldp_neighbors) if isinstance(lldp_neighbors, (list, tuple)) else [],
    }


def parse_huawei_interfaces(value):
    text = _text(value)
    result = {}
    # display interface brief: Interface PHY Protocol ...; member lines are indented but are physical interfaces too.
    for line in text.splitlines():
        m = re.match(r"^(\s*)([A-Za-z][A-Za-z0-9./:-]*(?:\.\d+)?)(?:\([^)]*\))?\s+(up|down|administratively down)\s+(up|down|up\(s\)|down\(s\))\b", line, re.I)
        if not m: continue
        indent, name, phy, proto = m.groups()
        if name.lower() in {"interface", "phy"}: continue
        result[name] = {"operstatus": "up" if phy.lower() == "up" and proto.lower().startswith("up") else "down", "type": _iface_type(name), "description": ""}
    # Capture nested Eth-Trunk member rows from the abbreviated table too, but don't create duplicates.
    for line in text.splitlines():
        m = re.match(r"^\s+((?:GigabitEthernet|XGigabitEthernet|GE|XGE|100GE|40GE)\S+?)(?:\([^)]*\))?\s+(up|down)\s+(up|down)\b", line, re.I)
        if m:
            name, phy, proto = m.groups()
            result[name] = {"operstatus": "up" if phy.lower() == "up" and proto.lower() == "up" else "down", "type": _iface_type(name), "description": ""}
    return result


def parse_huawei_ip_interface_brief(value, interfaces=None):
    """Enrich parsed Huawei interfaces with IP addresses from display ip interface brief.

    The command output varies slightly by VRP/USG release, so only rows with a
    recognizable interface name and IPv4 address/mask are accepted. Existing
    operational state remains sourced from display interface brief.
    """
    result = {name: dict(data) for name, data in (interfaces or {}).items() if isinstance(data, dict)}
    text = _text(value)
    row = re.compile(
        r"^\s*([A-Za-z][A-Za-z0-9./:-]*(?:\.\d+)?)\s+"
        r"(unassigned|(?:\d{1,3}\.){3}\d{1,3}(?:/\d{1,2}|\s+\d{1,3}(?:\.\d{1,3}){3}))\s+"
        r"(\*?down|up|down|\^down)\s+(up|down|\*?down|\^down)\b", re.I)
    for line in text.splitlines():
        match = row.match(line)
        if not match:
            continue
        name, address, physical, protocol = match.groups()
        if name.casefold() in {"interface", "number"}:
            continue
        data = result.setdefault(name, {"operstatus": "unknown", "type": _iface_type(name), "description": ""})
        addresses = []
        if address.casefold() != "unassigned":
            parts = address.split()
            if len(parts) == 2:
                try:
                    import ipaddress
                    addresses = [str(ipaddress.ip_interface(f"{parts[0]}/{ipaddress.IPv4Address(parts[1]).netmask}"))]
                except ValueError:
                    addresses = []
            elif "/" in address:
                try:
                    import ipaddress
                    addresses = [str(ipaddress.ip_interface(address))]
                except ValueError:
                    addresses = []
        data["ip_addresses"] = addresses
        # Use the IP table's state only when the interface status table did not identify it.
        if data.get("operstatus", "unknown") == "unknown":
            data["operstatus"] = "up" if physical.casefold() == "up" and protocol.casefold() == "up" else "down"
    return result


def parse_huawei_lag_members(value):
    text = _text(value)
    result = {}
    current_lag = ""
    for line in text.splitlines():
        # Unindented aggregate row establishes the parent; indented physical rows are members.
        m = re.match(r"^([^\s][A-Za-z][A-Za-z0-9./:-]*(?:\.\d+)?)\s+(?:up|down|administratively down)\s+(?:up|down|up\(s\)|down\(s\))\b", line, re.I)
        if m:
            name = m.group(1)
            current_lag = name if name.lower().startswith("eth-trunk") and not re.search(r"\.\d+$", name) else ""
            continue
        if not current_lag:
            continue
        m = re.match(r"^\s+((?:GigabitEthernet|XGigabitEthernet|GE|XGE|100GE|40GE)\S+?)(?:\([^)]*\))?\s+(?:up|down)\s+(?:up|down)\b", line, re.I)
        if m:
            result.setdefault(current_lag, []).append(m.group(1))
    return result




def parse_huawei_running_config(value, interfaces=None):
    """Enrich Huawei VRP switch facts from read-only display current-configuration.

    Operational status remains sourced from display interface brief. This parser
    adds explicit interface configuration and VLAN names/descriptions without
    inferring unconfigured values.
    """
    text = _text(value)
    result = {name: dict(data) for name, data in (interfaces or {}).items()}
    vlan_defs = {}
    current_iface = None
    current_vlan = None
    block_lines = []

    def add_vlan_line(vid, lines):
        data = vlan_defs.setdefault(vid, {"vid": vid, "name": f"VLAN{vid}", "status": "active"})
        for raw in lines:
            line = raw.strip()
            m = re.match(r"^name\s+(.+?)\s*$", line, re.I)
            if m:
                data["name"] = m.group(1).strip().strip('"')[:64]
            m = re.match(r"^description\s+(.+?)\s*$", line, re.I)
            if m:
                data["description"] = m.group(1).strip()[:200]

    def flush_iface():
        nonlocal current_iface, block_lines
        if not current_iface:
            return
        name = current_iface
        data = result.setdefault(name, {"operstatus": "unknown", "type": _iface_type(name), "description": ""})
        data.setdefault("description", "")
        data.setdefault("ip_addresses", [])
        data.setdefault("tagged_vlans", [])
        data.setdefault("untagged_vlans", [])
        data.setdefault("allowed_vlans", [])
        for raw in block_lines:
            line = raw.strip()
            m = re.match(r"^description\s+(.+?)\s*$", line, re.I)
            if m:
                data["description"] = m.group(1).strip()[:200]
                continue
            m = re.match(r"^ip address\s+(\d{1,3}(?:\.\d{1,3}){3})\s+(\d{1,3}(?:\.\d{1,3}){3})\s*$", line, re.I)
            if m:
                address, mask = m.groups()
                try:
                    import ipaddress
                    cidr = str(ipaddress.ip_interface(f"{address}/{mask}"))
                    if cidr not in data["ip_addresses"]: data["ip_addresses"].append(cidr)
                except ValueError:
                    pass
                continue
            m = re.match(r"^port link-type\s+(access|trunk|hybrid)\s*$", line, re.I)
            if m:
                data["mode"] = m.group(1).lower(); continue
            m = re.match(r"^port default vlan\s+(\d+)\s*$", line, re.I)
            if m:
                vid = int(m.group(1)); data["untagged_vlans"] = [vid]; data["native_vlan"] = vid; continue
            m = re.match(r"^port trunk pvid vlan\s+(\d+)\s*$", line, re.I)
            if m:
                vid = int(m.group(1)); data["native_vlan"] = vid
                if vid not in data["untagged_vlans"]: data["untagged_vlans"].append(vid)
                continue
            m = re.match(r"^port trunk allow-pass vlan\s+(.+?)\s*$", line, re.I)
            if m:
                vids = _parse_vlan_ids(m.group(1))
                for vid in vids:
                    if vid not in data["allowed_vlans"]: data["allowed_vlans"].append(vid)
                continue
            m = re.match(r"^eth-trunk\s+(\d+)\s*$", line, re.I)
            if m:
                data["lag"] = f"Eth-Trunk{m.group(1)}"
                continue
            if line.lower() == "shutdown": data["admin_status"] = "disabled"
            elif line.lower() == "undo shutdown": data["admin_status"] = "enabled"
        if data.get("mode") == "trunk":
            native = data.get("native_vlan")
            for vid in data["allowed_vlans"]:
                if vid != native and vid not in data["tagged_vlans"]: data["tagged_vlans"].append(vid)
        for key in ("tagged_vlans", "untagged_vlans", "allowed_vlans"):
            data[key] = sorted(set(data.get(key, [])))
        current_iface = None
        block_lines = []

    for raw in text.splitlines():
        line = raw.strip()
        m = re.match(r"^interface\s+(\S+)\s*$", line, re.I)
        if m:
            flush_iface(); current_vlan = None; current_iface = m.group(1); block_lines = []; continue
        m = re.match(r"^vlan\s+(\d{1,4})\s*$", line, re.I)
        if m:
            flush_iface(); current_vlan = int(m.group(1)); current_iface = None; block_lines = []; continue
        if line == "#" or line == "!":
            if current_iface: flush_iface()
            elif current_vlan is not None: add_vlan_line(current_vlan, block_lines)
            current_vlan = None; block_lines = []; continue
        if current_iface: block_lines.append(raw)
        elif current_vlan is not None: block_lines.append(raw)
    if current_iface: flush_iface()
    elif current_vlan is not None: add_vlan_line(current_vlan, block_lines)
    return {"interfaces": result, "vlans": [vlan_defs[k] for k in sorted(vlan_defs)]}


def _parse_vlan_ids(value):
    """Parse Huawei VLAN lists and ranges, ignoring command negations/tokens."""
    ids = []
    for token in str(value).split():
        token = token.strip()
        if re.fullmatch(r"\d+", token): ids.append(int(token))
        elif re.fullmatch(r"\d+-\d+", token):
            first, last = map(int, token.split('-', 1))
            if first <= last and last - first <= 4094: ids.extend(range(first, last + 1))
    return [vid for vid in ids if 1 <= vid <= 4094]


def parse_huawei_vlans(value):
    """Parse VLAN definitions (names/descriptions) from Huawei running-config."""
    parsed = parse_huawei_running_config(value, {})
    return parsed["vlans"]



def parse_eltex_esr_version(value):
    """Parse ESR-200 `show version` output (Boot/SW version format)."""
    text = _text(value)
    sw = re.search(r'(?im)^\s*SW version:\s*(.+?)\s*$', text)
    boot = re.search(r'(?im)^\s*Boot version:\s*(.+?)\s*$', text)
    return {"version": sw.group(1).strip() if sw else "", "boot_version": boot.group(1).strip() if boot else ""}


def parse_eltex_esr_system(value):
    """Parse ESR-200 `show system` identity fields across firmware label variants."""
    text = _text(value)

    def field(label):
        m = re.search(r'(?im)^\s*' + re.escape(label) + r'\s*:\s*(.*?)\s*$', text)
        return m.group(1).strip() if m else ""

    # ESR-200 `show system` uses labels such as "System serial number"
    # and "System MAC address". Other firmware variants may use shorter labels.
    # Do not infer a serial from another field.
    serial_match = re.search(
        r'(?im)^\s*(?:system\s+)?serial(?:\s+(?:number|no\.?))?\s*:?\s*(\S.*?)\s*$', text
    )
    mac = field("System MAC address") or field("MAC address") or field("MAC")
    return {"model": field("System type"), "hostname": field("System name"),
            "version": field("Software version"), "hardware_version": field("Hardware version"),
            "uptime": field("System uptime") or field("Uptime"), "mac": mac,
            "serial": serial_match.group(1).strip() if serial_match else ""}


def parse_eltex_esr_interfaces(value):
    """Parse ESR `show interfaces status`; avoid confusing wrapped Last change with rows."""
    result = {}
    for line in _text(value).splitlines():
        m = re.match(r'^\s*((?:gi|gigabitethernet)\d+/\d+/\d+(?:\.\d+)?)\s+(Up|Down)\s+(Up|Down)\s+(\d+)\s+([0-9a-f:]{17})\s+', line, re.I)
        if not m:
            continue
        name, admin, link, mtu, mac = m.groups()
        result[name] = {"type": _iface_type(name), "admin_status": "enabled" if admin.lower() == "up" else "disabled",
                        "operstatus": "up" if link.lower() == "up" else "down", "mtu": int(mtu), "mac_address": mac.lower(), "description": ""}
    return result


def parse_eltex_esr_descriptions(value):
    """Parse ESR `show interfaces description` table."""
    result = {}
    for line in _text(value).splitlines():
        m = re.match(r'^\s*((?:gi|gigabitethernet)\d+/\d+/\d+(?:\.\d+)?)\s+(Up|Down)\s+(Up|Down)\s*(.*?)\s*$', line, re.I)
        if m:
            name, admin, link, desc = m.groups()
            result[name] = {"admin_status": "enabled" if admin.lower() == "up" else "disabled",
                            "operstatus": "up" if link.lower() == "up" else "down", "description": desc.strip()}
    return result


def parse_eltex_esr_ip_interfaces(value):
    """Parse ESR `show ip interface` rows into interface-to-address mappings."""
    result = {}
    for line in _text(value).splitlines():
        m = re.match(r'^\s*(\d{1,3}(?:\.\d{1,3}){3}/\d{1,2})\s+((?:gi|gigabitethernet)\d+/\d+/\d+(?:\.\d+)?)\s+(Up|Down)\s+(Up|Down)\s+(\S+)\s*$', line, re.I)
        if m:
            address, name, admin, link, addr_type = m.groups()
            result[name] = {"address": address, "admin_status": "enabled" if admin.lower() == "up" else "disabled",
                            "operstatus": "up" if link.lower() == "up" else "down", "address_type": addr_type}
    return result


def parse_eltex_esr_vlans(value):
    """Parse ESR `show running-config vlans` blocks, not the incomplete operational VLAN table."""
    found = {}
    current = None
    for raw in _text(value).splitlines():
        line = raw.strip()
        m = re.match(r'^vlan\s+(\d{1,4})\s*$', line, re.I)
        if m:
            vid = int(m.group(1)); current = vid if 1 <= vid <= 4094 else None
            if current is not None: found.setdefault(current, "")
            continue
        if re.match(r'^exit\s*$', line, re.I):
            current = None; continue
        m = re.match(r'^name\s+"?(.*?)"?\s*$', line, re.I)
        if current is not None and m:
            found[current] = m.group(1).strip().strip('"')
    return [{"vid": vid, "name": name or f"VLAN{vid}", "status": "active"} for vid, name in sorted(found.items())]


def parse_eltex_esr_vrrp(value):
    """Parse `show vrrp` summary and detailed single-router output."""
    text = _text(value)
    detail = {}
    labels = {"VRRP ID":"id", "VRRP Version":"version", "Interface":"interface", "Priority":"priority", "State":"state",
              "Track ID":"track_id", "Source IP address":"source_ip", "Virtual IP address":"virtual_ip",
              "Virtual MAC address":"virtual_mac", "Synchronization group ID":"sync_group", "Preemption":"preemption",
              "Advertisement interval":"advertisement_interval", "Gratuitous ARP delay":"garp_delay",
              "Gratuitous ARP repeat":"garp_repeat", "Gratuitous ARP refresh":"garp_refresh",
              "Gratuitous ARP refresh repeat":"garp_refresh_repeat"}
    for line in text.splitlines():
        m = re.match(r'^\s*([^:]+):\s*(.*?)\s*$', line)
        if m and m.group(1) in labels:
            key, val = labels[m.group(1)], m.group(2)
            if key in {"id", "version", "priority", "sync_group", "advertisement_interval", "garp_delay", "garp_repeat", "garp_refresh", "garp_refresh_repeat"}:
                n = re.search(r'-?\d+', val); val = int(n.group()) if n else val
            detail[key] = val
    if detail:
        return [detail]
    rows = []
    for line in text.splitlines():
        m = re.match(r'^\s*(\d{1,3})\s+(\S+)\s+(\d+)\s+(Enabled|Disabled)\s+(Master|Backup|Initialize|Init)\s*$', line, re.I)
        if m:
            vid, vip, priority, preempt, state = m.groups()
            rows.append({"id": int(vid), "virtual_ip": vip, "priority": int(priority), "preemption": preempt, "state": state.title()})
    return rows


def parse_eltex_esr_routes(value):
    """Parse ESR `show ip route` route rows conservatively."""
    routes = []
    for line in _text(value).splitlines():
        m = re.match(r'^\s*([A-Z0-9*]+)\s+\*?\s*(\d{1,3}(?:\.\d{1,3}){3}/\d{1,2})\s+\[([^]]+)\](?:\s+via\s+(\d{1,3}(?:\.\d{1,3}){3})\s+on\s+(\S+)|\s+dev\s+(\S+))?', line)
        if m:
            code, prefix, metric, nexthop, out_if, dev = m.groups()
            routes.append({"code": code.strip(), "prefix": prefix, "metric": metric,
                           "next_hop": nexthop or "", "interface": out_if or dev or ""})
    return routes


def parse_eltex_esr_failover(value):
    """Parse read-only firewall failover status and counters."""
    text = _text(value); result = {}
    mapping = {"Communication interface":"interface", "Status":"status", "Bytes sent":"bytes_sent",
               "Bytes received":"bytes_received", "Packets sent":"packets_sent", "Packets received":"packets_received",
               "Send errors":"send_errors", "Receive errors":"receive_errors"}
    for line in text.splitlines():
        m = re.match(r'^\s*([^:]+):\s*(.*?)\s*$', line)
        if m and m.group(1) in mapping:
            key, val = mapping[m.group(1)], m.group(2)
            if key != "interface" and key != "status":
                n = re.search(r'\d+', val); val = int(n.group()) if n else None
            result[key] = val
    return result

def parse_eltex_version(value):
    """Parse the active software version and optional identity fields from Eltex show version."""
    text = _text(value)
    # The first Version line belongs to Active-image; later ones may describe Inactive-image.
    version = re.search(r"(?im)^\s*Version:\s*([^\s]+)", text)
    model = re.search(r"(?im)^\s*(?:Model|System Model|Product Name):\s*(.+?)\s*$", text)
    serial = re.search(r"(?im)^\s*(?:Serial Number|Serial):\s*(\S+)", text)
    return {
        "version": version.group(1).strip() if version else "",
        "model": model.group(1).strip() if model else "",
        "serial": serial.group(1).strip() if serial else "",
    }


def parse_eltex_system(value):
    """Parse Eltex show system identity; normalize model for NetBox type mapping."""
    text = _text(value)
    description = re.search(r"(?im)^\s*System Description:\s*(.+?)\s*$", text)
    if not description:
        # Some firmware variants expose the product only in the per-unit table.
        description = re.search(r"(?im)^\s*\d+\s+(MES[0-9A-Z-]+(?:\s+rev\.[A-Z0-9]+)?[^\r\n]*)$", text)
    description_text = description.group(1).strip() if description else ""
    # Keep a stable model key matching group_vars/all.yml; revision belongs in raw description.
    model_match = re.search(r"\b(MES[0-9A-Z-]+)\b", description_text, re.I)
    units = re.findall(r"(?im)^\s*(\d+)\s+(MES[0-9A-Z-]+(?:\s+rev\.[A-Z0-9]+)?[^\r\n]*)$", text)
    return {
        "model": model_match.group(1).upper() if model_match else "",
        "description": description_text,
        "unit_count": len({unit[0] for unit in units}),
        "units": [{"unit": int(number), "description": unit_description.strip()} for number, unit_description in units],
    }




def parse_eltex_inventory(value):
    """Parse show inventory chassis serials and per-port transceiver inventory."""
    text = _text(value)
    units = []
    current = None
    for line in text.splitlines():
        m = re.match(r'^\s*NAME:\s*"(\d+)"\s+DESCR:\s*"([^"]*)"', line, re.I)
        if m:
            if current:
                units.append(current)
            current = {"unit": int(m.group(1)), "description": m.group(2).strip()}
            continue
        m = re.match(r'^\s*PID:\s*(.*?)\s+VID:\s*(.*?)\s+SN:\s*(\S+)', line, re.I)
        if m and current:
            current.update({"pid": m.group(1).strip(), "vid": m.group(2).strip(), "serial": m.group(3).strip()})
            units.append(current)
            current = None
    if current:
        units.append(current)
    chassis = [item for item in units if "unit" in item and item.get("serial")]
    transceivers = []
    for item in units:
        if "unit" in item:
            continue
        name = item.get("name", "")
        if name:
            transceivers.append(item)
    # Re-parse NAME/PID blocks, since interface module names aren't numeric chassis IDs.
    blocks = re.split(r'(?=^\s*NAME:)', text, flags=re.M)
    chassis, transceivers = [], []
    for block in blocks:
        name = re.search(r'^\s*NAME:\s*"([^"]+)"\s+DESCR:\s*"([^"]*)"', block, re.M)
        pid = re.search(r'^\s*PID:\s*(.*?)\s+VID:\s*(.*?)\s+SN:\s*(\S+)', block, re.M)
        if not name or not pid:
            continue
        item = {"name": name.group(1).strip(), "description": name.group(2).strip(), "pid": pid.group(1).strip(), "vid": pid.group(2).strip(), "serial": pid.group(3).strip()}
        if item["name"].isdigit():
            item["unit"] = int(item["name"])
            chassis.append(item)
        else:
            port = re.search(r'(?:TenGigabitEthernet|GigabitEthernet|XGigabitEthernet|te|gi|xge)(\d+/\d+/\d+)', item["name"], re.I)
            if port:
                item["interface"] = "te" + port.group(1) if "tenGigabitEthernet" in item["name"].lower() or item["name"].lower().startswith("te") else item["name"]
            transceivers.append(item)
    return {"units": chassis, "transceivers": transceivers}


def parse_eltex_interface_descriptions(value):
    """Parse Eltex `show interfaces Port-Channel` output (physical + Po tables)."""
    text = _text(value)
    result = {}
    for line in text.splitlines():
        m = re.match(r'^\s*((?:te|gi|fa|eth)\d+/\d+/\d+|Po\d+)\s+(Access(?:\s+\(\d+\))?|Trunk|Hybrid)(?:\s+\S+)?\s+(Up|Down)\s+(Up|Down|Not Present)\s*(.*?)\s*$', line, re.I)
        if not m:
            continue
        name, mode, admin, link, description = m.groups()
        result[name] = {
            "description": description.strip(),
            "admin_status": "enabled" if admin.lower() == "up" else "disabled",
            "operstatus": "up" if link.lower() == "up" else "not_present" if link.lower() == "not present" else "down",
            "port_mode": mode.strip(),
        }
    return result


def parse_eltex_lag_members(value):
    """Parse `show interfaces channel-group`, retaining only Active members."""
    text = _text(value)
    result = {}
    for line in text.splitlines():
        m = re.match(r'^\s*(Po\d+)\s+(Active|Non-candidate):\s*(.*?)\s*$', line, re.I)
        if not m:
            continue
        lag, state, members = m.groups()
        if state.lower() != "active":
            continue
        found = re.findall(r'\b(?:te|gi|fa|eth)\d+/\d+/\d+\b', members, re.I)
        if found:
            result[lag] = found
    return result


def parse_eltex_lag_states(value):
    """Preserve the reported state of every Port-Channel, including Non-candidate."""
    text = _text(value)
    result = {}
    for line in text.splitlines():
        m = re.match(r'^\s*(Po\d+)\s+(Active|Non-candidate):', line, re.I)
        if not m:
            continue
        lag, state = m.groups()
        result[lag] = 'active' if state.casefold() == 'active' else 'non_candidate'
    return result


def apply_eltex_lag_states(interfaces, states):
    """Attach observed LAG participation state without mislabeling it as link state."""
    if not isinstance(interfaces, dict) or not isinstance(states, dict):
        return interfaces if isinstance(interfaces, dict) else {}
    result = {name: dict(details) if isinstance(details, dict) else details for name, details in interfaces.items()}
    names = {str(name).casefold(): name for name in result}
    for lag, state in states.items():
        canonical = names.get(str(lag).casefold())
        if canonical is not None and isinstance(result[canonical], dict):
            result[canonical]['lag_status'] = state
    return result



def parse_eltex_lldp(value):
    """Parse Eltex `show lldp neighbors`, including wrapped remote Port IDs."""
    text = _text(value)
    result = []
    lines = text.splitlines()
    i = 0
    mac_re = re.compile(r'^(?:[0-9a-f]{2}:){5}[0-9a-f]{2}$', re.I)
    while i < len(lines):
        line = lines[i]
        m = re.match(r'^\s*((?:te|gi|fa|eth|po)\d+/\d+/\d+)\s+(\S+)\s+(\S+)(?:\s+(.*))?$', line, re.I)
        if not m or not mac_re.fullmatch(m.group(2)):
            i += 1
            continue
        local, chassis, remote, tail = m.groups()
        tail = tail or ""
        # Port IDs can wrap with either `/0/1` or `0/8` on the continuation line.
        if i + 1 < len(lines) and re.fullmatch(r'\s*(?:/\d+)+\s*|\s*\d+(?:/\d+)+\s*', lines[i + 1]):
            remote += lines[i + 1].strip()
            i += 1
        tail = re.sub(r'\s+[OBRWHC, ]+\s+\d+\s*$', '', tail).strip()
        item = {"local_interface": local, "chassis_id": chassis, "neighbor_interface": remote}
        capability_only = bool(re.fullmatch(r"[OBRWHC,\s]+", tail, re.I))
        if tail and tail.lower() != "(none).(none)" and not capability_only:
            item["neighbor_device"] = tail
        result.append(item)
        i += 1
    return result


def parse_eltex_vlans(value):
    """Parse Eltex VLAN table, preserving wrapped names and port lists."""
    text = _text(value)
    lines = text.splitlines()
    header_index = next((i for i, line in enumerate(lines) if re.search(r'\bVlan\b', line, re.I) and 'Tagged Ports' in line and 'UnTagged Ports' in line), None)
    if header_index is None:
        return parse_vlans(text)
    header = lines[header_index]
    untagged_start = header.find('UnTagged Ports')
    rows, current = [], None

    def finish():
        if current:
            current['name'] = (current['name'].strip() or f"VLAN{current['vid']}")[:64]
            current['tagged_ports'] = list(dict.fromkeys(current['tagged_ports']))
            current['untagged_ports'] = list(dict.fromkeys(current['untagged_ports']))
            current['status'] = 'active'
            rows.append(current.copy())

    for line in lines[header_index + 1:]:
        if not line.strip() or re.match(r'^\s*-{3,}', line):
            continue
        vid_match = re.match(r'^\s*(\d{1,4})\s+', line)
        if vid_match:
            finish()
            vid = int(vid_match.group(1))
            if not 1 <= vid <= 4094:
                current = None
                continue
            fields = re.split(r'\s{2,}', line.strip())
            # Prefer the text preceding the first port token over split columns:
            # long VLAN names can overflow the nominal Name column and collapse
            # the whitespace separator, which previously made a port list look
            # like the VLAN name (or even made `S` the name).
            after_vid = line[vid_match.end():]
            first_port = re.search(r'\b(?:te|gi|fa|eth|Po)\d', after_vid, re.I)
            if first_port:
                name = after_vid[:first_port.start()].strip()
                name = re.sub(r'\s+$', '', name)
            else:
                name = fields[1] if len(fields) > 1 else f'VLAN{vid}'
                if name in {'D', 'S', 'G', 'R', 'V'} and len(fields) > 2:
                    name = fields[1]
            current = {'vid': vid, 'name': name or f'VLAN{vid}', 'tagged_ports': [], 'untagged_ports': [], 'created_by': fields[-1] if fields and fields[-1] in {'D', 'S', 'G', 'R', 'V'} else ''}
            port_tokens = [field for field in fields[1:] if re.search(r'\b(?:te|gi|fa|eth|Po)\d', field, re.I)]
            if not port_tokens and first_port:
                port_tokens = [after_vid[first_port.start():]]
            if len(port_tokens) >= 2:
                current['tagged_ports'].extend(_expand_eltex_ports(port_tokens[0]))
                current['untagged_ports'].extend(_expand_eltex_ports(port_tokens[1]))
            elif port_tokens:
                first_pos = line.find(port_tokens[0])
                target = 'untagged_ports' if first_pos >= max(untagged_start - 5, 35) else 'tagged_ports'
                current[target].extend(_expand_eltex_ports(port_tokens[0]))
            continue
        if not current:
            continue
        port_match = re.search(r'\b(?:te|gi|fa|eth|Po)\d', line, re.I)
        if port_match:
            # If the VLAN name wrapped, its final fragment precedes the first
            # port column on this continuation line (e.g. `y   te2/0/1,Po1`).
            prefix = line[:port_match.start()].strip()
            if prefix and not re.search(r'\b(?:te|gi|fa|eth|Po)\d', prefix, re.I):
                if len(line[:port_match.start()]) >= 10 and prefix not in {'D', 'S', 'G', 'R', 'V'}:
                    current['name'] += prefix
            target = 'untagged_ports' if port_match.start() >= max(untagged_start - 5, 35) else 'tagged_ports'
            current[target].extend(_expand_eltex_ports(line))
        else:
            # A name that exceeds the Name column wraps onto a separate line.
            fragment = line.strip()
            if fragment and fragment not in {'D', 'S', 'G', 'R', 'V'}:
                current['name'] += fragment
    finish()
    return rows or parse_vlans(text)


def validate_eltex_vlan_memberships(value, interfaces):
    """Keep only VLAN member ports that exist in the collected interface inventory.

    Eltex MES firmware can return malformed/impossible port ranges in `show vlan`
    (for example te3/0/1-32 on a two-unit stack). The range parser must not turn
    those values into invented inventory references. Physical and logical port
    membership is accepted only when the normalized interface was independently
    observed in `show interfaces status` / `show interfaces Port-Channel`.
    """
    if not isinstance(value, list) or not isinstance(interfaces, dict):
        return value if isinstance(value, list) else []
    # Match case-insensitively but retain the canonical name from the interface list.
    known = {str(name).casefold(): str(name) for name in interfaces}
    validated = []
    for row in value:
        if not isinstance(row, dict):
            continue
        item = dict(row)
        for field in ("tagged_ports", "untagged_ports"):
            ports = item.get(field, [])
            if not isinstance(ports, list):
                ports = []
            item[field] = list(dict.fromkeys(
                known[str(port).casefold()] for port in ports
                if str(port).casefold() in known
            ))
        validated.append(item)
    return validated


def filter_eltex_configured_port_channels(interfaces, vlans, lag_members):
    """Drop Eltex Po interfaces that only exist as firmware placeholders.

    A port-channel is considered configured when it has active LAG members,
    appears in a non-default VLAN, or has explicit interface-level settings
    (description, non-default port mode, or administrative shutdown). Merely
    appearing in VLAN 1's default untagged list is not evidence of configuration.
    """
    if not isinstance(interfaces, dict):
        return {}
    vlan_rows = vlans if isinstance(vlans, list) else []
    members = lag_members if isinstance(lag_members, dict) else {}
    configured = {str(name).casefold() for name, ports in members.items() if re.fullmatch(r'Po\d+', str(name), re.I) and ports}
    for row in vlan_rows:
        if not isinstance(row, dict):
            continue
        try:
            vid = int(row.get('vid', 0))
        except (TypeError, ValueError):
            vid = 0
        if vid == 1:
            continue
        for field in ('tagged_ports', 'untagged_ports'):
            for port in row.get(field, []) if isinstance(row.get(field, []), list) else []:
                if re.fullmatch(r'Po\d+', str(port), re.I):
                    configured.add(str(port).casefold())
    for name, details in interfaces.items():
        if not re.fullmatch(r'Po\d+', str(name), re.I) or not isinstance(details, dict):
            continue
        description = str(details.get('description', '')).strip()
        mode = re.sub(r'\s+', ' ', str(details.get('port_mode', '')).strip()).casefold()
        admin = str(details.get('admin_status', '')).strip().casefold()
        if description or (mode and mode not in {'access (1)', 'access'}) or admin == 'disabled':
            configured.add(str(name).casefold())
    return {
        name: details for name, details in interfaces.items()
        if not re.fullmatch(r'Po\d+', str(name), re.I) or str(name).casefold() in configured
    }


def filter_eltex_vlan_port_channels(vlans, interfaces, lag_members):
    """Remove placeholder Po references from VLANs after filtering Po inventory."""
    filtered_interfaces = filter_eltex_configured_port_channels(interfaces, vlans, lag_members)
    return validate_eltex_vlan_memberships(vlans, filtered_interfaces)


def _expand_eltex_ports(value):
    ports = []
    for token in re.split(r'[\s,]+', value.strip()):
        if not token:
            continue
        m = re.fullmatch(r'(te|gi|fa|eth)(\d+/\d+/)(\d+)(?:-(\d+))?', token, re.I)
        if m:
            prefix, middle, start, end = m.groups()
            first, last = int(start), int(end or start)
            if last >= first and last - first <= 256:
                ports.extend(f"{prefix.lower()}{middle}{n}" for n in range(first, last + 1))
            continue
        m = re.fullmatch(r'Po(\d+)(?:-(\d+))?', token, re.I)
        if m:
            first, last = int(m.group(1)), int(m.group(2) or m.group(1))
            if last >= first and last - first <= 128:
                ports.extend(f"Po{n}" for n in range(first, last + 1))
    return ports


def parse_eltex_interfaces(value):
    text = _text(value)
    result = {}
    for line in text.splitlines():
        # show interfaces status: Port Name Status ... or compact rows. Exclude headers and separators.
        m = re.match(r"^\s*((?:te|gi|fa|eth|po|port-channel|vlan|vl)\d[\w./:-]*)\s+(.*?)\s*$", line, re.I)
        if not m: continue
        name, rest = m.groups()
        if name.lower() in {"port", "interface"}: continue
        # Eltex distinguishes a present-but-disconnected port from a physical
        # port with no module/device present. Do not flatten both into `down`.
        if re.search(r"\bNot Present\b", rest, re.I):
            status = "not_present"
        else:
            up = bool(re.search(r"\b(?:connected|up|forwarding)\b", rest, re.I)) and not bool(re.search(r"\b(?:notconnect|down|inactive)\b", rest, re.I))
            status = "up" if up else "down"
        result[name] = {"operstatus": status, "type": _iface_type(name), "description": ""}
    return result


def parse_vlans(value):
    text = _text(value)
    result = []
    for line in text.splitlines():
        m = re.match(r"^\s*(\d{1,4})\s+(\S+)", line)
        if not m: continue
        vid = int(m.group(1))
        if 1 <= vid <= 4094:
            result.append({"vid": vid, "name": m.group(2)[:64], "status": "active"})
    # Deduplicate repeated table rows while preserving the first observed name.
    return list({item["vid"]: item for item in reversed(result)}.values())[::-1]




def parse_snr_vlans(value):
    """Parse VLAN definitions from SNR eNOS running-config output.

    Supports `vlan <vid>` blocks with an optional `name <name>` line and
    compact `vlan <vid> name <name>` forms. Only explicitly configured VLANs
    are returned; interface membership is not used to invent VLAN names.
    """
    text = _text(value)
    found = {}

    def clean_vlan_name(value):
        # Some SNR eNOS outputs append operational state to the VLAN name,
        # e.g. `name Phones state enable`. The state is represented separately
        # in the normalized report, so keep only the configured name.
        name = (value or "").strip().strip('"')
        name = re.sub(r"\s+state\s+(?:enable|disable)\s*$", "", name, flags=re.I)
        return name[:64]

    current_vid = None
    for raw in text.splitlines():
        line = raw.strip()
        m = re.match(r"^vlan\s+(\d{1,4})(?:\s+name\s+(.+?))?\s*$", line, re.I)
        if m:
            vid = int(m.group(1))
            current_vid = vid if 1 <= vid <= 4094 else None
            if current_vid is not None:
                name = clean_vlan_name(m.group(2))
                found[current_vid] = name if name else found.get(current_vid, "")
            continue
        if line == "!":
            current_vid = None
            continue
        if current_vid is not None:
            m = re.match(r"^name\s+(.+?)\s*$", line, re.I)
            if m:
                found[current_vid] = clean_vlan_name(m.group(1))
    return [{"vid": vid, "name": name or f"VLAN{vid}", "status": "active"}
            for vid, name in sorted(found.items())]

def parse_cisco_version(value):
    text = _text(value)
    version = re.search(r"Cisco IOS(?: XE)? Software.*?Version\s+([^,\s]+)", text, re.I)
    if not version:
        version = re.search(r"Version\s+([^,\s]+)", text, re.I)
    model = ""
    # show version often names a chassis family; show inventory's PID is preferred by the task.
    m = re.search(r"(?im)^\s*cisco\s+(C\d{3,5}[A-Z0-9-]*|WS-C\S+|Catalyst\s+\S+)", text)
    if m: model = m.group(1).strip()
    serial = re.search(r"(?im)^\s*(?:System serial number|Processor board ID)\s*[: ]\s*(\S+)", text)
    return {"model": model, "version": version.group(1).strip() if version else "", "serial": serial.group(1) if serial else ""}


def parse_cisco_inventory(value):
    text = _text(value)
    model = re.search(r"(?im)^\s*PID:\s*([^,\s]+)", text)
    serial = re.search(r"(?im)^\s*PID:.*?\bSN:\s*([^,\s]+)", text)
    return {"model": model.group(1).strip() if model else "", "serial": serial.group(1).strip() if serial else ""}


def parse_snr_version(value):
    text = _text(value)
    model = re.search(r"(?im)^\s*(SNR-S\d+[A-Z0-9-]*)(?:\s+Ethernet Managed Switch)?\s*$", text)
    version = re.search(r"(?im)^\s*Software Version\s*[: ]\s*(\S+)", text)
    serial = re.search(r"(?im)^\s*Serial No\.?\s*:\s*(\S+)", text)
    return {"model": model.group(1).strip() if model else "", "version": version.group(1).strip() if version else "", "serial": serial.group(1).strip() if serial else ""}


def parse_cisco_interfaces(value):
    """Parse IOS XE `show interfaces status`, preserving names/descriptions.

    The Name column is optional and may contain spaces. Locate the Status token
    instead of assuming it is always column two.
    """
    text = _text(value)
    result = {}
    allowed = re.compile(r"^(?:Gi|GigabitEthernet|Te|TenGigabitEthernet|Fo|FortyGigabitEthernet|Twe|TwentyFiveGigE|Hu|HundredGigE|Eth|Ethernet|Fa|FastEthernet|Po|Port-channel|Vl|Vlan|Lo|Loopback|Tu|Tunnel|Mgmt|Management|GiMgmt)\S*$", re.I)
    statuses = {"connected", "notconnect", "disabled", "err-disabled", "inactive", "monitoring", "suspended"}
    for line in text.splitlines():
        parts = line.split()
        if len(parts) < 2 or not allowed.match(parts[0]):
            continue
        name = parts[0]
        status_index = next((i for i, part in enumerate(parts[1:], 1) if part.lower() in statuses), None)
        if status_index is None:
            continue
        status = parts[status_index].lower()
        # Name is everything between the interface and Status columns. Empty names
        # are common and produce status_index == 1.
        description = " ".join(parts[1:status_index]).strip()
        result[name] = {"operstatus": "up" if status == "connected" else "down",
                        "type": _iface_type(name), "description": description}
    return result


def parse_cisco_interface_descriptions(value):
    """Parse IOS/IOS XE `show interfaces description` without truncating descriptions."""
    text = _text(value)
    result = {}
    allowed = re.compile(r"^(?:Gi|GigabitEthernet|Te|TenGigabitEthernet|Fo|FortyGigabitEthernet|Twe|TwentyFiveGigE|Hu|HundredGigE|Eth|Ethernet|Fa|FastEthernet|Po|Port-channel|Vl|Vlan|Lo|Loopback|Tu|Tunnel|Mgmt|Management|GiMgmt)\S*$", re.I)
    for raw in text.splitlines():
        parts = raw.strip().split(None, 3)
        if len(parts) < 3 or not allowed.match(parts[0]):
            continue
        # IOS XE table: Interface Status Protocol Description. The description
        # is the entire remainder, including spaces; never use the truncated
        # Name column from `show interfaces status` when this data is available.
        if parts[1].lower() not in {"up", "down", "admin-down", "administratively-down"}:
            continue
        if parts[2].lower() not in {"up", "down", "administratively-down"}:
            continue
        result[parts[0]] = parts[3].strip() if len(parts) > 3 else ""
    return result


def parse_cisco_lldp(value):
    """Parse IOS/IOS XE `show lldp neighbors detail` blocks.

    Only records with a local interface and an advertised remote endpoint are
    returned. A chassis ID is retained for diagnostics but is not treated as a
    NetBox device name or remote interface.
    """
    text = _text(value)
    result = []
    current = {}

    def flush():
        local = current.get("local_interface")
        if local and (current.get("neighbor_device") or current.get("chassis_id")):
            item = {"local_interface": local}
            for key in ("neighbor_device", "neighbor_interface", "chassis_id", "management_ip"):
                if current.get(key):
                    item[key] = current[key]
            result.append(item)

    for raw in text.splitlines():
        line = raw.strip()
        m = re.match(r"^Local Intf:\s*(.+?)\s*$", line, re.I)
        if m:
            flush(); current = {"local_interface": m.group(1).strip()}; continue
        m = re.match(r"^Chassis id:\s*(.+?)\s*$", line, re.I)
        if m:
            current["chassis_id"] = m.group(1).strip(); continue
        m = re.match(r"^Port id:\s*(.+?)\s*$", line, re.I)
        if m:
            val = m.group(1).strip()
            if val and val.lower() not in {"not advertised", "unknown"}:
                current["neighbor_interface"] = val
            continue
        m = re.match(r"^System Name:\s*(.+?)\s*$", line, re.I)
        if m:
            val = m.group(1).strip()
            if val and val.lower() not in {"not advertised", "unknown"}:
                current["neighbor_device"] = val
            continue
        m = re.match(r"^Management Address(?:es)?:\s*$", line, re.I)
        if m:
            current["_management_section"] = True; continue
        m = re.match(r"^(?:IP|IPv4):\s*(\d{1,3}(?:\.\d{1,3}){3})\s*$", line, re.I)
        if m and current.get("_management_section"):
            current["management_ip"] = m.group(1); current.pop("_management_section", None)
    flush()
    # Deduplicate exact repeated advertisements without merging distinct neighbors.
    unique = []
    seen = set()
    for item in result:
        key = tuple(item.get(k, "") for k in ("local_interface", "neighbor_device", "neighbor_interface", "chassis_id"))
        if key not in seen:
            seen.add(key); unique.append(item)
    return unique


def parse_snr_interfaces(value):
    text = _text(value)
    result = {}
    allowed = re.compile(r"^(?:ge|xe|eth|ethernet|port-channel|po|vlan|loopback|lo|cpu|mgmt)\d*[\w./:-]*$", re.I)
    up_tokens = {"up", "connected", "forwarding"}
    down_tokens = {"down", "disabled", "notconnect", "notpresent", "inactive", "administratively", "err-disabled"}
    for line in text.splitlines():
        parts = line.split()
        if len(parts) < 2 or not allowed.match(parts[0]):
            continue
        name = parts[0]
        tokens = {part.lower().strip("(),") for part in parts[1:]}
        if not (tokens & (up_tokens | down_tokens)):
            continue
        is_up = bool(tokens & up_tokens) and not bool(tokens & down_tokens)
        result[name] = {"operstatus": "up" if is_up else "down", "type": _iface_type(name), "description": ""}
    return result


def parse_cisco_lag_members(value):
    text = _text(value)
    result = {}
    for line in text.splitlines():
        # IOS/IOS XE: 1 Po1(SU) LACP Gi1/0/1(P) Gi1/0/2(P)
        m = re.search(r"\b(Po\d+|Port-channel\d+|Port-Channel\d+)\s*\([^)]*\).*?\s+(?:LACP|PAgP|on|static)?\s*((?:(?:Gi|Te|Fo|Twe|Hu|Fa|ge|xe|GigabitEthernet|TenGigabitEthernet|FortyGigabitEthernet|Ethernet)\S+\([^)]*\)\s*)+)", line, re.I)
        if m:
            parent, members = m.groups()
            parsed = re.findall(r"((?:Gi|Te|Fo|Twe|Hu|Fa|ge|xe|GigabitEthernet|TenGigabitEthernet|FortyGigabitEthernet|Ethernet)\S+?)\([^)]*\)", members, re.I)
            if parsed: result[parent] = parsed
    return result



def parse_snr_running_config(value, interfaces=None):
    """Enrich SNR interface facts from read-only `show running-config` output.

    Interface status/type stay sourced from `show interface brief`; this parser adds
    explicitly configured descriptions, interface IPs and L2 VLAN mode details.
    It never infers an address prefix or VLAN membership not present in the config.
    """
    text = _text(value)
    result = {name: dict(data) for name, data in (interfaces or {}).items()}
    current_name = None
    current_lines = []

    def flush():
        if not current_name:
            return
        name = current_name
        data = result.setdefault(name, {
            "operstatus": "unknown", "type": _iface_type(name), "description": ""
        })
        data.setdefault("description", "")
        data.setdefault("ip_addresses", [])
        data.setdefault("tagged_vlans", [])
        data.setdefault("untagged_vlans", [])
        data.setdefault("allowed_vlans", [])
        for raw_line in current_lines:
            line = raw_line.strip()
            m = re.match(r"^description\s+(.+?)\s*$", line, re.I)
            if m:
                data["description"] = m.group(1).strip()
                continue
            # SNR eNOS config may show CIDR notation or address + dotted mask.
            m = re.match(r"^ip address\s+(\d{1,3}(?:\.\d{1,3}){3})(?:/(\d{1,2})|(\s+\d{1,3}(?:\.\d{1,3}){3}))?\s*$", line, re.I)
            if m:
                address, prefix, mask = m.groups()
                cidr = f"{address}/{prefix}" if prefix else address
                if mask:
                    try:
                        import ipaddress
                        cidr = str(ipaddress.ip_interface(f"{address}/{mask}"))
                    except ValueError:
                        # Keep the address visible, but do not invent a prefix.
                        cidr = address
                if cidr not in data["ip_addresses"]:
                    data["ip_addresses"].append(cidr)
                continue
            m = re.match(r"^switchport\s+mode\s+(access|trunk|hybrid)\s*$", line, re.I)
            if m:
                data["mode"] = m.group(1).lower()
                continue
            m = re.match(r"^switchport\s+(?:hybrid|trunk)\s+native vlan\s+(\d+)\s*$", line, re.I)
            if m:
                vid = int(m.group(1))
                data["native_vlan"] = vid
                if data.get("mode") == "trunk" and vid not in data["untagged_vlans"]:
                    data["untagged_vlans"].append(vid)
                continue
            m = re.match(r"^switchport\s+hybrid\s+allowed vlan\s+(\d+)\s+(tag|untag)\s*$", line, re.I)
            if m:
                vid, tag_mode = int(m.group(1)), m.group(2).lower()
                key = "tagged_vlans" if tag_mode == "tag" else "untagged_vlans"
                if vid not in data[key]: data[key].append(vid)
                if vid not in data["allowed_vlans"]: data["allowed_vlans"].append(vid)
                continue
            m = re.match(r"^switchport\s+trunk\s+allowed vlan\s+(.+?)\s*$", line, re.I)
            if m:
                value = m.group(1).strip()
                vids = []
                for part in value.split(','):
                    part = part.strip()
                    if re.fullmatch(r"\d+", part): vids.append(int(part))
                    elif re.fullmatch(r"\d+\s*-\s*\d+", part):
                        a, b = map(int, re.split(r"\s*-\s*", part))
                        if b >= a and b-a <= 4094: vids.extend(range(a, b+1))
                for vid in vids:
                    if vid not in data["allowed_vlans"]: data["allowed_vlans"].append(vid)
                continue
            m = re.match(r"^switchport\s+trunk\s+native vlan\s+(\d+)\s*$", line, re.I)
            if m:
                vid = int(m.group(1))
                data["native_vlan"] = vid
                if vid not in data["untagged_vlans"]: data["untagged_vlans"].append(vid)

    for line in text.splitlines():
        m = re.match(r"^\s*interface\s+(\S+)\s*$", line, re.I)
        if m:
            flush()
            current_name = m.group(1)
            current_lines = []
        elif current_name:
            if re.match(r"^\s*end\s*$", line, re.I):
                flush(); current_name = None; current_lines = []
            elif line.strip() == "!":
                flush(); current_name = None; current_lines = []
            else:
                current_lines.append(line)
    flush()
    # For SNR trunk ports, configured allowed VLANs are tagged except the
    # explicitly configured native VLAN, which is untagged.
    for data in result.values():
        if str(data.get("mode", "")).lower() == "trunk":
            native = data.get("native_vlan")
            if native is not None and native not in data.setdefault("untagged_vlans", []):
                data["untagged_vlans"].append(native)
            for vid in data.get("allowed_vlans", []):
                if vid != native and vid not in data.setdefault("tagged_vlans", []):
                    data["tagged_vlans"].append(vid)
        for key in ("tagged_vlans", "untagged_vlans", "allowed_vlans"):
            if key in data: data[key] = sorted(set(data[key]))
    return result

def parse_snr_lag_members(value):
    text = _text(value)
    # SNR eNOS uses Cisco-like etherchannel output; normalize its abbreviated interface names.
    return parse_cisco_lag_members(text)


def parse_huawei_lldp(value):
    """Parse Huawei VRP table output and USG expanded per-interface LLDP output."""
    text = _text(value)
    result = []
    # Huawei VRP switch `display lldp neighbor brief` table:
    # Local Intf  Neighbor Dev  Neighbor Intf  Exptime(s)
    for line in text.splitlines():
        m = re.match(r"^\s*((?:GE|XGE|GigabitEthernet|XGigabitEthernet|100GE|40GE)\S*)\s+(\S+)\s+(\S+)\s+\d+\s*$", line, re.I)
        if not m:
            continue
        local, neighbor, remote = m.groups()
        if local.lower() in {"local", "interface"} or neighbor.lower() in {"neighbor", "dev"}:
            continue
        item = {"local_interface": local}
        if neighbor != "-":
            item["neighbor_device"] = neighbor
        if re.fullmatch(r"(?:[0-9a-f]{4}-){2}[0-9a-f]{4}", remote, re.I):
            item["chassis_id"] = remote
        elif remote != "-":
            item["neighbor_interface"] = remote
        result.append(item)

    # USG output is expanded per local interface and may contain the firmware's
    # spelling `ChasssisId` (one extra 's'). Preserve observed IDs/capabilities;
    # never infer a remote device name from a MAC address.
    current_local = ""
    current = {}

    def flush():
        if not current_local:
            return
        if current.get("neighbor_interface") and (current.get("chassis_id") or current.get("neighbor_device")):
            item = {"local_interface": current_local, **current}
            result.append(item)

    for line in text.splitlines():
        m = re.match(r"^(?:Interface\s+)?(\S+)\s+has\s+\d+\s+neighbor(?:s|\(s\))\s*:", line, re.I)
        if m:
            flush()
            current_local = m.group(1)
            current = {}
            continue
        if re.match(r"^\s*Neighbor\s+\d+\s*:", line, re.I):
            flush()
            current = {}
            continue
        m = re.match(r"^\s*(?:System\s+name|SysName)\s*:\s*(.+?)\s*$", line, re.I)
        if m:
            current["neighbor_device"] = m.group(1).strip()
            continue
        m = re.match(r"^\s*(?:Port\s*ID|PortId)\s*:\s*(.+?)\s*$", line, re.I)
        if m:
            current["neighbor_interface"] = m.group(1).strip()
            continue
        m = re.match(r"^\s*(?:Chass+is\s*ID|Chass+isId)\s*:\s*(.+?)\s*$", line, re.I)
        if m:
            current["chassis_id"] = m.group(1).strip()
            continue
        m = re.match(r"^\s*ChassisIdSubtype\s*:\s*(.+?)\s*$", line, re.I)
        if m:
            current["chassis_id_subtype"] = m.group(1).strip()
            continue
        m = re.match(r"^\s*PortIdSubtype\s*:\s*(.+?)\s*$", line, re.I)
        if m:
            current["port_id_subtype"] = m.group(1).strip()
            continue
        m = re.match(r"^\s*SysCapEnabled\s*:\s*(.+?)\s*$", line, re.I)
        if m and m.group(1).strip():
            current.setdefault("system_capabilities", []).append(m.group(1).strip())
            continue
        m = re.match(r"^\s*SysCapSupported\s*:\s*(.+?)\s*$", line, re.I)
        if m and m.group(1).strip():
            current.setdefault("supported_capabilities", []).append(m.group(1).strip())
            continue
        # Eltex-style one-row LLDP output, also accepted by this shared parser.
        m = re.match(r"^\s*((?:te|gi|fa|eth|po|port-channel|GigabitEthernet|XGigabitEthernet|GE|XGE)\S+)\s+(\S+)\s+((?:te|gi|fa|eth|po|port-channel|GigabitEthernet|XGigabitEthernet|GE|XGE)\S+)\b", line, re.I)
        if m:
            result.append({"local_interface": m.group(1), "neighbor_device": m.group(2), "neighbor_interface": m.group(3)})
    flush()

    # Expanded output can be parsed by both the table and detail paths on some
    # firmware versions; de-duplicate without collapsing distinct physical ports.
    unique = []
    seen = set()
    for item in result:
        key = (item.get("local_interface", "").casefold(), item.get("chassis_id", "").casefold(),
               item.get("neighbor_device", "").casefold(), item.get("neighbor_interface", "").casefold())
        if key not in seen:
            seen.add(key)
            unique.append(item)
    return unique


class FilterModule:
    def filters(self):
        return {
            "parse_huawei_version": parse_huawei_version,
            "parse_huawei_device_model": parse_huawei_device_model,
            "parse_huawei_hostname": parse_huawei_hostname,
            "build_huawei_usg6670_report": build_huawei_usg6670_report,
            "parse_huawei_interfaces": parse_huawei_interfaces,
            "parse_huawei_ip_interface_brief": parse_huawei_ip_interface_brief,
            "parse_huawei_lag_members": parse_huawei_lag_members,
            "parse_huawei_running_config": parse_huawei_running_config,
            "parse_huawei_vlans": parse_huawei_vlans,
            "parse_eltex_esr_version": parse_eltex_esr_version,
            "parse_eltex_esr_system": parse_eltex_esr_system,
            "parse_eltex_esr_interfaces": parse_eltex_esr_interfaces,
            "parse_eltex_esr_descriptions": parse_eltex_esr_descriptions,
            "parse_eltex_esr_ip_interfaces": parse_eltex_esr_ip_interfaces,
            "parse_eltex_esr_vlans": parse_eltex_esr_vlans,
            "parse_eltex_esr_vrrp": parse_eltex_esr_vrrp,
            "parse_eltex_esr_routes": parse_eltex_esr_routes,
            "parse_eltex_esr_failover": parse_eltex_esr_failover,
            "parse_eltex_version": parse_eltex_version,
            "parse_eltex_system": parse_eltex_system,
            "parse_eltex_interfaces": parse_eltex_interfaces,
            "parse_eltex_inventory": parse_eltex_inventory,
            "parse_eltex_interface_descriptions": parse_eltex_interface_descriptions,
            "parse_eltex_lag_members": parse_eltex_lag_members,
            "parse_eltex_lag_states": parse_eltex_lag_states,
            "apply_eltex_lag_states": apply_eltex_lag_states,
            "parse_eltex_vlans": parse_eltex_vlans,
            "validate_eltex_vlan_memberships": validate_eltex_vlan_memberships,
            "filter_eltex_configured_port_channels": filter_eltex_configured_port_channels,
            "filter_eltex_vlan_port_channels": filter_eltex_vlan_port_channels,
            "parse_eltex_lldp": parse_eltex_lldp,
            "parse_cisco_version": parse_cisco_version,
            "parse_cisco_inventory": parse_cisco_inventory,
            "parse_cisco_interfaces": parse_cisco_interfaces,
            "parse_cisco_interface_descriptions": parse_cisco_interface_descriptions,
            "parse_cisco_lag_members": parse_cisco_lag_members,
            "parse_cisco_lldp": parse_cisco_lldp,
            "parse_snr_version": parse_snr_version,
            "parse_snr_interfaces": parse_snr_interfaces,
            "parse_snr_running_config": parse_snr_running_config,
            "parse_snr_vlans": parse_snr_vlans,
            "parse_snr_lag_members": parse_snr_lag_members,
            "parse_vlans": parse_vlans,
            "parse_huawei_lldp": parse_huawei_lldp,
        }
