#!/usr/bin/env python3
"""Run one read-only command on an Eltex ESR CLI over an interactive SSH shell.

This deliberately bypasses Ansible network_cli's IOS terminal/prompt handling,
which is not a suitable platform match for ESR. It does not enter configuration
mode and accepts exactly one command per invocation.
"""
from __future__ import annotations

import os
import re
import sys
import time


ANSI_RE = re.compile(r"\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])")


def clean(text: str) -> str:
    return ANSI_RE.sub("", text).replace("\r\n", "\n").replace("\r", "\n")


def receive_initial_prompt(channel: paramiko.Channel, timeout: float = 20.0) -> tuple[str, str]:
    """Read login/banner output until quiet, then identify the final prompt line."""
    data = bytearray()
    deadline = time.monotonic() + timeout
    last_data_at: float | None = None
    while time.monotonic() < deadline:
        if channel.recv_ready():
            chunk = channel.recv(65535)
            if not chunk:
                break
            data.extend(chunk)
            last_data_at = time.monotonic()
            continue
        if data and last_data_at is not None and time.monotonic() - last_data_at >= 0.6:
            text = clean(data.decode("utf-8", errors="replace"))
            lines = [line.strip() for line in text.split("\n") if line.strip()]
            if lines and re.search(r"[>#]\s*$", lines[-1]):
                return text, lines[-1]
        time.sleep(0.05)
    text = clean(data.decode("utf-8", errors="replace"))
    lines = [line.strip() for line in text.split("\n") if line.strip()]
    if lines and re.search(r"[>#]\s*$", lines[-1]):
        return text, lines[-1]
    raise RuntimeError("Could not identify the ESR CLI prompt after SSH login; check that the account opens the interactive CLI.")


def run_command(channel: paramiko.Channel, prompt: str, command: str, timeout: float) -> str:
    channel.send(command + "\n")
    data = bytearray()
    deadline = time.monotonic() + timeout
    prompt_re = re.compile(r"(?:^|\n)" + re.escape(prompt) + r"[ \t]*$", re.MULTILINE)
    while time.monotonic() < deadline:
        if channel.recv_ready():
            chunk = channel.recv(65535)
            if not chunk:
                break
            data.extend(chunk)
            normalized = clean(data.decode("utf-8", errors="replace")).strip()
            if prompt_re.search(normalized):
                lines = normalized.split("\n")
                # Drop the command echo and the final CLI prompt, preserving all
                # device output between them for the existing parsers.
                if lines and lines[0].strip() == command.strip():
                    lines = lines[1:]
                while lines and not lines[-1].strip():
                    lines.pop()
                if lines and lines[-1].strip() == prompt.strip():
                    lines.pop()
                return "\n".join(lines).strip() + ("\n" if lines else "")
            continue
        time.sleep(0.05)
    raise TimeoutError(f"Timed out waiting for the ESR CLI prompt after command: {command}")


def main() -> int:
    if len(sys.argv) != 2 or not sys.argv[1].strip():
        print("Usage: eltex_esr_cli.py COMMAND", file=sys.stderr)
        return 2
    command = sys.argv[1].strip()
    host = os.environ.get("ESR_SSH_HOST", "").strip()
    username = os.environ.get("ESR_SSH_USER", "")
    password = os.environ.get("ESR_SSH_PASSWORD", "")
    if not host or not username:
        print("Missing ESR_SSH_HOST or ESR_SSH_USER environment variable.", file=sys.stderr)
        return 2
    try:
        port = int(os.environ.get("ESR_SSH_PORT", "22"))
        connect_timeout = float(os.environ.get("ESR_SSH_CONNECT_TIMEOUT", "15"))
        command_timeout = float(os.environ.get("ESR_SSH_COMMAND_TIMEOUT", "60"))
        import paramiko
        client = paramiko.SSHClient()
        client.load_system_host_keys()
        # Respect the host-key confirmation performed by the local NetBox Sync UI.
        client.set_missing_host_key_policy(paramiko.RejectPolicy())
        client.connect(
            hostname=host,
            port=port,
            username=username,
            password=password or None,
            timeout=connect_timeout,
            banner_timeout=connect_timeout,
            auth_timeout=connect_timeout,
            allow_agent=not bool(password),
            look_for_keys=not bool(password),
        )
        try:
            channel = client.invoke_shell(term="vt100", width=240, height=1000)
            try:
                _, prompt = receive_initial_prompt(channel, timeout=connect_timeout)
                output = run_command(channel, prompt, command, command_timeout)
                sys.stdout.write(output)
                return 0
            finally:
                channel.close()
        finally:
            client.close()
    except Exception as exc:  # noqa: BLE001 - surface concise diagnostics to Ansible
        print(f"ESR SSH CLI collection failed: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
