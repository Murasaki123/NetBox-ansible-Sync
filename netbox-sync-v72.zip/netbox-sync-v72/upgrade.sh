#!/usr/bin/env bash
# Safe in-place updater for the Docker Compose deployment.
# Drop exactly one release ZIP into /opt/netbox-sync-updates and run this script.
set -Eeuo pipefail

APP_DIR="${APP_DIR:-/opt/netbox-sync}"
UPDATE_DIR="${UPDATE_DIR:-/opt/netbox-sync-updates}"
BACKUP_DIR="${BACKUP_DIR:-/opt/netbox-sync-backups}"
PROCESSED_DIR="$UPDATE_DIR/processed"
TIMESTAMP="$(date +%Y%m%d-%H%M%S)"
STAGE=""
BACKUP=""

log() { printf '[netbox-sync-upgrade] %s\n' "$*"; }
die() { log "ОШИБКА: $*" >&2; exit 1; }

if [[ "$(id -u)" -ne 0 ]]; then
  die "Запустите от root: sudo $APP_DIR/upgrade.sh"
fi
command -v docker >/dev/null 2>&1 || die "docker не найден."
command -v unzip >/dev/null 2>&1 || die "unzip не найден. Установите unzip и повторите."
command -v rsync >/dev/null 2>&1 || die "rsync не найден. Установите rsync и повторите."
[[ -f "$APP_DIR/docker-compose.yml" && -f "$APP_DIR/webui/app.py" ]] || die "Не найдена текущая установка в $APP_DIR."
[[ -d "$UPDATE_DIR" ]] || die "Папка обновлений не найдена: $UPDATE_DIR"

shopt -s nullglob nocaseglob
archives=("$UPDATE_DIR"/*.zip)
shopt -u nullglob nocaseglob
((${#archives[@]} == 1)) || {
  if ((${#archives[@]} == 0)); then die "Положите один ZIP-архив релиза в $UPDATE_DIR"; fi
  die "В $UPDATE_DIR найдено несколько ZIP-архивов. Оставьте один архив; обработанные архивы перемещаются в processed/."
}
ARCHIVE="${archives[0]}"

mkdir -p "$BACKUP_DIR" "$PROCESSED_DIR"
chmod 700 "$BACKUP_DIR" "$PROCESSED_DIR"
STAGE="$(mktemp -d /opt/netbox-sync-upgrade.XXXXXX)"
cleanup() { [[ -z "$STAGE" || ! -d "$STAGE" ]] || rm -rf -- "$STAGE"; }
trap cleanup EXIT

log "Проверяю архив: $(basename "$ARCHIVE")"
unzip -tq "$ARCHIVE" >/dev/null || die "ZIP повреждён. Текущая установка не изменена."
mapfile -t roots < <(unzip -Z1 "$ARCHIVE" | awk -F/ 'NF && $1 != "" {print $1}' | sort -u)
((${#roots[@]} == 1)) || die "В архиве должна быть одна корневая папка проекта."
ROOT_NAME="${roots[0]}"
unzip -q "$ARCHIVE" -d "$STAGE"
NEW_DIR="$STAGE/$ROOT_NAME"
[[ -f "$NEW_DIR/docker-compose.yml" && -f "$NEW_DIR/webui/app.py" && -f "$NEW_DIR/Dockerfile" ]] || die "В архиве не найдена ожидаемая структура NetBox Sync."

# Prevent accidental updates with a release archive older than the installed source.
if [[ -f "$APP_DIR/RELEASE_VERSION" && -f "$NEW_DIR/RELEASE_VERSION" ]]; then
  current="$(cat "$APP_DIR/RELEASE_VERSION")"
  incoming="$(cat "$NEW_DIR/RELEASE_VERSION")"
  [[ "$current" != "$incoming" ]] || die "Версия $incoming уже установлена."
fi

BACKUP="$BACKUP_DIR/netbox-sync-before-$TIMESTAMP.tar.gz"
log "Останавливаю контейнер перед резервным копированием."
if ! docker compose --project-directory "$APP_DIR" -f "$APP_DIR/docker-compose.yml" stop; then
  die "Не удалось штатно остановить контейнер. Установка не обновлялась."
fi
log "Создаю полную резервную копию: $BACKUP"
if ! tar -czf "$BACKUP" -C "$(dirname "$APP_DIR")" "$(basename "$APP_DIR")"; then
  docker compose --project-directory "$APP_DIR" -f "$APP_DIR/docker-compose.yml" up -d || true
  die "Не удалось создать резервную копию. Обновление отменено."
fi
chmod 600 "$BACKUP"

restore_backup() {
  log "Выполняю откат из резервной копии…" >&2
  local restore_dir
  restore_dir="$(mktemp -d /opt/netbox-sync-restore.XXXXXX)"
  if tar -xzf "$BACKUP" -C "$restore_dir"; then
    local restored="$restore_dir/$(basename "$APP_DIR")"
    if [[ -d "$restored" ]]; then
      rsync -a --delete "$restored/" "$APP_DIR/"
      rm -rf -- "$restore_dir"
      docker compose --project-directory "$APP_DIR" -f "$APP_DIR/docker-compose.yml" up -d || true
      log "Откат выполнен. Резервная копия сохранена: $BACKUP" >&2
      return 0
    fi
  fi
  log "КРИТИЧЕСКАЯ ОШИБКА: автоматический откат не удался. Резервная копия: $BACKUP" >&2
  return 1
}

log "Обновляю файлы приложения, сохраняя данные и локальные настройки."
# Keep the persistent DB/secrets, TLS, operator environment and local inventory config.
# group_vars/all.yml may contain site-specific settings; vendor task files still update.
if ! rsync -a --delete \
  --exclude='/local_data/***' \
  --exclude='/.env' --exclude='/.env.*' \
  --exclude='/.venv/***' \
  --exclude='/inventory/***' \
  --exclude='/group_vars/all.yml' \
  --exclude='/host_vars/***' \
  --exclude='/deploy/tls/***' \
  --exclude='/deploy/ca-private/***' \
  --exclude='/vault.yml' --exclude='/.vault_pass' --exclude='/deploy/vault_pass' \
  "$NEW_DIR/" "$APP_DIR/"; then
  restore_backup || true
  die "Не удалось обновить файлы. Выполнена попытка отката."
fi

# Make the selected release explicit for future upgrade checks.
if [[ -f "$NEW_DIR/RELEASE_VERSION" ]]; then
  cp -f "$NEW_DIR/RELEASE_VERSION" "$APP_DIR/RELEASE_VERSION"
fi

log "Проверяю конфигурацию Compose и собираю новый образ."
if ! docker compose --project-directory "$APP_DIR" -f "$APP_DIR/docker-compose.yml" config -q || \
   ! docker compose --project-directory "$APP_DIR" -f "$APP_DIR/docker-compose.yml" build; then
  restore_backup || true
  die "Проверка/сборка не прошла. Выполнена попытка отката."
fi

log "Запускаю обновлённую версию."
if ! docker compose --project-directory "$APP_DIR" -f "$APP_DIR/docker-compose.yml" up -d --force-recreate; then
  restore_backup || true
  die "Контейнер не запустился. Выполнена попытка отката."
fi
sleep 5
state="$(docker inspect --format '{{.State.Status}}' netbox-sync-web 2>/dev/null || true)"
if [[ "$state" != "running" ]]; then
  docker compose --project-directory "$APP_DIR" -f "$APP_DIR/docker-compose.yml" logs --tail=100 || true
  restore_backup || true
  die "Контейнер после обновления имеет состояние '$state'. Выполнена попытка отката."
fi

mv -- "$ARCHIVE" "$PROCESSED_DIR/$(basename "$ARCHIVE")"
log "Обновление завершено. Контейнер netbox-sync-web работает."
log "Резервная копия: $BACKUP"
log "Архив перемещён в: $PROCESSED_DIR/$(basename "$ARCHIVE")"
docker compose --project-directory "$APP_DIR" -f "$APP_DIR/docker-compose.yml" ps
